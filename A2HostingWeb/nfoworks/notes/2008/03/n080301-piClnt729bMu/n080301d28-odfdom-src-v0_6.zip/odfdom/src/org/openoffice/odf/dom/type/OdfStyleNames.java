/************************************************************************
 *
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS FILE HEADER.
 * 
 * Copyright 2008 by Sun Microsystems, Inc.
 *
 * OpenOffice.org - a multi-platform office productivity suite
 *
 * $RCSfile: $
 * $Revision: $
 *
 *
 * OpenOffice.org is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License version 3
 * only, as published by the Free Software Foundation.
 *
 * OpenOffice.org is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License version 3 for more details
 * (a copy is included in the LICENSE file that accompanied this code).
 *
 * You should have received a copy of the GNU Lesser General Public License
 * version 3 along with OpenOffice.org.  If not, see
 * <http://www.openoffice.org/license.html>
 * for a copy of the LGPLv3 License.
 *
 ************************************************************************/
package org.openoffice.odf.dom.type;

import java.util.Arrays;
import java.util.Iterator;
import java.util.List;
        
public class OdfStyleNames {
    
    public static String toString( List<String> _aStyleNames )
    {
        StringBuffer aRet = new StringBuffer();
        Iterator<String> aIter = _aStyleNames.iterator();
        while( aIter.hasNext() )
        {
            if( aRet.length() > 0 )
                aRet.append( ' ' );
            String aStyleName = OdfStyleName.toString(aIter.next());
            aRet.append( aStyleName );
        }
        return aRet.toString();
    }

    public static List<String> valueOf( String _aStringValue )
    {
        if( _aStringValue.length()==0 )
            return null;
        
        List<String> aRet = Arrays.asList( _aStringValue.split( " " ) );
        
        return aRet;
    }
}
