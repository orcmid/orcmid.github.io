/************************************************************************
 *
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS FILE HEADER.
 * 
 * Copyright 2008 by Sun Microsystems, Inc.
 *
 * OpenOffice.org - a multi-platform office productivity suite
 *
 * $RCSfile: $
 * $Revision: $
 *
 * This file is part of OpenOffice.org.
 *
 * OpenOffice.org is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License version 3
 * only, as published by the Free Software Foundation.
 *
 * OpenOffice.org is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License version 3 for more details
 * (a copy is included in the LICENSE file that accompanied this code).
 *
 * You should have received a copy of the GNU Lesser General Public License
 * version 3 along with OpenOffice.org.  If not, see
 * <http://www.openoffice.org/license.html>
 * for a copy of the LGPLv3 License.
 *
 ************************************************************************/
// !!! GENERATED SOURCE CODE !!!
package org.openoffice.odf.dom.style.props;

import org.openoffice.odf.dom.OdfName;
import org.openoffice.odf.dom.OdfNamespace;

public interface OdfChartProperties {
    public final static OdfStyleProperty ConnectBars = 
        OdfStyleProperty.get(OdfStylePropertiesSet.ChartProperties, OdfName.get(OdfNamespace.CHART, "connect-bars"));
    public final static OdfStyleProperty DataLabelNumber = 
        OdfStyleProperty.get(OdfStylePropertiesSet.ChartProperties, OdfName.get(OdfNamespace.CHART, "data-label-number"));
    public final static OdfStyleProperty DataLabelSymbol = 
        OdfStyleProperty.get(OdfStylePropertiesSet.ChartProperties, OdfName.get(OdfNamespace.CHART, "data-label-symbol"));
    public final static OdfStyleProperty DataLabelText = 
        OdfStyleProperty.get(OdfStylePropertiesSet.ChartProperties, OdfName.get(OdfNamespace.CHART, "data-label-text"));
    public final static OdfStyleProperty Deep = 
        OdfStyleProperty.get(OdfStylePropertiesSet.ChartProperties, OdfName.get(OdfNamespace.CHART, "deep"));
    public final static OdfStyleProperty DisplayLabel = 
        OdfStyleProperty.get(OdfStylePropertiesSet.ChartProperties, OdfName.get(OdfNamespace.CHART, "display-label"));
    public final static OdfStyleProperty ErrorCategory = 
        OdfStyleProperty.get(OdfStylePropertiesSet.ChartProperties, OdfName.get(OdfNamespace.CHART, "error-category"));
    public final static OdfStyleProperty ErrorLowerIndicator = 
        OdfStyleProperty.get(OdfStylePropertiesSet.ChartProperties, OdfName.get(OdfNamespace.CHART, "error-lower-indicator"));
    public final static OdfStyleProperty ErrorLowerLimit = 
        OdfStyleProperty.get(OdfStylePropertiesSet.ChartProperties, OdfName.get(OdfNamespace.CHART, "error-lower-limit"));
    public final static OdfStyleProperty ErrorMargin = 
        OdfStyleProperty.get(OdfStylePropertiesSet.ChartProperties, OdfName.get(OdfNamespace.CHART, "error-margin"));
    public final static OdfStyleProperty ErrorPercentage = 
        OdfStyleProperty.get(OdfStylePropertiesSet.ChartProperties, OdfName.get(OdfNamespace.CHART, "error-percentage"));
    public final static OdfStyleProperty ErrorUpperIndicator = 
        OdfStyleProperty.get(OdfStylePropertiesSet.ChartProperties, OdfName.get(OdfNamespace.CHART, "error-upper-indicator"));
    public final static OdfStyleProperty ErrorUpperLimit = 
        OdfStyleProperty.get(OdfStylePropertiesSet.ChartProperties, OdfName.get(OdfNamespace.CHART, "error-upper-limit"));
    public final static OdfStyleProperty GapWidth = 
        OdfStyleProperty.get(OdfStylePropertiesSet.ChartProperties, OdfName.get(OdfNamespace.CHART, "gap-width"));
    public final static OdfStyleProperty Interpolation = 
        OdfStyleProperty.get(OdfStylePropertiesSet.ChartProperties, OdfName.get(OdfNamespace.CHART, "interpolation"));
    public final static OdfStyleProperty IntervalMajor = 
        OdfStyleProperty.get(OdfStylePropertiesSet.ChartProperties, OdfName.get(OdfNamespace.CHART, "interval-major"));
    public final static OdfStyleProperty IntervalMinorDivisor = 
        OdfStyleProperty.get(OdfStylePropertiesSet.ChartProperties, OdfName.get(OdfNamespace.CHART, "interval-minor-divisor"));
    public final static OdfStyleProperty JapaneseCandleStick = 
        OdfStyleProperty.get(OdfStylePropertiesSet.ChartProperties, OdfName.get(OdfNamespace.CHART, "japanese-candle-stick"));
    public final static OdfStyleProperty LabelArrangement = 
        OdfStyleProperty.get(OdfStylePropertiesSet.ChartProperties, OdfName.get(OdfNamespace.CHART, "label-arrangement"));
    public final static OdfStyleProperty Lines = 
        OdfStyleProperty.get(OdfStylePropertiesSet.ChartProperties, OdfName.get(OdfNamespace.CHART, "lines"));
    public final static OdfStyleProperty LinkDataStyleToSource = 
        OdfStyleProperty.get(OdfStylePropertiesSet.ChartProperties, OdfName.get(OdfNamespace.CHART, "link-data-style-to-source"));
    public final static OdfStyleProperty Logarithmic = 
        OdfStyleProperty.get(OdfStylePropertiesSet.ChartProperties, OdfName.get(OdfNamespace.CHART, "logarithmic"));
    public final static OdfStyleProperty Maximum = 
        OdfStyleProperty.get(OdfStylePropertiesSet.ChartProperties, OdfName.get(OdfNamespace.CHART, "maximum"));
    public final static OdfStyleProperty MeanValue = 
        OdfStyleProperty.get(OdfStylePropertiesSet.ChartProperties, OdfName.get(OdfNamespace.CHART, "mean-value"));
    public final static OdfStyleProperty Minimum = 
        OdfStyleProperty.get(OdfStylePropertiesSet.ChartProperties, OdfName.get(OdfNamespace.CHART, "minimum"));
    public final static OdfStyleProperty Origin = 
        OdfStyleProperty.get(OdfStylePropertiesSet.ChartProperties, OdfName.get(OdfNamespace.CHART, "origin"));
    public final static OdfStyleProperty Overlap = 
        OdfStyleProperty.get(OdfStylePropertiesSet.ChartProperties, OdfName.get(OdfNamespace.CHART, "overlap"));
    public final static OdfStyleProperty Percentage = 
        OdfStyleProperty.get(OdfStylePropertiesSet.ChartProperties, OdfName.get(OdfNamespace.CHART, "percentage"));
    public final static OdfStyleProperty PieOffset = 
        OdfStyleProperty.get(OdfStylePropertiesSet.ChartProperties, OdfName.get(OdfNamespace.CHART, "pie-offset"));
    public final static OdfStyleProperty RegressionType = 
        OdfStyleProperty.get(OdfStylePropertiesSet.ChartProperties, OdfName.get(OdfNamespace.CHART, "regression-type"));
    public final static OdfStyleProperty ScaleText = 
        OdfStyleProperty.get(OdfStylePropertiesSet.ChartProperties, OdfName.get(OdfNamespace.CHART, "scale-text"));
    public final static OdfStyleProperty SeriesSource = 
        OdfStyleProperty.get(OdfStylePropertiesSet.ChartProperties, OdfName.get(OdfNamespace.CHART, "series-source"));
    public final static OdfStyleProperty SolidType = 
        OdfStyleProperty.get(OdfStylePropertiesSet.ChartProperties, OdfName.get(OdfNamespace.CHART, "solid-type"));
    public final static OdfStyleProperty SplineOrder = 
        OdfStyleProperty.get(OdfStylePropertiesSet.ChartProperties, OdfName.get(OdfNamespace.CHART, "spline-order"));
    public final static OdfStyleProperty SplineResolution = 
        OdfStyleProperty.get(OdfStylePropertiesSet.ChartProperties, OdfName.get(OdfNamespace.CHART, "spline-resolution"));
    public final static OdfStyleProperty Stacked = 
        OdfStyleProperty.get(OdfStylePropertiesSet.ChartProperties, OdfName.get(OdfNamespace.CHART, "stacked"));
    public final static OdfStyleProperty SymbolHeight = 
        OdfStyleProperty.get(OdfStylePropertiesSet.ChartProperties, OdfName.get(OdfNamespace.CHART, "symbol-height"));
    public final static OdfStyleProperty SymbolType = 
        OdfStyleProperty.get(OdfStylePropertiesSet.ChartProperties, OdfName.get(OdfNamespace.CHART, "symbol-type"));
    public final static OdfStyleProperty SymbolWidth = 
        OdfStyleProperty.get(OdfStylePropertiesSet.ChartProperties, OdfName.get(OdfNamespace.CHART, "symbol-width"));
    public final static OdfStyleProperty TextOverlap = 
        OdfStyleProperty.get(OdfStylePropertiesSet.ChartProperties, OdfName.get(OdfNamespace.CHART, "text-overlap"));
    public final static OdfStyleProperty ThreeDimensional = 
        OdfStyleProperty.get(OdfStylePropertiesSet.ChartProperties, OdfName.get(OdfNamespace.CHART, "three-dimensional"));
    public final static OdfStyleProperty TickMarksMajorInner = 
        OdfStyleProperty.get(OdfStylePropertiesSet.ChartProperties, OdfName.get(OdfNamespace.CHART, "tick-marks-major-inner"));
    public final static OdfStyleProperty TickMarksMajorOuter = 
        OdfStyleProperty.get(OdfStylePropertiesSet.ChartProperties, OdfName.get(OdfNamespace.CHART, "tick-marks-major-outer"));
    public final static OdfStyleProperty TickMarksMinorInner = 
        OdfStyleProperty.get(OdfStylePropertiesSet.ChartProperties, OdfName.get(OdfNamespace.CHART, "tick-marks-minor-inner"));
    public final static OdfStyleProperty TickMarksMinorOuter = 
        OdfStyleProperty.get(OdfStylePropertiesSet.ChartProperties, OdfName.get(OdfNamespace.CHART, "tick-marks-minor-outer"));
    public final static OdfStyleProperty Vertical = 
        OdfStyleProperty.get(OdfStylePropertiesSet.ChartProperties, OdfName.get(OdfNamespace.CHART, "vertical"));
    public final static OdfStyleProperty Visible = 
        OdfStyleProperty.get(OdfStylePropertiesSet.ChartProperties, OdfName.get(OdfNamespace.CHART, "visible"));
    public final static OdfStyleProperty Direction = 
        OdfStyleProperty.get(OdfStylePropertiesSet.ChartProperties, OdfName.get(OdfNamespace.STYLE, "direction"));
    public final static OdfStyleProperty RotationAngle = 
        OdfStyleProperty.get(OdfStylePropertiesSet.ChartProperties, OdfName.get(OdfNamespace.STYLE, "rotation-angle"));
    public final static OdfStyleProperty LineBreak = 
        OdfStyleProperty.get(OdfStylePropertiesSet.ChartProperties, OdfName.get(OdfNamespace.TEXT, "line-break"));
}
