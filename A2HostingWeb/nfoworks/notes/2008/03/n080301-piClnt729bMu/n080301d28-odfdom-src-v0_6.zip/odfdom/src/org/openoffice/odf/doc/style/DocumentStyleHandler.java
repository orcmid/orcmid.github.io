/************************************************************************
 *
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS FILE HEADER.
 * 
 * Copyright 2008 by Sun Microsystems, Inc.
 *
 * OpenOffice.org - a multi-platform office productivity suite
 *
 * $RCSfile: $
 * $Revision: $
 *
 * This file is part of OpenOffice.org.
 *
 * OpenOffice.org is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License version 3
 * only, as published by the Free Software Foundation.
 *
 * OpenOffice.org is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License version 3 for more details
 * (a copy is included in the LICENSE file that accompanied this code).
 *
 * You should have received a copy of the GNU Lesser General Public License
 * version 3 along with OpenOffice.org.  If not, see
 * <http://www.openoffice.org/license.html>
 * for a copy of the LGPLv3 License.
 *
 ************************************************************************/
package org.openoffice.odf.doc.style;

import java.util.Stack;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import org.openoffice.odf.dom.OdfName;
import org.openoffice.odf.dom.OdfNamespace;
import org.openoffice.odf.dom.style.OdfStyleCollection;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.xml.sax.Attributes;
import org.xml.sax.ContentHandler;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;

/**
 * Handler used by the SAX parser to parse the document styles.
 * Forwards style element handling to the StyleSectionHandler by pushing
 * this handler on the handler stack. The StyleSectionHandler will remove
 * itself from the stack when its work is done.
 * <p> Note: Until now only &lt;style:default-style&gt;, &lt;style:style&gt and 
 * &lt;office:font-face-decls&gt elements are made accessible. Further elements
 * are saved as unknown content. 
 * @see StyleSectionHandler
 */
public class DocumentStyleHandler extends DefaultHandler {

    private OdfStyleCollection m_styles;
    private OdfStyleCollection m_defaultStyles;
    private Document m_document;
    private Element m_unknown;
    private Stack<ContentHandler> m_handlerStack = new Stack<ContentHandler>();

    /**
     * Create a new document style handler. 
     * @param styles 
     * @param defaultStyles 
     */
    public DocumentStyleHandler(OdfStyleCollection styles, OdfStyleCollection defaultStyles) {
        m_styles = styles;
        m_defaultStyles = defaultStyles;
        try {
            DocumentBuilder db = DocumentBuilderFactory.newInstance().newDocumentBuilder();
            m_document = db.newDocument();
        } catch (ParserConfigurationException e) {
            throw new RuntimeException("cannot initialize style handling");
        }
    }

    /**
     * @inheritDoc
     */
    @Override
    public void startElement(String uri, String localName, String qName, Attributes atts) throws SAXException {
        if (!m_handlerStack.empty()) {
            // dispatch to handler...
            m_handlerStack.peek().startElement(uri, localName, qName, atts);
        } else if (localName.equals("document-styles") && uri.equals(OdfNamespace.OFFICE.getUri())) {
            // nothing to do for root element
            return;
        } else if (localName.equals("styles") && uri.equals(OdfNamespace.OFFICE.getUri())) {
            // start of style section
            m_handlerStack.push(new StyleSectionHandler(
                    OdfNamespace.OFFICE.getOdfName("styles"), m_handlerStack, m_styles, m_defaultStyles));
            return;
        } else {
            // other content, add/create unknown
            OdfName name = OdfName.get(uri, localName);
            Element e = m_document.createElementNS(uri, qName);
            for (int i = 0; i < atts.getLength(); i++) {
                e.setAttributeNS(atts.getURI(i), atts.getQName(i), atts.getValue(i));
            }
            if (m_unknown != null) {
                m_unknown.appendChild(e);
            }
            // make the new element the insertion point for subsequent unknown content
            m_unknown = e;
        }
    }

    /**
     * @inheritDoc
     */
    @Override
    public void endElement(String uri, String localName, String qName) throws SAXException {
        if (!m_handlerStack.empty()) {
            (m_handlerStack.peek()).endElement(uri, localName, qName);
        } else {
            // if we are handling an unkown element, move one node up
            if (m_unknown != null) {
                // topmost unkown element returns null
                Element tmpUnknown = m_unknown;
                m_unknown = (Element) m_unknown.getParentNode();
                // if the unkown element was closed, add it to the style
                if (m_unknown == null) {
                    if (tmpUnknown.getLocalName().equals("font-face-decls") &&
                            tmpUnknown.getNamespaceURI().equals(OdfNamespace.OFFICE.getUri())) {
                        m_styles.setFontFaceDecls(tmpUnknown);
                    } else {
                        m_styles.addUnknownContent(tmpUnknown);
                    }
                }
            }
        }
    }
}
