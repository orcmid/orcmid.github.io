/************************************************************************
 *
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS FILE HEADER.
 * 
 * Copyright 2008 by Sun Microsystems, Inc.
 *
 * OpenOffice.org - a multi-platform office productivity suite
 *
 * $RCSfile: $
 * $Revision: $
 *
 * This file is part of OpenOffice.org.
 *
 * OpenOffice.org is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License version 3
 * only, as published by the Free Software Foundation.
 *
 * OpenOffice.org is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License version 3 for more details
 * (a copy is included in the LICENSE file that accompanied this code).
 *
 * You should have received a copy of the GNU Lesser General Public License
 * version 3 along with OpenOffice.org.  If not, see
 * <http://www.openoffice.org/license.html>
 * for a copy of the LGPLv3 License.
 *
 ************************************************************************/
// !!! GENERATED SOURCE CODE !!!
package org.openoffice.odf.dom.style.props;

import org.openoffice.odf.dom.OdfName;
import org.openoffice.odf.dom.OdfNamespace;


public interface OdfTableCellProperties {
    public final static OdfStyleProperty BackgroundColor = 
        OdfStyleProperty.get(OdfStylePropertiesSet.TableCellProperties, OdfName.get(OdfNamespace.FO, "background-color"));
    public final static OdfStyleProperty Border = 
        OdfStyleProperty.get(OdfStylePropertiesSet.TableCellProperties, OdfName.get(OdfNamespace.FO, "border"));
    public final static OdfStyleProperty BorderBottom = 
        OdfStyleProperty.get(OdfStylePropertiesSet.TableCellProperties, OdfName.get(OdfNamespace.FO, "border-bottom"));
    public final static OdfStyleProperty BorderLeft = 
        OdfStyleProperty.get(OdfStylePropertiesSet.TableCellProperties, OdfName.get(OdfNamespace.FO, "border-left"));
    public final static OdfStyleProperty BorderRight = 
        OdfStyleProperty.get(OdfStylePropertiesSet.TableCellProperties, OdfName.get(OdfNamespace.FO, "border-right"));
    public final static OdfStyleProperty BorderTop = 
        OdfStyleProperty.get(OdfStylePropertiesSet.TableCellProperties, OdfName.get(OdfNamespace.FO, "border-top"));
    public final static OdfStyleProperty Padding = 
        OdfStyleProperty.get(OdfStylePropertiesSet.TableCellProperties, OdfName.get(OdfNamespace.FO, "padding"));
    public final static OdfStyleProperty PaddingBottom = 
        OdfStyleProperty.get(OdfStylePropertiesSet.TableCellProperties, OdfName.get(OdfNamespace.FO, "padding-bottom"));
    public final static OdfStyleProperty PaddingLeft = 
        OdfStyleProperty.get(OdfStylePropertiesSet.TableCellProperties, OdfName.get(OdfNamespace.FO, "padding-left"));
    public final static OdfStyleProperty PaddingRight = 
        OdfStyleProperty.get(OdfStylePropertiesSet.TableCellProperties, OdfName.get(OdfNamespace.FO, "padding-right"));
    public final static OdfStyleProperty PaddingTop = 
        OdfStyleProperty.get(OdfStylePropertiesSet.TableCellProperties, OdfName.get(OdfNamespace.FO, "padding-top"));
    public final static OdfStyleProperty WrapOption = 
        OdfStyleProperty.get(OdfStylePropertiesSet.TableCellProperties, OdfName.get(OdfNamespace.FO, "wrap-option"));
    public final static OdfStyleProperty BorderLineWidth = 
        OdfStyleProperty.get(OdfStylePropertiesSet.TableCellProperties, OdfName.get(OdfNamespace.STYLE, "border-line-width"));
    public final static OdfStyleProperty BorderLineWidthBottom = 
        OdfStyleProperty.get(OdfStylePropertiesSet.TableCellProperties, OdfName.get(OdfNamespace.STYLE, "border-line-width-bottom"));
    public final static OdfStyleProperty BorderLineWidthLeft = 
        OdfStyleProperty.get(OdfStylePropertiesSet.TableCellProperties, OdfName.get(OdfNamespace.STYLE, "border-line-width-left"));
    public final static OdfStyleProperty BorderLineWidthRight = 
        OdfStyleProperty.get(OdfStylePropertiesSet.TableCellProperties, OdfName.get(OdfNamespace.STYLE, "border-line-width-right"));
    public final static OdfStyleProperty BorderLineWidthTop = 
        OdfStyleProperty.get(OdfStylePropertiesSet.TableCellProperties, OdfName.get(OdfNamespace.STYLE, "border-line-width-top"));
    public final static OdfStyleProperty CellProtect = 
        OdfStyleProperty.get(OdfStylePropertiesSet.TableCellProperties, OdfName.get(OdfNamespace.STYLE, "cell-protect"));
    public final static OdfStyleProperty DecimalPlaces = 
        OdfStyleProperty.get(OdfStylePropertiesSet.TableCellProperties, OdfName.get(OdfNamespace.STYLE, "decimal-places"));
    public final static OdfStyleProperty DiagonalBlTr = 
        OdfStyleProperty.get(OdfStylePropertiesSet.TableCellProperties, OdfName.get(OdfNamespace.STYLE, "diagonal-bl-tr"));
    public final static OdfStyleProperty DiagonalBlTrWidths = 
        OdfStyleProperty.get(OdfStylePropertiesSet.TableCellProperties, OdfName.get(OdfNamespace.STYLE, "diagonal-bl-tr-widths"));
    public final static OdfStyleProperty DiagonalTlBr = 
        OdfStyleProperty.get(OdfStylePropertiesSet.TableCellProperties, OdfName.get(OdfNamespace.STYLE, "diagonal-tl-br"));
    public final static OdfStyleProperty DiagonalTlBrWidths = 
        OdfStyleProperty.get(OdfStylePropertiesSet.TableCellProperties, OdfName.get(OdfNamespace.STYLE, "diagonal-tl-br-widths"));
    public final static OdfStyleProperty Direction = 
        OdfStyleProperty.get(OdfStylePropertiesSet.TableCellProperties, OdfName.get(OdfNamespace.STYLE, "direction"));
    public final static OdfStyleProperty GlyphOrientationVertical = 
        OdfStyleProperty.get(OdfStylePropertiesSet.TableCellProperties, OdfName.get(OdfNamespace.STYLE, "glyph-orientation-vertical"));
    public final static OdfStyleProperty PrintContent = 
        OdfStyleProperty.get(OdfStylePropertiesSet.TableCellProperties, OdfName.get(OdfNamespace.STYLE, "print-content"));
    public final static OdfStyleProperty RepeatContent = 
        OdfStyleProperty.get(OdfStylePropertiesSet.TableCellProperties, OdfName.get(OdfNamespace.STYLE, "repeat-content"));
    public final static OdfStyleProperty RotationAlign = 
        OdfStyleProperty.get(OdfStylePropertiesSet.TableCellProperties, OdfName.get(OdfNamespace.STYLE, "rotation-align"));
    public final static OdfStyleProperty RotationAngle = 
        OdfStyleProperty.get(OdfStylePropertiesSet.TableCellProperties, OdfName.get(OdfNamespace.STYLE, "rotation-angle"));
    public final static OdfStyleProperty StyleShadow = 
        OdfStyleProperty.get(OdfStylePropertiesSet.TableCellProperties, OdfName.get(OdfNamespace.STYLE, "shadow"));
    public final static OdfStyleProperty ShrinkToFit = 
        OdfStyleProperty.get(OdfStylePropertiesSet.TableCellProperties, OdfName.get(OdfNamespace.STYLE, "shrink-to-fit"));
    public final static OdfStyleProperty TextAlignSource = 
        OdfStyleProperty.get(OdfStylePropertiesSet.TableCellProperties, OdfName.get(OdfNamespace.STYLE, "text-align-source"));
    public final static OdfStyleProperty VerticalAlign = 
        OdfStyleProperty.get(OdfStylePropertiesSet.TableCellProperties, OdfName.get(OdfNamespace.STYLE, "vertical-align"));
}
