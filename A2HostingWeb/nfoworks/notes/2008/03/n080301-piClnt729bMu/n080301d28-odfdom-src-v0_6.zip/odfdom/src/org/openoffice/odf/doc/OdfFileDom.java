/************************************************************************
 *
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS FILE HEADER.
 * 
 * Copyright 2008 by Sun Microsystems, Inc.
 *
 * OpenOffice.org - a multi-platform office productivity suite
 *
 * $RCSfile: $
 * $Revision: $
 *
 *
 * OpenOffice.org is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License version 3
 * only, as published by the Free Software Foundation.
 *
 * OpenOffice.org is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License version 3 for more details
 * (a copy is included in the LICENSE file that accompanied this code).
 *
 * You should have received a copy of the GNU Lesser General Public License
 * version 3 along with OpenOffice.org.  If not, see
 * <http://www.openoffice.org/license.html>
 * for a copy of the LGPLv3 License.
 *
 ************************************************************************/
package org.openoffice.odf.doc;

import java.lang.reflect.Field;
import org.apache.xerces.dom.DocumentImpl;
import org.openoffice.odf.doc.element.OdfElementFactory;
import org.openoffice.odf.dom.OdfName;
import org.openoffice.odf.dom.element.OdfElement;
import org.w3c.dom.DOMException;

public class OdfFileDom extends DocumentImpl {
    private String mPackagePath;
    private OdfDocument mOdfDocument;
    
    /**
     * Creates the DOM representation of an XML file of an Odf document.
     * 
     * @param odfDocument   the document the XML files belongs to
     * @param packagePath   the internal package path to the XML file
     */  
    OdfFileDom(OdfDocument odfDocument, String packagePath){
        mOdfDocument = odfDocument;        
        mPackagePath = packagePath;
    }
       
    public OdfDocument getOdfDocument(){
        return mOdfDocument;
    }    
    
    public String getPackagePath(){
        return mPackagePath;
    }
  
    @Override
    public OdfElement createElementNS(String nsuri, String qname) throws DOMException {
        return createElementNS(OdfName.get(nsuri, qname));
    }    
    
    public OdfElement createElementNS(OdfName name) throws DOMException {
        return OdfElementFactory.createOdfElement(this, name);
    }
    
    public <T extends OdfElement> T createOdfElement(Class<T> clazz) {
        try {
            Field fname = clazz.getField("ELEMENT_NAME");
            OdfName name = (OdfName) fname.get(null);
            return (T) createElementNS(name);
        } catch (Exception ex) {
            if (ex instanceof RuntimeException) {
                throw (RuntimeException) ex;
            }
            return null;
        }
    }    
    
    @Override
    public String toString(){
        return ((OdfElement) this.getDocumentElement()).toString();
    }    
}
