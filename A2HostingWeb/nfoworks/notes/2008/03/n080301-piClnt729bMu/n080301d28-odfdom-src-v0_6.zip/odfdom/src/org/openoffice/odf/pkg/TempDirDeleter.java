/************************************************************************
 *
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS FILE HEADER.
 * 
 * Copyright 2008 by Sun Microsystems, Inc.
 *
 * OpenOffice.org - a multi-platform office productivity suite
 *
 * $RCSfile: $
 * $Revision: $
 *
 *
 * OpenOffice.org is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License version 3
 * only, as published by the Free Software Foundation.
 *
 * OpenOffice.org is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License version 3 for more details
 * (a copy is included in the LICENSE file that accompanied this code).
 *
 * You should have received a copy of the GNU Lesser General Public License
 * version 3 along with OpenOffice.org.  If not, see
 * <http://www.openoffice.org/license.html>
 * for a copy of the LGPLv3 License.
 *
 ************************************************************************/
package org.openoffice.odf.pkg;
import java.io.File;
import java.util.ArrayList;
import java.util.Iterator;
    
class TempDirDeleter extends Thread {
    private static TempDirDeleter deleterThread=null;

    private ArrayList dirList = new ArrayList();

    static TempDirDeleter getInstance() {
        if ( deleterThread==null ) {
            deleterThread = new TempDirDeleter();
            Runtime.getRuntime().addShutdownHook(deleterThread);
        }
        return deleterThread;
    }
    
    synchronized void add(File dir) {
        dirList.add(dir);
    }

    synchronized void remove(File dir) {
        dirList.remove(dir);
    }

    public void run() {
        synchronized (this) {
            Iterator iterator = dirList.iterator();
            while (iterator.hasNext()) {
                File dir = (File)iterator.next();
                deleteDirectoryRecursive(dir);
                iterator.remove();
            }
            dirList.clear();
        }
    }
    
    private void deleteDirectoryRecursive(File dir) {
        if ( dir == null ) return;

        File[] fileArray = dir.listFiles();
        
        if (fileArray != null) {
            for (int i = 0; i < fileArray.length; i++) {
                if (fileArray[i].isDirectory())
                    deleteDirectoryRecursive(fileArray[i]);
                else
                    fileArray[i].delete();
            }
        }
        dir.delete();
        getInstance();
    }

    void deleteDirectory(File dir) {
        deleteDirectoryRecursive(dir);
        dirList.remove(dir);
    }
}
