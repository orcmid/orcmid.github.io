<?xml version="1.0" encoding="UTF-8"?>
<!--

  DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS FILE HEADER.
  
  Copyright 2008 by Sun Microsystems, Inc.
 
  OpenOffice.org - a multi-platform office productivity suite
 
  $RCSfile: $
 
  $Revision: $
 
  This file is part of OpenOffice.org.
 
  OpenOffice.org is free software: you can redistribute it and/or modify
  it under the terms of the GNU Lesser General Public License version 3
  only, as published by the Free Software Foundation.
 
  OpenOffice.org is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU Lesser General Public License version 3 for more details
  (a copy is included in the LICENSE file that accompanied this code).
 
  You should have received a copy of the GNU Lesser General Public License
  version 3 along with OpenOffice.org.  If not, see
  <http://www.openoffice.org/license.html>
  for a copy of the LGPLv3 License.
 
-->

<xsl:stylesheet xmlns:xsl="http://www.w3.org/1999/XSL/Transform" version="1.0"
                xmlns:rng="http://relaxng.org/ns/structure/1.0" 
>
                               
    <!-- Print local name of a namespaced name in Camel case. -->
    <xsl:template name="output-name">
        <xsl:param name="qname"/>
        <xsl:param name="start" select="true()"/>
        
        <!-- remove prefix from qname -->
        <xsl:variable name="name">
            <xsl:choose>
                <xsl:when test="$start"><xsl:value-of select="substring-after($qname,':')"/></xsl:when>
                <xsl:otherwise><xsl:value-of select="$qname"/></xsl:otherwise>
            </xsl:choose>
        </xsl:variable>
        
        <!-- if the local name is 'Class' then append prefix to avoid name clash with getClass -->
        <xsl:if test="$start and $name='class'">
            <xsl:variable name="prefix" select="substring-before($qname,':')"/>
            <xsl:value-of select="translate( substring($prefix, 1, 1), 'abcdefghijklmnopqrstuvwxyz', 'ABCDEFGHIJKLMNOPQRSTUVWXYZ')"/>
            <xsl:value-of select="substring($prefix,2)"/>
        </xsl:if>
            
        <xsl:value-of select="translate( substring($name, 1, 1), 'abcdefghijklmnopqrstuvwxyz', 'ABCDEFGHIJKLMNOPQRSTUVWXYZ')"/>
        <xsl:variable name="part" select="substring-before($name,'-')"/>
        <xsl:choose>
            <xsl:when test="string-length($part) > 0">
                <xsl:value-of select="substring($part,2)"/>
                <xsl:call-template name="output-name">
                    <xsl:with-param name="qname" select="substring-after($name, '-')"/>
                    <xsl:with-param name="start" select="false()"/>
                </xsl:call-template>
            </xsl:when>
            <xsl:otherwise>
                <xsl:value-of select="substring($name,2)"/>
            </xsl:otherwise>                
        </xsl:choose>
    </xsl:template>

    <!-- Output namespace prefix upper case -->
    <xsl:template name="output-namespace-prefix">
        <xsl:param name="qname"/>
        <xsl:value-of select="translate( substring-before($qname,':'), 'abcdefghijklmnopqrstuvwxyz', 'ABCDEFGHIJKLMNOPQRSTUVWXYZ')"/>
    </xsl:template>

    <!-- Output a constant value in upper case, '-' gets '_' -->
    <xsl:template name="output-constant-name">
        <xsl:param name="name"/>
        <xsl:value-of select="translate( $name, 'abcdefghijklmnopqrstuvwxyz-', 'ABCDEFGHIJKLMNOPQRSTUVWXYZ_')"/>
    </xsl:template>

    <!-- Output a qualified name non-qualified -->
    <xsl:template name="output-nq-name">
        <xsl:param name="name"/>
        <xsl:choose>
            <xsl:when test="contains( $name, '.' )">
                <xsl:call-template name="output-nq-name">
                    <xsl:with-param name="name" select="substring-after( $name, '.' )"/>
                </xsl:call-template>
            </xsl:when>
            <xsl:otherwise>
                <xsl:value-of select="$name"/>
            </xsl:otherwise>
        </xsl:choose>
    </xsl:template>

   <xsl:template name="last-index-of">
        <xsl:param name="string"/>
        <xsl:param name="char"/>
        <xsl:param name="pos" select="0"/>
        <xsl:choose>
            <xsl:when test="contains( $string, $char )">
                <xsl:call-template name="last-index-of">
                    <xsl:with-param name="string" select="substring-after( $string, $char )"/>
                    <xsl:with-param name="char" select="$char"/>
                    <xsl:with-param name="pos" select="$pos + string-length(substring-before($string,$char)) + 1"/>
                </xsl:call-template>
            </xsl:when>
            <xsl:otherwise>
                <xsl:value-of select="$pos"/>
            </xsl:otherwise>
        </xsl:choose>
    </xsl:template>

    <xsl:template name="output-filename">
        <xsl:param name="path"/>
        <xsl:variable name="pos">
            <xsl:call-template name="last-index-of">
                <xsl:with-param name="string" select="$path"/>
                <xsl:with-param name="char" select="'/'"/>
            </xsl:call-template>
        </xsl:variable>
        <xsl:value-of select="substring( $path, $pos + 1 )"/>
    </xsl:template>
    
    
    <xsl:template name="output-dirname-as-qname">
        <xsl:param name="path"/>        
        <xsl:variable name="pos">
            <xsl:call-template name="last-index-of">
                <xsl:with-param name="string" select="$path"/>
                <xsl:with-param name="char" select="'/'"/>
            </xsl:call-template>
        </xsl:variable>
        <xsl:value-of select="translate( substring( $path, 1, $pos - 1 ), '/', '.')"/>
    </xsl:template>
    
    <xsl:template name="output-call-method-odfname-get">
        <xsl:param name="qname"/>
        <method-call primary="OdfName" method="get">
            <xsl:variable name="prefix">
                <xsl:call-template name="output-namespace-prefix">
                    <xsl:with-param name="qname" select="$qname"/>
                </xsl:call-template>
            </xsl:variable>
            <with-param>
                <expression primary="OdfNamespace" value="{$prefix}"/>
            </with-param>
            <with-param value="&quot;{substring-after($qname,':')}&quot;"/>
        </method-call>
    </xsl:template>

    <xsl:template name="output-mandatory-formal-parameters">
        <xsl:variable name="id" select="generate-id(.)"/>
        <xsl:for-each select=".//rng:attribute">
            <xsl:sort select="substring-after(@name,':')"/>
            <xsl:variable name="name" select="substring-after(@name,':')"/>
            <xsl:if test="not( preceding::rng:attribute[substring-after(@name,':') = $name and generate-id(ancestor::rng:element)=$id] ) and parent::rng:element">
                <xsl:variable name="javaName">
                    <xsl:call-template name="output-name">
                        <xsl:with-param name="qname" select="@name"/>
                    </xsl:call-template>
                </xsl:variable>
                
                <xsl:variable name="odfType">
                    <!-- xsl:apply-templates select="rng:ref/@name"/ -->
                    <xsl:call-template name="output-odf-type"/>
                </xsl:variable>
                <param type="{$odfType}" name="_a{$javaName}"/>
            </xsl:if>
        </xsl:for-each>
    </xsl:template>
    
    <xsl:template name="exclude-attributes">
        <xsl:param name="qname" select="@name"/>
        <xsl:choose>
            <xsl:when test="$qname='xlink:type' or $qname='xlink:show' or $qname='xlink:actuate'">true</xsl:when>
            <xsl:when test="$createBase and not(//rng:element[@name=$elementNameForBase]//rng:attribute[@name=$qname])">true</xsl:when>
            <xsl:when test="$createDerived and //rng:element[@name=$elementNameForDerived]//rng:attribute[@name=$qname]">true</xsl:when>
        </xsl:choose>
    </xsl:template>
    
    <xsl:template name="output-odf-type">
        <xsl:apply-templates select="*" mode="get-odf-type"/>
    </xsl:template>
    
    <xsl:template match="rng:ref" mode="get-odf-type">
        <xsl:value-of select="@name"/>
    </xsl:template>

    <xsl:template match="rng:data" mode="get-odf-type">
        <xsl:value-of select="@type"/>
    </xsl:template>

    <xsl:template match="rng:text" mode="get-odf-type">
        <xsl:text>string</xsl:text>
    </xsl:template>

    
    <xsl:template match="*" mode="get-odf-type">
        <xsl:variable name="elementName" select="ancestor::rng:element/@name"/>
        <xsl:variable name="attrName" select="ancestor::rng:attribute/@name"/>
        <xsl:text>Odf</xsl:text>
        <xsl:call-template name="output-name">
            <xsl:with-param name="qname" select="$elementName"/>
        </xsl:call-template>
        <xsl:call-template name="output-name">
            <xsl:with-param name="qname" select="$attrName"/>
        </xsl:call-template>
        <xsl:text>AttrValue</xsl:text>
    </xsl:template>

    <xsl:template match="text()" mode="get-odf-type"/>

</xsl:stylesheet>
