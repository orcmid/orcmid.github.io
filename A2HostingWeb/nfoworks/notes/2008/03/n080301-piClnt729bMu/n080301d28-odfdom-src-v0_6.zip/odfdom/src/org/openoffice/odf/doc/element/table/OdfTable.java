/************************************************************************
 *
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS FILE HEADER.
 * 
 * Copyright 2008 by Sun Microsystems, Inc.
 *
 * OpenOffice.org - a multi-platform office productivity suite
 *
 * $RCSfile: $
 * $Revision: $
 *
 *
 * OpenOffice.org is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License version 3
 * only, as published by the Free Software Foundation.
 *
 * OpenOffice.org is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License version 3 for more details
 * (a copy is included in the LICENSE file that accompanied this code).
 *
 * You should have received a copy of the GNU Lesser General Public License
 * version 3 along with OpenOffice.org.  If not, see
 * <http://www.openoffice.org/license.html>
 * for a copy of the LGPLv3 License.
 *
 ************************************************************************/
package org.openoffice.odf.doc.element.table;

import org.openoffice.odf.dom.element.table.OdfTableElement;
import org.openoffice.odf.dom.util.DomNodeList;
import org.openoffice.odf.doc.OdfFileDom;
import java.util.ArrayList;
import java.util.List;
import org.openoffice.odf.dom.element.table.OdfTableColumnElement;
import org.openoffice.odf.dom.style.OdfStyle;
import org.openoffice.odf.dom.style.OdfTableColumnStyle;
import org.w3c.dom.DOMException;
import org.w3c.dom.Node;

public class OdfTable extends OdfTableElement {

    /** Creates a new instance of OdfParagraphElementImpl */
    public OdfTable(OdfFileDom ownerDoc) {
        super(ownerDoc);
    }

    //@Override
    public OdfTableColumnStyle getColumnStyle(int c) {
        List<OdfTableColumnStyle> list = getColumnStyleList();
        try {
            return list.get(c);
        } catch (Exception e) {
            return null;
        }
    }

    //@Override
    public void setColumnStyle(int c, OdfTableColumnStyle s) {
        List<OdfTableColumnStyle> list = getColumnStyleList();
        if (list.size() > c) {
            s.copyTo(list.get(c));
        } else {
            while (list.size() <= c) {
                OdfTableColumnStyle s2 = new OdfTableColumnStyle(s.getName());
                s.copyTo(s2);
                list.add(s2);
            }
        }
    }

    //@Override
    public List<OdfTableColumnStyle> getColumnStyleList() {
        return makeColumnStyleList();
    }

    private List<OdfTableColumnStyle> makeColumnStyleList() {
        ArrayList<OdfTableColumnStyle> list = new ArrayList<OdfTableColumnStyle>();
        // get the column definitions
        for (Node n : new DomNodeList(this.getChildNodes())) {
            if (n instanceof OdfTableColumn) {
                OdfTableColumn col = (OdfTableColumn) n;
                OdfStyle cs = col.getAutomaticStyle();
                for (int i = 0; i < col.getNumberColumnsRepeated(); i++) {
                    OdfTableColumnStyle style = new OdfTableColumnStyle(cs.getName());
                    cs.copyTo(style);
                    list.add(style);
                }
            }
        }
        return list;
    }

    //@Override
    public void setColumnStyleList(List<OdfTableColumnStyle> sl) {
        // remove existing column definitions
        // we cannot use the DomNodeList directly since it is a live list and 
        // will change whenever a node is removed
        List<Node> rmList = new ArrayList<Node>();
        for (Node n : new DomNodeList(this.getChildNodes())) {
            if (n instanceof OdfTableColumn) {
                rmList.add(n);
            }
        }
        for (Node n : rmList) {
            removeChild(n);
        }

        Node ref = getFirstChild();
        // create new TableColumn elements
        OdfTableColumnStyle prev = null;
        OdfTableColumn tce = null;

        for (OdfTableColumnStyle col : sl) {
            if (prev == null || prev.compareTo(col) != 0) {
                tce = (OdfTableColumn) getOwnerDocument().createElementNS(
                        OdfTableColumn.ELEMENT_NAME.getUri(),
                        OdfTableColumn.ELEMENT_NAME.getQName());
                tce.setLocalStyleProperties(col);
                insertBefore(tce, ref);
                prev = col;
            } else if (tce != null) {
                tce.setNumberColumnsRepeated(tce.getNumberColumnsRepeated() + 1);
            }
        }
    }

    //@Override
    public OdfTableColumn getTableColumn(int c) {
        List<OdfTableColumn> list = getTableColumnList();
        if (list.size() > c) {
            return list.get(c);
        } else {
            return null;
        }
    }

    public List<OdfTableColumn> getTableColumnList() {
        return makeTableColumnList();
    }

    //@Override
    public int getTableColumnCount() {
        return makeTableColumnList().size();
    }

    //@Override
    public OdfTableColumn addTableColumn() {
        return addTableColumn(1, null);
    }

    public OdfTableColumn addTableColumn(int repeat) {
        return addTableColumn(repeat, null);
    }

    //@Override
    public OdfTableColumn addTableColumn(OdfTableColumnStyle style) {
        return addTableColumn(1, style);
    }

    //@Override
    public OdfTableColumn addTableColumn(int repeat, OdfTableColumnStyle style) {
        // find the last table coulmn element
        Node ref = getFirstChild();
        for (Node n : new DomNodeList(this.getChildNodes())) {
            if (n instanceof OdfTableColumn) {
                ref = n.getNextSibling();
            }
        }
        OdfTableColumn tce =
                (OdfTableColumn) getOwnerDocument().createElementNS(
                OdfTableColumn.ELEMENT_NAME.getUri(),
                OdfTableColumn.ELEMENT_NAME.getQName());
        if (ref != null) {
            tce = (OdfTableColumn) insertBefore(tce, ref);
        } else {
            tce = (OdfTableColumn) appendChild(tce);
        }
        if (style != null) {
            tce.setLocalStyleProperties(style);
        }

        if (repeat > 1) {
            tce.setNumberColumnsRepeated(repeat);
        }

        return tce;
    }

    private List<OdfTableColumn> makeTableColumnList() {
        ArrayList<OdfTableColumn> list = new ArrayList<OdfTableColumn>();
        // get the column definitions
        for (Node n : new DomNodeList(this.getChildNodes())) {
            if (n instanceof OdfTableColumn) {
                OdfTableColumn col = (OdfTableColumn) n;
                for (int i = 0; i < col.getNumberColumnsRepeated(); i++) {
                    list.add(col);
                }
            }
        }
        return list;
    }

    public void setColumnList(List<OdfTableColumn> cl) {
        // remove existing column definitions
        // we cannot use the DomNodeList directly since it is a live list and 
        // will change whenever a node is removed
        List<Node> rmList = new ArrayList<Node>();
        for (Node n : new DomNodeList(this.getChildNodes())) {
            if (n instanceof OdfTableColumn) {
                rmList.add(n);
            }
        }
        for (Node n : rmList) {
            removeChild(n);
        }

        Node ref = getFirstChild();
        // create new TableColumn elements
        OdfTableColumn prev = null;

        for (OdfTableColumn tce : cl) {
            if (prev == null || prev != tce) {
                insertBefore(tce, ref);
                prev = tce;
            } else if (tce != null) {
                tce.setNumberColumnsRepeated(tce.getNumberColumnsRepeated() + 1);
            }
        }
    }

    @Override
    public Node appendChild(Node aNewChild) throws DOMException {
        Node aNode = super.appendChild(aNewChild);
        if (aNode instanceof OdfTableRow) {
            OdfTableRow aRow = (OdfTableRow) aNode;
            aRow.inheritSpannedCells(0);
        }

        return aNode;
    }

    // 2DO: Remove this after refactoring
    public List<OdfTableColumnElement> getTableColumnElementList() {
        throw new UnsupportedOperationException("Not supported yet.");
    }
}
