/************************************************************************
 *
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS FILE HEADER.
 * 
 * Copyright 2008 by Sun Microsystems, Inc.
 *
 * OpenOffice.org - a multi-platform office productivity suite
 *
 * $RCSfile: $
 * $Revision: $
 *
 *
 * OpenOffice.org is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License version 3
 * only, as published by the Free Software Foundation.
 *
 * OpenOffice.org is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License version 3 for more details
 * (a copy is included in the LICENSE file that accompanied this code).
 *
 * You should have received a copy of the GNU Lesser General Public License
 * version 3 along with OpenOffice.org.  If not, see
 * <http://www.openoffice.org/license.html>
 * for a copy of the LGPLv3 License.
 *
 ************************************************************************/
package org.openoffice.odf.doc;

import java.util.logging.Level;
import java.util.logging.Logger;


public class OdfPresentationDocument extends OdfDocument {

    private static String EMPTY_PRESENTATION_DOCUMENT_PATH = "/resources/OdfPresentationDocument.odp";

    static {
        try {
            EMPTY_PRESENTATION_DOCUMENT_PATH = OdfDocument.class.getResource(EMPTY_PRESENTATION_DOCUMENT_PATH).toURI().getPath();
        } catch (Exception ex) {
            Logger.getLogger(OdfPresentationDocument.class.getName()).log(Level.SEVERE, null, ex);
        }        
    }
    
    /**
     * Creates an empty document.
     * @throws java.lang.Exception - if the document could not be created
     */
    public OdfPresentationDocument() throws Exception {        
        super(EMPTY_PRESENTATION_DOCUMENT_PATH);
    }
    
    /**
     * Get the mimetype
     * 
     * @return the MIMETYPE string of this package
     */
    @Override
    public String getMimetype() {
        return MIME_TYPE_ODF_PRESENTATION;
    }    

   private static final String TO_STRING_METHOD_TOKEN = "\n" +MIME_TYPE_ODF_PRESENTATION + " - ID: ";

    @Override
    public String toString() {
        return TO_STRING_METHOD_TOKEN + this.hashCode() + " " + getOdfPackage().getBaseURI();
    }
}
