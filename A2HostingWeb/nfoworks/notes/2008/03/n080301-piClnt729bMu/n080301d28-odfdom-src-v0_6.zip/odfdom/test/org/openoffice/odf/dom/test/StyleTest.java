/************************************************************************
 *
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS FILE HEADER.
 * 
 * Copyright 2008 by Sun Microsystems, Inc.
 *
 * OpenOffice.org - a multi-platform office productivity suite
 *
 * $RCSfile: $
 * $Revision: $
 *
 *
 * OpenOffice.org is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License version 3
 * only, as published by the Free Software Foundation.
 *
 * OpenOffice.org is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License version 3 for more details
 * (a copy is included in the LICENSE file that accompanied this code).
 *
 * You should have received a copy of the GNU Lesser General Public License
 * version 3 along with OpenOffice.org.  If not, see
 * <http://www.openoffice.org/license.html>
 * for a copy of the LGPLv3 License.
 *
 ************************************************************************/
package org.openoffice.odf.dom.test;

import java.util.Map;
import org.junit.Assert;
import org.junit.Test;
import org.openoffice.odf.dom.OdfNamespace;
import org.openoffice.odf.doc.OdfDocument;
import org.openoffice.odf.doc.OdfTextDocument;
import org.openoffice.odf.doc.element.text.OdfParagraph;
import org.openoffice.odf.dom.style.OdfParagraphStyle;
import org.openoffice.odf.dom.style.OdfStyle;
import org.openoffice.odf.dom.style.OdfStyleCollection;
import org.openoffice.odf.dom.style.OdfStyleFamily;
import org.openoffice.odf.dom.style.OdfTextStyle;
import org.openoffice.odf.dom.style.props.OdfStylePropertiesSet;
import org.openoffice.odf.dom.style.props.OdfStyleProperty;
import org.openoffice.odf.dom.style.props.OdfTextProperties;

public class StyleTest {

    public StyleTest() {
    }

    @Test
    public void testStyleOrdering() {
        OdfStyle style1 = new OdfStyle("style1", OdfStyleFamily.Text);
        style1.setProperty(OdfTextProperties.FontWeight, "bold");

        OdfTextStyle ts1 = new OdfTextStyle("text1");
        ts1.setProperty(ts1.FontName, "Helvetica");

        OdfStyle style2 = new OdfStyle("style2", OdfStyleFamily.getByName("text"));
        style2.setProperty(OdfStylePropertiesSet.TextProperties, OdfNamespace.FO, "font-weight", "bold");

        OdfStyle style3 = new OdfStyle("style3", OdfStyleFamily.Text);
        style3.setProperty(OdfStylePropertiesSet.TextProperties, OdfNamespace.FO, "font-weight", "bold");
        style3.setProperty(OdfStylePropertiesSet.TextProperties, OdfNamespace.FO, "font-size", "15pt");

        OdfStyle style4 = new OdfStyle("style4", OdfStyleFamily.Text);

        Assert.assertTrue(style1.compareTo(null) > 0);

        Assert.assertTrue(style1.compareTo(style2) == 0);
        Assert.assertTrue(style2.compareTo(style1) == 0);

        Assert.assertTrue(style1.compareTo(style3) < 0);
        Assert.assertTrue(style3.compareTo(style1) > 0);

        Assert.assertTrue(style4.compareTo(style1) < 0);
    }

    @Test
    public void testPropertyInheritance() {
        OdfStyleCollection c = new OdfStyleCollection();
        OdfStyle parent = new OdfStyle("TheParent", OdfTextStyle.FAMILY, c);
        parent.setProperty(OdfTextProperties.FontSize, "12pt");
        parent.setProperty(OdfTextProperties.Color, "#FF0000");

        OdfStyle child = new OdfStyle("TheChild", OdfTextStyle.FAMILY, parent.getName(), c);
        child.setProperty(OdfTextProperties.FontSize, "18pt");

        // child should now be 18pr, red
        Map<OdfStyleProperty, String> props = child.getProperties();
        Assert.assertEquals("18pt", props.get(OdfTextProperties.FontSize));
        Assert.assertEquals("#FF0000", props.get(OdfTextProperties.Color));

    }

    @Test
    public void testNewStyle() throws Exception {
        OdfDocument doc = new OdfTextDocument();
        OdfParagraph pe = (OdfParagraph) doc.getContent().createElementNS(
                OdfParagraph.ELEMENT_NAME.getUri(),
                OdfParagraph.ELEMENT_NAME.getQName());
        OdfStyle style = pe.newDocumentStyle("test-style");
        Assert.assertTrue(style instanceof OdfParagraphStyle);
    }
}
