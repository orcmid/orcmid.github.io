/************************************************************************
 *
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS FILE HEADER.
 * 
 * Copyright 2008 by Sun Microsystems, Inc.
 *
 * OpenOffice.org - a multi-platform office productivity suite
 *
 * $RCSfile: $
 * $Revision: $
 *
 *
 * OpenOffice.org is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License version 3
 * only, as published by the Free Software Foundation.
 *
 * OpenOffice.org is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License version 3 for more details
 * (a copy is included in the LICENSE file that accompanied this code).
 *
 * You should have received a copy of the GNU Lesser General Public License
 * version 3 along with OpenOffice.org.  If not, see
 * <http://www.openoffice.org/license.html>
 * for a copy of the LGPLv3 License.
 *
 ************************************************************************/
package org.openoffice.odf.doc.element.text;

import org.openoffice.odf.doc.OdfFileDom;
import java.util.logging.Logger;
import org.openoffice.odf.dom.element.text.OdfListElement;
import org.openoffice.odf.dom.style.OdfListLevelStyle;
import org.openoffice.odf.dom.style.OdfListStyle;
import org.openoffice.odf.dom.element.text.OdfListElement;
import org.w3c.dom.Node;

public class OdfList extends OdfListElement {

    private OdfListStyle m_localListStyle;

    /** Creates a new instance of OdfParagraphElementImpl 
     */
    public OdfList(OdfFileDom ownerDoc) {
        super(ownerDoc);
    }

    public void setLocalListStyle(OdfListStyle ls) {
        m_localListStyle = new OdfListStyle("#local-list-style", ls, null);
    }

    public OdfListStyle getLocalListStyle() {
        OdfListStyle aStyle = m_localListStyle;
        if (aStyle == null) {
            OdfList aParentList = getParentList();
            if (aParentList != null) {
                aStyle = aParentList.getLocalListStyle();
            } else {
                m_localListStyle = new OdfListStyle("#local-list-style", null);
                aStyle = m_localListStyle;
            }
        }
        return aStyle;
    }

    public OdfListStyle getListStyle() {
        if (m_localListStyle != null) {
            return m_localListStyle;
        } else {
            String listName = getStyleName();
            if (listName != null && listName.length() > 0) {
                return mOdfDocument.getDocumentStyles().getListStyle(listName);
            } else {
                // if no style is specified at this particular list element, we
                // as the parent list (if any)
                OdfList parentList = getParentList();
                if (parentList != null) {
                    return parentList.getListStyle();
                } else {
                    return null;
                }
            }
        }
    }

    public int getListLevel() {
        int level = 1;
        Node parent = getParentNode();
        while (parent != null) {
            if (parent instanceof OdfListElement) {
                level++;
            }
            parent = parent.getParentNode();
        }
        return level;
    }

    public OdfListLevelStyle getListLevelStyle() {
        OdfListLevelStyle odfListLevelStyle = null;
        OdfListStyle style = getListStyle();
        int level = getListLevel();
        if (style != null) {
            odfListLevelStyle = style.getLevel(level, false, false);
        } else {
            Logger.getLogger(OdfList.class.getName()).warning("No ListLevelStyle found!");
        }
        return odfListLevelStyle;
    }

    public OdfList getParentList() {
        Node parent = getParentNode();
        while (parent != null) {
            if (parent instanceof OdfList) {
                return (OdfList) parent;
            }
            parent = parent.getParentNode();
        }
        return null;
    }
}
