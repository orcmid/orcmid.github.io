/************************************************************************
 *
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS FILE HEADER.
 * 
 * Copyright 2008 by Sun Microsystems, Inc.
 *
 * OpenOffice.org - a multi-platform office productivity suite
 *
 * $RCSfile: $
 * $Revision: $
 *
 * This file is part of OpenOffice.org.
 *
 * OpenOffice.org is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License version 3
 * only, as published by the Free Software Foundation.
 *
 * OpenOffice.org is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License version 3 for more details
 * (a copy is included in the LICENSE file that accompanied this code).
 *
 * You should have received a copy of the GNU Lesser General Public License
 * version 3 along with OpenOffice.org.  If not, see
 * <http://www.openoffice.org/license.html>
 * for a copy of the LGPLv3 License.
 *
 ************************************************************************/
// !!! GENERATED SOURCE CODE !!!
package org.openoffice.odf.dom.style.props;

import org.openoffice.odf.dom.OdfName;
import org.openoffice.odf.dom.OdfNamespace;


public interface OdfTableProperties {
    public final static OdfStyleProperty BackgroundColor = 
        OdfStyleProperty.get(OdfStylePropertiesSet.TableProperties, OdfName.get(OdfNamespace.FO, "background-color"));
    public final static OdfStyleProperty BreakAfter = 
        OdfStyleProperty.get(OdfStylePropertiesSet.TableProperties, OdfName.get(OdfNamespace.FO, "break-after"));
    public final static OdfStyleProperty BreakBefore = 
        OdfStyleProperty.get(OdfStylePropertiesSet.TableProperties, OdfName.get(OdfNamespace.FO, "break-before"));
    public final static OdfStyleProperty KeepWithNext = 
        OdfStyleProperty.get(OdfStylePropertiesSet.TableProperties, OdfName.get(OdfNamespace.FO, "keep-with-next"));
    public final static OdfStyleProperty Margin = 
        OdfStyleProperty.get(OdfStylePropertiesSet.TableProperties, OdfName.get(OdfNamespace.FO, "margin"));
    public final static OdfStyleProperty MarginBottom = 
        OdfStyleProperty.get(OdfStylePropertiesSet.TableProperties, OdfName.get(OdfNamespace.FO, "margin-bottom"));
    public final static OdfStyleProperty MarginLeft = 
        OdfStyleProperty.get(OdfStylePropertiesSet.TableProperties, OdfName.get(OdfNamespace.FO, "margin-left"));
    public final static OdfStyleProperty MarginRight = 
        OdfStyleProperty.get(OdfStylePropertiesSet.TableProperties, OdfName.get(OdfNamespace.FO, "margin-right"));
    public final static OdfStyleProperty MarginTop = 
        OdfStyleProperty.get(OdfStylePropertiesSet.TableProperties, OdfName.get(OdfNamespace.FO, "margin-top"));
    public final static OdfStyleProperty MayBreakBetweenRows = 
        OdfStyleProperty.get(OdfStylePropertiesSet.TableProperties, OdfName.get(OdfNamespace.STYLE, "may-break-between-rows"));
    public final static OdfStyleProperty PageNumber = 
        OdfStyleProperty.get(OdfStylePropertiesSet.TableProperties, OdfName.get(OdfNamespace.STYLE, "page-number"));
    public final static OdfStyleProperty RelWidth = 
        OdfStyleProperty.get(OdfStylePropertiesSet.TableProperties, OdfName.get(OdfNamespace.STYLE, "rel-width"));
    public final static OdfStyleProperty StyleShadow = 
        OdfStyleProperty.get(OdfStylePropertiesSet.TableProperties, OdfName.get(OdfNamespace.STYLE, "shadow"));
    public final static OdfStyleProperty Width = 
        OdfStyleProperty.get(OdfStylePropertiesSet.TableProperties, OdfName.get(OdfNamespace.STYLE, "width"));
    public final static OdfStyleProperty WritingMode = 
        OdfStyleProperty.get(OdfStylePropertiesSet.TableProperties, OdfName.get(OdfNamespace.STYLE, "writing-mode"));
    public final static OdfStyleProperty Align = 
        OdfStyleProperty.get(OdfStylePropertiesSet.TableProperties, OdfName.get(OdfNamespace.TABLE, "align"));
    public final static OdfStyleProperty BorderModel = 
        OdfStyleProperty.get(OdfStylePropertiesSet.TableProperties, OdfName.get(OdfNamespace.TABLE, "border-model"));
    public final static OdfStyleProperty Display = 
        OdfStyleProperty.get(OdfStylePropertiesSet.TableProperties, OdfName.get(OdfNamespace.TABLE, "display"));
}
