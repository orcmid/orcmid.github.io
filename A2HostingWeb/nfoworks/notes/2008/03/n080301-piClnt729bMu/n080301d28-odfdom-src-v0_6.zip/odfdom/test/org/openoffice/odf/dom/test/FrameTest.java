/************************************************************************
 *
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS FILE HEADER.
 * 
 * Copyright 2008 by Sun Microsystems, Inc.
 *
 * OpenOffice.org - a multi-platform office productivity suite
 *
 * $RCSfile: $
 * $Revision: $
 *
 *
 * OpenOffice.org is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License version 3
 * only, as published by the Free Software Foundation.
 *
 * OpenOffice.org is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License version 3 for more details
 * (a copy is included in the LICENSE file that accompanied this code).
 *
 * You should have received a copy of the GNU Lesser General Public License
 * version 3 along with OpenOffice.org.  If not, see
 * <http://www.openoffice.org/license.html>
 * for a copy of the LGPLv3 License.
 *
 ************************************************************************/
package org.openoffice.odf.dom.test;

import org.junit.Assert;
import org.junit.Test;
import org.openoffice.odf.dom.OdfNamespace;
import org.openoffice.odf.doc.OdfDocument;
import org.openoffice.odf.doc.element.draw.OdfFrame;
import org.openoffice.odf.dom.style.OdfStyle;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

public class FrameTest {

    public FrameTest() {
    }

    @Test
    public void testFrame() {
        try {            
            OdfDocument odfdoc = new OdfDocument("test/resources/frame.odt");
            NodeList lst = odfdoc.getContent().getElementsByTagNameNS(OdfNamespace.DRAW.getUri(), "frame");
            for (int i = 0; i < lst.getLength(); i++) {
                Node node = lst.item(i);
                Assert.assertTrue(node instanceof OdfFrame);
                OdfFrame fe = (OdfFrame) lst.item(i);

                OdfStyle ds = fe.getDocumentStyle();
                // the frame itself has no document style (fr1)
//                assertNull(ds);
//                
//                // but the local style has a document style parent                
//                assertNotNull(ds);
//                assertEquals("Frame", ds.getName());

                OdfStyle ls = fe.getAutomaticStyle();
                Assert.assertNotNull(ls);
                Assert.assertEquals("#local-style", ls.getName());
            }
        } catch (Exception e) {
            e.printStackTrace();
            Assert.fail(e.getMessage());
        }
    }
}
