/************************************************************************
 *
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS FILE HEADER.
 * 
 * Copyright 2008 by Sun Microsystems, Inc.
 *
 * OpenOffice.org - a multi-platform office productivity suite
 *
 * $RCSfile: $
 * $Revision: $
 *
 * This file is part of OpenOffice.org.
 *
 * OpenOffice.org is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License version 3
 * only, as published by the Free Software Foundation.
 *
 * OpenOffice.org is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License version 3 for more details
 * (a copy is included in the LICENSE file that accompanied this code).
 *
 * You should have received a copy of the GNU Lesser General Public License
 * version 3 along with OpenOffice.org.  If not, see
 * <http://www.openoffice.org/license.html>
 * for a copy of the LGPLv3 License.
 *
 ************************************************************************/
package org.openoffice.odf.dom.style;

import org.openoffice.odf.dom.style.props.OdfTextProperties;
import org.openoffice.odf.dom.style.props.OdfListLevelProperties;
import org.openoffice.odf.dom.OdfNamespace;
import org.w3c.dom.Element;
import org.w3c.dom.Node;

public class OdfListLevelStyle extends OdfStyle implements OdfTextProperties, OdfListLevelProperties {

    protected String m_list_name;
    private int m_level;
    private String m_numSuffix;
    private String m_numPrefix;
    private String m_bulletChar;
    private boolean m_numbered;
    private String m_numFormat;

    /** Creates a new instance of OdfListLevelStyle */
    public OdfListLevelStyle(String name, int lvl, boolean numbered, String prefix, String suffix, String numFormat, String bullet) {
        super(null, null);
        m_list_name = name;
        m_level = lvl;
        m_numbered = numbered;
        m_numSuffix = suffix;
        m_numPrefix = prefix;
        m_numFormat = numFormat;
        m_bulletChar = bullet;

        double nIndent = lvl * .25;
        setProperty(SpaceBefore, String.valueOf(nIndent).concat("in"));
        setProperty(MinLabelWidth, ".25in");
    }

    @Override
    public String getName() {
        return m_list_name;
    }

    public int getLevel() {
        return m_level;
    }

    public String getSuffix() {
        return m_numSuffix;
    }

    public String getPrefix() {
        return m_numPrefix;
    }

    public String getBulletChar() {
        return m_bulletChar;
    }

    public void setBulletChar(String bulletChar) {
        m_bulletChar = bulletChar;
    }

    public boolean isNumbered() {
        return m_numbered;
    }

    public String getNumFormat() {
        return m_numFormat;
    }

    public void setNumbered(boolean bSet) {
        m_numbered = bSet;
    }

    @Override
    public boolean equals(Object o) {
        return compareTo(o) == 0;
    }

    @Override
    public int compareTo(Object obj) {
        if (obj == null) {
            return 1;
        }
        if (!(obj instanceof OdfListLevelStyle)) {
            return 1;
        }
        OdfListLevelStyle other = (OdfListLevelStyle) obj;


        /*
        int c = 0;
        if (m_numbered && (c = m_numSuffix.compareTo(other.m_numSuffix)) != 0)
        return c;        
        if ((! m_numbered) && (c = m_bulletChar.compareTo(other.m_bulletChar)) != 0)
        return c;        
         */

        if (m_level > other.m_level) {
            return 1;
        }
        if (m_level < other.m_level) {
            return -1;
        }

        if (m_numbered && (!other.m_numbered)) {
            return 1;
        }
        if ((!m_numbered) && other.m_numbered) {
            return -1;
        }

        return super.compareTo(other);
    }

    @Override
    public void appendToNode(Node node) {

        String qname = isNumbered()
                ? "text:list-level-style-number"
                : "text:list-level-style-bullet";
        appendToNode(node, OdfNamespace.TEXT.getUri(), qname);

        // local information...
        Element e = (Element) node.getLastChild();
        e.setAttributeNS(OdfNamespace.TEXT.getUri(), "text:level", Integer.toString(m_level));
        if (m_bulletChar != null && m_bulletChar.length() > 0) {
            e.setAttributeNS(OdfNamespace.TEXT.getUri(), "text:bullet-char", m_bulletChar);
        }
        if (m_numPrefix != null && m_numPrefix.length() > 0) {
            e.setAttributeNS(OdfNamespace.STYLE.getUri(), "style:num-prefix", m_numPrefix);
        }
        if (m_numSuffix != null && m_numSuffix.length() > 0) {
            e.setAttributeNS(OdfNamespace.STYLE.getUri(), "style:num-suffix", m_numSuffix);
        }
        if (m_numFormat != null && m_numFormat.length() > 0) {
            e.setAttributeNS(OdfNamespace.STYLE.getUri(), "style:num-format", m_numFormat);
        }
    }
}
