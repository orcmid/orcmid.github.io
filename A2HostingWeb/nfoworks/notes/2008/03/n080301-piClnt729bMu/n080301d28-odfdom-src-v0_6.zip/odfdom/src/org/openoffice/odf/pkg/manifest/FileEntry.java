/************************************************************************
 *
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS FILE HEADER.
 * 
 * Copyright 2008 by Sun Microsystems, Inc.
 *
 * OpenOffice.org - a multi-platform office productivity suite
 *
 * $RCSfile: $
 * $Revision: $
 *
 *
 * OpenOffice.org is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License version 3
 * only, as published by the Free Software Foundation.
 *
 * OpenOffice.org is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License version 3 for more details
 * (a copy is included in the LICENSE file that accompanied this code).
 *
 * You should have received a copy of the GNU Lesser General Public License
 * version 3 along with OpenOffice.org.  If not, see
 * <http://www.openoffice.org/license.html>
 * for a copy of the LGPLv3 License.
 *
 ************************************************************************/
package org.openoffice.odf.pkg.manifest;

public class FileEntry {

    private String _path;
    private String _mediaType="";
    private int _size=-1;
    private EncryptionData _encryptionData;

    public FileEntry() {
    }

    public FileEntry(String path, String mediaType) {
        _path=path;
        _mediaType=(mediaType==null?"":mediaType);
        _size=0;
    }

    public FileEntry(String path, String mediaType,int size) {
        _path=path;
        _mediaType=mediaType;
        _size=size;
    }

    public void setPath(String path) {
        _path=path;
    }

    public String getPath() {
        return _path;
    }

    public void setMediaType(String mediaType) {
        _mediaType=(mediaType==null?"":mediaType);
    }
    
    public String getMediaType() {
        return _mediaType;
    }

    public void setSize(int size) {
        _size=size;
    }

    /**
     * get the size or -1 if not set
     */
    public int getSize() {
        return _size;
    }

    public void setEncryptionData(EncryptionData encryptionData) {
        _encryptionData=encryptionData;
    }

    public EncryptionData getEncryptionData() {
        return _encryptionData;
    }

}

