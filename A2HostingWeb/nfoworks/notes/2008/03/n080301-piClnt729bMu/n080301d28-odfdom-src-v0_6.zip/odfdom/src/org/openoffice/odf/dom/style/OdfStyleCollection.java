/************************************************************************
 *
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS FILE HEADER.
 * 
 * Copyright 2008 by Sun Microsystems, Inc.
 *
 * OpenOffice.org - a multi-platform office productivity suite
 *
 * $RCSfile: $
 * $Revision: $
 *
 * This file is part of OpenOffice.org.
 *
 * OpenOffice.org is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License version 3
 * only, as published by the Free Software Foundation.
 *
 * OpenOffice.org is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License version 3 for more details
 * (a copy is included in the LICENSE file that accompanied this code).
 *
 * You should have received a copy of the GNU Lesser General Public License
 * version 3 along with OpenOffice.org.  If not, see
 * <http://www.openoffice.org/license.html>
 * for a copy of the LGPLv3 License.
 *
 ************************************************************************/
package org.openoffice.odf.dom.style;

import org.openoffice.odf.dom.OdfNamespace;
import java.util.AbstractMap;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import org.w3c.dom.Document;
import org.w3c.dom.DocumentFragment;
import org.w3c.dom.Element;
import org.w3c.dom.Node;

/**
 * The OdfStyleCollection collects used styles from the document and provides access 
 * to them. These styles are kept in Maps which distinguish between styles and list styles. 
 * Unknown content and styles are maintained in DocumentFragments.
 */
public class OdfStyleCollection extends AbstractMap<String, OdfStyle> {

    private Map<String, OdfStyle> m_styles = new HashMap<String, OdfStyle>();
    private Map<String, OdfListStyle> m_listStyles = new HashMap<String, OdfListStyle>();
    private DocumentFragment m_unknownStyles;
    private DocumentFragment m_unknownContent;
    private Element m_fontFaceDecls;

    /**
     * Create a OdfStyleCollection. DocumentFragments are created to maintain
     * unkonwn content/styles
     */
    public OdfStyleCollection() {
        try {
            DocumentBuilder db = DocumentBuilderFactory.newInstance().newDocumentBuilder();
            Document doc = db.newDocument();
            m_unknownStyles = doc.createDocumentFragment();
            m_unknownContent = doc.createDocumentFragment();
        } catch (ParserConfigurationException e) {
            throw new RuntimeException("unable to initialize styles", e);
        }
    }

    /**
     * Add a style to the style collection
     * @param style to add
     */
    public void addStyle(OdfStyle style) {
        m_styles.put(style.getName(), style);
    }

    /**
     * Get a style to from the style collection
     * @param name style name
     * @return retrieved OdfStyle
     */
    public OdfStyle getStyle(String name) {
        OdfStyle style = m_styles.get(name);
        return style;
    }

    /**
     * Get a list style to from the style collection
     * @param name list style name
     * @return retrieved OdfListStyle
     */
    public OdfListStyle getListStyle(String name) {
        OdfListStyle style = m_listStyles.get(name);
        return style;
    }

    public Set<Map.Entry<String, OdfStyle>> entrySet() {
        return m_styles.entrySet();
    }

    /**
     * Add an unknown element to be maintained in a DocumentFragment
     * @param element
     */
    public void addUnknownStyle(Element element) {
        Node imported = m_unknownStyles.getOwnerDocument().importNode(element, true);
        m_unknownStyles.appendChild(imported);
    }

    /**
     * Get the unknow styles summarized in a DocumentFragment
     * @return 
     */
    public DocumentFragment getUnknownStyles() {
        return m_unknownStyles;
    }

    /**
     * Add unknown content to be maintained in a DocumentFragment
     * @param element
     */
    public void addUnknownContent(Element element) {
        Node imported = m_unknownContent.getOwnerDocument().importNode(element, true);
        m_unknownContent.appendChild(imported);
    }

    /**
     * Get unknow content summarized in a DocumentFragment
     * @return
     */
    public DocumentFragment getUnkownContent() {
        return m_unknownContent;
    }

    /**
     * Set font-face-decls 
     * @param e
     */
    public void setFontFaceDecls(Element e) {
        Node imported = m_unknownContent.getOwnerDocument().importNode(e, true);
        m_fontFaceDecls = (Element) imported;
    }

    /**
     * Get a font-face-decls element if existing otherwise create an empty
     * font-face-decl element
     * @return
     */
    public Element getFontFaceDecls() {
        if (m_fontFaceDecls != null) {
            return m_fontFaceDecls;
        } else {
            return m_unknownContent.getOwnerDocument().createElementNS(
                    OdfNamespace.OFFICE.getUri(), "office:font-face-decls");
        }
    }

    /**
     * Append style information of the style collection to give node
     * @param node
     */
    public void appendToNode(Node node) {
        for (OdfStyle style : m_styles.values()) {
            style.appendToNode(node);
        }
        for (OdfListStyle style : m_listStyles.values()) {
            style.appendToNode(node);
        }
        Node imported = node.getOwnerDocument().importNode(m_unknownStyles, true);
        node.appendChild(imported);
    }

    /**
     * Add a listStyle to the style collection
     * @param listStyle to add
     */
    public void addListStyle(OdfListStyle listStyle) {
        m_listStyles.put(listStyle.getName(), listStyle);
    }

    @Override
    public String toString() {
        return "Styles: " + m_styles.toString() + "\nListStyles: " + this.m_listStyles;
    }
}
