/************************************************************************
 *
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS FILE HEADER.
 * 
 * Copyright 2008 by Sun Microsystems, Inc.
 *
 * OpenOffice.org - a multi-platform office productivity suite
 *
 * $RCSfile: $
 * $Revision: $
 *
 *
 * OpenOffice.org is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License version 3
 * only, as published by the Free Software Foundation.
 *
 * OpenOffice.org is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License version 3 for more details
 * (a copy is included in the LICENSE file that accompanied this code).
 *
 * You should have received a copy of the GNU Lesser General Public License
 * version 3 along with OpenOffice.org.  If not, see
 * <http://www.openoffice.org/license.html>
 * for a copy of the LGPLv3 License.
 *
 ************************************************************************/
package org.openoffice.odf.dom.element;

import org.openoffice.odf.doc.OdfFileDom;
import org.openoffice.odf.doc.*;
import org.openoffice.odf.dom.OdfName;
import org.openoffice.odf.dom.style.OdfStyle;
import org.openoffice.odf.dom.style.OdfStyleFamily;
import org.w3c.dom.DOMException;

// 2DO: change modifier public to package after refactoring
abstract public class OdfStylableElement extends OdfElement {

    private OdfStyle mAutomaticStyle;
    private OdfStyle mDocumentStyle;
    private OdfStyleFamily mFamily;
    // customization points
    private OdfName mStyleNameAttrib;
    // example OdfName.get(OdfNamespace.TEXT, "text:style-name");
    /** Creates a new instance of OdfElementImpl */
    public OdfStylableElement(OdfFileDom ownerDocument, OdfName name, OdfStyleFamily family, OdfName styleNameAttrib) throws DOMException {
        super(ownerDocument, name.getUri(), name.getQName());
        mFamily = family;
        mStyleNameAttrib = styleNameAttrib;
    }

    public String getStyleName() {
        return getAttributeNS(mStyleNameAttrib.getUri(),
                mStyleNameAttrib.getLocalName());
    }

    public void setStyleName(String name) {
        setAttributeNS(mStyleNameAttrib.getUri(),
                mStyleNameAttrib.getQName(), name);
    }

    public void setLocalStyleProperties(OdfStyle style) {
        mAutomaticStyle = style.getAsLocalStyle();
        setStyleName(style.getName());
    }

    /* Only returns a DocumentStyle if there is no local style */
    public OdfStyle reuseDocumentStyle(String styleName) {
        OdfStyle style = null;
        if (styleName != null) {
            style = mOdfDocument.getDocumentStyles().getStyle(styleName);
            if (style != null) {
                setDocumentStyle(style);
            }
        }
        return style;
    }
    
    public void setDocumentStyle(OdfStyle style) {
        // when there is a local style, the document style becomes the parent 
        // of the local style
        if (mAutomaticStyle != null) {
            mAutomaticStyle.setParentName(style.getName());
        } else {
            setStyleName(style.getName());
        }
    }
    protected static final String LOCAL_STYLE_PREFIX = "#local-style";

    public OdfStyle newDocumentStyle(String name) {
        OdfStyle newDocStyle = mFamily.newStyle(name, mOdfDocument.getDocumentStyles());
        setDocumentStyle(newDocStyle);
        return newDocStyle;
    }    

    /* Only returns a DocumentStyle if there is no local style */
    public OdfStyle getDocumentStyle() {
        OdfStyle style = null;
        if (mDocumentStyle != null) {
            style = mDocumentStyle;
        } else {
            String styleName = getStyleName();
            style = reuseDocumentStyle(styleName);
            if (style == null && mAutomaticStyle != null) {
                style = mOdfDocument.getDocumentStyles().getStyle(mAutomaticStyle.getParentName());
            }
        }
        return style;
    }

    public boolean hasDocumentStyle() {
        boolean hasDocumentStyle = false;
        if (mDocumentStyle != null) {
            hasDocumentStyle = true;
        } else {
            OdfStyle style = null;
            String styleName = getStyleName();
            if (styleName != null) {
                style = mOdfDocument.getDocumentStyles().getStyle(styleName);
                // a document style may be referenced indirectly from the local style...
                if (style != null) {
                    mDocumentStyle = style;
                    hasDocumentStyle = true;
                }
            }
        }
        return hasDocumentStyle;
    }

    public OdfStyle getAutomaticStyle() {
        if (mAutomaticStyle == null) {
            mAutomaticStyle = mFamily.newStyle(LOCAL_STYLE_PREFIX, null);
            // if there is already a document style, but no local style
            String styleName = null;
            if ((styleName = getStyleName()) != null) {
                mAutomaticStyle.setParentName(styleName);
            }
        }
        return mAutomaticStyle;
    }

    public boolean hasAutomaticStyle() {
        return (mAutomaticStyle != null);
    }


    public OdfStyleFamily getStyleFamily() {
        return mFamily;
    }

    public OdfStyle getMergedStyle() {
        OdfStyle merged = new OdfStyle("#merged-style", getStyleFamily());
        OdfStyle docStyle = getDocumentStyle();
        if (mAutomaticStyle != null) {
            // a document style may be referenced indirectly from the local style...
            if (docStyle == null) {
                docStyle = mOdfDocument.getDocumentStyles().getStyle(mAutomaticStyle.getParentName());
            }
            // copy local style to merged style             
            mAutomaticStyle.copyTo(merged);
        }

        // copy doc style to merged style
        // copyTo only copies properties that are not already set at the 
        // target style
        if (docStyle != null) {
            docStyle.copyTo(merged);
        }

        return merged;
    }
}
