/************************************************************************
 *
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS FILE HEADER.
 * 
 * Copyright 2008 by Sun Microsystems, Inc.
 *
 * OpenOffice.org - a multi-platform office productivity suite
 *
 * $RCSfile: $
 * $Revision: $
 *
 * This file is part of OpenOffice.org.
 *
 * OpenOffice.org is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License version 3
 * only, as published by the Free Software Foundation.
 *
 * OpenOffice.org is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License version 3 for more details
 * (a copy is included in the LICENSE file that accompanied this code).
 *
 * You should have received a copy of the GNU Lesser General Public License
 * version 3 along with OpenOffice.org.  If not, see
 * <http://www.openoffice.org/license.html>
 * for a copy of the LGPLv3 License.
 *
 ************************************************************************/
// !!! GENERATED SOURCE CODE !!!
package org.openoffice.odf.dom.style.props;

import org.openoffice.odf.dom.OdfName;
import org.openoffice.odf.dom.OdfNamespace;


public interface OdfTableColumnProperties {
    public final static OdfStyleProperty BreakAfter = 
        OdfStyleProperty.get(OdfStylePropertiesSet.TableColumnProperties, OdfName.get(OdfNamespace.FO, "break-after"));
    public final static OdfStyleProperty BreakBefore = 
        OdfStyleProperty.get(OdfStylePropertiesSet.TableColumnProperties, OdfName.get(OdfNamespace.FO, "break-before"));
    public final static OdfStyleProperty ColumnWidth = 
        OdfStyleProperty.get(OdfStylePropertiesSet.TableColumnProperties, OdfName.get(OdfNamespace.STYLE, "column-width"));
    public final static OdfStyleProperty RelColumnWidth = 
        OdfStyleProperty.get(OdfStylePropertiesSet.TableColumnProperties, OdfName.get(OdfNamespace.STYLE, "rel-column-width"));
    public final static OdfStyleProperty UseOptimalColumnWidth = 
        OdfStyleProperty.get(OdfStylePropertiesSet.TableColumnProperties, OdfName.get(OdfNamespace.STYLE, "use-optimal-column-width"));
}
