/************************************************************************
 *
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS FILE HEADER.
 * 
 * Copyright 2008 by Sun Microsystems, Inc.
 *
 * OpenOffice.org - a multi-platform office productivity suite
 *
 * $RCSfile: $
 * $Revision: $
 *
 *
 * OpenOffice.org is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License version 3
 * only, as published by the Free Software Foundation.
 *
 * OpenOffice.org is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License version 3 for more details
 * (a copy is included in the LICENSE file that accompanied this code).
 *
 * You should have received a copy of the GNU Lesser General Public License
 * version 3 along with OpenOffice.org.  If not, see
 * <http://www.openoffice.org/license.html>
 * for a copy of the LGPLv3 License.
 *
 ************************************************************************/
package org.openoffice.odf.dom.test;

import org.junit.Assert;
import org.junit.Test;
import org.openoffice.odf.dom.OdfNamespace;
import org.openoffice.odf.doc.OdfDocument;
import org.openoffice.odf.doc.OdfFileDom;
import org.openoffice.odf.doc.element.text.OdfList;
import org.openoffice.odf.dom.style.OdfListLevelStyle;
import org.openoffice.odf.dom.style.OdfListStyle;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

public class ListTest {

    public ListTest() {
    }

    @Test
    public void testList() {
        try {            
            OdfDocument odfdoc = new OdfDocument("test/resources/list.odt");
            OdfFileDom odfContent = odfdoc.getContent();
            NodeList lst = odfContent.getElementsByTagNameNS(OdfNamespace.TEXT.getUri(), "list");
            for (int i = 0; i < lst.getLength(); i++) {
                Node node = lst.item(i);
                Assert.assertTrue(node instanceof OdfList);
                OdfList le = (OdfList) lst.item(i);

                OdfListStyle ls = le.getListStyle();
                Assert.assertNotNull(ls);
                OdfListLevelStyle lvl = ls.getLevel(1, false, false);
                Assert.assertNotNull(lvl);

                int level = le.getListLevel();
                OdfListLevelStyle lvl1 = ls.getLevel(level, false, false);
                OdfListLevelStyle lvl2 = le.getListLevelStyle();
                Assert.assertEquals(lvl1, lvl2);
            }
        } catch (Exception e) {
            e.printStackTrace();
            Assert.fail(e.getMessage());
        }
    }
}
