<?xml version="1.0" encoding="UTF-8"?>
<!--

  DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS FILE HEADER.
  
  Copyright 2008 by Sun Microsystems, Inc.
 
  OpenOffice.org - a multi-platform office productivity suite
 
  $RCSfile: $
 
  $Revision: $
 
  This file is part of OpenOffice.org.
 
  OpenOffice.org is free software: you can redistribute it and/or modify
  it under the terms of the GNU Lesser General Public License version 3
  only, as published by the Free Software Foundation.
 
  OpenOffice.org is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU Lesser General Public License version 3 for more details
  (a copy is included in the LICENSE file that accompanied this code).
 
  You should have received a copy of the GNU Lesser General Public License
  version 3 along with OpenOffice.org.  If not, see
  <http://www.openoffice.org/license.html>
  for a copy of the LGPLv3 License.
 
-->
<xsl:stylesheet xmlns:xsl="http://www.w3.org/1999/XSL/Transform" version="1.0"
                xmlns:rng="http://relaxng.org/ns/structure/1.0" 
>
    <xsl:output method="text"/>
    <xsl:include href="genJavaCodeHelpers.xsl"/>
    
    <!-- file -->
    <xsl:template match="/file">
        <xsl:call-template name="output-file-prefix"/>
        <xsl:apply-templates select="package"/>
        <xsl:call-template name="output-lf"/>
        <xsl:apply-templates select="import"/>
        <xsl:apply-templates select="interface/@extends|class/@extends" mode="import"/>
        <xsl:call-template name="type-imports"/>
        <xsl:call-template name="typecast-imports"/>
        <xsl:call-template name="output-lf"/>
        <xsl:apply-templates select="interface|class|enum"/>
    </xsl:template>
        
    <!-- interface/class -->
    
    <!-- interface -->
    <xsl:template match="interface">
        <xsl:apply-templates select="doc" mode="doc"/>
        <xsl:text>public interface </xsl:text>
        <xsl:value-of select="@name"/>
        <xsl:call-template name="extends"/>
        <xsl:call-template name="output-lf"/>
        <xsl:text>{</xsl:text>            
        <xsl:call-template name="output-lf"/>
        <xsl:apply-templates/>
        <xsl:text>};</xsl:text>
        <xsl:call-template name="output-lf"/>
    </xsl:template>

    <!-- class definition -->
    <xsl:template match="class">
        <xsl:apply-templates select="doc" mode="doc"/>
        <xsl:if test="@modifier and string-length(@modifier) > 0">
            <xsl:value-of select="@modifier"/>
            <xsl:text> </xsl:text>
        </xsl:if>
        <xsl:text>class </xsl:text><xsl:value-of select="@name"/>
        <xsl:call-template name="extends"/>
        <xsl:if test="@implements">
            <xsl:text> implements </xsl:text>
            <xsl:value-of select="@implements"/>
        </xsl:if>
        <xsl:call-template name="output-lf"/>
        <xsl:text>{</xsl:text>            
        <xsl:call-template name="output-lf"/>
        <xsl:apply-templates/>
        <xsl:text>};</xsl:text>
        <xsl:call-template name="output-lf"/>
    </xsl:template>

    <!-- enum definition -->
    <xsl:template match="enum">
        <xsl:apply-templates select="doc" mode="doc"/>
        <xsl:if test="@modifier and string-length(@modifier) > 0">
            <xsl:value-of select="@modifier"/>
            <xsl:text> </xsl:text>
        </xsl:if>
        <xsl:text>enum </xsl:text><xsl:value-of select="@name"/>
        <xsl:call-template name="extends"/>
        <xsl:call-template name="output-lf"/>
        <xsl:text>{</xsl:text>            
        <xsl:call-template name="output-lf"/>
        <xsl:text>    </xsl:text>
        <xsl:for-each select="enum-value">
            <xsl:if test="position() > 1">
                <xsl:text>,</xsl:text>
            </xsl:if>
            <xsl:text> </xsl:text>
            <xsl:value-of select="@name"/>
            <xsl:if test="count(with-param)">
                <xsl:call-template name="output-paramter-list"/>
            </xsl:if>
        </xsl:for-each>
        <xsl:text>;</xsl:text>
        <xsl:call-template name="output-lf"/>
        <xsl:call-template name="output-lf"/>
        <xsl:apply-templates/>
        <xsl:text>};</xsl:text>
        <xsl:call-template name="output-lf"/>
    </xsl:template>

    <!-- extends clause -->
    <xsl:template name="extends">
        <xsl:if test="@extends">
            <xsl:text> extends </xsl:text>
            <xsl:call-template name="output-name-nq">
                <xsl:with-param name="name" select="@extends"/>
            </xsl:call-template>
        </xsl:if>
    </xsl:template>
    
    <!-- member/method declaration/definition -->
    
    <!-- member declaration -->
    <xsl:template match="member">
        <xsl:text>    </xsl:text>
        <xsl:if test="@modifier and string-length(@modifier) > 0">
            <xsl:value-of select="@modifier"/>
            <xsl:text> </xsl:text>
        </xsl:if>
        <xsl:call-template name="output-java-type-nq">
            <xsl:with-param name="odfType" select="@type"/>
        </xsl:call-template>
        <xsl:text> </xsl:text>
        <xsl:value-of select="@name"/>
        <xsl:if test="*">
            <xsl:text> = </xsl:text>
            <xsl:apply-templates select="*"/>
        </xsl:if>
        <xsl:text>;</xsl:text>
        <xsl:call-template name="output-lf"/>
        <xsl:call-template name="output-lf"/>
    </xsl:template>
    
    <!-- method declaration -->
    <xsl:template match="method-decl">
        <xsl:apply-templates select="doc" mode="doc"/>
        <xsl:call-template name="output-method-decl"/>
        <xsl:text>;</xsl:text>
        <xsl:call-template name="output-lf"/>
        <xsl:call-template name="output-lf"/>
    </xsl:template>

    <!-- constructor definition -->
    <xsl:template match="constructor">
        <xsl:call-template name="output-method-decl">
            <xsl:with-param name="name" select="ancestor::class/@name|ancestor::enum/@name"/>
        </xsl:call-template>
        <xsl:call-template name="output-lf"/>
        <xsl:text>    {</xsl:text>
        <xsl:call-template name="output-lf"/>
        <xsl:apply-templates/>
        <xsl:text>    }</xsl:text>
        <xsl:call-template name="output-lf"/>
        <xsl:call-template name="output-lf"/>
    </xsl:template>
    
    <!-- method definition -->
    <xsl:template match="method">
        <xsl:apply-templates select="doc" mode="doc"/>
        <xsl:call-template name="output-method-decl"/>
        <xsl:call-template name="output-lf"/>
        <xsl:text>    {</xsl:text>
        <xsl:call-template name="output-lf"/>
        <xsl:apply-templates/>
        <xsl:text>    }</xsl:text>
        <xsl:call-template name="output-lf"/>
        <xsl:call-template name="output-lf"/>
    </xsl:template>

    <xsl:template name="output-method-decl">
        <xsl:param name="name" select="@name"/>
        <xsl:param name="modifier">
            <xsl:choose>
                <xsl:when test="@modifier">
                    <xsl:value-of select="@modifier"/>
                </xsl:when>
                <xsl:otherwise>public</xsl:otherwise>
            </xsl:choose>
        </xsl:param>
        <xsl:text>    </xsl:text>
        <xsl:if test="string-length($modifier) > 0">
            <xsl:value-of select="$modifier"/>
            <xsl:text> </xsl:text>
        </xsl:if>
        <xsl:if test="@return">
            <xsl:call-template name="output-java-type-nq">
                <xsl:with-param name="odfType" select="@return"/>
            </xsl:call-template>
        <xsl:text> </xsl:text>
        </xsl:if>
        <xsl:value-of select="$name"/>
        <xsl:call-template name="output-method-decl-params"/>
    </xsl:template>

    <xsl:template name="output-method-decl-params">
        <xsl:text>(</xsl:text>
        <xsl:if test="count(param)">
            <xsl:for-each select="param">
                <xsl:text> </xsl:text>
                <xsl:if test="position() > 1">
                    <xsl:text>,</xsl:text>
                </xsl:if>
                <xsl:call-template name="output-java-type-nq">
                    <xsl:with-param name="odfType" select="@type"/>
                </xsl:call-template>
                <xsl:text> </xsl:text>
                <xsl:value-of select="@name"/>
            </xsl:for-each>
            <xsl:text> </xsl:text>
        </xsl:if>
        <xsl:text>)</xsl:text>
    </xsl:template>
    
    <!-- statements -->

    <!-- return -->
    <xsl:template match="return">
        <xsl:text>        return </xsl:text>
            <xsl:apply-templates/>
        <xsl:text>;</xsl:text>
        <xsl:call-template name="output-lf"/>
    </xsl:template>
    
    <!-- statement -->
    <xsl:template match="statement">
        <xsl:text>        </xsl:text>
            <xsl:apply-templates/>
        <xsl:text>;</xsl:text>
        <xsl:call-template name="output-lf"/>
    </xsl:template>
    
    <!-- variable declaration -->
    <xsl:template match="variable">
        <xsl:text>        </xsl:text>
        <xsl:call-template name="output-java-type-nq">
            <xsl:with-param name="odfType" select="@type"/>
        </xsl:call-template>
        <xsl:text> </xsl:text>
        <xsl:value-of select="@name"/>
        <xsl:if test="*">
            <xsl:text> = </xsl:text>
            <xsl:apply-templates select="*"/>
        </xsl:if>
        <xsl:text>;</xsl:text>        
        <xsl:call-template name="output-lf"/>
    </xsl:template>
    
    <xsl:template match="assign">
        <xsl:text>        </xsl:text>
        <xsl:value-of select="@name"/>
        <xsl:text> = </xsl:text>        
        <xsl:apply-templates/>
        <xsl:text>;</xsl:text>        
        <xsl:call-template name="output-lf"/>
    </xsl:template>
    

    <!-- choice -->
    <xsl:template match="choice">
        <xsl:for-each select="when">
            <xsl:text>        </xsl:text>
            <xsl:if test="position() > 1">
                <xsl:text>else </xsl:text>
            </xsl:if>
            <xsl:text>if( </xsl:text>
            <xsl:choose>
                <xsl:when test="@test">
                    <xsl:value-of select="@test"/>
                </xsl:when>
                <xsl:otherwise>
                    <xsl:apply-templates select="test/*"/>
                </xsl:otherwise>
            </xsl:choose>
            <xsl:text> )</xsl:text>
            <xsl:call-template name="output-lf"/>
            <xsl:text>        {</xsl:text>
            <xsl:call-template name="output-lf"/>
            <xsl:text>    </xsl:text>
            <xsl:apply-templates select="*[not(self::test)]"/>
            <xsl:text>        }</xsl:text>
            <xsl:call-template name="output-lf"/>
        </xsl:for-each>
    </xsl:template>

    <!-- choice -->
    <xsl:template match="iterator">
        <xsl:text>        for( </xsl:text>
        <xsl:call-template name="output-java-type-nq">
            <xsl:with-param name="odfType" select="@type"/>
        </xsl:call-template>
        <xsl:text> </xsl:text>
        <xsl:value-of select="@name"/>
        <xsl:text> : </xsl:text>
        <xsl:apply-templates select="init"/>
        <xsl:text> )</xsl:text>
        <xsl:call-template name="output-lf"/>
        <xsl:text>        {</xsl:text>
        <xsl:call-template name="output-lf"/>
        <xsl:apply-templates select="*[not(self::init)]"/>
        <xsl:text>        }</xsl:text>
        <xsl:call-template name="output-lf"/>
    </xsl:template>
    
    <!-- expressions -->
    
    <!-- call to method -->
    <xsl:template match="method-call">
        <xsl:if test="@primary">
            <xsl:value-of select="@primary"/>
            <xsl:text>.</xsl:text>
        </xsl:if>
        <xsl:value-of select="@method"/>
        <xsl:call-template name="output-paramter-list"/>
    </xsl:template>
    
    <!-- new instance -->
    <xsl:template match="new">
        <xsl:text>new </xsl:text>
        <xsl:call-template name="output-method-decl">
            <xsl:with-param name="name" select="ancestor::class/@name"/>
        </xsl:call-template>
        <xsl:call-template name="output-paramter-list"/>
    </xsl:template>
    
    <xsl:template name="output-paramter-list">
        <xsl:text>(</xsl:text>
        <xsl:if test="count(with-param)">
            <xsl:for-each select="with-param">
                <xsl:if test="position() > 1">
                    <xsl:text>,</xsl:text>
                </xsl:if>
                <xsl:text> </xsl:text>
                <xsl:choose>
                    <xsl:when test="@value">
                        <xsl:value-of select="@value"/>
                    </xsl:when>
                    <xsl:otherwise>
                        <xsl:apply-templates/>
                    </xsl:otherwise>
                </xsl:choose>
            </xsl:for-each>
            <xsl:text> </xsl:text>
        </xsl:if>
        <xsl:text>)</xsl:text>
    </xsl:template>

    <!-- operator -->
    <xsl:template match="operator">
        <xsl:apply-templates select="*[1]"/>
        <xsl:value-of select="@name"/>
        <xsl:apply-templates select="*[2]"/>
    </xsl:template>
    
    <!-- (simple) expression -->
    <xsl:template match="expression">
        <xsl:if test="@primary">
            <xsl:value-of select="@primary"/>
            <xsl:text>.</xsl:text>
        </xsl:if>
        <xsl:value-of select="@value"/>
    </xsl:template>

    <!-- typecast expression from string -->
    <xsl:template match="typecast[@from='string']">
        <xsl:call-template name="output-java-typecast-nq">
            <xsl:with-param name="odfType" select="@to"/>
        </xsl:call-template>
        <xsl:text>.</xsl:text>
        <xsl:call-template name="output-value-of-method-name">
            <xsl:with-param name="odfType" select="@to"/>
        </xsl:call-template>
        <xsl:text>( </xsl:text>
        <xsl:value-of select="@value"/>
        <xsl:text>)</xsl:text>
    </xsl:template>

    <!-- typecast to string -->
    <xsl:template match="typecast[@to='string']">
        <xsl:call-template name="output-java-typecast-nq">
            <xsl:with-param name="odfType" select="@from"/>
        </xsl:call-template>
        <xsl:text>.</xsl:text>
        <xsl:call-template name="output-to-string-method-name">
            <xsl:with-param name="odfType" select="@from"/>
        </xsl:call-template>
        <xsl:text>( </xsl:text>
        <xsl:value-of select="@value"/>
        <xsl:text>)</xsl:text>
    </xsl:template>
    
    <!-- invalid typecast -->
    <xsl:template match="typecast">
        <xsl:message terminate="yes">
            <xsl:text>Typecast from </xsl:text>
            <xsl:value-of select="@from"/>
            <xsl:text> to </xsl:text>
            <xsl:value-of select="@to"/>
            <xsl:text> is missing.</xsl:text>
        </xsl:message>
    </xsl:template>
        
    <!-- package and import list -->

    <!-- package -->
    <xsl:template match="package">
        <xsl:text>package </xsl:text>
        <xsl:value-of select="@name"/>
        <xsl:text>;</xsl:text>
        <xsl:call-template name="output-lf"/>
    </xsl:template>

    <!-- output import statement for included imports -->
    <xsl:template match="import">
        <xsl:call-template name="output-import"/>
    </xsl:template>

    <!-- output import statement for @extends attribute -->
    <xsl:template match="@extends" mode="import">
        <xsl:if test="not(starts-with(.,/file/package/@name))">
            <xsl:call-template name="output-import">
                <xsl:with-param name="name" select="."/>
            </xsl:call-template>
        </xsl:if>
    </xsl:template>
    
    <!-- output import statement for used type classes -->
    <xsl:template name="type-imports">
        <xsl:for-each select="//method|//method-decl|//param|//variable">
            <xsl:variable name="odfType">
                <xsl:choose>
                    <xsl:when test="@return">
                        <xsl:value-of select="@return"/>
                    </xsl:when>
                    <xsl:when test="@type">
                        <xsl:value-of select="@type"/>
                    </xsl:when>
                </xsl:choose>
            </xsl:variable>
            
            <xsl:if test="generate-id(.) = generate-id(key('odftype',$odfType))">
                <xsl:call-template name="output-import">
                    <xsl:with-param name="name">
                        <xsl:call-template name="output-java-type">
                            <xsl:with-param name="odfType" select="$odfType"/>
                        </xsl:call-template>
                    </xsl:with-param>
                </xsl:call-template>
            </xsl:if>
        </xsl:for-each>
    </xsl:template>

    <!-- output import statement for used typecast classes -->
    <xsl:template name="typecast-imports">
        <xsl:for-each select="//typecast">
            <xsl:variable name="odfType">
                <xsl:choose>
                    <xsl:when test="@from[.='string']">
                        <xsl:value-of select="@to"/>
                    </xsl:when>
                    <xsl:when test="@to[.='string']">
                        <xsl:value-of select="@from"/>
                    </xsl:when>
                </xsl:choose>
            </xsl:variable>
                    
            <xsl:if test="generate-id(.) = generate-id(key('odftypecast',$odfType))">
                <xsl:call-template name="output-import">
                    <xsl:with-param name="name">
                        <xsl:call-template name="output-java-typecast">
                            <xsl:with-param name="odfType" select="$odfType"/>
                        </xsl:call-template>
                    </xsl:with-param>
                </xsl:call-template>
            </xsl:if>
        </xsl:for-each>
    </xsl:template>

    <!-- output import statement for 'name' -->
    <xsl:template name="output-import">
        <xsl:param name="name" select="@name"/>
        <xsl:if test="contains($name,'.') and not(starts-with($name,'java.lang.'))">
            <xsl:text>import </xsl:text>
            <xsl:choose>
                <xsl:when test="contains( $name, '&lt;' )">
                    <xsl:value-of select="substring-before($name,'&lt;')"/>
                </xsl:when>
                <xsl:otherwise>
                    <xsl:value-of select="$name"/>
                </xsl:otherwise>
            </xsl:choose>
            <xsl:text>;</xsl:text>
            <xsl:call-template name="output-lf"/>
        </xsl:if>
    </xsl:template>
    
    <!-- output documentation -->
    <xsl:template match="doc"/>
    
    <xsl:template match="doc" mode="doc">
        <xsl:variable name="indent">
            <xsl:choose>
                <xsl:when test="ancestor::method|ancestor::method-decl">
                    <xsl:text>    </xsl:text>
                </xsl:when>
                <xsl:otherwise>
                    <xsl:text/>
                </xsl:otherwise>
            </xsl:choose>
        </xsl:variable>
        <xsl:value-of select="$indent"/>
        <xsl:text>/**</xsl:text>
        <xsl:call-template name="output-lf"/>
        <xsl:value-of select="$indent"/>
        <xsl:text> * </xsl:text>
        <xsl:value-of select="."/>
        <xsl:call-template name="output-lf"/>
        <xsl:value-of select="$indent"/>
        <xsl:text> */</xsl:text>
        <xsl:call-template name="output-lf"/>
    </xsl:template>

    <!-- output lf -->
    <xsl:template name="output-lf">
        <xsl:text>
</xsl:text>            
    </xsl:template>

    <!-- ignore all text -->
    <xsl:template match="text()"/>

</xsl:stylesheet>