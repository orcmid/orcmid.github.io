/************************************************************************
 *
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS FILE HEADER.
 * 
 * Copyright 2008 by Sun Microsystems, Inc.
 *
 * OpenOffice.org - a multi-platform office productivity suite
 *
 * $RCSfile: $
 * $Revision: $
 *
 *
 * OpenOffice.org is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License version 3
 * only, as published by the Free Software Foundation.
 *
 * OpenOffice.org is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License version 3 for more details
 * (a copy is included in the LICENSE file that accompanied this code).
 *
 * You should have received a copy of the GNU Lesser General Public License
 * version 3 along with OpenOffice.org.  If not, see
 * <http://www.openoffice.org/license.html>
 * for a copy of the LGPLv3 License.
 *
 ************************************************************************/
package org.openoffice.odf.doc.element.table;

import org.openoffice.odf.doc.OdfFileDom;
import org.openoffice.odf.dom.element.table.OdfTableCellElement;
import org.openoffice.odf.dom.style.OdfStyle;
import org.openoffice.odf.dom.style.OdfTableColumnStyle;

public class OdfTableCell extends OdfTableCellElement implements OdfTableCellBase {

    /** Creates a new instance of OdfParagraphElementImpl */
    public OdfTableCell(OdfFileDom ownerDoc) {
        super(ownerDoc);
    }

    public int getColumnIndex() {
        return OdfTableCellBaseImpl.getColumnIndex(this);
    }

    public OdfTableColumn getTableColumn() {
        return OdfTableCellBaseImpl.getTableColumn(this);
    }

    public OdfTableRow getTableRow() {
        return getAncestorAs(OdfTableRow.class);
    }

    public OdfTable getTable() {
        return OdfTableCellBaseImpl.getTable(this);
    }

    public OdfStyle getTableColumnStyle() {
        return OdfTableCellBaseImpl.getTableColumnStyle(this);
    }

    public void setTableColumnStyle(OdfTableColumnStyle columnStyle) {
        OdfTableCellBaseImpl.setTableColumnStyle(this, columnStyle);
    }
}
