/************************************************************************
 *
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS FILE HEADER.
 * 
 * Copyright 2008 by Sun Microsystems, Inc.
 *
 * OpenOffice.org - a multi-platform office productivity suite
 *
 * $RCSfile: $
 * $Revision: $
 *
 *
 * OpenOffice.org is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License version 3
 * only, as published by the Free Software Foundation.
 *
 * OpenOffice.org is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License version 3 for more details
 * (a copy is included in the LICENSE file that accompanied this code).
 *
 * You should have received a copy of the GNU Lesser General Public License
 * version 3 along with OpenOffice.org.  If not, see
 * <http://www.openoffice.org/license.html>
 * for a copy of the LGPLv3 License.
 *
 ************************************************************************/
package org.openoffice.odf.pkg.manifest;

public class EncryptionData {

    private String _checksumType;
    private String _checksum;
    Algorithm _algorithm;
    KeyDerivation _keyDerivation;

    public EncryptionData() {
    }

    public EncryptionData(String checksumType, String checksum,
                          Algorithm algorithm, KeyDerivation keyDerivation) {

        _checksumType=checksumType;
        _checksum=checksum;
        _algorithm=algorithm;
        _keyDerivation=keyDerivation;
    }

    public void setChecksumType(String checksumType) {
        _checksumType=checksumType;
    }

    public String getChecksumType() {
        return _checksumType;
    }

    public void setChecksum(String checksum) {
        _checksum=checksum;
    }

    public String getChecksum() {
        return _checksum;
    }

    public void setAlgorithm(Algorithm algorithm) {
        _algorithm=algorithm;
    }

    public Algorithm getAlgorithm() {
        return _algorithm;
    }

    public void setKeyDerivation(KeyDerivation keyDerivation) {
        _keyDerivation=keyDerivation;
    }

    public KeyDerivation getKeyDerivation() {
        return _keyDerivation;
    }

}
