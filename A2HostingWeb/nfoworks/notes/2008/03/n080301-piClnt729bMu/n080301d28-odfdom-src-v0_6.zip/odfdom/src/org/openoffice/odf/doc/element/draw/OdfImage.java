/************************************************************************
 *
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS FILE HEADER.
 * 
 * Copyright 2008 by Sun Microsystems, Inc.
 *
 * OpenOffice.org - a multi-platform office productivity suite
 *
 * $RCSfile: $
 * $Revision: $
 *
 *
 * OpenOffice.org is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License version 3
 * only, as published by the Free Software Foundation.
 *
 * OpenOffice.org is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License version 3 for more details
 * (a copy is included in the LICENSE file that accompanied this code).
 *
 * You should have received a copy of the GNU Lesser General Public License
 * version 3 along with OpenOffice.org.  If not, see
 * <http://www.openoffice.org/license.html>
 * for a copy of the LGPLv3 License.
 *
 ************************************************************************/
package org.openoffice.odf.doc.element.draw;

import org.openoffice.odf.dom.element.draw.OdfImageElement;
import java.net.URI;
import java.net.URISyntaxException;
import java.util.logging.Level;
import java.util.logging.Logger;
import org.openoffice.odf.doc.OdfFileDom;
import org.openoffice.odf.dom.util.URITransformer;

public class OdfImage extends OdfImageElement {

    private URI m_ImageURI;

    /** Creates a new instance of OdfParagraphElementImpl */
    public OdfImage(OdfFileDom ownerDoc) {
        super(ownerDoc);
    }

    public URI getImageUri() {
        try {
            if (m_ImageURI == null) {
                m_ImageURI = new URI(URITransformer.encodePath(this.getHref()));
            }
        } catch (URISyntaxException ex) {
            Logger.getLogger(OdfImage.class.getName()).log(Level.SEVERE, null, ex);
        }
        return m_ImageURI;
    }

    public void setImageUri(URI imageUri) {
        this.setHref(URITransformer.decodePath(imageUri.toString()));
        m_ImageURI = imageUri;
    }

////2DO:      
//    public void addImage(URI imageURI, String imgName, String mediaType) {
//        OdfDocument doc = (OdfDocument) this.getOwnerDocument();
//        OdfPackage pkg = doc.getOdfPackage();
//    }
}
