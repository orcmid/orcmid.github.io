/************************************************************************
 *
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS FILE HEADER.
 * 
 * Copyright 2008 by Sun Microsystems, Inc.
 *
 * OpenOffice.org - a multi-platform office productivity suite
 *
 * $RCSfile: $
 * $Revision: $
 *
 *
 * OpenOffice.org is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License version 3
 * only, as published by the Free Software Foundation.
 *
 * OpenOffice.org is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License version 3 for more details
 * (a copy is included in the LICENSE file that accompanied this code).
 *
 * You should have received a copy of the GNU Lesser General Public License
 * version 3 along with OpenOffice.org.  If not, see
 * <http://www.openoffice.org/license.html>
 * for a copy of the LGPLv3 License.
 *
 ************************************************************************/
package org.openoffice.odf.dom.test;

import org.junit.Assert;
import org.junit.Test;
import org.openoffice.odf.doc.OdfDocument;
import org.openoffice.odf.doc.OdfFileDom;
import org.openoffice.odf.doc.element.text.OdfParagraph;
import org.openoffice.odf.doc.element.table.OdfTable;
import org.openoffice.odf.doc.element.table.OdfTableCell;
import org.openoffice.odf.doc.element.table.OdfTableRow;
import org.openoffice.odf.dom.style.OdfStyle;
import org.openoffice.odf.dom.style.props.OdfTableColumnProperties;
import org.openoffice.odf.dom.style.props.OdfTableProperties;
import org.w3c.dom.NodeList;

public class CreateTableTest {

    public CreateTableTest() {
    }

    @Test
    public void testCreateTable1() {
        try {            
            OdfFileDom doc = new OdfDocument("test/resources/empty.odt").getContent();

            
            // find the last paragraph
            NodeList lst = doc.getElementsByTagNameNS(
                    OdfParagraph.ELEMENT_NAME.getUri(),
                    OdfParagraph.ELEMENT_NAME.getLocalName());
            Assert.assertTrue(lst.getLength() > 0);
            OdfParagraph p0 = (OdfParagraph) lst.item(lst.getLength() - 1);

            OdfTable table = doc.createOdfElement(OdfTable.class);

            OdfTableRow tr = (OdfTableRow) table.appendChild(
                    doc.createOdfElement(OdfTableRow.class));
            OdfTableCell td1 = (OdfTableCell) tr.appendChild(
                    doc.createOdfElement(OdfTableCell.class));
            OdfParagraph p1 = doc.createOdfElement(OdfParagraph.class);
            p1.appendChild(doc.createTextNode("content 1"));
            td1.appendChild(p1);

            OdfTableCell td2 = (OdfTableCell) tr.appendChild(
                    doc.createOdfElement(OdfTableCell.class));
            OdfParagraph p2 = doc.createOdfElement(OdfParagraph.class);
            p2.appendChild(doc.createTextNode("cell 2"));
            td2.appendChild(p2);

            OdfTableCell td3 = (OdfTableCell) tr.appendChild(
                    doc.createOdfElement(OdfTableCell.class));
            OdfParagraph p3 = doc.createOdfElement(OdfParagraph.class);
            p3.appendChild(doc.createTextNode("table cell content 3"));
            td3.appendChild(p3);

            p0.getParentNode().insertBefore(table, p0);

            OdfStyle ts = table.getAutomaticStyle();
            ts.setProperty(OdfTableProperties.Width, "12cm");
            ts.setProperty(OdfTableProperties.Align, "left");

            OdfStyle cs1 = td1.getTableColumn().getAutomaticStyle();
            cs1.setProperty(OdfTableColumnProperties.ColumnWidth, "2cm");

            OdfStyle cs2 = td2.getTableColumn().getAutomaticStyle();
            cs2.setProperty(OdfTableColumnProperties.ColumnWidth, "4cm");

            OdfStyle cs3 = td3.getTableColumn().getAutomaticStyle();
            cs3.setProperty(OdfTableColumnProperties.ColumnWidth, "6cm");

            doc.getOdfDocument().save("build/tabletest.odt");

        } catch (Exception e) {
            e.printStackTrace();
            Assert.fail("Failed with " + e.getClass().getName() + ": '" + e.getMessage() + "'");
        }
    }
}
