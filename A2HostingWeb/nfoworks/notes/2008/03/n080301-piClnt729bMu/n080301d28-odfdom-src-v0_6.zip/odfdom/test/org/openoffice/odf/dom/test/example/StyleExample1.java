/************************************************************************
 *
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS FILE HEADER.
 * 
 * Copyright 2008 by Sun Microsystems, Inc.
 *
 * OpenOffice.org - a multi-platform office productivity suite
 *
 * $RCSfile: $
 * $Revision: $
 *
 *
 * OpenOffice.org is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License version 3
 * only, as published by the Free Software Foundation.
 *
 * OpenOffice.org is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License version 3 for more details
 * (a copy is included in the LICENSE file that accompanied this code).
 *
 * You should have received a copy of the GNU Lesser General Public License
 * version 3 along with OpenOffice.org.  If not, see
 * <http://www.openoffice.org/license.html>
 * for a copy of the LGPLv3 License.
 *
 ************************************************************************/
package org.openoffice.odf.dom.test.example;

import org.openoffice.odf.doc.OdfDocument;
import org.openoffice.odf.dom.util.NodeAction;
import org.openoffice.odf.dom.element.OdfElement;
import org.openoffice.odf.dom.element.OdfStylableElement;
import org.openoffice.odf.dom.style.OdfStyle;
import org.w3c.dom.Node;


public class StyleExample1 {
    
    public static void main(String[] args) {
        try {
            OdfDocument odfdoc = new OdfDocument("test/resources/test1.odt");
            System.out.println("parsed document.");
            
            OdfElement e = (OdfElement) odfdoc.getContent().getDocumentElement();
            NodeAction dumpStyles = new NodeAction() {
                protected void apply(Node node, Object arg, int depth) {
                    String indent = new String();
                    for (int i=0; i<depth; i++) indent += "  ";
                    System.out.print(indent + node.getNodeName());
                    if (node.getNodeType() == Node.TEXT_NODE) {
                        System.out.print(": " + node.getNodeValue());
                    }
                    System.out.println();
                    if (node instanceof OdfStylableElement) {
                        System.out.println(indent+"-style info...");
                        OdfStylableElement se = (OdfStylableElement) node;
                        OdfStyle ds = se.getDocumentStyle();
                        OdfStyle ls = se.getAutomaticStyle();                
                        if (ls != null) {
                            System.out.println(indent + "-OdfLocalStyle: " + ls);                    
                        } 
                        if (ds != null) {
                            System.out.println(indent + "-OdfDocumentStyle: " + ds);
                        }
                    }
                }
            };       
            dumpStyles.performAction(e, null);                
            // serializeXml(e, System.out);                                    
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
