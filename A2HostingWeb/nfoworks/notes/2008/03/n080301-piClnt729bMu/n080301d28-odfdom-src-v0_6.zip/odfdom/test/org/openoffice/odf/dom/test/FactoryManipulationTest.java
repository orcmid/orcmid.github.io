/************************************************************************
 *
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS FILE HEADER.
 * 
 * Copyright 2008 by Sun Microsystems, Inc.
 *
 * OpenOffice.org - a multi-platform office productivity suite
 *
 * $RCSfile: $
 * $Revision: $
 *
 *
 * OpenOffice.org is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License version 3
 * only, as published by the Free Software Foundation.
 *
 * OpenOffice.org is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License version 3 for more details
 * (a copy is included in the LICENSE file that accompanied this code).
 *
 * You should have received a copy of the GNU Lesser General Public License
 * version 3 along with OpenOffice.org.  If not, see
 * <http://www.openoffice.org/license.html>
 * for a copy of the LGPLv3 License.
 *
 ************************************************************************/
package org.openoffice.odf.dom.test;

import org.junit.Assert;
import org.junit.Test;
import org.openoffice.odf.dom.OdfNamespace;
import org.openoffice.odf.doc.OdfDocument;
import org.openoffice.odf.doc.OdfFileDom;
import org.openoffice.odf.doc.element.OdfElementFactory;
import org.openoffice.odf.doc.element.text.OdfSpan;
import org.openoffice.odf.pkg.OdfPackage;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

public class FactoryManipulationTest {

    public FactoryManipulationTest() {
    }

    @Test
    public void testFactoryManipulation() {
        try {
            // MyOwnPrivateSpanClass_1 is derived from OdfSpan (doc layer)
            OdfElementFactory.mapOdfNameToClass(OdfSpan.ELEMENT_NAME, MyOwnPrivateSpanClass_1.class);
            OdfPackage pkg = new OdfPackage("test/resources/factorymanipulation.odt");        
            OdfFileDom contentDom = new OdfDocument(pkg).getContent();
            NodeList lst = contentDom.getElementsByTagNameNS(OdfNamespace.TEXT.getUri(), "span");
            Assert.assertTrue(lst.getLength() == 1);
            Node node = lst.item(0);
            Assert.assertTrue(node instanceof MyOwnPrivateSpanClass_1);
            
            // MyOwnPrivateSpanClass_2 is derived from OdfSpanElement (dom layer)
            OdfElementFactory.mapOdfNameToClass(OdfSpan.ELEMENT_NAME, MyOwnPrivateSpanClass_2.class);
            contentDom = new OdfDocument(pkg).getContent();
            lst = contentDom.getElementsByTagNameNS(OdfNamespace.TEXT.getUri(), "span");
            Assert.assertTrue(lst.getLength() == 1);
            node = lst.item(0);
            Assert.assertTrue(node instanceof MyOwnPrivateSpanClass_2);

            // MyOwnPrivateSpanClass_3 is derived from OdfElement to replace OdfSpanElement (dom layer)
            OdfElementFactory.mapOdfNameToClass(OdfSpan.ELEMENT_NAME, MyOwnPrivateSpanClass_3.class);
            contentDom = new OdfDocument(pkg).getContent();
            lst = contentDom.getElementsByTagNameNS(OdfNamespace.TEXT.getUri(), "span");
            Assert.assertTrue(lst.getLength() == 1);
            node = lst.item(0);
            Assert.assertTrue(node instanceof MyOwnPrivateSpanClass_3);

            // MyOwnPrivateOdfElement is derived from OdfElement to handle <text:userdefined>
            OdfElementFactory.mapOdfNameToClass(MyOwnPrivateOdfElement.ELEMENT_NAME, MyOwnPrivateOdfElement.class);
            contentDom = new OdfDocument(pkg).getContent();
            lst = contentDom.getElementsByTagNameNS(OdfNamespace.TEXT.getUri(), "userdefined");
            Assert.assertTrue(lst.getLength() == 1);
            node = lst.item(0);
            Assert.assertTrue(node instanceof MyOwnPrivateOdfElement);
        } catch (Exception e) {
            e.printStackTrace();
            Assert.fail(e.getMessage());
        }
    }
}
