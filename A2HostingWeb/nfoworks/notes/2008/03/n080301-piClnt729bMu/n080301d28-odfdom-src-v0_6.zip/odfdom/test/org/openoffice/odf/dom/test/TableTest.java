/************************************************************************
 *
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS FILE HEADER.
 * 
 * Copyright 2008 by Sun Microsystems, Inc.
 *
 * OpenOffice.org - a multi-platform office productivity suite
 *
 * $RCSfile: $
 * $Revision: $
 *
 *
 * OpenOffice.org is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License version 3
 * only, as published by the Free Software Foundation.
 *
 * OpenOffice.org is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License version 3 for more details
 * (a copy is included in the LICENSE file that accompanied this code).
 *
 * You should have received a copy of the GNU Lesser General Public License
 * version 3 along with OpenOffice.org.  If not, see
 * <http://www.openoffice.org/license.html>
 * for a copy of the LGPLv3 License.
 *
 ************************************************************************/
package org.openoffice.odf.dom.test;

import java.util.List;
import org.junit.Assert;
import org.junit.Test;
import org.openoffice.odf.dom.OdfNamespace;
import org.openoffice.odf.doc.OdfDocument;
import org.openoffice.odf.doc.element.table.OdfTable;
import org.openoffice.odf.doc.element.table.OdfTableCell;
import org.openoffice.odf.doc.element.table.OdfTableRow;
import org.openoffice.odf.dom.style.OdfStyle;
import org.openoffice.odf.dom.style.OdfTableColumnStyle;
import org.openoffice.odf.dom.style.props.OdfTableColumnProperties;
import org.openoffice.odf.pkg.OdfPackage;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

public class TableTest {

    public TableTest() {
    }

    @Test
    public void testTable() {
        try {
            OdfDocument odfdoc = new OdfDocument("test/resources/table.odt");
            NodeList lst = odfdoc.getContentCached().getElementsByTagNameNS(OdfNamespace.TABLE.getUri(), "table");
            int tscount = 0;
            for (int i = 0; i < lst.getLength(); i++) {
                Node node = lst.item(i);
                Assert.assertTrue(node instanceof OdfTable);
                OdfTable te = (OdfTable) lst.item(i);

                OdfStyle ds = te.getDocumentStyle();
                Assert.assertNull(ds);

                if (te.hasAutomaticStyle()) {
                    OdfStyle ls = te.getAutomaticStyle();
                    tscount++;

                    List<OdfTableColumnStyle> csl = te.getColumnStyleList();
                    Assert.assertNotNull(csl);
                    Assert.assertTrue(csl.size() > 0);

                    OdfTableColumnStyle s = csl.get(1);
                    s.setProperty(OdfTableColumnProperties.ColumnWidth, "10cm");
                    te.setColumnStyleList(csl);

                    List<OdfTableColumnStyle> csl2 = te.getColumnStyleList();
                    Assert.assertNotNull(csl2);
                    Assert.assertTrue(csl2.size() == 2);
                }
            }
            Assert.assertTrue(tscount > 0);

        } catch (Exception e) {
            e.printStackTrace();
            Assert.fail(e.getMessage());
        }
    }

    @Test
    public void testCellsAndRows() {
        try {
            OdfDocument odfdoc = new OdfDocument("test/resources/table.odt");
            NodeList lst = odfdoc.getContentCached().getElementsByTagNameNS(OdfNamespace.TABLE.getUri(), "table-cell");
            for (int i = 0; i < lst.getLength(); i++) {
                Node node = lst.item(i);
                Assert.assertTrue(node instanceof OdfTableCell);
                OdfTableCell td = (OdfTableCell) lst.item(i);
                OdfTableRow tr = td.getTableRow();
                Assert.assertNotNull(tr);

                OdfTable table = tr.getTable();
                Assert.assertNotNull(table);
                Assert.assertTrue(table == td.getTable());
            }
        } catch (Exception e) {
            e.printStackTrace();
            Assert.fail(e.getMessage());
        }
    }
}
