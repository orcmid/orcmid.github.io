/************************************************************************
 *
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS FILE HEADER.
 * 
 * Copyright 2008 by Sun Microsystems, Inc.
 *
 * OpenOffice.org - a multi-platform office productivity suite
 *
 * $RCSfile: $
 * $Revision: $
 *
 *
 * OpenOffice.org is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License version 3
 * only, as published by the Free Software Foundation.
 *
 * OpenOffice.org is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License version 3 for more details
 * (a copy is included in the LICENSE file that accompanied this code).
 *
 * You should have received a copy of the GNU Lesser General Public License
 * version 3 along with OpenOffice.org.  If not, see
 * <http://www.openoffice.org/license.html>
 * for a copy of the LGPLv3 License.
 *
 ************************************************************************/
package org.openoffice.odf.doc.element.table;

import org.openoffice.odf.dom.util.DomNodeList;
import org.openoffice.odf.dom.style.OdfStyle;
import org.openoffice.odf.dom.element.table.OdfTableCellElementBase;
import org.openoffice.odf.dom.element.table.OdfTableColumnElement;
import org.openoffice.odf.dom.style.OdfTableColumnStyle;
import org.w3c.dom.Node;

/**
 *
 *
 */
class OdfTableCellBaseImpl {

    static public int getColumnIndex(OdfTableCellBase _aBase) {
        OdfTableRow tr = _aBase.getTableRow();
        int result = 0;
        for (Node n : new DomNodeList(tr.getChildNodes())) {
            if (n == _aBase) {
                return result;
            }
            if (n instanceof OdfTableCellElementBase) {
                result += ((OdfTableCellElementBase)n).getNumberColumnsRepeated();
            }
        }
        return result;
    }

    static public OdfTableColumn getTableColumn(OdfTableCellBase _aBase) {
        return _aBase.getTable().getTableColumn(_aBase.getColumnIndex());
    }

    static public OdfTable getTable(OdfTableCellBase _aBase) {
        OdfTableRow row = _aBase.getTableRow();
        return row.getTable();
    }

    static public OdfStyle getTableColumnStyle(OdfTableCellBase _aBase) {
        OdfStyle tcs = null;
        OdfTableColumnElement col = _aBase.getTableColumn();
        if (col != null) {
            tcs = col.getAutomaticStyle();
        }
        return tcs;
    }

    static public void setTableColumnStyle(OdfTableCellBase _aBase, OdfTableColumnStyle columnStyle) {
        int startColumn = _aBase.getColumnIndex();
        int endColumn = startColumn + Math.max(_aBase.getNumberColumnsSpanned(), _aBase.getNumberColumnsRepeated());
        OdfTable table = _aBase.getTable();
        for (int i = 0; i < endColumn; i++) {
            table.setColumnStyle(i, columnStyle);
        }
    }
}
