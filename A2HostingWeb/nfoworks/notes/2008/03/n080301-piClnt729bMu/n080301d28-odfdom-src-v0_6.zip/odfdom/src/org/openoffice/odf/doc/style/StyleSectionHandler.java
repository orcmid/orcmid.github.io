/************************************************************************
 *
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS FILE HEADER.
 * 
 * Copyright 2008 by Sun Microsystems, Inc.
 *
 * OpenOffice.org - a multi-platform office productivity suite
 *
 * $RCSfile: $
 * $Revision: $
 *
 * This file is part of OpenOffice.org.
 *
 * OpenOffice.org is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License version 3
 * only, as published by the Free Software Foundation.
 *
 * OpenOffice.org is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License version 3 for more details
 * (a copy is included in the LICENSE file that accompanied this code).
 *
 * You should have received a copy of the GNU Lesser General Public License
 * version 3 along with OpenOffice.org.  If not, see
 * <http://www.openoffice.org/license.html>
 * for a copy of the LGPLv3 License.
 *
 ************************************************************************/
package org.openoffice.odf.doc.style;

import java.util.Stack;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import org.openoffice.odf.dom.style.OdfListStyle;
import org.openoffice.odf.dom.OdfName;
import org.openoffice.odf.dom.OdfNamespace;
import org.openoffice.odf.dom.style.OdfStyle;
import org.openoffice.odf.dom.style.OdfStyleCollection;
import org.openoffice.odf.dom.style.OdfStyleFamily;
import org.openoffice.odf.dom.style.props.OdfStylePropertiesSet;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;

/**
 * Handler used by the SAX parser to parse the automatic styles of the content.xml,
 * as well as the document styles of the styles.xml. The StyleSectionHandler will remove
 * itself from the stack when its work is done.
 */
public class StyleSectionHandler extends DefaultHandler {

    private OdfStyleCollection m_styles;
    private OdfStyleCollection m_defaultStyles;
    private OdfStyle m_currentStyle;
    private OdfStylePropertiesSet m_currentPropertiesSet;
    private Stack m_handlerStack;
    private OdfName m_context;
    private Document m_document;
    private Element m_unknown;

    /**
     * 
     * @param styles the style collection in which parsed styles are placed
     */
    public StyleSectionHandler(OdfStyleCollection styles) {
        this(null, null, styles, null);
    }

    /**
     * Create a new style handler in a handler stack. this handler must already
     * be placed on the stack and will remove itself from the stack when the element
     * demoted by the context qname ends
     * @param context the element's qname denoting the handler context
     * @param handlerStack the stack of content handlers from which this 
     *        handler should remove itself when the context ends
     * @param styles the style collection in which parsed styles are placed
     * @param defaultStyles the style collection in which parsed default styles are placed
     */
    public StyleSectionHandler(OdfName context, Stack handlerStack, OdfStyleCollection styles, OdfStyleCollection defaultStyles) {
        m_handlerStack = handlerStack;
        m_styles = styles;
        m_defaultStyles = defaultStyles;
        m_context = context;

        try {
            DocumentBuilder db = DocumentBuilderFactory.newInstance().newDocumentBuilder();
            m_document = db.newDocument();
        } catch (ParserConfigurationException e) {
            throw new RuntimeException("cannot initialize style handling");
        }
    }

    /**
     * @inheritDoc
     */
    @Override
    public void startElement(String uri, String localName, String qName, Attributes atts) throws SAXException {

        if (localName.equals("style") && uri.equals(OdfNamespace.STYLE.getUri())) {
            // start a new style
            String name = atts.getValue(OdfNamespace.STYLE.getUri(), "name");
            String parent = atts.getValue(OdfNamespace.STYLE.getUri(), "parent-style-name");
            String family = atts.getValue(OdfNamespace.STYLE.getUri(), "family");
            String next = atts.getValue(OdfNamespace.STYLE.getUri(), "next-style-name");
            m_currentStyle = new OdfStyle(name, OdfStyleFamily.getByName(family), parent, next, m_styles);

        } else if (localName.equals("default-style") && uri.equals(OdfNamespace.STYLE.getUri())) {
            // start a new default style
            String family = atts.getValue(OdfNamespace.STYLE.getUri(), "family");
            String name = "DEFAULT_" + family.toUpperCase() + "_STYLE";
            String parent = null;
            String next = null;
            m_currentStyle = new OdfStyle(name, OdfStyleFamily.getByName(family), parent, next, m_defaultStyles);

        } else {
            // add properties to the current style...
            OdfStylePropertiesSet set = null;
            if (m_currentStyle != null && (set = OdfStyle.getPropertySet(localName)) != null) {
                m_currentPropertiesSet = set;
                for (int i = 0; i < atts.getLength(); i++) {
                    m_currentStyle.setProperty(set, OdfNamespace.get(atts.getURI(i)),
                            atts.getLocalName(i), atts.getValue(i));
                }
            } else {
                // unkown style properties or element, build a document fragment and add it 
                // as an unknown element
                // OdfName name = OdfName.get(uri, localName);
                Element e = m_document.createElementNS(uri, qName);
                for (int i = 0; i < atts.getLength(); i++) {
                    e.setAttributeNS(atts.getURI(i), atts.getQName(i), atts.getValue(i));
                }
                if (m_unknown != null) {
                    m_unknown.appendChild(e);
                }
                m_unknown = e;
            }
        }
    }

    /**
     * @inheritDoc
     */
    @Override
    public void endElement(String uri, String localName, String qName) throws SAXException {
        OdfName on = OdfName.get(uri, qName);

        // reset current style if necessary
        if (localName.equals("style") && uri.equals(OdfNamespace.STYLE.getUri())) {
            m_currentStyle = null;
            return;
        }

        // reset current property set if necessary
        if (uri.equals(OdfNamespace.STYLE.getUri()) && m_currentStyle != null &&
                OdfStyle.getPropertySet(localName) != null) {
            m_currentPropertiesSet = null;
            return;
        }

        // if we are handling an unkown element, move one node up
        if (m_unknown != null) {
            // topmost unkown element returns null
            Element tmpUnknown = m_unknown;
            m_unknown = (Element) m_unknown.getParentNode();
            // if the unkown element was closed, add it to the style
            if (m_unknown == null) {
                if (m_currentStyle != null) {
                    String propertiesSet = null;
                    if (m_currentPropertiesSet != null) {
                        propertiesSet = OdfStyle.getPropertySetName(m_currentPropertiesSet);
                    }
                    m_currentStyle.addUnknownProperty(propertiesSet, tmpUnknown);
                } else if (uri.equals(OdfNamespace.TEXT.getUri()) && localName.equals("list-style")) {
                    // 2DO: Possible Refactor case for clarity - remove the collection from the OdfListStyle - list style will be added in OdfListStyle to m_styles
                    new OdfListStyle(tmpUnknown, m_styles);
                } else {
                    m_styles.addUnknownStyle(tmpUnknown);
                }
            }
            return;
        }

        // remove this handler from the stack when the auto-style section finishes
        if (on.equals(m_context) && m_handlerStack != null) {
            m_handlerStack.pop();
            return;
        }
    }
}
