<?xml version="1.0" encoding="UTF-8"?>
<!--

  DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS FILE HEADER.
  
  Copyright 2008 by Sun Microsystems, Inc.
 
  OpenOffice.org - a multi-platform office productivity suite
 
  $RCSfile: $
 
  $Revision: $
 
  This file is part of OpenOffice.org.
 
  OpenOffice.org is free software: you can redistribute it and/or modify
  it under the terms of the GNU Lesser General Public License version 3
  only, as published by the Free Software Foundation.
 
  OpenOffice.org is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU Lesser General Public License version 3 for more details
  (a copy is included in the LICENSE file that accompanied this code).
 
  You should have received a copy of the GNU Lesser General Public License
  version 3 along with OpenOffice.org.  If not, see
  <http://www.openoffice.org/license.html>
  for a copy of the LGPLv3 License.
 
-->

<xsl:stylesheet xmlns:xsl="http://www.w3.org/1999/XSL/Transform" version="1.0"
                xmlns:rng="http://relaxng.org/ns/structure/1.0" 
>
    <xsl:output method="xml" indent="yes"/>
    
    <xsl:param name="className" select="'!UnknownInterface!'"/>
    <xsl:param name="defineName" select="''"/>
    <xsl:param name="elementName" select="''"/>
    <xsl:param name="attributeName" select="''"/>

    <!-- dummies for genXMLCodeHelpers.xsl -->
    <xsl:variable name="elementNameForDerived" select="''"/>
    <xsl:variable name="elementNameForBase" select="''"/>
    
    <xsl:variable name="createBase" select="false()"/>
    <xsl:variable name="createDerived" select="false()"/>
    
    <xsl:include href="genXMLCodeHelpers.xsl"/>

    <!-- process schema -->
    <xsl:template match="/rng:grammar">
        <file>
            <package>
                <xsl:attribute name="name">
                    <xsl:call-template name="output-dirname-as-qname">
                        <xsl:with-param name="path" select="$className"/>
                    </xsl:call-template>
                </xsl:attribute>
            </package>
            <xsl:choose>
                <xsl:when test="$defineName != ''">
                    <xsl:apply-templates select="rng:define[@name=$defineName]"/>
                </xsl:when>
                <xsl:otherwise>
                    <xsl:apply-templates select="rng:element[@name=$elementName]//rng:attribute[@name=$attributeName]"/>
                </xsl:otherwise>
            </xsl:choose>
        </file>
    </xsl:template>

    <xsl:template match="rng:define|rng:attribute">
        <enum modifier="public">
            <xsl:attribute name="name">
                <xsl:call-template name="output-filename">
                    <xsl:with-param name="path" select="$className"/>
                </xsl:call-template>
            </xsl:attribute>
            <xsl:apply-templates select="rng:choice"/>
        </enum>
    </xsl:template>
    
    
    <xsl:template match="rng:choice">
        <xsl:for-each select="rng:value">
            <xsl:sort/>
            <enum-value>
                <xsl:attribute name="name">
                    <xsl:call-template name="output-constant-name">
                        <xsl:with-param name="name" select="."/>
                    </xsl:call-template>
                </xsl:attribute>
                <with-param value="&quot;{.}&quot;"/>
            </enum-value>
        </xsl:for-each>

        <xsl:variable name="classNameNQ">
            <xsl:call-template name="output-filename">
                <xsl:with-param name="path" select="$className"/>
            </xsl:call-template>
        </xsl:variable>
        
        <member modifier="private" type="string" name="m_aValue"/>
        
        <constructor modifier="">
            <param type="string" name="_aValue"/>
            <assign name="m_aValue">
                <expression value="_aValue"/>
            </assign>
        </constructor>
        
        <method return="string" name="toString">
            <return>
                <expression value="m_aValue"/>
            </return>
        </method>
        
        <method modifier="public static" return="string" name="toString">
            <param name="_aEnum" type="{$classNameNQ}"/>
            <return>
                <method-call primary="_aEnum" method="toString"/>
            </return>
        </method>
        
        <method modifier="public static" return="{$classNameNQ}" name="enumValueOf">
            <param name="_aString" type="string"/>
            <iterator type="{$classNameNQ}" name="aIter">
                <init>
                    <method-call method="values"/>
                </init>
                <choice>
                    <when>
                        <test>
                            <method-call primary="_aString" method="equals">
                                <with-param>
                                    <method-call primary="aIter" method="toString"/>
                                </with-param>
                            </method-call>
                        </test>
                        <return>
                            <expression value="aIter"/>
                        </return>
                    </when>
                </choice>
            </iterator>
            <return>
                <expression value="null"/>
            </return>
        </method>
    </xsl:template>
            
</xsl:stylesheet>
