/************************************************************************
 *
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS FILE HEADER.
 * 
 * Copyright 2008 by Sun Microsystems, Inc.
 *
 * OpenOffice.org - a multi-platform office productivity suite
 *
 * $RCSfile: $
 * $Revision: $
 *
 *
 * OpenOffice.org is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License version 3
 * only, as published by the Free Software Foundation.
 *
 * OpenOffice.org is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License version 3 for more details
 * (a copy is included in the LICENSE file that accompanied this code).
 *
 * You should have received a copy of the GNU Lesser General Public License
 * version 3 along with OpenOffice.org.  If not, see
 * <http://www.openoffice.org/license.html>
 * for a copy of the LGPLv3 License.
 *
 ************************************************************************/

package org.openoffice.odf.pkg;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import javax.xml.transform.stream.StreamSource;
import org.openoffice.odf.pkg.manifest.FileEntry;

/**
 * OdfPackageStream is a representation of a stream that is part of an ODF file.
 * If a stream is written to through the output stream, this will be
 * reflected when the output stream is closed
 *
 */
class OdfPackageStream extends StreamSource {
    
    private OdfPackage pkg;
    private String name;
    private InputStream inputStream;
    private OutputStream outputStream=null;
    private boolean bClosed;
    
    public OdfPackageStream(OdfPackage pkg, String name) throws Exception {

        super(pkg.getInputStream(name), pkg.getBaseURI()+"/"+name);
        this.pkg=pkg;
        this.name=name;
    }
    
    public boolean isOutput() {
    // denote that the output stream has been requested
        return outputStream!=null;
    }
    
    public OutputStream getOutputStream() throws Exception {
        if (bClosed) throw new IOException("stream already closed");
        outputStream = pkg.getOutputStream(name);
        return outputStream;
    }
        
    public FileEntry geFileEntry() {
        return pkg.getFileEntry(name);
    }

    public String getName() {
        return name;
    }
    
    public OdfPackage getPackage() {
        return pkg;
    }

    void close() throws IOException {
        bClosed = true;
        inputStream.close();
        outputStream.close();
    }
    
}
