/************************************************************************
 *
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS FILE HEADER.
 * 
 * Copyright 2008 by Sun Microsystems, Inc.
 *
 * OpenOffice.org - a multi-platform office productivity suite
 *
 * $RCSfile: $
 * $Revision: $
 *
 * This file is part of OpenOffice.org.
 *
 * OpenOffice.org is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License version 3
 * only, as published by the Free Software Foundation.
 *
 * OpenOffice.org is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License version 3 for more details
 * (a copy is included in the LICENSE file that accompanied this code).
 *
 * You should have received a copy of the GNU Lesser General Public License
 * version 3 along with OpenOffice.org.  If not, see
 * <http://www.openoffice.org/license.html>
 * for a copy of the LGPLv3 License.
 *
 ************************************************************************/
package org.openoffice.odf.dom.style;

import org.openoffice.odf.dom.style.props.OdfStyleProperty;
import org.openoffice.odf.dom.OdfName;
import org.openoffice.odf.dom.OdfNamespace;
import org.openoffice.odf.dom.style.props.OdfStylePropertiesSet;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.SortedMap;
import java.util.TreeMap;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import org.w3c.dom.Document;
import org.w3c.dom.DocumentFragment;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

/**
 * This class is designed to handle automatic or document styles.
 * 
 */
public class OdfStyle implements Comparable {

    /**
     * The inner class PropertyMap serves as a container for style properties
     */
    protected class PropertyMap extends TreeMap<OdfName, String> implements Comparable {

        private OdfStylePropertiesSet m_set;

        /**
         * Create a property map 
         * @param set 
         */
        public PropertyMap(OdfStylePropertiesSet set) {
            m_set = set;
        }

        /**
         * 
         * @param node
         */
        public void appendPropertySetToNode(Node node) {
            Document doc = node.getOwnerDocument();
            Element propelem = doc.createElementNS(OdfNamespace.STYLE.getUri(),
                    "style:" + getPropertySetName(m_set));
            Iterator<Map.Entry<OdfName, String>> iprops = entrySet().iterator();
            while (iprops.hasNext()) {
                Map.Entry<OdfName, String> entry = iprops.next();
                OdfName propname = entry.getKey();
                String value = entry.getValue();
                propelem.setAttributeNS(propname.getUri(), propname.getQName(), value);
            }
            node.appendChild(propelem);
        }

        private int compare(Comparable o1, Comparable o2) {
            if (o1 == o2) {
                return 0;
            }
            if (o1 == null) {
                return -1;
            }
            if (o2 == null) {
                return 1;
            }
            return o1.compareTo(o2);
        }

        public int compareTo(Object o) {
            PropertyMap map = (PropertyMap) o;
            int s1 = size();
            int s2 = map.size();
            if (s1 > s2) {
                return 1;
            } else if (s1 < s2) {
                return -1;
            } else {
                Iterator<Map.Entry<OdfName, String>> it1 = entrySet().iterator();
                Iterator<Map.Entry<OdfName, String>> it2 = map.entrySet().iterator();
                // for (int i=0; i<s1; i++) {                    
                while (it1.hasNext() && it2.hasNext()) {
                    Map.Entry<OdfName, String> e1 = it1.next();
                    Map.Entry<OdfName, String> e2 = it2.next();
                    // compare keys
                    int ck = e1.getKey().compareTo(e2.getKey());
                    if (ck == 0) {
                        // key matches, compare values
                        int cv = compare(e1.getValue(), e2.getValue());
                        if (cv != 0) {
                            return cv;
                        }
                    } else {
                        return ck;
                    }
                }
            }
            return 0;
        }
    }
    private static DocumentBuilder m_docbuilder;
    private static Map<OdfStylePropertiesSet, String> m_propertySetNames;
    private OdfStyleCollection m_collection;
    private String m_parentName;
    private String m_name;
    private OdfStyleFamily m_family;
    private String m_nextName;
    private String m_class;
    // unknown stuff
    private SortedMap<String, DocumentFragment> m_unknownFragments =
            new TreeMap<String, DocumentFragment>();
    private DocumentFragment m_unknown;
    /**
     * container for all the property sets
     */
    protected SortedMap<OdfStylePropertiesSet, PropertyMap> m_propertySets =
            new TreeMap<OdfStylePropertiesSet, PropertyMap>();
    

    static {
        m_propertySetNames = new HashMap<OdfStylePropertiesSet, String>();
        m_propertySetNames.put(OdfStylePropertiesSet.TextProperties, "text-properties");
        m_propertySetNames.put(OdfStylePropertiesSet.ParagraphProperties, "paragraph-properties");
        m_propertySetNames.put(OdfStylePropertiesSet.SectionProperties, "section-properties");
        m_propertySetNames.put(OdfStylePropertiesSet.RubyProperties, "ruby-properties");
        m_propertySetNames.put(OdfStylePropertiesSet.TableProperties, "table-properties");
        m_propertySetNames.put(OdfStylePropertiesSet.TableColumnProperties, "table-column-properties");
        m_propertySetNames.put(OdfStylePropertiesSet.TableRowProperties, "table-row-properties");
        m_propertySetNames.put(OdfStylePropertiesSet.TableCellProperties, "table-cell-properties");
        m_propertySetNames.put(OdfStylePropertiesSet.GraphicProperties, "graphic-properties");
        m_propertySetNames.put(OdfStylePropertiesSet.DrawingPageProperties, "drawing-page-properties");
        m_propertySetNames.put(OdfStylePropertiesSet.ChartProperties, "chart-properties");
        m_propertySetNames.put(OdfStylePropertiesSet.ListLevelProperties, "list-level-properties");
    }
    

    static {
        try {
            m_docbuilder = DocumentBuilderFactory.newInstance().newDocumentBuilder();
        } catch (ParserConfigurationException e) {
        }
    }

    /**
     * 
     * @param set
     * @return
     */
    public static String getPropertySetName(OdfStylePropertiesSet set) {
        return m_propertySetNames.get(set);
    }

    /**
     * 
     * @param name
     * @return
     */
    public static OdfStylePropertiesSet getPropertySet(String name) {
        OdfStylePropertiesSet set = null;
        for (Map.Entry<OdfStylePropertiesSet, String> entry : m_propertySetNames.entrySet()) {
            if (entry.getValue().equals(name)) {
                set = entry.getKey();
                break;
            }
        }
        return set;
    }

    /**
     * 
     * @param name
     * @param family
     */
    public OdfStyle(String name, OdfStyleFamily family) {
        this(name, family, null, null, null);
    }

    /**
     * 
     * @param name
     * @param family
     * @param collection
     */
    public OdfStyle(String name, OdfStyleFamily family, OdfStyleCollection collection) {
        this(name, family, null, null, collection);
    }

    /**
     * 
     * @param name
     * @param family
     * @param parent
     */
    public OdfStyle(String name, OdfStyleFamily family, String parent) {
        this(name, family, parent, null, null);
    }

    /**
     * 
     * @param name
     * @param family
     * @param parent
     * @param collection
     */
    public OdfStyle(String name, OdfStyleFamily family, String parent, OdfStyleCollection collection) {
        this(name, family, parent, null, collection);
    }

    /**
     * 
     * @param name
     * @param style
     * @param c
     */
    public OdfStyle(String name, OdfStyle style, OdfStyleCollection c) {
        this(name, style.getFamily(), style.getParentName(), style.getNextName(), c);
        for (Map.Entry<OdfStylePropertiesSet, PropertyMap> entry : style.m_propertySets.entrySet()) {
            OdfStylePropertiesSet set = entry.getKey();
            PropertyMap map = entry.getValue();
            // copy properties into this instance
            for (Map.Entry<OdfName, String> property : map.entrySet()) {
                setProperty(set, property.getKey().getUri(), property.getKey().getLocalName(), property.getValue());
            }
        }
    }

    /**
     * 
     * @param name
     * @param family
     * @param parent
     * @param next
     * @param collection
     */
    public OdfStyle(String name, OdfStyleFamily family, String parent, String next, OdfStyleCollection collection) {
        m_name = name;
        m_family = family;
        m_parentName = parent;
        m_nextName = next;
        m_collection = collection;
        if (m_collection != null) {
            m_collection.addStyle(this);
        }
        if (m_docbuilder != null) {
            Document doc = m_docbuilder.newDocument();
            m_unknown = doc.createDocumentFragment();
        } else {
            throw new RuntimeException("Style subsystem cannot be initialized");
        }
    }

    /**
     * 
     * @return
     */
    public OdfStyle getAsLocalStyle() {
        OdfStyle localStyle = new OdfStyle("#local-style", m_family);
        copyTo(localStyle);
        return localStyle;
    }

    /** 
     * Copy all style properties to the target style
     * @param target 
     */
    public void copyTo(OdfStyle target) {
        target.m_family = m_family;
        target.m_parentName = null;
        target.m_nextName = m_nextName;
        target.m_collection = null;

        // copy all attributes from the given style (and its parents) 
        // to this local style

        // start with unknown properties...
        NodeList lst = m_unknown.getChildNodes();
        for (int i = 0; i < lst.getLength(); i++) {
            Node node = lst.item(i);
            if (node.getNodeType() == Node.ELEMENT_NODE) {
                target.addUnknownProperty(null, (Element) node);
            }
        }

        // then the unknown properties below the OdfStylePropertiesSets...
        for (Map.Entry<String, DocumentFragment> entry : m_unknownFragments.entrySet()) {
            DocumentFragment unknown = entry.getValue();
            lst = unknown.getChildNodes();
            for (int i = 0; i < lst.getLength(); i++) {
                Node node = lst.item(i);
                if (node.getNodeType() == Node.ELEMENT_NODE) {
                    target.addUnknownProperty(entry.getKey(), (Element) node);
                }
            }
        }

        // ... continue with named style property sets ...
        OdfStyle style = this;
        while (style != null) {
            for (Map.Entry<OdfStylePropertiesSet, PropertyMap> entry : style.m_propertySets.entrySet()) {
                OdfStylePropertiesSet set = entry.getKey();
                PropertyMap map = entry.getValue();
                for (Map.Entry<OdfName, String> prop : map.entrySet()) {
                    // copy the property only if it hasn't been set yet
                    OdfName oname = prop.getKey();
                    String value = prop.getValue();
                    String localValue = target.getProperty(set, oname);
                    if (localValue == null) {
                        target.setProperty(set, oname, value);
                    }
                }
            }

            target.m_parentName = style.getParentName();

            // old code which can cause infinite loops:
            //style = style.getParentStyle();

            // new safer code:
            OdfStyle parentStyle = style.getParentStyle();
            if (parentStyle != style) {
                style = parentStyle;
            } else {
                style = null;
            }
        }
    }

    /**
     * 
     * @return
     */
    public OdfStyleFamily getFamily() {
        return m_family;
    }

    /**
     * 
     * @return
     */
    public String getFamilyName() {
        if (m_family != null) {
            return m_family.getName();
        } else {
            return null;
        }
    }

    /**
     * 
     * @return
     */
    public String getNextName() {
        return m_nextName;
    }

    /**
     * 
     * @return
     */
    public String getName() {
        return m_name;
    }

    /**
     * 
     * @return
     */
    public String getParentName() {
        return m_parentName;
    }

    /**
     * 
     * @param name
     */
    public void setParentName(String name) {
        m_parentName = name;
    }

    /**
     * 
     * @return
     */
    public OdfStyle getParentStyle() {
        if (m_parentName != null && m_collection != null) {
            return m_collection.getStyle(m_parentName);
        } else {
            return null;
        }
    }

    /**
     * 
     * @param prop
     * @return
     */
    public String getProperty(OdfStyleProperty prop) {
        return getProperty(prop.getPropertySet(), prop.getName());
    }

    /**
     * 
     * @param set
     * @param uri
     * @param name
     * @return
     */
    public String getProperty(OdfStylePropertiesSet set, String uri, String name) {
        OdfName on = OdfName.get(uri, name);
        return getProperty(set, on, true);
    }

    /**
     * 
     * @param set
     * @param uri
     * @param name
     * @param deep
     * @return
     */
    public String getProperty(OdfStylePropertiesSet set, String uri, String name, boolean deep) {
        OdfName on = OdfName.get(uri, name);
        return getProperty(set, on, deep);
    }

    /**
     * 
     * @param set
     * @param on
     * @return
     */
    protected String getProperty(OdfStylePropertiesSet set, OdfName on) {
        return getProperty(set, on, true);
    }

    /**
     * 
     * @param set
     * @param on
     * @param deep
     * @return
     */
    protected String getProperty(OdfStylePropertiesSet set, OdfName on, boolean deep) {
        // retrieve the property value from the indicated property set...
        String value = null;
        Map<OdfName, String> propertyMap = m_propertySets.get(set);
        if (propertyMap != null) {
            value = propertyMap.get(on);
        }

        // if the property wasn't found here look in the parent style
        if (value == null && deep) {
            OdfStyle ps = getParentStyle();
            if (ps != null) {
                value = ps.getProperty(set, on, deep);
            }
        }
        return value;
    }

    /**
     * get a map containing all properties of this style and their values
     * id the parameter deep is set to true, the map will also include
     * any properties set by parent styles
     * @param deep if true, recurse into parant styles
     * @return 
     */
    public Map<OdfStyleProperty, String> getProperties(boolean deep) {
        TreeMap<OdfStyleProperty, String> result = new TreeMap<OdfStyleProperty, String>();
        OdfStyle style = this;
        while (style != null) {
            for (OdfStylePropertiesSet set : OdfStylePropertiesSet.values()) {
                PropertyMap map = style.m_propertySets.get(set);
                if (map == null) {
                    continue;
                }
                for (Map.Entry<OdfName, String> entry : map.entrySet()) {
                    OdfStyleProperty prop = OdfStyleProperty.get(set, entry.getKey());
                    if (!result.containsKey(prop)) {
                        result.put(prop, entry.getValue());
                    }
                }
            }
            if (deep) {
                style = style.getParentStyle();
            } else {
                style = null;
            }
        }
        return result;
    }

    /**
     * same as getProperties(true)
     * @return 
     */
    public Map<OdfStyleProperty, String> getProperties() {
        return getProperties(true);
    }

    /**
     * 
     * @param prop
     * @param value
     */
    public void setProperty(OdfStyleProperty prop, String value) {
        setProperty(prop.getPropertySet(), prop.getName(), value);
    }

    /**
     * 
     * @param set
     * @param ns
     * @param name
     * @param value
     */
    public void setProperty(OdfStylePropertiesSet set, OdfNamespace ns, String name, String value) {
        OdfName on = OdfName.get(ns, name);
        setProperty(set, on, value);
    }

    /**
     * 
     * @param set
     * @param uri
     * @param name
     * @param value
     */
    public void setProperty(OdfStylePropertiesSet set, String uri, String name, String value) {
        OdfName on = OdfName.get(uri, name);
        setProperty(set, on, value);
    }

    /**
     * 
     * @param set
     * @param oname
     * @param value
     */
    protected void setProperty(OdfStylePropertiesSet set, OdfName oname, String value) {
        PropertyMap map = m_propertySets.get(set);
        if (map == null) {
            map = new PropertyMap(set);
            m_propertySets.put(set, map);
        }
        map.put(oname, value);
    }

    /**
     * 
     * @param set
     * @param e
     */
    public void addUnknownProperty(String set, Element e) {
        if (set == null) {
            Node n = m_unknown.getOwnerDocument().importNode(e, true);
            m_unknown.appendChild(n);
        } else {
            DocumentFragment unknown = m_unknownFragments.get(set);
            if (null == unknown) {
                Document doc = m_docbuilder.newDocument();
                unknown = doc.createDocumentFragment();
                m_unknownFragments.put(set, unknown);
            }
            Node n = unknown.getOwnerDocument().importNode(e, true);
            unknown.appendChild(n);
        }
    }

    /**
     * 
     * @return
     */
    public DocumentFragment getUnknownProperties() {
        return m_unknown;
    }

    // create string representation for debugging
    @Override
    public String toString() {
        StringBuffer sb = new StringBuffer();
        sb.append(m_name + " [" + m_family + "] {");
        if (m_parentName != null) {
            sb.append("(parent: " + m_parentName + ") ");
        }
        for (Map.Entry<OdfStylePropertiesSet, PropertyMap> entry : m_propertySets.entrySet()) {
            sb.append(getPropertySetName(entry.getKey()) + "->");
            for (Map.Entry<OdfName, String> prop : entry.getValue().entrySet()) {
                sb.append(prop.getKey().getLocalName() + ":" + prop.getValue());
                sb.append(";");
            }
        }
        sb.append("}");
        return sb.toString();
    }

    /**
     * add a properties element to a style element
     * @param node 
     */
    public void appendToNode(Node node) {
        appendToNode(node, OdfNamespace.STYLE.getUri(), "style:style");
    }

    /**
     * 
     * @param node
     * @param uri
     * @param qname
     */
    protected void appendToNode(Node node, String uri, String qname) {
        Document doc = node.getOwnerDocument();
        Element style = doc.createElementNS(uri, qname);
        // set the style element attributes        
        if (m_name != null) {
            style.setAttributeNS(OdfNamespace.STYLE.getUri(), "style:name", m_name);
        }
        if (m_family != null) {
            style.setAttributeNS(OdfNamespace.STYLE.getUri(), "style:family", getFamilyName());
        }
        if (m_parentName != null) {
            style.setAttributeNS(OdfNamespace.STYLE.getUri(), "style:parent-style-name", m_parentName);
        }
        if (m_nextName != null) {
            style.setAttributeNS(OdfNamespace.STYLE.getUri(), "style:next-style-name", m_nextName);
        }
        if (m_class != null) {
            style.setAttributeNS(OdfNamespace.STYLE.getUri(), "style:class", m_class);
        }

        // create the properties...
        for (Map.Entry<OdfStylePropertiesSet, PropertyMap> entry : m_propertySets.entrySet()) {
            entry.getValue().appendPropertySetToNode(style);
        }

        node.appendChild(style);

        // add general unkown properties        
        Node imported = doc.importNode(m_unknown, true);
        style.appendChild(imported);

        // add unknown properties to child properties
        NodeList lst = style.getChildNodes();
        for (int i = 0; i < lst.getLength(); ++i) {
            Node childNode = lst.item(i);
            if (childNode.getNodeType() == Node.ELEMENT_NODE) {
                Element element = (Element) childNode;
                String keyString = element.getLocalName();
                DocumentFragment unknown = m_unknownFragments.get(keyString);
                if (unknown != null) {
                    imported = doc.importNode(unknown, true);
                    element.appendChild(imported);
                }
            }
        }
    }

    @Override
    public boolean equals(Object obj) {
        if (obj == null || !(obj instanceof OdfStyle)) {
            return false;
        }
        OdfStyle style = (OdfStyle) obj;
        return compareTo(style) == 0;
    }

    // wrapper for calling compareTo for two objects handling null references
    private int compare(Object o1, Object o2) {
        if (o1 == null && o2 == null) {
            return 0;
        }
        if (o1 != null && o2 == null) {
            return 1;
        }
        if (o1 == null && o2 != null) {
            return -1;
        }
        return ((Comparable) o1).compareTo(o2);
    }

    public int compareTo(Object obj) {

        if (obj == null) {
            return 1;
        }

        OdfStyle style = (OdfStyle) obj;
        int c = 0;

        // compare top-level properties, stop comparing as soon as the first 
        // difference is (compare != 0) is detected
        if ((c = compare(m_family, style.m_family)) != 0) {
            return c;
        }
        if ((c = compare(m_nextName, style.m_nextName)) != 0) {
            return c;
        }
        if ((c = compare(m_parentName, style.m_parentName)) != 0) {
            return c;
        }
        if ((c = compare(m_class, style.m_class)) != 0) {
            return c;
        }

        // compare the number of stored property sets
        if ((c = compare(Integer.valueOf(m_propertySets.size()),
                Integer.valueOf(style.m_propertySets.size()))) != 0) {
            return c;
        }

        // same number of property sets, compare individual sets
        for (Map.Entry<OdfStylePropertiesSet, PropertyMap> entry : m_propertySets.entrySet()) {
            OdfStylePropertiesSet set = entry.getKey();
            PropertyMap map1 = entry.getValue();
            PropertyMap map2 = style.m_propertySets.get(set);
            if ((c = compare(map1, map2)) != 0) {
                return c;
            }
        }

        // no differences found, styles are equal
        return 0;
    }
}
