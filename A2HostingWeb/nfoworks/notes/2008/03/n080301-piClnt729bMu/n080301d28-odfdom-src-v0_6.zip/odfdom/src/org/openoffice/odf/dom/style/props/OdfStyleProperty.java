/************************************************************************
 *
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS FILE HEADER.
 * 
 * Copyright 2008 by Sun Microsystems, Inc.
 *
 * OpenOffice.org - a multi-platform office productivity suite
 *
 * $RCSfile: $
 * $Revision: $
 *
 * This file is part of OpenOffice.org.
 *
 * OpenOffice.org is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License version 3
 * only, as published by the Free Software Foundation.
 *
 * OpenOffice.org is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License version 3 for more details
 * (a copy is included in the LICENSE file that accompanied this code).
 *
 * You should have received a copy of the GNU Lesser General Public License
 * version 3 along with OpenOffice.org.  If not, see
 * <http://www.openoffice.org/license.html>
 * for a copy of the LGPLv3 License.
 *
 ************************************************************************/
package org.openoffice.odf.dom.style.props;

import java.util.TreeSet;
import org.openoffice.odf.dom.OdfName;

/**
 * Class to represent a odf style attribut. Each instance has a name and belongs
 * to an ODF style-properties element. 
 */
public class OdfStyleProperty implements Comparable {

    private OdfStylePropertiesSet m_propSet;
    private OdfName m_name;

    private OdfStyleProperty(OdfStylePropertiesSet propSet, OdfName name) {
        m_propSet = propSet;
        m_name = name;
    }
    private static TreeSet<OdfStyleProperty> m_styleProperties = new TreeSet<OdfStyleProperty>();

    /**
     * Looks if an OdfStyleProperty is already listed in the static sytleProperties set,
     * otherwise creates a new one.
     * @param propSet an OdfStylePropertiesSet member
     * @param name
     * @return new created or existing OdfStylePorperty
     */
    public static OdfStyleProperty get(OdfStylePropertiesSet propSet, OdfName name) {
        OdfStyleProperty temp = new OdfStyleProperty(propSet, name);
        OdfStyleProperty result = m_styleProperties.floor(temp);
        if (temp.equals(result)) {
            return result;
        } else {
            m_styleProperties.add(temp);
            return temp;
        }
    }

    /**
     * 
     * @return an OdfStylePropertiesSet member 
     */
    public OdfStylePropertiesSet getPropertySet() {
        return m_propSet;
    }

    /**
     * 
     * @return name of OdfStyleProperty instance
     */
    public OdfName getName() {
        return m_name;
    }

    /** 
     * @inheritDoc
     */
    @Override
    public String toString() {
        return m_name.getQName();
    }

    public OdfStyleProperty copy() {
        OdfStyleProperty clone = new OdfStyleProperty(m_propSet, m_name);
        return clone;
    }

    /** 
     * @inheritDoc
     */
    @Override
    public int hashCode() {
        int hash = 3;
        hash = 83 * hash + (this.m_propSet != null ? this.m_propSet.hashCode() : 0);
        hash = 83 * hash + (this.m_name != null ? this.m_name.hashCode() : 0);
        return hash;
    }

    /** 
     * @inheritDoc
     */
    @Override
    public boolean equals(Object o) {
        return compareTo(o) == 0;
    }

    public int compareTo(Object o) {
        if (!(o instanceof OdfStyleProperty)) {
            return -1;
        }
        OdfStyleProperty prop = (OdfStyleProperty) o;
        int c = 0;
        if ((c = m_propSet.compareTo(prop.m_propSet)) != 0) {
            return c;
        }
        if ((c = m_name.compareTo(prop.m_name)) != 0) {
            return c;
        }
        // all is equal...
        return 0;
    }
}
