/************************************************************************
 *
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS FILE HEADER.
 * 
 * Copyright 2008 by Sun Microsystems, Inc.
 *
 * OpenOffice.org - a multi-platform office productivity suite
 *
 * $RCSfile: $
 * $Revision: $
 *
 * This file is part of OpenOffice.org.
 *
 * OpenOffice.org is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License version 3
 * only, as published by the Free Software Foundation.
 *
 * OpenOffice.org is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License version 3 for more details
 * (a copy is included in the LICENSE file that accompanied this code).
 *
 * You should have received a copy of the GNU Lesser General Public License
 * version 3 along with OpenOffice.org.  If not, see
 * <http://www.openoffice.org/license.html>
 * for a copy of the LGPLv3 License.
 *
 ************************************************************************/
// !!! GENERATED SOURCE CODE !!!
package org.openoffice.odf.dom.style.props;

import org.openoffice.odf.dom.OdfName;
import org.openoffice.odf.dom.OdfNamespace;

public interface OdfDrawingPageProperties {
    public final static OdfStyleProperty BackgroundSize = 
        OdfStyleProperty.get(OdfStylePropertiesSet.DrawingPageProperties, OdfName.get(OdfNamespace.DRAW, "background-size"));
    public final static OdfStyleProperty BackgroundObjectsVisible = 
        OdfStyleProperty.get(OdfStylePropertiesSet.DrawingPageProperties, OdfName.get(OdfNamespace.PRESENTATION, "background-objects-visible"));
    public final static OdfStyleProperty BackgroundVisible = 
        OdfStyleProperty.get(OdfStylePropertiesSet.DrawingPageProperties, OdfName.get(OdfNamespace.PRESENTATION, "background-visible"));
    public final static OdfStyleProperty DisplayDateTime = 
        OdfStyleProperty.get(OdfStylePropertiesSet.DrawingPageProperties, OdfName.get(OdfNamespace.PRESENTATION, "display-date-time"));
    public final static OdfStyleProperty DisplayFooter = 
        OdfStyleProperty.get(OdfStylePropertiesSet.DrawingPageProperties, OdfName.get(OdfNamespace.PRESENTATION, "display-footer"));
    public final static OdfStyleProperty DisplayHeader = 
        OdfStyleProperty.get(OdfStylePropertiesSet.DrawingPageProperties, OdfName.get(OdfNamespace.PRESENTATION, "display-header"));
    public final static OdfStyleProperty DisplayPageNumber = 
        OdfStyleProperty.get(OdfStylePropertiesSet.DrawingPageProperties, OdfName.get(OdfNamespace.PRESENTATION, "display-page-number"));
    public final static OdfStyleProperty Duration = 
        OdfStyleProperty.get(OdfStylePropertiesSet.DrawingPageProperties, OdfName.get(OdfNamespace.PRESENTATION, "duration"));
    public final static OdfStyleProperty TransitionSpeed = 
        OdfStyleProperty.get(OdfStylePropertiesSet.DrawingPageProperties, OdfName.get(OdfNamespace.PRESENTATION, "transition-speed"));
    public final static OdfStyleProperty TransitionStyle = 
        OdfStyleProperty.get(OdfStylePropertiesSet.DrawingPageProperties, OdfName.get(OdfNamespace.PRESENTATION, "transition-style"));
    public final static OdfStyleProperty TransitionType = 
        OdfStyleProperty.get(OdfStylePropertiesSet.DrawingPageProperties, OdfName.get(OdfNamespace.PRESENTATION, "transition-type"));
    public final static OdfStyleProperty Visibility = 
        OdfStyleProperty.get(OdfStylePropertiesSet.DrawingPageProperties, OdfName.get(OdfNamespace.PRESENTATION, "visibility"));
    public final static OdfStyleProperty Direction = 
        OdfStyleProperty.get(OdfStylePropertiesSet.DrawingPageProperties, OdfName.get(OdfNamespace.SMIL, "direction"));
    public final static OdfStyleProperty Fadecolor = 
        OdfStyleProperty.get(OdfStylePropertiesSet.DrawingPageProperties, OdfName.get(OdfNamespace.SMIL, "fadeColor"));
    public final static OdfStyleProperty Subtype = 
        OdfStyleProperty.get(OdfStylePropertiesSet.DrawingPageProperties, OdfName.get(OdfNamespace.SMIL, "subtype"));
}
