/************************************************************************
 *
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS FILE HEADER.
 * 
 * Copyright 2008 by Sun Microsystems, Inc.
 *
 * OpenOffice.org - a multi-platform office productivity suite
 *
 * $RCSfile: $
 * $Revision: $
 *
 *
 * OpenOffice.org is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License version 3
 * only, as published by the Free Software Foundation.
 *
 * OpenOffice.org is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License version 3 for more details
 * (a copy is included in the LICENSE file that accompanied this code).
 *
 * You should have received a copy of the GNU Lesser General Public License
 * version 3 along with OpenOffice.org.  If not, see
 * <http://www.openoffice.org/license.html>
 * for a copy of the LGPLv3 License.
 *
 ************************************************************************/
package org.openoffice.odf.dom.type;
        
public class OdfRelLength {
 
    // TODO: Should a rel length stay a string?
    public static String toString( String _aLength )
    {
        if( !(_aLength.equals( "scale" ) || _aLength.equals("scale-min") ||
               _aLength.matches("^-?([0-9]+(\\.[0-9]*)?|\\.[0-9]+)%$") ) )
            throw new IllegalArgumentException( "Illegal relative length");
        return _aLength;
    }

    public static String valueOf( String _aStringValue )
    {
        return _aStringValue;
    }
}
