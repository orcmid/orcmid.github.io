/************************************************************************
 *
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS FILE HEADER.
 * 
 * Copyright 2008 by Sun Microsystems, Inc.
 *
 * OpenOffice.org - a multi-platform office productivity suite
 *
 * $RCSfile: $
 * $Revision: $
 *
 *
 * OpenOffice.org is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License version 3
 * only, as published by the Free Software Foundation.
 *
 * OpenOffice.org is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License version 3 for more details
 * (a copy is included in the LICENSE file that accompanied this code).
 *
 * You should have received a copy of the GNU Lesser General Public License
 * version 3 along with OpenOffice.org.  If not, see
 * <http://www.openoffice.org/license.html>
 * for a copy of the LGPLv3 License.
 *
 ************************************************************************/
package org.openoffice.odf.doc;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.net.JarURLConnection;
import java.net.MalformedURLException;
import java.net.URI;
import java.net.URISyntaxException;
import java.net.URL;
import java.util.Stack;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.Source;
import javax.xml.transform.TransformerException;
import javax.xml.transform.URIResolver;
import javax.xml.transform.stream.StreamSource;
import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathConstants;
import javax.xml.xpath.XPathExpressionException;
import javax.xml.xpath.XPathFactory;
import org.apache.xerces.parsers.SAXParser;
import org.openoffice.odf.doc.element.table.OdfTableColumn;
import org.openoffice.odf.doc.element.text.OdfList;
import org.openoffice.odf.doc.style.DocumentStyleHandler;
import org.openoffice.odf.doc.style.OdfAutoStylePool;
import org.openoffice.odf.doc.style.StyleSectionHandler;
import org.openoffice.odf.dom.OdfName;
import org.openoffice.odf.dom.OdfNamespace;
import org.openoffice.odf.dom.element.OdfElement;
import org.openoffice.odf.dom.element.OdfStylableElement;
import org.openoffice.odf.dom.style.OdfListStyle;
import org.openoffice.odf.dom.style.OdfStyle;
import org.openoffice.odf.dom.style.OdfStyleCollection;
import org.openoffice.odf.dom.util.NodeAction;
import org.openoffice.odf.pkg.OdfPackage;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.Text;
import org.xml.sax.Attributes;
import org.xml.sax.ContentHandler;
import org.xml.sax.EntityResolver;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;

public class OdfDocument {

    public static String MIME_TYPE_ODF_FORMULA = "application/vnd.oasis.opendocument.formula";
    public static String MIME_TYPE_ODF_GRAPHICS = "application/vnd.oasis.opendocument.graphics";
    public static String MIME_TYPE_ODF_PRESENTATION = "application/vnd.oasis.opendocument.presentation";
    public static String MIME_TYPE_ODF_SPREADSHEET = "application/vnd.oasis.opendocument.spreadsheet";
    public static String MIME_TYPE_ODF_TEXT = "application/vnd.oasis.opendocument.text";
    private OdfPackage mPackage;
    private OdfStyleCollection mDocumentStyles;
    private OdfStyleCollection mAutomaticStyles;
    private OdfStyleCollection mDefaultStyles;
    private OdfFileDom mContentDom;
//    private OdfFileDom mStylesDom;
//    private OdfFileDom mSettingsDom;
//    private OdfFileDom mMetaDom;
    private XPath mXPath;

    /**
     * Creates an OdfDocument from the OpenDocument provided by a path.
     *
     * @param path - the path to the ODF document.
     * @throws java.lang.Exception - if the document could not be created
     */
    public OdfDocument(String path) throws Exception {
        mPackage = new OdfPackage(path);
        initialize(this);
    }

    /**
     * Creates an OdfDocument from the OpenDocument provided by a File.
     *
     * @param file - a file representing the ODF document
     * @throws java.lang.Exception - if the document could not be created
     */
    public OdfDocument(File file) throws Exception {
        mPackage = new OdfPackage(file);
        initialize(this);
    }

    /**
     * Creates an OdfDocument from the OpenDocument provided by an ODF package.
     *
     * @param odfPackage - the ODF package view on the ODF document
     * @throws java.lang.Exception - if the document could not be created
     */
    public OdfDocument(OdfPackage odfPackage) throws Exception {
        mPackage = odfPackage;
        initialize(this);
    }

    /**
     * Load a document from given path.
     *
     * @param path - the local path to the file
     * @return the OpenDocument represented by an OdfDocument
     * @throws java.lang.Exception 
     */
    public static OdfDocument load(String path) throws Exception {
        return new OdfDocument(path);
    }

    /**
     * Loads an OdfDocument from the OpenDocument provided by a File.
     *
     * @param file - a File to load content from
     * @return the OpenDocument represented by an OdfDocument
     * @throws java.lang.Exception - if the document could not be created
     */
    public static OdfDocument load(File file) throws Exception {
        return new OdfDocument(file);
    }

    /**
     * Get the URI, where this ODF document is stored. 
     * @return the URI to the ODF document. Returns null if document is not stored yet.
     */
    public String getBaseURI() {
        return mPackage.getBaseURI();
    }

    void setDocumentStyles(OdfStyleCollection c) {
        mDocumentStyles = c;
    }

    public OdfStyleCollection getDocumentStyles() {
        return mDocumentStyles;
    }

    void setDefaultStyles(OdfStyleCollection c) {
        mDefaultStyles = c;
    }

    public OdfStyleCollection getDefaultStyles() {
        return mDefaultStyles;
    }

    void setAutomaticStyles(OdfStyleCollection c) {
        mAutomaticStyles = c;
    }

    /** Get the collection of automatic styles after loading.
     *  NOTE: 
     *  This method will be removed when cell range style handling is moved
     *  into odfdom.
     * @return automatic styles collection
     */
    public OdfStyleCollection getAutomaticStylesInternal() {
        return mAutomaticStyles;
    }

    public OdfStyleCollection getAutomaticStyles() {
        // node action to collect all the local styles into the autostyle pool
        NodeAction<OdfAutoStylePool> collectStyles = new NodeAction<OdfAutoStylePool>() {

            protected void apply(Node cur, OdfAutoStylePool pool, int depth) {
                if (cur instanceof OdfStylableElement) {
                    OdfStylableElement se = (OdfStylableElement) cur;
                    if (se.hasAutomaticStyle()) {
                        OdfStyle ls = se.getAutomaticStyle();
                        String name = pool.addStyle(ls);
                        String oldname = se.getStyleName();
                        se.setStyleName(name);
                    }
                // 2DO: What is the complete list of automatic stlye capabable elements, which have to be checked?                    
                } else if (cur instanceof OdfList) {
                    OdfList le = (OdfList) cur;
                    OdfListStyle ls = le.getListStyle();
                    if (ls != null && ls.getName().equals("#local-list-style")) {
                        String name = pool.addListStyle(ls);
                        String oldname = le.getStyleName();
                        if (!oldname.isEmpty()) {
                            le.setStyleName(name);
                        }
                    }
                } else if (cur instanceof OdfTableColumn) {
                    OdfTableColumn tce = (OdfTableColumn) cur;
                    OdfStyle cs = tce.getDefaultCellStyle();
                    if (cs != null) {
                        String name = pool.addStyle(cs);
                        tce.setDefaultCellStyleName(name);
                    }
                }
            }
        };

        OdfAutoStylePool pool = new OdfAutoStylePool();
        collectStyles.performAction(mContentDom.getDocumentElement(), pool);

        OdfStyleCollection ac = pool.getStyleCollection();
        mAutomaticStyles = ac;
        return mAutomaticStyles;
    }

    public OdfFileDom getContent() {
        try {
            // gather the current used auomatic styles from the content..
            OdfStyleCollection styles = getAutomaticStyles();
            // create a new "office:automatic-styles" element 
            OdfElement newAutoStyleElement = (OdfElement) mContentDom.createElementNS(OdfNamespace.OFFICE.getUri(), "office:automatic-styles");
            // fill the new element with the gathered style information (subelements)
            styles.appendToNode(newAutoStyleElement);

            // XPath initialization
            XPath xpath = getXPath();
            // receives a possible existent "office:automatic-styles" element 
            OdfElement autoStyleElement = (OdfElement) xpath.evaluate("/office:document-content/office:automatic-styles", mContentDom, XPathConstants.NODE);

            if (autoStyleElement != null) {
                // insert automatic styles with existent...
                Node replaceChild = mContentDom.getDocumentElement().replaceChild(newAutoStyleElement, autoStyleElement);
            } else {
                // get "office:body" element, where ahead "office:automatic-styles" should be inserted
                OdfElement bodyElement = (OdfElement) xpath.evaluate("/office:document-content/office:body", mContentDom, XPathConstants.NODE);
                // insert automatic styles...
                mContentDom.getDocumentElement().insertBefore(newAutoStyleElement, bodyElement);
            }
        } catch (XPathExpressionException ex) {
            Logger.getLogger(OdfDocument.class.getName()).log(Level.SEVERE, null, ex);
        }
        return mContentDom;
    }

    /** Temporary performance solution as getContent() does performAction all automatic styles into the DOM
     * @return DOM of content.xml file with not refreshed automatic styles
     */
    public OdfFileDom getContentCached() {
        return mContentDom;
    }

    private XPath getXPath() {
        if (mXPath == null) {
            mXPath = XPathFactory.newInstance().newXPath();
            mXPath.setNamespaceContext(new OdfNamespace());
        }
        return mXPath;
    }

    public Document getStyles() {
        Document doc = null;
        try {
            doc = DocumentBuilderFactory.newInstance().newDocumentBuilder().newDocument();
            Element ds = doc.createElementNS(OdfNamespace.OFFICE.getUri(), "office:document-styles");
            doc.appendChild(ds);

            OdfStyleCollection styles = getDocumentStyles();

            ds.appendChild(doc.importNode(styles.getFontFaceDecls(), true));
            Element officeStyles = doc.createElementNS(OdfNamespace.OFFICE.getUri(), "office:styles");
            ds.appendChild(officeStyles);
            styles.appendToNode(officeStyles);


            // unkown content from styles contentDom
            Node imported = doc.importNode(styles.getUnkownContent(), true);
            ds.appendChild(imported);
        } catch (ParserConfigurationException ex) {
            Logger.getLogger(OdfDocument.class.getName()).log(Level.SEVERE, null, ex);
        }
        return doc;
    }

    public OdfPackage getOdfPackage() {
        return mPackage;
    }

    /**
     * Get the mimetype
     * 
     * @return the MIMETYPE string of this package
     */
    public String getMimetype() {
        return mPackage.getMimetype();
    }

    /**
     * Save the document to given path.
     *
     * @param path - the path to the file
     * @throws java.lang.Exception  if the document could not be saved
     */
    public void save(String path) throws Exception {
        mPackage.insert(mContentDom, "content.xml");
        mPackage.save(path);
    }
    
    /**
     * Save the document to given file.
     *
     * @param file - the file to save the document
     * @throws java.lang.Exception  if the document could not be saved
     */
    public void save(File file) throws Exception {
        mPackage.insert(mContentDom, "content.xml");
        mPackage.save(file);
    }    
    
    private Resolver mResolver;

    /**
     * get EntityResolver to be used in XML Parsers
     * which can resolve content inside the OdfPackage
     */
    EntityResolver getEntityResolver() {
        if (mResolver == null) {
            mResolver = new Resolver();
        }
        return mResolver;
    }

    /**
     * get URIResolver to be used in XSL Transformations
     * which can resolve content inside the OdfPackage
     */
    URIResolver getURIResolver() {
        if (mResolver == null) {
            mResolver = new Resolver();
        }
        return mResolver;
    }
 
    /**
     * resolve external entities
     */
    private class Resolver implements EntityResolver, URIResolver {

        /**
         * Resolver constructor.
         */
        public Resolver() {
        }

        /**
         * Allow the application to resolve external entities.
         *
         * The Parser will call this method before opening any external entity except
         * the top-level document entity (including the external DTD subset,
         * external entities referenced within the DTD, and external entities referenced
         * within the document element): the application may request that the parser
         * resolve the entity itself, that it use an alternative URI,
         * or that it use an entirely different input source.
         */
        public InputSource resolveEntity(String publicId, String systemId)
                throws SAXException, IOException {

            if (systemId != null) {
                if ((mPackage.getBaseURI() != null) && systemId.startsWith(mPackage.getBaseURI())) {
                    if (systemId.equals(mPackage.getBaseURI())) {
                        InputStream in = null;
                        try {
                            in = mPackage.getInputStream();
                        } catch (Exception e) {
                            throw new SAXException(e);
                        }
                        InputSource ins;
                        ins = new InputSource(in);

                        if (ins == null) {
                            return null;
                        }
                        ins.setSystemId(systemId);
                        return ins;
                    } else {
                        if (systemId.length() > mPackage.getBaseURI().length() + 1) {
                            InputStream in = null;
                            try {
                                String path = systemId.substring(mPackage.getBaseURI().length() + 1);
                                in = mPackage.getInputStream(path);
                                InputSource ins = new InputSource(in);
                                ins.setSystemId(systemId);
                                return ins;
                            } catch (Exception ex) {
                                Logger.getLogger(OdfDocument.class.getName()).log(Level.SEVERE, null, ex);
                            } finally {
                                try {
                                    in.close();
                                } catch (IOException ex) {
                                    Logger.getLogger(OdfDocument.class.getName()).log(Level.SEVERE, null, ex);
                                }
                            }
                        }
                        return null;
                    }
                } else if (systemId.startsWith("resource:/")) {
                    int i = systemId.indexOf('/');
                    if ((i > 0) && systemId.length() > i + 1) {
                        String res = systemId.substring(i + 1);
                        ClassLoader cl = OdfPackage.class.getClassLoader();
                        InputStream in = cl.getResourceAsStream(res);
                        if (in != null) {
                            InputSource ins = new InputSource(in);
                            ins.setSystemId(systemId);
                            return ins;
                        }
                    }
                    return null;
                } else if (systemId.startsWith("jar:")) {
                    try {
                        URL url = new URL(systemId);
                        JarURLConnection jarConn = (JarURLConnection) url.openConnection();
                        InputSource ins = new InputSource(jarConn.getInputStream());
                        ins.setSystemId(systemId);
                        return ins;
                    } catch (MalformedURLException me) {
                        throw new SAXException(me); // Incorrect URL format used
                    }
                }
            }
            return null;
        }

        public Source resolve(String href, String base)
                throws TransformerException {
            try {
                URI uri = null;
                if (base != null) {
                    URI baseuri = new URI(base);
                    uri = baseuri.resolve(href);
                } else {
                    uri = new URI(href);
                }

                InputSource ins = null;
                try {
                    ins = resolveEntity(null, uri.toString());
                } catch (Exception e) {
                    throw new TransformerException(e);
                }
                if (ins == null) {
                    return null;
                }
                InputStream in = ins.getByteStream();
                StreamSource src = new StreamSource(in);
                return src;
            } catch (URISyntaxException use) {
                return null;
            }
        }
    }
    private static OdfName mAutomaticStylesElementName = OdfName.get(
            OdfNamespace.OFFICE, "automatic-styles");
    private static OdfName mStylesElementName = OdfName.get(
            OdfNamespace.OFFICE, "styles");

    private OdfDocument initialize(OdfDocument odfDocument) throws Exception {
        // create sax parser
        SAXParser parser = new SAXParser();

        // initialize the input source's content.xml
        mContentDom = new OdfFileDom(odfDocument, "content.xml");
        Handler handler = new Handler(mContentDom);
        parser.setContentHandler(handler);
        InputSource contentSource = new InputSource(odfDocument.getOdfPackage().getContentStream());
        parser.parse(contentSource);
        odfDocument.setAutomaticStyles(handler.getLocalStyles());

        // initialize the document styles from the package
        parser.reset();
        OdfStyleCollection documentStyles = new OdfStyleCollection();
        OdfStyleCollection defaultStyles = new OdfStyleCollection();
        DocumentStyleHandler sh = new DocumentStyleHandler(documentStyles, defaultStyles);
        parser.setContentHandler(sh);
        InputSource styleSource = new InputSource(odfDocument.getOdfPackage().getStylesStream());
        parser.parse(styleSource);
        odfDocument.setDocumentStyles(documentStyles);
        odfDocument.setDefaultStyles(defaultStyles);


        // meta data & settings -- 2DO: better DOM on demand...
        // ...        

        return odfDocument;
    }

    private class Handler extends DefaultHandler {
        // the empty document to which nodes will be added
        private OdfFileDom m_document;
        private Node m_root;
        // the context node 
        private Node m_node;
        private OdfStyleCollection m_automaticStyles = new OdfStyleCollection();

        OdfStyleCollection getLocalStyles() {
            return m_automaticStyles;
        }
        // a stack of sub handlers. handlers will be pushed on the stack whenever
        // they are required and must pop themselves from the stack when done
        private Stack<ContentHandler> m_handlerStack = new Stack<ContentHandler>();

        Handler(Node root) {
            m_root = root;
            if (m_root instanceof OdfFileDom) {
                m_document = (OdfFileDom) m_root;
            } else {
                m_document = (OdfFileDom) m_root.getOwnerDocument();
            }
            m_node = m_root;
        }

        @Override
        public void startDocument() throws SAXException {
        }

        @Override
        public void endDocument() throws SAXException {
        }

        @Override
        public void endElement(String uri, String localName, String qName) throws SAXException {
            if (!m_handlerStack.empty()) {
                (m_handlerStack.peek()).endElement(uri, localName, qName);
            } else {
                // pop to the parent node
                m_node = m_node.getParentNode();
            }
        }

        @Override
        public void startElement(String uri, String localName, String qName, Attributes attributes) throws SAXException {
            // if there is a specilized handler on the stack, dispatch the event 
            OdfName on = OdfName.get(uri, qName);
            if (!m_handlerStack.empty()) {
                m_handlerStack.peek().startElement(
                        uri, localName, qName, attributes);
            } else if (on.equals(mAutomaticStylesElementName)) {
                // let the autostyle handler handle automatic styles
                ContentHandler autoHandler = new StyleSectionHandler(on, m_handlerStack, m_automaticStyles, null);
                m_handlerStack.push(autoHandler);
            } else {
                Element element = m_document.createElementNS(uri, qName);
                for (int i = 0; i < attributes.getLength(); i++) {
                    element.setAttributeNS(attributes.getURI(i),
                            attributes.getQName(i), attributes.getValue(i));
                }
                // move local styles to elements that use them...
                if (element instanceof OdfStylableElement) {
                    OdfStylableElement ste = (OdfStylableElement) element;
                    String styleName = ste.getStyleName();
                    if (styleName != null) {
                        OdfStyle style = m_automaticStyles.getStyle(styleName);
                        if (style != null) {
                            ste.setLocalStyleProperties(style);
                        }
                    }
                } else if (element instanceof OdfList) {
                    OdfList le = (OdfList) element;
                    String styleName = le.getStyleName();
                    if (styleName != null) {
                        OdfListStyle style = m_automaticStyles.getListStyle(styleName);
                        if (style != null) {
                            le.setLocalListStyle(style);
                        }
                    }
                } else if (element instanceof OdfTableColumn) {
                    OdfTableColumn tc = (OdfTableColumn) element;
                    String styleName = tc.getDefaultCellStyleName();
                    if (styleName != null) {
                        OdfStyle style = m_automaticStyles.getStyle(styleName);
                        if (style != null) {
                            tc.setDefaultCellStyle(style);
                        }
                    }
                }

                // add the new element as a child of the current context node
                m_node.appendChild(element);
                // push the new element as the context node...
                m_node = element;
            }
        }

        @Override
        public void characters(char[] ch, int start, int length) throws SAXException {
            if (!m_handlerStack.empty()) {
                m_handlerStack.peek().characters(ch, start, length);
            } else {
                Text text = m_document.createTextNode(new String(ch, start, length));
                m_node.appendChild(text);
            }
        }

        @Override
        public InputSource resolveEntity(String publicId, String systemId) throws IOException, SAXException {
            return super.resolveEntity(publicId, systemId);
        }
    }
    private static final String TO_STRING_METHOD_TOKEN = "\nID: ";

    @Override
    public String toString() {
        return TO_STRING_METHOD_TOKEN + this.hashCode() + " " + mPackage.getBaseURI();
    }
}
