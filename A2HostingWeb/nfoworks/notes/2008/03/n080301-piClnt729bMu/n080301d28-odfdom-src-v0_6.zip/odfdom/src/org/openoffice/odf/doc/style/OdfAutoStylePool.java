/************************************************************************
 *
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS FILE HEADER.
 * 
 * Copyright 2008 by Sun Microsystems, Inc.
 *
 * OpenOffice.org - a multi-platform office productivity suite
 *
 * $RCSfile: $
 * $Revision: $
 *
 * This file is part of OpenOffice.org.
 *
 * OpenOffice.org is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License version 3
 * only, as published by the Free Software Foundation.
 *
 * OpenOffice.org is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License version 3 for more details
 * (a copy is included in the LICENSE file that accompanied this code).
 *
 * You should have received a copy of the GNU Lesser General Public License
 * version 3 along with OpenOffice.org.  If not, see
 * <http://www.openoffice.org/license.html>
 * for a copy of the LGPLv3 License.
 *
 ************************************************************************/
package org.openoffice.odf.doc.style;

import org.openoffice.odf.dom.style.OdfStyleCollection;
import org.openoffice.odf.dom.style.OdfStyle;
import org.openoffice.odf.dom.style.OdfListStyle;
import java.util.TreeSet;
import java.util.SortedSet;

/**
 * This class holds sets of automatic and list styles occuring in the ODF document.
 * Multiple automatic style instances with equal styling should not exist.
 */
public class OdfAutoStylePool {

    private SortedSet<OdfStyle> m_styles = new TreeSet<OdfStyle>();
    private SortedSet<OdfListStyle> m_listStyles = new TreeSet<OdfListStyle>();

    /**
     * Creates a new instance of AutoStylePool
     */
    public OdfAutoStylePool() {
    }

    /**
     * adds a style, if not already existing, to the auto-style pool
     * @param style to add
     * @return new name by which the style can be referenced
     */
    public String addStyle(OdfStyle style) {
        // check whether there is already an equal style in the collection
        OdfStyle autoStyle = null;
        SortedSet<OdfStyle> tail = m_styles.tailSet(style);
        if (tail.size() > 0) {
            autoStyle = tail.first();
            if (autoStyle.equals(style)) {
                return autoStyle.getName();
            }
        }

        // no matching style found, add this style to the pool
        String name = "A" + m_styles.size();
        autoStyle = new OdfStyle(name, style, null);
        m_styles.add(autoStyle);
        return name;
    }

    /**
     * adds a list style, if not already existing, to the auto-style pool
     * @param style to add
     * @return new name by which the style can be referenced
     */
    public String addListStyle(OdfListStyle style) {
        OdfListStyle listStyle = null;
        SortedSet<OdfListStyle> tail = m_listStyles.tailSet(style);
        if (tail.size() > 0) {
            listStyle = tail.first();
            if (listStyle.equals(style)) {
                return listStyle.getName();
            }
        }
        // no matching style found, add this style to the pool
        String name = "L" + m_listStyles.size();
        listStyle = new OdfListStyle(name, style, null);
        m_listStyles.add(listStyle);
        return name;
    }

    /**
     * @return the auto-style pool as a an OdfStyleCollection
     */
    public OdfStyleCollection getStyleCollection() {
        OdfStyleCollection sc = new OdfStyleCollection();
        for (OdfStyle as : m_styles) {
            new OdfStyle(as.getName(), as, sc);
        }

        for (OdfListStyle als : m_listStyles) {
            new OdfListStyle(als.getName(), als, sc);
        }

        return sc;
    }
}
