/************************************************************************
 *
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS FILE HEADER.
 * 
 * Copyright 2008 by Sun Microsystems, Inc.
 *
 * OpenOffice.org - a multi-platform office productivity suite
 *
 * $RCSfile: $
 * $Revision: $
 *
 * This file is part of OpenOffice.org.
 *
 * OpenOffice.org is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License version 3
 * only, as published by the Free Software Foundation.
 *
 * OpenOffice.org is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License version 3 for more details
 * (a copy is included in the LICENSE file that accompanied this code).
 *
 * You should have received a copy of the GNU Lesser General Public License
 * version 3 along with OpenOffice.org.  If not, see
 * <http://www.openoffice.org/license.html>
 * for a copy of the LGPLv3 License.
 *
 ************************************************************************/
// !!! GENERATED SOURCE CODE !!!
package org.openoffice.odf.dom.style.props;

import org.openoffice.odf.dom.OdfName;
import org.openoffice.odf.dom.OdfNamespace;

public interface OdfListLevelProperties {
    public final static OdfStyleProperty Height = 
        OdfStyleProperty.get(OdfStylePropertiesSet.ListLevelProperties, OdfName.get(OdfNamespace.FO, "height"));
    public final static OdfStyleProperty TextAlign = 
        OdfStyleProperty.get(OdfStylePropertiesSet.ListLevelProperties, OdfName.get(OdfNamespace.FO, "text-align"));
    public final static OdfStyleProperty Width = 
        OdfStyleProperty.get(OdfStylePropertiesSet.ListLevelProperties, OdfName.get(OdfNamespace.FO, "width"));
    public final static OdfStyleProperty FontName = 
        OdfStyleProperty.get(OdfStylePropertiesSet.ListLevelProperties, OdfName.get(OdfNamespace.STYLE, "font-name"));
    public final static OdfStyleProperty VerticalPos = 
        OdfStyleProperty.get(OdfStylePropertiesSet.ListLevelProperties, OdfName.get(OdfNamespace.STYLE, "vertical-pos"));
    public final static OdfStyleProperty VerticalRel = 
        OdfStyleProperty.get(OdfStylePropertiesSet.ListLevelProperties, OdfName.get(OdfNamespace.STYLE, "vertical-rel"));
    public final static OdfStyleProperty Y = 
        OdfStyleProperty.get(OdfStylePropertiesSet.ListLevelProperties, OdfName.get(OdfNamespace.SVG, "y"));
    public final static OdfStyleProperty MinLabelDistance = 
        OdfStyleProperty.get(OdfStylePropertiesSet.ListLevelProperties, OdfName.get(OdfNamespace.TEXT, "min-label-distance"));
    public final static OdfStyleProperty MinLabelWidth = 
        OdfStyleProperty.get(OdfStylePropertiesSet.ListLevelProperties, OdfName.get(OdfNamespace.TEXT, "min-label-width"));
    public final static OdfStyleProperty SpaceBefore = 
        OdfStyleProperty.get(OdfStylePropertiesSet.ListLevelProperties, OdfName.get(OdfNamespace.TEXT, "space-before"));
}
