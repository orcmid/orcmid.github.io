/************************************************************************
 *
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS FILE HEADER.
 * 
 * Copyright 2008 by Sun Microsystems, Inc.
 *
 * OpenOffice.org - a multi-platform office productivity suite
 *
 * $RCSfile: $
 * $Revision: $
 *
 *
 * OpenOffice.org is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License version 3
 * only, as published by the Free Software Foundation.
 *
 * OpenOffice.org is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License version 3 for more details
 * (a copy is included in the LICENSE file that accompanied this code).
 *
 * You should have received a copy of the GNU Lesser General Public License
 * version 3 along with OpenOffice.org.  If not, see
 * <http://www.openoffice.org/license.html>
 * for a copy of the LGPLv3 License.
 *
 ************************************************************************/
package org.openoffice.odf.doc.element.draw;

import org.openoffice.odf.doc.OdfFileDom;
import org.openoffice.odf.dom.element.draw.OdfFrameElement;
import org.openoffice.odf.dom.type.OdfAnchorType;

public class OdfFrame extends OdfFrameElement {

    // 2DO: OdfMeassure / OdfUnit

    // 2DO - What are mandatory ODF attributes, what are the OOo defaults?
    // 2DO - mandatory attributes part of the constructor default values should always be set in constructor
    /** Creates a new instance of OdfParagraphElementImpl */
    public OdfFrame(OdfFileDom ownerDoc) {
        super(ownerDoc);
        this.setAnchorType(OdfAnchorType.PARAGRAPH);
    }
}
