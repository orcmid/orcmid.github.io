/************************************************************************
 *
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS FILE HEADER.
 * 
 * Copyright 2008 by Sun Microsystems, Inc.
 *
 * OpenOffice.org - a multi-platform office productivity suite
 *
 * $RCSfile: $
 * $Revision: $
 *
 *
 * OpenOffice.org is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License version 3
 * only, as published by the Free Software Foundation.
 *
 * OpenOffice.org is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License version 3 for more details
 * (a copy is included in the LICENSE file that accompanied this code).
 *
 * You should have received a copy of the GNU Lesser General Public License
 * version 3 along with OpenOffice.org.  If not, see
 * <http://www.openoffice.org/license.html>
 * for a copy of the LGPLv3 License.
 *
 ************************************************************************/
package org.openoffice.odf.doc.element;

import org.openoffice.odf.doc.element.table.OdfCoveredTableCell;
import org.openoffice.odf.doc.element.table.OdfTableColumn;
import org.openoffice.odf.doc.element.table.OdfTable;
import org.openoffice.odf.doc.element.table.OdfTableRow;
import org.openoffice.odf.doc.element.table.OdfTableCell;
import java.lang.reflect.Constructor;
import java.util.HashMap;
import java.util.Map;
import org.openoffice.odf.doc.OdfFileDom;
import org.openoffice.odf.dom.element.OdfElement;
import org.openoffice.odf.dom.OdfName;
import org.openoffice.odf.doc.element.draw.OdfFrame;
import org.openoffice.odf.doc.element.draw.OdfImage;
import org.openoffice.odf.doc.element.text.OdfSpace;
import org.openoffice.odf.doc.element.text.OdfParagraph;
import org.openoffice.odf.doc.element.text.OdfHeading;
import org.openoffice.odf.doc.element.text.OdfLineBreak;
import org.openoffice.odf.doc.element.text.OdfList;
import org.openoffice.odf.doc.element.text.OdfListItem;
import org.openoffice.odf.doc.element.text.OdfSoftPageBreak;
import org.openoffice.odf.doc.element.text.OdfSpace;
import org.openoffice.odf.doc.element.text.OdfSpan;
import org.openoffice.odf.doc.element.text.OdfTab;
import org.w3c.dom.DOMException;


public class OdfElementFactory {

    private static Map<OdfName, Class> m_elementTypes;

    static {
        populateElementTypes();
    }

    private synchronized static void populateElementTypes() {
        if (m_elementTypes != null) {
            return;
        }
        m_elementTypes = new HashMap<OdfName, Class>();
        m_elementTypes.put(OdfParagraph.ELEMENT_NAME, OdfParagraph.class);
        m_elementTypes.put(OdfFrame.ELEMENT_NAME, OdfFrame.class);
        m_elementTypes.put(OdfImage.ELEMENT_NAME, OdfImage.class);
        m_elementTypes.put(OdfLineBreak.ELEMENT_NAME, OdfLineBreak.class);
        m_elementTypes.put(OdfTable.ELEMENT_NAME, OdfTable.class);
        m_elementTypes.put(OdfCoveredTableCell.ELEMENT_NAME, OdfCoveredTableCell.class);
        m_elementTypes.put(OdfTableCell.ELEMENT_NAME, OdfTableCell.class);
        m_elementTypes.put(OdfTableRow.ELEMENT_NAME, OdfTableRow.class);
        m_elementTypes.put(OdfTableColumn.ELEMENT_NAME, OdfTableColumn.class);
        m_elementTypes.put(OdfHeading.ELEMENT_NAME, OdfHeading.class);
        m_elementTypes.put(OdfList.ELEMENT_NAME, OdfList.class);
        m_elementTypes.put(OdfListItem.ELEMENT_NAME, OdfListItem.class);
        m_elementTypes.put(OdfSpace.ELEMENT_NAME, OdfSpace.class);
        m_elementTypes.put(OdfSoftPageBreak.ELEMENT_NAME, OdfSoftPageBreak.class);
        m_elementTypes.put(OdfSpan.ELEMENT_NAME, OdfSpan.class);
        m_elementTypes.put(OdfTab.ELEMENT_NAME, OdfTab.class);
    }
    
    public static void mapOdfNameToClass(OdfName odfName, Class className){
        m_elementTypes.put(odfName, className);
    }

    public static OdfElement createOdfElement(OdfFileDom ownerDocument, OdfName name) throws DOMException {
        OdfElement e = null;

        // lookup registered class for qname
        Class elementClass = m_elementTypes.get(name);

        // if a class was registered create an instance of that class
        if (elementClass != null) {
            try {
                Constructor ctor = elementClass.getConstructor(new Class[]{OdfFileDom.class});
                e = (OdfElement) ctor.newInstance(new Object[]{ownerDocument});
                return e;
            } catch (Exception cause) {
                // an exception at this point is a bug. Throw an Error
                throw new Error("OdfDOM error in element factory", cause);
            }
        }

        // otherwise create the default class for odf
        return (OdfElement) new OdfDefault(ownerDocument, name);
    }
}
