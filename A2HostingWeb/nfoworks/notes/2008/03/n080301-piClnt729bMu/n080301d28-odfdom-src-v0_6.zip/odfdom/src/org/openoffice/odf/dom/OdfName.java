/************************************************************************
 *
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS FILE HEADER.
 * 
 * Copyright 2008 by Sun Microsystems, Inc.
 *
 * OpenOffice.org - a multi-platform office productivity suite
 *
 * $RCSfile: $
 * $Revision: $
 *
 *
 * OpenOffice.org is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License version 3
 * only, as published by the Free Software Foundation.
 *
 * OpenOffice.org is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License version 3 for more details
 * (a copy is included in the LICENSE file that accompanied this code).
 *
 * You should have received a copy of the GNU Lesser General Public License
 * version 3 along with OpenOffice.org.  If not, see
 * <http://www.openoffice.org/license.html>
 * for a copy of the LGPLv3 License.
 *
 ************************************************************************/
package org.openoffice.odf.dom;

import java.util.HashMap;

public class OdfName implements Comparable {
    
    private OdfNamespace m_ns;
    private String m_localname;
    private String m_fullstring;
    // private static TreeSet<OdfName> m_names = new TreeSet<OdfName>();
    private static HashMap<String, OdfName> m_names = new HashMap<String, OdfName>();
    
    private void init(OdfNamespace ns, String localname) {
        m_ns = ns;
        m_localname = localname;
        StringBuilder b = new StringBuilder();
        b.append('{');
        b.append(m_ns.toString());
        b.append('}');
        b.append(m_localname);
        m_fullstring = b.toString();
    }
    
    private OdfName(OdfNamespace ns, String localname) {
        int i = 0;
        if ((i = localname.indexOf(':'))>=0) {
            localname = localname.substring(i+1);
        }
        init(ns, localname);
    }
    
    private OdfName(String uri, String qname) {
        String[] qnpair = OdfNamespace.splitQName(qname);
        OdfNamespace ns = OdfNamespace.get(qnpair[0], uri);
        init(ns, qnpair[1]);
    }
    
    public static OdfName get(OdfName name) {
        OdfName n = m_names.get(name.toString());
        if (n != null) {
            return n;
        } else {
            m_names.put(name.toString(), name);
            return name;
        }
    }
    
    public static OdfName get(OdfNamespace ns, String localname) {
        return get(new OdfName(ns, localname));
    }

    public static OdfName get(String uri, String localname) {
        return get(new OdfName(uri, localname));
    }
    
    public String getUri() {
        return m_ns.getUri();
    }
    
    public String getLocalName() {
        return m_localname;
    }
    
    public String getQName() {
        if (m_ns.hasPrefix())
            return m_ns.getPrefix() + ":" + m_localname;
        else
            return m_localname;
    }
    
    public String toString() {
        return m_fullstring;
    }
    
    public boolean equals(Object obj) { 
        if (obj != null)
            return toString().equals(obj.toString());
        else
            return false;
    }
    
    public int hashCode() {
       return toString().hashCode();
    }

    public int compareTo(Object o) {
        return toString().compareTo(o.toString());
    }
}
