/************************************************************************
 *
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS FILE HEADER.
 * 
 * Copyright 2008 by Sun Microsystems, Inc.
 *
 * OpenOffice.org - a multi-platform office productivity suite
 *
 * $RCSfile: $
 * $Revision: $
 *
 *
 * OpenOffice.org is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License version 3
 * only, as published by the Free Software Foundation.
 *
 * OpenOffice.org is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License version 3 for more details
 * (a copy is included in the LICENSE file that accompanied this code).
 *
 * You should have received a copy of the GNU Lesser General Public License
 * version 3 along with OpenOffice.org.  If not, see
 * <http://www.openoffice.org/license.html>
 * for a copy of the LGPLv3 License.
 *
 ************************************************************************/
package org.openoffice.odf.dom.test;

import java.util.Collection;
import java.util.Map;
import java.util.TreeSet;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import org.junit.Assert;
import org.junit.Test;
import org.openoffice.odf.dom.OdfNamespace;
import org.openoffice.odf.doc.OdfDocument;
import org.openoffice.odf.doc.style.OdfAutoStylePool;
import org.openoffice.odf.dom.util.NodeAction;
import org.openoffice.odf.dom.element.OdfElement;
import org.openoffice.odf.dom.element.OdfStylableElement;
import org.openoffice.odf.dom.style.OdfStyle;
import org.openoffice.odf.dom.style.OdfStyleCollection;
import org.openoffice.odf.dom.style.OdfStyleFamily;
import org.w3c.dom.Document;
import org.w3c.dom.DocumentFragment;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

public class DocumentTest {

    private static final String TEST_FILE = "test/resources/test2.odt";

    public DocumentTest() {
    }

    @Test
    public void testParser() {
        try {
            OdfDocument odfdoc = new OdfDocument(TEST_FILE);
            OdfElement e = (OdfElement) odfdoc.getContent().getDocumentElement();
            
        } catch (Exception e) {
            e.printStackTrace();
            Assert.fail(e.getMessage());
        }
    }

    @Test
    public void testDumpDom() {
        try {
            OdfDocument odfdoc = new OdfDocument(TEST_FILE);

            Transformer trans = TransformerFactory.newInstance().newTransformer();
            trans.setOutputProperty("indent", "yes");
            trans.setOutputProperty("{http://xml.apache.org/xslt}indent-amount", "2");

            System.out.println("content.xml -------------------");
            trans.transform(new DOMSource(odfdoc.getContent()), new StreamResult(System.out));
            System.out.println("-------------------------------");
            System.out.println("styles.xml --------------------");
            trans.transform(new DOMSource(odfdoc.getStyles()), new StreamResult(System.out));
            System.out.println("-------------------------------");


        } catch (Exception e) {
            e.printStackTrace();
            Assert.fail(e.getMessage());
        }
    }

    @Test
    public void testAutoStyles() {
        try {
            OdfDocument odfdoc = new OdfDocument(TEST_FILE);
            OdfElement e = (OdfElement) odfdoc.getContent().getDocumentElement();
            
            // node action to collect all the local styles into the autostyle pool
            NodeAction<OdfAutoStylePool> collectStyles = new NodeAction<OdfAutoStylePool>() {

                protected void apply(Node cur, OdfAutoStylePool pool, int depth) {
                    if (cur instanceof OdfStylableElement) {
                        OdfStylableElement se = (OdfStylableElement) cur;
                        OdfStyleFamily fam = se.getStyleFamily();
                        System.out.println("> " + cur.getClass().getName() + " (" + cur.getNodeName() + ")-> " +
                                "style-family " + fam.getName() + " allows " + fam.getProperties().size() + " props.");
                        OdfStyle ls = se.getAutomaticStyle();
                        if (ls != null) {
                            String name = pool.addStyle(ls);
                        }
                    }
                }
            };

            OdfAutoStylePool pool = new OdfAutoStylePool();
            collectStyles.performAction(e, pool);

            OdfStyleCollection ac = pool.getStyleCollection();

            Assert.assertTrue(ac.size() > 0);

            // all styles should be unique (not equal)
            Collection<OdfStyle> styles = ac.values();
            TreeSet<OdfStyle> testSet = new TreeSet<OdfStyle>();
            for (OdfStyle style : styles) {
                OdfStyle test = testSet.floor(style);
                Assert.assertTrue(test == null || !test.equals(style));
                testSet.add(style);
            }

        } catch (Exception e) {
            e.printStackTrace();
            Assert.fail(e.getMessage());
        }
    }

    @Test
    public void testDocumentStyles() {
        try {
            OdfDocument odfdoc = new OdfDocument(TEST_FILE);
            OdfStyleCollection styles = odfdoc.getDocumentStyles();

            Assert.assertTrue(styles.size() > 0);

            Document sd = DocumentBuilderFactory.newInstance().newDocumentBuilder().newDocument();
            Element se = sd.createElementNS(OdfNamespace.STYLE.getUri(), "styles-test");
            sd.appendChild(se);

            for (Object entry : styles.entrySet()) {
                OdfStyle s = (OdfStyle) ((Map.Entry) entry).getValue();
                s.appendToNode(se);
            }

            DocumentFragment u = styles.getUnkownContent();
            NodeList lst = u.getChildNodes();
            Assert.assertTrue(lst.getLength() > 0);

        /*
        // style output to stdout
        Element unkown = (Element) se.appendChild(sd.createElement("unkown-style-info"));
        unkown.appendChild(sd.importNode(u, true));            
        Transformer t = TransformerFactory.newInstance().newTransformer();
        t.transform(new DOMSource(sd), new StreamResult(System.out));
         */

        } catch (Exception e) {
            e.printStackTrace();
            Assert.fail(e.getMessage());
        }
    }

    @Test
    public void testSaveDocument() {
        try {
            OdfDocument odfdoc = new OdfDocument(TEST_FILE);
            OdfElement e = (OdfElement) odfdoc.getContent().getDocumentElement();
            NodeAction<String> replaceText = new NodeAction<String>() {

                protected void apply(Node cur, String replace, int depth) {
                    if (cur.getNodeType() == Node.TEXT_NODE) {
                        cur.setNodeValue(cur.getNodeValue().replaceAll("\\w", replace));
                    }
                }
            };
//            replaceText.performAction(e, "X");            
            odfdoc.save("build/test/list-out.odt");
        } catch (Exception e) {
            e.printStackTrace();
            Assert.fail(e.getMessage());
        }
    }
}
