/************************************************************************
 *
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS FILE HEADER.
 * 
 * Copyright 2008 by Sun Microsystems, Inc.
 *
 * OpenOffice.org - a multi-platform office productivity suite
 *
 * $RCSfile: $
 * $Revision: $
 *
 *
 * OpenOffice.org is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License version 3
 * only, as published by the Free Software Foundation.
 *
 * OpenOffice.org is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License version 3 for more details
 * (a copy is included in the LICENSE file that accompanied this code).
 *
 * You should have received a copy of the GNU Lesser General Public License
 * version 3 along with OpenOffice.org.  If not, see
 * <http://www.openoffice.org/license.html>
 * for a copy of the LGPLv3 License.
 *
 ************************************************************************/
package org.openoffice.odf.dom.test;

import org.junit.Assert;
import org.junit.Test;
import org.openoffice.odf.dom.OdfNamespace;
import org.openoffice.odf.doc.OdfDocument;
import org.openoffice.odf.dom.style.OdfGraphicStyle;
import org.openoffice.odf.dom.style.OdfParagraphStyle;
import org.openoffice.odf.dom.style.OdfStyle;
import org.openoffice.odf.dom.style.OdfStyleFamily;
import org.openoffice.odf.dom.style.OdfTableRowStyle;
import org.openoffice.odf.dom.style.OdfTableStyle;
import org.openoffice.odf.dom.style.props.OdfStylePropertiesSet;

/**
 * Tests if default styles are parsed correctly into
 * the defaultstyleCollection of the OdfDocument
 */
public class DefaultStylesTest {

    private static String TEST_FILE = "test/resources/test2.odt";

    public DefaultStylesTest() {
    }

    @Test
    public void testDefaultStyles() {
        try {
            OdfDocument doc = new OdfDocument(TEST_FILE);

            OdfStyle oDSG = doc.getDefaultStyles().getStyle("DEFAULT_GRAPHIC_STYLE");
            Assert.assertEquals(oDSG.getFamilyName(), OdfStyleFamily.Graphic.getName());
            String prop1 = oDSG.getProperty(OdfStylePropertiesSet.GraphicProperties, OdfNamespace.DRAW.toString(), OdfGraphicStyle.ShadowOffsetX.toString());
            Assert.assertEquals(prop1, "0.1181in");

            OdfStyle oDSP = doc.getDefaultStyles().getStyle("DEFAULT_PARAGRAPH_STYLE");
            Assert.assertEquals(oDSP.getFamilyName(), OdfStyleFamily.Paragraph.getName());
            String prop2 = oDSP.getProperty(OdfStylePropertiesSet.TextProperties, OdfNamespace.STYLE.toString(), OdfParagraphStyle.FontName.toString());
            Assert.assertEquals(prop2, "Thorndale");
            String prop3 = oDSP.getProperty(OdfStylePropertiesSet.TextProperties, OdfNamespace.STYLE.toString(), OdfParagraphStyle.LetterKerning.toString());
            Assert.assertEquals(prop3, "true");

            OdfStyle oDST = doc.getDefaultStyles().getStyle("DEFAULT_TABLE_STYLE");
            Assert.assertEquals(oDST.getFamilyName(), OdfStyleFamily.Table.getName());
            String prop4 = oDST.getProperty(OdfStylePropertiesSet.TableProperties, OdfNamespace.STYLE.toString(), OdfTableStyle.BorderModel.toString());
            Assert.assertEquals(prop4, "collapsing");


            OdfStyle oDSTR = doc.getDefaultStyles().getStyle("DEFAULT_TABLE-ROW_STYLE");
            Assert.assertEquals(oDSTR.getFamilyName(), OdfStyleFamily.TableRow.getName());
            String prop5 = oDSTR.getProperty(OdfStylePropertiesSet.TableRowProperties, OdfNamespace.STYLE.toString(), OdfTableRowStyle.KeepTogether.toString());
            Assert.assertEquals(prop5, "auto");


        } catch (Exception e) {
            e.printStackTrace();
            Assert.fail(e.getMessage());
        }

    }
}
