<?xml version="1.0" encoding="UTF-8"?>
<!--

  DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS FILE HEADER.
  
  Copyright 2008 by Sun Microsystems, Inc.
 
  OpenOffice.org - a multi-platform office productivity suite
 
  $RCSfile: $
 
  $Revision: $
 
  This file is part of OpenOffice.org.
 
  OpenOffice.org is free software: you can redistribute it and/or modify
  it under the terms of the GNU Lesser General Public License version 3
  only, as published by the Free Software Foundation.
 
  OpenOffice.org is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU Lesser General Public License version 3 for more details
  (a copy is included in the LICENSE file that accompanied this code).
 
  You should have received a copy of the GNU Lesser General Public License
  version 3 along with OpenOffice.org.  If not, see
  <http://www.openoffice.org/license.html>
  for a copy of the LGPLv3 License.
 
-->

<xsl:stylesheet xmlns:xsl="http://www.w3.org/1999/XSL/Transform" version="1.0"
                xmlns:rng="http://relaxng.org/ns/structure/1.0" 
                xmlns:a="http://relaxng.org/ns/compatibility/annotations/1.0"
>
    <xsl:output method="xml" indent="yes"/>
    
    <xsl:param name="interfaceName" select="'!UnknownInterface!'"/>
    <xsl:param name="elementName" select="'!UnknownElement!'"/>
    <xsl:param name="styleFamily" select="'none'"/>
    
    <xsl:param name="extends" select="''"/>
    <xsl:param name="elementNameForDerived" select="''"/>
    <xsl:param name="elementNameForBase" select="''"/>
    
    <xsl:variable name="createBase" select="$elementNameForBase != ''"/>
    <xsl:variable name="createDerived" select="$elementNameForDerived != ''"/>

    <xsl:include href="genXMLCodeHelpers.xsl"/>

    <!-- process schema -->
    <xsl:template match="/rng:grammar">
        <file>
            <package>
                <xsl:attribute name="name">
                    <xsl:call-template name="output-dirname-as-qname">
                        <xsl:with-param name="path" select="$interfaceName"/>
                    </xsl:call-template>
                </xsl:attribute>
            </package>
            <xsl:apply-templates select="rng:element[@name=$elementName]"/>
        </file>
    </xsl:template>
    
    <xsl:template match="rng:element">
        <xsl:variable name="hasFamily" select="$styleFamily != 'none'"/>
        <xsl:variable name="extends">
            <xsl:choose>
                <xsl:when test="$extends != ''">
                    <xsl:value-of select="$extends"/>
                </xsl:when>
                <xsl:when test="$hasFamily">
                    <xsl:text>org.openoffice.odf.dom.element.OdfStylableElement</xsl:text>
                </xsl:when>
                <xsl:otherwise>
                    <xsl:text>org.openoffice.odf.dom.element.OdfElement</xsl:text>
                </xsl:otherwise>
            </xsl:choose>
        </xsl:variable>

        <import name="org.openoffice.odf.OdfName"/>
        <import name="org.openoffice.odf.OdfNamespace"/>
        <import name="org.openoffice.odf.doc.OdfFileDom"/>
        <xsl:if test="$hasFamily">
            <import name="org.openoffice.odf.dom.style.OdfStyleFamily"/>
        </xsl:if>

        <xsl:variable name="interfaceNameNQ">
            <xsl:call-template name="output-filename">
                <xsl:with-param name="path" select="$interfaceName"/>
            </xsl:call-template>
        </xsl:variable>
        
        <class name="{$interfaceNameNQ}" extends="{$extends}">
            <xsl:attribute name="modifier">
                <xsl:choose>
                    <xsl:when test="$createBase">
                        <xsl:text>public abstract</xsl:text>
                    </xsl:when>
                    <xsl:otherwise>
                        <xsl:text>public</xsl:text>
                    </xsl:otherwise>
                </xsl:choose>
            </xsl:attribute>

          <xsl:attribute name="implements">
               <xsl:call-template name="output-filename">
                    <xsl:with-param name="path" select="$interfaceName"/>
               </xsl:call-template>
           </xsl:attribute>
           <doc>
                <xsl:text>ODF DOM Element implementation for element &quot;&lt;</xsl:text>
                <xsl:value-of select="$elementName"/>
                <xsl:text>&gt;&quot;.</xsl:text>
            </doc>
            
            <constructor>
                <param name="_aOwnerDoc" type="OdfFileDom"/>
                <xsl:if test="$createBase">
                    <param name="_elementName" type="OdfName"/>
                    <xsl:if test="$hasFamily">
                        <param name="_styleFamily" type="OdfStyleFamily"/>
                        <param name="_styleAttrName" type="OdfName"/>
                    </xsl:if> 
                </xsl:if>
                <statement>
                    <method-call method="super">
                        <with-param value="_aOwnerDoc"/>
                        <xsl:choose>
                            <xsl:when test="$createBase">
                                <with-param value="_elementName"/>
                                <xsl:if test="$hasFamily">
                                    <with-param value="_styleFamily"/>
                                    <with-param value="_styleAttrName"/>
                                </xsl:if>
                            </xsl:when>
                            <xsl:otherwise>
                                <with-param value="ELEMENT_NAME"/>
                                <xsl:if test="$hasFamily">
                                    <with-param value="OdfStyleFamily.{$styleFamily}"/>
                                    <with-param>
                                        <xsl:variable name="styleAttr">
                                            <xsl:apply-templates select="*" mode="style-attr"/>
                                        </xsl:variable>
                                        <xsl:call-template name="output-call-method-odfname-get">
                                            <xsl:with-param name="qname" select="$styleAttr"/>
                                        </xsl:call-template>
                                    </with-param>
                                </xsl:if>
                            </xsl:otherwise>
                        </xsl:choose>
                    </method-call>
                </statement>
            </constructor>
            
            <xsl:if test="not($createBase)">
                <method return="OdfName" name="getOdfName">
                    <return>
                        <expression value="ELEMENT_NAME"/>
                    </return>
                </method>
            </xsl:if>

            <xsl:variable name="id" select="generate-id(.)"/>
            
            <!--
            <method-decl modifier="public static" return="{$interfaceNameNQ}" name="newInstance">
                <doc>
                    <xsl:text>Create instance of </xsl:text>
                    <xsl:value select="$interfaceName"/>
                    <xsl:text>.</xsl:text>
                </doc>
                <xsl:call-template name="output-mandatory-formal-parameters"/>
                <return>
                    <new>
                        <xsl:for-each select=".//rng:attribute">
                            <xsl:sort select="substring-after(@name,':')"/>
                            <xsl:variable name="name" select="substring-after(@name,':')"/>
                            <xsl:if test="not( preceding::rng:attribute[substring-after(@name,':') = $name and generate-id(ancestor::rng:element)=$id] ) and parent::rng:element">
                                <xsl:variable name="javaName">
                                    <xsl:call-template name="output-name">
                                        <xsl:with-param name="qname" select="@name"/>
                                    </xsl:call-template>
                                </xsl:variable>
                                <with-param value="_a{$javaName}"/>
                            </xsl:if>
                        </xsl:for-each>
                    </new>
                </return>
            </method-decl>
            -->
            
            <method return="void" name="init">
                <doc>
                    <xsl:text>Initialite mandatory attributes.</xsl:text>
                </doc>
                <xsl:call-template name="output-mandatory-formal-parameters"/>
                <xsl:for-each select=".//rng:attribute">
                    <xsl:sort select="substring-after(@name,':')"/>
                    <xsl:variable name="name" select="substring-after(@name,':')"/>
                    <xsl:if test="not( preceding::rng:attribute[substring-after(@name,':') = $name and generate-id(ancestor::rng:element)=$id] ) and parent::rng:element">
                        <xsl:variable name="javaName">
                            <xsl:call-template name="output-name">
                                <xsl:with-param name="qname" select="@name"/>
                            </xsl:call-template>
                        </xsl:variable>
                        <statement>
                            <method-call method="set{$javaName}">
                                <with-param value="_a{$javaName}"/>
                            </method-call>
                        </statement>
                    </xsl:if>
                </xsl:for-each>
            </method>
            
            <xsl:for-each select=".//rng:attribute">
                <xsl:sort select="substring-after(@name,':')"/>
                <xsl:variable name="name" select="substring-after(@name,':')"/>
                <xsl:if test="not( preceding::rng:attribute[substring-after(@name,':') = $name and generate-id(ancestor::rng:element)=$id] )">
                    <xsl:call-template name="attribute"/>
                </xsl:if>
            </xsl:for-each>
        </class>
    </xsl:template>
    
    <xsl:template name="attribute">
        <xsl:variable name="exclude">
            <xsl:call-template name="exclude-attributes"/>
        </xsl:variable>
        <xsl:if test="$exclude != 'true'">
            <xsl:variable name="javaName">
                <xsl:call-template name="output-name">
                    <xsl:with-param name="qname" select="@name"/>
                </xsl:call-template>
            </xsl:variable>

            <xsl:variable name="odfType">
                <!-- xsl:apply-templates select="rng:ref/@name"/ -->
                <xsl:call-template name="output-odf-type"/>
            </xsl:variable>

            <method return="{$odfType}" name="get{$javaName}">
                <doc>
                    <xsl:text>Get value of attribute &quot;</xsl:text>
                    <xsl:value-of select="@name"/>
                    <xsl:text>&quot;.</xsl:text>
                </doc>
                <xsl:choose>
                    <xsl:when test="$odfType='string' and not(@a:defaultValue)">
                        <return>
                            <method-call method="getOdfAttribute">
                                <with-param>
                                    <xsl:call-template name="output-call-method-odfname-get">
                                        <xsl:with-param name="qname" select="@name"/>
                                    </xsl:call-template>
                                </with-param>
                            </method-call>
                        </return>
                    </xsl:when>
                    <xsl:otherwise>
                        <variable type="string" name="aStringVal">
                            <method-call method="getOdfAttribute">
                                <with-param>
                                    <xsl:call-template name="output-call-method-odfname-get">
                                        <xsl:with-param name="qname" select="@name"/>
                                    </xsl:call-template>
                                </with-param>
                            </method-call>
                        </variable>
                        <xsl:if test="@a:defaultValue">
                            <choice>
                                <when>
                                    <test>
                                        <operator name="==">
                                            <method-call primary="aStringVal" method="length"/>
                                            <expression value="0"/>
                                        </operator>
                                    </test>
                                    <assign name="aStringVal">
                                        <expression value="&quot;{@a:defaultValue}&quot;"/>
                                    </assign>
                                </when>
                            </choice>
                        </xsl:if>
                        <return>
                            <xsl:choose>
                                <xsl:when test="$odfType='string'">
                                    <expression value="aStringVal"/>
                                </xsl:when>
                                <xsl:otherwise>
                                    <typecast from="string" to="{$odfType}" value="aStringVal"/>
                                </xsl:otherwise>
                            </xsl:choose>
                        </return>
                    </xsl:otherwise>
                </xsl:choose>
            </method>

            <method return="void" name="set{$javaName}">
                <doc>
                    <xsl:text>Set value of attribute &quot;</xsl:text>
                    <xsl:value-of select="@name"/>
                    <xsl:text>&quot;.</xsl:text>
                </doc>
                <param type="{$odfType}" name="_a{$javaName}"/>
                <xsl:choose>
                    <xsl:when test="$odfType='string'">
                        <statement>
                            <method-call method="setOdfAttribute">
                                <with-param>
                                    <xsl:call-template name="output-call-method-odfname-get">
                                        <xsl:with-param name="qname" select="@name"/>
                                    </xsl:call-template>
                                </with-param>
                                <with-param value="_a{$javaName}"/>
                            </method-call>
                        </statement>
                    </xsl:when>
                    <xsl:otherwise>
                        <variable type="string" name="aStringVal">
                            <typecast from="{$odfType}" to="string" value="_a{$javaName}"/>
                        </variable>
                        <statement>
                            <method-call method="setOdfAttribute">
                                <with-param>
                                    <xsl:call-template name="output-call-method-odfname-get">
                                        <xsl:with-param name="qname" select="@name"/>
                                    </xsl:call-template>
                                </with-param>
                                <with-param value="aStringVal"/>
                            </method-call>
                        </statement>
                    </xsl:otherwise>
                </xsl:choose>
                <xsl:call-template name="set-attribute-specific-code"/>
            </method>
        </xsl:if>
    </xsl:template>
    
    <xsl:template match="rng:attribute" mode="style-attr">
        <xsl:if test="substring-after(@name,':')='style-name'">
            <xsl:value-of select="@name"/>
        </xsl:if>
    </xsl:template>

    <xsl:template match="*" mode="style-attr">
        <xsl:apply-templates mode="style-attr"/>
    </xsl:template>

    <xsl:template match="@*|text()" mode="style-attr"/>

    <xsl:template name="set-attribute-specific-code">
        <xsl:choose>
            <xsl:when test="@name='xlink:href'">
                <xsl:apply-templates select="ancestor::rng:element//rng:attribute" mode="set-xlink-href"/>
            </xsl:when>
        </xsl:choose>
    </xsl:template>

    <xsl:template match="rng:attribute[(@name='xlink:type' or @name='xlink:show' or @name='xlink:actuate') and @a:defaultValue]" mode="set-xlink-href">
        <statement>
            <method-call method="setOdfAttribute">
                 <with-param>
                     <xsl:call-template name="output-call-method-odfname-get">
                         <xsl:with-param name="qname" select="@name"/>
                     </xsl:call-template>
                </with-param>
                <with-param value="&quot;{@a:defaultValue}&quot;"/>
            </method-call>
        </statement>        
    </xsl:template>

    <xsl:template match="*|text()|@*" mode="set-xlink-href"/>
    
</xsl:stylesheet>
