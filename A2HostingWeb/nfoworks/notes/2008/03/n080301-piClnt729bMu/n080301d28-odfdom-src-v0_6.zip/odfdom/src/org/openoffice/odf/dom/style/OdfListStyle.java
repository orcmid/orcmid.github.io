/************************************************************************
 *
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS FILE HEADER.
 * 
 * Copyright 2008 by Sun Microsystems, Inc.
 *
 * OpenOffice.org - a multi-platform office productivity suite
 *
 * $RCSfile: $
 * $Revision: $
 *
 * This file is part of OpenOffice.org.
 *
 * OpenOffice.org is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License version 3
 * only, as published by the Free Software Foundation.
 *
 * OpenOffice.org is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License version 3 for more details
 * (a copy is included in the LICENSE file that accompanied this code).
 *
 * You should have received a copy of the GNU Lesser General Public License
 * version 3 along with OpenOffice.org.  If not, see
 * <http://www.openoffice.org/license.html>
 * for a copy of the LGPLv3 License.
 *
 ************************************************************************/
package org.openoffice.odf.dom.style;

import org.openoffice.odf.dom.OdfNamespace;
import org.openoffice.odf.dom.style.props.OdfStylePropertiesSet;
import java.util.SortedSet;
import java.util.TreeSet;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

/**
 *
 * 
 */
public class OdfListStyle implements Comparable {

    private String m_name;
    private SortedSet<OdfListLevelStyle> m_levels = new TreeSet<OdfListLevelStyle>();

    private static int getNumber(String numstr) {
        if (numstr == null) {
            return 0;
        }
        try {
            return Integer.parseInt(numstr);
        } catch (NumberFormatException e) {
            return 0;
        }
    }

    public OdfListStyle(Element e, OdfStyleCollection col) {
        m_name = e.getAttributeNS(OdfNamespace.STYLE.getUri(), "name");

        if (col != null) {
            col.addListStyle(this);
        }

        // process style information into ListLevelStyles
        NodeList lst = e.getChildNodes();
        int n = lst.getLength();
        for (int i = 0; i < n; i++) {
            Node node = lst.item(i);
            if (node.getNodeType() == node.ELEMENT_NODE &&
                    node.getNamespaceURI().equals(OdfNamespace.TEXT.getUri()) &&
                    node.getLocalName().startsWith("list-level-style")) {
                Element lse = (Element) node;
                String name = lse.getAttributeNS(OdfNamespace.TEXT.getUri(), "style-name");
                int level = getNumber(lse.getAttributeNS(OdfNamespace.TEXT.getUri(), "level"));
                boolean numbered = lse.getLocalName().endsWith("number");
                String prefix = lse.getAttributeNS(OdfNamespace.STYLE.getUri(), "num-prefix");
                String suffix = lse.getAttributeNS(OdfNamespace.STYLE.getUri(), "num-suffix");
                String nformat = lse.getAttributeNS(OdfNamespace.STYLE.getUri(), "num-format");
                String bullet = lse.getAttributeNS(OdfNamespace.TEXT.getUri(), "bullet-char");
                OdfListLevelStyle lvlstyle = new OdfListLevelStyle(name, level, numbered, prefix, suffix, nformat, bullet);
                m_levels.add(lvlstyle);
                NodeList plst = lse.getChildNodes();
                int m = plst.getLength();
                for (int j = 0; j < m; j++) {
                    Node pnode = plst.item(j);
                    if (pnode.getNodeType() == node.ELEMENT_NODE) {
                        Element pe = (Element) pnode;
                        OdfStylePropertiesSet set =
                                pe.getLocalName().equals("text-properties")
                                ? OdfStylePropertiesSet.TextProperties
                                : OdfStylePropertiesSet.ListLevelProperties;
                        NamedNodeMap atts = pe.getAttributes();
                        int l = atts.getLength();
                        for (int k = 0; k < l; k++) {
                            Node item = atts.item(k);
                            lvlstyle.setProperty(set, item.getNamespaceURI(),
                                    item.getLocalName(), item.getNodeValue());
                        }
                    }
                }
            }
        }
    }

    public OdfListStyle(String name, OdfStyleCollection col) {
        m_name = name;
        if (col != null) {
            col.addListStyle(this);
        }
    }

    public OdfListStyle(String name, OdfListStyle orig, OdfStyleCollection col) {
        this(name, col);
        // copy over original level styles
        for (OdfListLevelStyle ls : orig.m_levels) {
            OdfListLevelStyle newls = new OdfListLevelStyle(
                    ls.getName(), ls.getLevel(), ls.isNumbered(),
                    ls.getPrefix(), ls.getSuffix(), ls.getNumFormat(), ls.getBulletChar());
            ls.copyTo(newls);
            m_levels.add(newls);
        }

    }

    public String getName() {
        return m_name;
    }

    public void addListLevel(OdfListLevelStyle lvl) {
        m_levels.add(lvl);
    }

    public OdfListLevelStyle getLevel(int nLevel, boolean bCreate, boolean bNumbered) {
        String defaultBullet = bNumbered ? null : "\u25cf";
        
        OdfListLevelStyle aDummyStyle =
                new OdfListLevelStyle(getName(), nLevel, bNumbered, null, null, null, defaultBullet);
        SortedSet<OdfListLevelStyle> aTailSet = m_levels.tailSet(aDummyStyle);
        OdfListLevelStyle aStyle = null;
        if (aTailSet.size() > 0) {
            aStyle = aTailSet.first();
            if (aStyle.getLevel() != nLevel) {
                aStyle = null;
            }
        }

        if (aStyle == null && bCreate) {
            aStyle = aDummyStyle;
            m_levels.add(aStyle);
        }

        return aStyle;
    }

    public void appendToNode(Node node) {
        Document doc = node.getOwnerDocument();
        Element e = doc.createElementNS(OdfNamespace.TEXT.getUri(), "text:list-style");
        e.setAttributeNS(OdfNamespace.STYLE.getUri(), "style:name", m_name);
        e = (Element) node.appendChild(e);
        for (OdfListLevelStyle lvl : m_levels) {
            lvl.appendToNode(e);
        }
    }

    @Override
    public boolean equals(Object o) {
        return compareTo(o) == 0;
    }

    @Override
    public int hashCode() {
        int hash = 5;
        hash = 23 * hash + (this.m_name != null ? this.m_name.hashCode() : 0);
        hash = 23 * hash + (this.m_levels != null ? this.m_levels.hashCode() : 0);
        return hash;
    }

    public int compareTo(Object o) {
        if (o == null) {
            return 1;
        }
        if (!(o instanceof OdfListStyle)) {
            return 1;
        }

        OdfListStyle ls = (OdfListStyle) o;
        if (m_levels.size() > ls.m_levels.size()) {
            return 1;
        }
        if (m_levels.size() < ls.m_levels.size()) {
            return -1;
        }

        int i = 0;
        int c = 0;
        for (OdfListLevelStyle lvls : m_levels) {
            OdfListLevelStyle other = ls.getLevel(lvls.getLevel(), false, false);
            if ((c = lvls.compareTo(other)) != 0) {
                return c;
            }
        }
        return 0;
    }
}
