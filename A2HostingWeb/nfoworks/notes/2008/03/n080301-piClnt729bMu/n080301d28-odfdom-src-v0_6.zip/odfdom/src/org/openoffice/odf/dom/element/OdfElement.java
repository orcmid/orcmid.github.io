/************************************************************************
 *
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS FILE HEADER.
 * 
 * Copyright 2008 by Sun Microsystems, Inc.
 *
 * OpenOffice.org - a multi-platform office productivity suite
 *
 * $RCSfile: $
 * $Revision: $
 *
 *
 * OpenOffice.org is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License version 3
 * only, as published by the Free Software Foundation.
 *
 * OpenOffice.org is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License version 3 for more details
 * (a copy is included in the LICENSE file that accompanied this code).
 *
 * You should have received a copy of the GNU Lesser General Public License
 * version 3 along with OpenOffice.org.  If not, see
 * <http://www.openoffice.org/license.html>
 * for a copy of the LGPLv3 License.
 *
 ************************************************************************/
package org.openoffice.odf.dom.element;

import org.apache.xerces.dom.ElementNSImpl;
import org.openoffice.odf.doc.OdfDocument;
import org.openoffice.odf.dom.OdfName;
import org.openoffice.odf.doc.OdfFileDom;
import org.w3c.dom.DOMException;
import org.w3c.dom.Element;
import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.Node;
import org.w3c.dom.Text;

//2DO: Refactor public to package viewer, when inheritance is exchanged from OdfElement to specific Odf Element
abstract public class OdfElement extends ElementNSImpl {
    
    // the OdfDocument containing the element
    protected OdfDocument mOdfDocument;

    /** Creates a new instance of OdfElement */
    public OdfElement(OdfFileDom ownerDocument,
            String namespaceURI,
            String qualifiedName) throws DOMException {
        super(ownerDocument, namespaceURI, qualifiedName);
        mOdfDocument = ownerDocument.getOdfDocument();
    }

    /** Creates a new instance of OdfElement */
    public OdfElement(OdfFileDom ownerDocument, 
            OdfName aName) throws DOMException {
        super(ownerDocument, aName.getUri(), aName.getQName());
        mOdfDocument = ownerDocument.getOdfDocument();
    }
    
    abstract public OdfName getOdfName();
    
    protected <T extends OdfElement> T getParentAs(Class<T> clazz) {
        Node parent = getParentNode();
        if (parent != null && clazz.isInstance(parent)) {
            return clazz.cast(parent);
        } else {
            return null;
        }
    }

    protected <T extends OdfElement> T getAncestorAs(Class<T> clazz) {
        Node node = getParentNode();        
        while ( node != null) {
            if (clazz.isInstance(node)) {
                return clazz.cast(node);
            }
            node = node.getParentNode();
        }
        return null;
    }    
    
    @Override
    public String toString(){
        return mapNode(this, new StringBuilder()).toString();
    }
    
    /** Only Siblings will be traversed by this method as Children */
    static private StringBuilder mapNodeTree(Node node, StringBuilder xml){
        while(node != null){
            // mapping node and this mapping include always all descendants
            xml = mapNode(node, xml);
            // next sibling will be mapped to XML
            node = node.getNextSibling();
        }
        return xml;
    }
        
    private static StringBuilder mapNode(Node node, StringBuilder xml){
        if(node instanceof Element){
            xml = mapElementNode(node, xml);
        }else if(node instanceof Text){
            xml = mapTextNode(node, xml);
        }
        return xml;
    }
    
    private static StringBuilder mapTextNode(Node node, StringBuilder xml){
        if(node != null){
            xml = xml.append(node.getTextContent());
        }
        return xml;
    }
        
    private static StringBuilder mapElementNode(Node node, StringBuilder xml){
        if(node != null){
            xml = xml.append("<");
            xml = xml.append(node.getNodeName());
            xml = mapAttributeNode(node, xml);
            xml = xml.append(">");
            xml = mapNodeTree(node.getFirstChild(), xml);
            xml = xml.append("</");
            xml = xml.append(node.getNodeName());
            xml = xml.append(">");
        }
        return xml;
    }
    
    private static StringBuilder mapAttributeNode(Node node, StringBuilder xml){
        NamedNodeMap attrs = null;
        int length;
        if((attrs = node.getAttributes()) != null && (length = attrs.getLength()) > 0){
            for(int i=0;length > i;i++){
                xml = xml.append(" ");
                xml = xml.append(attrs.item(i).getNodeName());
                xml = xml.append("=\"");
                xml = xml.append(attrs.item(i).getNodeValue());
                xml = xml.append("\"");
            }
        }
        return xml;
    }   

    public void setOdfAttribute(OdfName name, String value) {
        setAttributeNS(name.getUri(), name.getQName(), value);
    }

    public String getOdfAttribute(OdfName name) {
        return getAttributeNS(name.getUri(), name.getLocalName());
    }
}
