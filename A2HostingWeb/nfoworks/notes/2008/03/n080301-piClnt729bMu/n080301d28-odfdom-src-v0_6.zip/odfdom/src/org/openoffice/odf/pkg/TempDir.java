/************************************************************************
 *
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS FILE HEADER.
 * 
 * Copyright 2008 by Sun Microsystems, Inc.
 *
 * OpenOffice.org - a multi-platform office productivity suite
 *
 * $RCSfile: $
 * $Revision: $
 *
 *
 * OpenOffice.org is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License version 3
 * only, as published by the Free Software Foundation.
 *
 * OpenOffice.org is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License version 3 for more details
 * (a copy is included in the LICENSE file that accompanied this code).
 *
 * You should have received a copy of the GNU Lesser General Public License
 * version 3 along with OpenOffice.org.  If not, see
 * <http://www.openoffice.org/license.html>
 * for a copy of the LGPLv3 License.
 *
 ************************************************************************/
package org.openoffice.odf.pkg;

import java.io.File;
import java.io.IOException;
import java.util.Hashtable;
    
class TempDir {

    static Hashtable _refCounts=new Hashtable();

    /**
     * Creates a temp directory with a generated name (given a certain prefix) 
     * in a given directory.
     * The directory (and all its content) will be destroyed on exit.
     */    
    static File createGeneratedName(String prefix, File directory)
        throws IOException {

        File tempFile = File.createTempFile(prefix, "", directory);
        if (!tempFile.delete())
            throw new IOException();
        if (!tempFile.mkdir())
            throw new IOException();
        TempDirDeleter.getInstance().add(tempFile);
        _refCounts.put(tempFile,new Integer(1));
        return tempFile;        
    }
    

    /**
     * Creates a temp directory with a generated name (given a certain prefix)
     * in default temporary-file directory.
     * Invoking this method is equivalent to invoking createGeneratedName(prefix, null).
     * The directory (and all its content) will be destroyed on exit.
     */    
    static File createGeneratedName(String prefix)
        throws IOException {
        return createGeneratedName(prefix,null);
    }

    /**
     * Creates a temp directory with a given name in a given directory.
     * The directory (and all its content) will be destroyed on exit.
     */    
    static File createNamed(String name, File directory)
        throws IOException {

        File tempFile = new File(directory, name);
        if (!tempFile.mkdir())
            throw new IOException();
        TempDirDeleter.getInstance().add(tempFile);
        _refCounts.put(tempFile,new Integer(1));
        return tempFile;        
    }    

    /**
     * increase refCount
     */
    static int ref(File dir) {
        int refCount=((Integer)_refCounts.get(dir)).intValue();
        ++refCount;
        _refCounts.put(dir,new Integer(refCount));
        return refCount;
    }
    
    /**
     * release reference, when refcount gets 0 Directory is deleted
     */
    static void release(File dir) {
        int refCount=((Integer)_refCounts.get(dir)).intValue();
        if ( --refCount==0 ) {
            TempDirDeleter.getInstance().deleteDirectory(dir);
            _refCounts.remove(dir);
        } else {
            _refCounts.put(dir,new Integer(refCount));
        }
    }
    
}
