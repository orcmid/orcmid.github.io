/************************************************************************
 *
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS FILE HEADER.
 * 
 * Copyright 2008 by Sun Microsystems, Inc.
 *
 * OpenOffice.org - a multi-platform office productivity suite
 *
 * $RCSfile: $
 * $Revision: $
 *
 *
 * OpenOffice.org is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License version 3
 * only, as published by the Free Software Foundation.
 *
 * OpenOffice.org is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License version 3 for more details
 * (a copy is included in the LICENSE file that accompanied this code).
 *
 * You should have received a copy of the GNU Lesser General Public License
 * version 3 along with OpenOffice.org.  If not, see
 * <http://www.openoffice.org/license.html>
 * for a copy of the LGPLv3 License.
 *
 ************************************************************************/
package org.openoffice.odf.dom.test.example;

import org.openoffice.odf.doc.OdfDocument;


public class LoadMultipleTimes {
    
    final static int num = 50;
    public static void main(String[] args) {
        OdfDocument doc = null;
        try {
            long t = 0;
            for (int i=0; i<num; i++) {
                long t1 = System.currentTimeMillis();                
                doc = new OdfDocument("test/resources/test1.odt");
                long t2 = System.currentTimeMillis() - t1;
                t = t + t2;
                System.out.println("open in " + t2 + " milliseconds");
                long f1 = Runtime.getRuntime().freeMemory();
                Runtime.getRuntime().gc();
                long f2 = Runtime.getRuntime().freeMemory();
                System.out.println("freemem pre-gc: " + f1 + ", post-gc: " + f2 + ", delta: " + (f1 - f2) + ".");
            }
            System.out.println("opening " + num + " times took " + t + " milliseconds");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
