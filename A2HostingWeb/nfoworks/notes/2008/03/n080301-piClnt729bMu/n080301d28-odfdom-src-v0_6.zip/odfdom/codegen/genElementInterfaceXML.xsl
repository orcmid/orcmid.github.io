<?xml version="1.0" encoding="UTF-8"?>
<!--

  DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS FILE HEADER.
  
  Copyright 2008 by Sun Microsystems, Inc.
 
  OpenOffice.org - a multi-platform office productivity suite
 
  $RCSfile: $
 
  $Revision: $
 
  This file is part of OpenOffice.org.
 
  OpenOffice.org is free software: you can redistribute it and/or modify
  it under the terms of the GNU Lesser General Public License version 3
  only, as published by the Free Software Foundation.
 
  OpenOffice.org is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU Lesser General Public License version 3 for more details
  (a copy is included in the LICENSE file that accompanied this code).
 
  You should have received a copy of the GNU Lesser General Public License
  version 3 along with OpenOffice.org.  If not, see
  <http://www.openoffice.org/license.html>
  for a copy of the LGPLv3 License.
 
-->

<xsl:stylesheet xmlns:xsl="http://www.w3.org/1999/XSL/Transform" version="1.0"
                xmlns:rng="http://relaxng.org/ns/structure/1.0" 
>
    <xsl:output method="xml" indent="yes"/>
    
    <xsl:param name="interfaceName" select="'!UnknownInterface!'"/>
    <xsl:param name="elementName" select="'!UnknownElement!'"/>
    <xsl:param name="styleFamily" select="'none'"/>

    <xsl:param name="extends" select="''"/>
    <xsl:param name="elementNameForDerived" select="''"/>
    <xsl:param name="elementNameForBase" select="''"/>
    
    <xsl:variable name="createBase" select="$elementNameForBase != ''"/>
    <xsl:variable name="createDerived" select="$elementNameForDerived != ''"/>
    
    <xsl:include href="genXMLCodeHelpers.xsl"/>

    <!-- process schema -->
    <xsl:template match="/rng:grammar">
        <file>
            <package>
                <xsl:attribute name="name">
                    <xsl:call-template name="output-dirname-as-qname">
                        <xsl:with-param name="path" select="$interfaceName"/>
                    </xsl:call-template>
                </xsl:attribute>
            </package>
            <xsl:apply-templates select="rng:element[@name=$elementName]"/>
        </file>
    </xsl:template>

    <xsl:template match="rng:element">
        <xsl:variable name="hasFamily" select="$styleFamily != 'none'"/>
        <xsl:variable name="extends">
            <xsl:choose>
                <xsl:when test="$extends != ''">
                    <xsl:value-of select="$extends"/>
                </xsl:when>
                <xsl:when test="$hasFamily">
                    <xsl:text>org.openoffice.odf.dom.element.OdfStylableElement</xsl:text>
                </xsl:when>
                <xsl:otherwise>
                    <xsl:text>org.openoffice.odf.dom.element.OdfElement</xsl:text>
                </xsl:otherwise>
            </xsl:choose>
        </xsl:variable>

        <xsl:if test="not($createBase)">
            <import name="org.openoffice.odf.OdfName"/>
            <import name="org.openoffice.odf.OdfNamespace"/>
        </xsl:if>
        
        <xsl:variable name="interfaceNameNQ">
            <xsl:call-template name="output-filename">
                <xsl:with-param name="path" select="$interfaceName"/>
            </xsl:call-template>
        </xsl:variable>
        <interface name="{$interfaceNameNQ}" extends="{$extends}">
            <doc>
                <xsl:text>ODF DOM Element Interface for element &quot;&lt;</xsl:text>
                <xsl:value-of select="$elementName"/>
                <xsl:text>&gt;&quot;.</xsl:text>
            </doc>
            
            <xsl:if test="not($createBase)">
                <member modifier="public static final" type="OdfName" name="ELEMENT_NAME">
                    <xsl:call-template name="output-call-method-odfname-get">
                        <xsl:with-param name="qname" select="$elementName"/>
                    </xsl:call-template>
                </member>
            </xsl:if>

            <!--
            <method-decl modifier="public static" return="{$interfaceNameNQ}" name="newInstance">
                <doc>
                    <xsl:text>Create instance of </xsl:text>
                    <xsl:value-of select="$interfaceName"/>
                    <xsl:text>.</xsl:text>
                </doc>
                <xsl:call-template name="output-mandatory-formal-parametrs"/>
            </method-decl>
            -->
            
            <method-decl return="void" name="init">
                <doc>
                    <xsl:text>Initialite mandatory attributes.</xsl:text>
                </doc>
                <xsl:call-template name="output-mandatory-formal-parameters"/>
            </method-decl>
            
            <xsl:variable name="id" select="generate-id(.)"/>
            <xsl:for-each select=".//rng:attribute">
                <xsl:sort select="substring-after(@name,':')"/>
                <xsl:variable name="name" select="substring-after(@name,':')"/>
                <xsl:if test="not( preceding::rng:attribute[substring-after(@name,':') = $name and generate-id(ancestor::rng:element)=$id] )">
                    <xsl:call-template name="attribute"/>
                </xsl:if>
            </xsl:for-each>
        </interface>
    </xsl:template>
    
    <xsl:template name="attribute">
        <xsl:variable name="exclude">
            <xsl:call-template name="exclude-attributes"/>
        </xsl:variable>
        <xsl:if test="$exclude != 'true'">
        
            <xsl:variable name="javaName">
                <xsl:call-template name="output-name">
                    <xsl:with-param name="qname" select="@name"/>
                </xsl:call-template>
            </xsl:variable>

            <xsl:variable name="odfType">
                <!-- xsl:apply-templates select="rng:ref/@name"/ -->
                <xsl:call-template name="output-odf-type"/>
            </xsl:variable>

            <method-decl return="{$odfType}" name="get{$javaName}">
                <doc>
                    <xsl:text>Get value of attribute &quot;</xsl:text>
                    <xsl:value-of select="@name"/>
                    <xsl:text>&quot;.</xsl:text>
                </doc>
            </method-decl>
            <method-decl return="void" name="set{$javaName}">
                <param type="{$odfType}" name="_a{$javaName}"/>
                <doc>
                    <xsl:text>Set value of attribute &quot;</xsl:text>
                    <xsl:value-of select="@name"/>
                    <xsl:text>&quot;.</xsl:text>
                </doc>
            </method-decl>
        </xsl:if>
    </xsl:template>
            
</xsl:stylesheet>
