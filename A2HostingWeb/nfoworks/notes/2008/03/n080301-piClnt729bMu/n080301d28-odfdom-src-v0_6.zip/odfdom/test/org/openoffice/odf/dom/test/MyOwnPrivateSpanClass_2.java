/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package org.openoffice.odf.dom.test;

import org.openoffice.odf.doc.OdfFileDom;
import org.openoffice.odf.dom.element.text.OdfSpanElement;


public class MyOwnPrivateSpanClass_2 extends OdfSpanElement {

    /** Creates a new instance of OdfParagraphElementImpl */
    public MyOwnPrivateSpanClass_2(OdfFileDom ownerDoc) {
        super(ownerDoc);
    }
}
