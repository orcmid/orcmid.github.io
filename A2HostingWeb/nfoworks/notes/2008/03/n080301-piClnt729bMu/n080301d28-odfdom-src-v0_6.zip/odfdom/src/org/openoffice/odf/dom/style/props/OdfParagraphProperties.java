/************************************************************************
 *
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS FILE HEADER.
 * 
 * Copyright 2008 by Sun Microsystems, Inc.
 *
 * OpenOffice.org - a multi-platform office productivity suite
 *
 * $RCSfile: $
 * $Revision: $
 *
 * This file is part of OpenOffice.org.
 *
 * OpenOffice.org is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License version 3
 * only, as published by the Free Software Foundation.
 *
 * OpenOffice.org is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License version 3 for more details
 * (a copy is included in the LICENSE file that accompanied this code).
 *
 * You should have received a copy of the GNU Lesser General Public License
 * version 3 along with OpenOffice.org.  If not, see
 * <http://www.openoffice.org/license.html>
 * for a copy of the LGPLv3 License.
 *
 ************************************************************************/
// !!! GENERATED SOURCE CODE !!!
package org.openoffice.odf.dom.style.props;

import org.openoffice.odf.dom.OdfName;
import org.openoffice.odf.dom.OdfNamespace;


public interface OdfParagraphProperties {
    public final static OdfStyleProperty BackgroundColor = 
        OdfStyleProperty.get(OdfStylePropertiesSet.ParagraphProperties, OdfName.get(OdfNamespace.FO, "background-color"));
    public final static OdfStyleProperty Border = 
        OdfStyleProperty.get(OdfStylePropertiesSet.ParagraphProperties, OdfName.get(OdfNamespace.FO, "border"));
    public final static OdfStyleProperty BorderBottom = 
        OdfStyleProperty.get(OdfStylePropertiesSet.ParagraphProperties, OdfName.get(OdfNamespace.FO, "border-bottom"));
    public final static OdfStyleProperty BorderLeft = 
        OdfStyleProperty.get(OdfStylePropertiesSet.ParagraphProperties, OdfName.get(OdfNamespace.FO, "border-left"));
    public final static OdfStyleProperty BorderRight = 
        OdfStyleProperty.get(OdfStylePropertiesSet.ParagraphProperties, OdfName.get(OdfNamespace.FO, "border-right"));
    public final static OdfStyleProperty BorderTop = 
        OdfStyleProperty.get(OdfStylePropertiesSet.ParagraphProperties, OdfName.get(OdfNamespace.FO, "border-top"));
    public final static OdfStyleProperty BreakAfter = 
        OdfStyleProperty.get(OdfStylePropertiesSet.ParagraphProperties, OdfName.get(OdfNamespace.FO, "break-after"));
    public final static OdfStyleProperty BreakBefore = 
        OdfStyleProperty.get(OdfStylePropertiesSet.ParagraphProperties, OdfName.get(OdfNamespace.FO, "break-before"));
    public final static OdfStyleProperty HyphenationKeep = 
        OdfStyleProperty.get(OdfStylePropertiesSet.ParagraphProperties, OdfName.get(OdfNamespace.FO, "hyphenation-keep"));
    public final static OdfStyleProperty HyphenationLadderCount = 
        OdfStyleProperty.get(OdfStylePropertiesSet.ParagraphProperties, OdfName.get(OdfNamespace.FO, "hyphenation-ladder-count"));
    public final static OdfStyleProperty JoinBorder = 
        OdfStyleProperty.get(OdfStylePropertiesSet.ParagraphProperties, OdfName.get(OdfNamespace.STYLE, "join-border"));
    public final static OdfStyleProperty KeepTogether = 
        OdfStyleProperty.get(OdfStylePropertiesSet.ParagraphProperties, OdfName.get(OdfNamespace.FO, "keep-together"));
    public final static OdfStyleProperty KeepWithNext = 
        OdfStyleProperty.get(OdfStylePropertiesSet.ParagraphProperties, OdfName.get(OdfNamespace.FO, "keep-with-next"));
    public final static OdfStyleProperty LineHeight = 
        OdfStyleProperty.get(OdfStylePropertiesSet.ParagraphProperties, OdfName.get(OdfNamespace.FO, "line-height"));
    public final static OdfStyleProperty Margin = 
        OdfStyleProperty.get(OdfStylePropertiesSet.ParagraphProperties, OdfName.get(OdfNamespace.FO, "margin"));
    public final static OdfStyleProperty MarginBottom = 
        OdfStyleProperty.get(OdfStylePropertiesSet.ParagraphProperties, OdfName.get(OdfNamespace.FO, "margin-bottom"));
    public final static OdfStyleProperty MarginLeft = 
        OdfStyleProperty.get(OdfStylePropertiesSet.ParagraphProperties, OdfName.get(OdfNamespace.FO, "margin-left"));
    public final static OdfStyleProperty MarginRight = 
        OdfStyleProperty.get(OdfStylePropertiesSet.ParagraphProperties, OdfName.get(OdfNamespace.FO, "margin-right"));
    public final static OdfStyleProperty MarginTop = 
        OdfStyleProperty.get(OdfStylePropertiesSet.ParagraphProperties, OdfName.get(OdfNamespace.FO, "margin-top"));
    public final static OdfStyleProperty Orphans = 
        OdfStyleProperty.get(OdfStylePropertiesSet.ParagraphProperties, OdfName.get(OdfNamespace.FO, "orphans"));
    public final static OdfStyleProperty Padding = 
        OdfStyleProperty.get(OdfStylePropertiesSet.ParagraphProperties, OdfName.get(OdfNamespace.FO, "padding"));
    public final static OdfStyleProperty PaddingBottom = 
        OdfStyleProperty.get(OdfStylePropertiesSet.ParagraphProperties, OdfName.get(OdfNamespace.FO, "padding-bottom"));
    public final static OdfStyleProperty PaddingLeft = 
        OdfStyleProperty.get(OdfStylePropertiesSet.ParagraphProperties, OdfName.get(OdfNamespace.FO, "padding-left"));
    public final static OdfStyleProperty PaddingRight = 
        OdfStyleProperty.get(OdfStylePropertiesSet.ParagraphProperties, OdfName.get(OdfNamespace.FO, "padding-right"));
    public final static OdfStyleProperty PaddingTop = 
        OdfStyleProperty.get(OdfStylePropertiesSet.ParagraphProperties, OdfName.get(OdfNamespace.FO, "padding-top"));
    public final static OdfStyleProperty TextAlign = 
        OdfStyleProperty.get(OdfStylePropertiesSet.ParagraphProperties, OdfName.get(OdfNamespace.FO, "text-align"));
    public final static OdfStyleProperty TextAlignLast = 
        OdfStyleProperty.get(OdfStylePropertiesSet.ParagraphProperties, OdfName.get(OdfNamespace.FO, "text-align-last"));
    public final static OdfStyleProperty TextIndent = 
        OdfStyleProperty.get(OdfStylePropertiesSet.ParagraphProperties, OdfName.get(OdfNamespace.FO, "text-indent"));
    public final static OdfStyleProperty Widows = 
        OdfStyleProperty.get(OdfStylePropertiesSet.ParagraphProperties, OdfName.get(OdfNamespace.FO, "widows"));
    public final static OdfStyleProperty AutoTextIndent = 
        OdfStyleProperty.get(OdfStylePropertiesSet.ParagraphProperties, OdfName.get(OdfNamespace.STYLE, "auto-text-indent"));
    public final static OdfStyleProperty BackgroundTransparency = 
        OdfStyleProperty.get(OdfStylePropertiesSet.ParagraphProperties, OdfName.get(OdfNamespace.STYLE, "background-transparency"));
    public final static OdfStyleProperty BorderLineWidth = 
        OdfStyleProperty.get(OdfStylePropertiesSet.ParagraphProperties, OdfName.get(OdfNamespace.STYLE, "border-line-width"));
    public final static OdfStyleProperty BorderLineWidthBottom = 
        OdfStyleProperty.get(OdfStylePropertiesSet.ParagraphProperties, OdfName.get(OdfNamespace.STYLE, "border-line-width-bottom"));
    public final static OdfStyleProperty BorderLineWidthLeft = 
        OdfStyleProperty.get(OdfStylePropertiesSet.ParagraphProperties, OdfName.get(OdfNamespace.STYLE, "border-line-width-left"));
    public final static OdfStyleProperty BorderLineWidthRight = 
        OdfStyleProperty.get(OdfStylePropertiesSet.ParagraphProperties, OdfName.get(OdfNamespace.STYLE, "border-line-width-right"));
    public final static OdfStyleProperty BorderLineWidthTop = 
        OdfStyleProperty.get(OdfStylePropertiesSet.ParagraphProperties, OdfName.get(OdfNamespace.STYLE, "border-line-width-top"));
    public final static OdfStyleProperty FontIndependentLineSpacing = 
        OdfStyleProperty.get(OdfStylePropertiesSet.ParagraphProperties, OdfName.get(OdfNamespace.STYLE, "font-independent-line-spacing"));
    public final static OdfStyleProperty JustifySingleWord = 
        OdfStyleProperty.get(OdfStylePropertiesSet.ParagraphProperties, OdfName.get(OdfNamespace.STYLE, "justify-single-word"));
    public final static OdfStyleProperty LineBreak = 
        OdfStyleProperty.get(OdfStylePropertiesSet.ParagraphProperties, OdfName.get(OdfNamespace.STYLE, "line-break"));
    public final static OdfStyleProperty LineHeightAtLeast = 
        OdfStyleProperty.get(OdfStylePropertiesSet.ParagraphProperties, OdfName.get(OdfNamespace.STYLE, "line-height-at-least"));
    public final static OdfStyleProperty LineSpacing = 
        OdfStyleProperty.get(OdfStylePropertiesSet.ParagraphProperties, OdfName.get(OdfNamespace.STYLE, "line-spacing"));
    public final static OdfStyleProperty PageNumber = 
        OdfStyleProperty.get(OdfStylePropertiesSet.ParagraphProperties, OdfName.get(OdfNamespace.STYLE, "page-number"));
    public final static OdfStyleProperty PunctuationWrap = 
        OdfStyleProperty.get(OdfStylePropertiesSet.ParagraphProperties, OdfName.get(OdfNamespace.STYLE, "punctuation-wrap"));
    public final static OdfStyleProperty RegisterTrue = 
        OdfStyleProperty.get(OdfStylePropertiesSet.ParagraphProperties, OdfName.get(OdfNamespace.STYLE, "register-true"));
    public final static OdfStyleProperty StyleShadow = 
        OdfStyleProperty.get(OdfStylePropertiesSet.ParagraphProperties, OdfName.get(OdfNamespace.STYLE, "shadow"));
    public final static OdfStyleProperty SnapToLayoutGrid = 
        OdfStyleProperty.get(OdfStylePropertiesSet.ParagraphProperties, OdfName.get(OdfNamespace.STYLE, "snap-to-layout-grid"));
    public final static OdfStyleProperty TabStopDistance = 
        OdfStyleProperty.get(OdfStylePropertiesSet.ParagraphProperties, OdfName.get(OdfNamespace.STYLE, "tab-stop-distance"));
    public final static OdfStyleProperty TextAutospace = 
        OdfStyleProperty.get(OdfStylePropertiesSet.ParagraphProperties, OdfName.get(OdfNamespace.STYLE, "text-autospace"));
    public final static OdfStyleProperty VerticalAlign = 
        OdfStyleProperty.get(OdfStylePropertiesSet.ParagraphProperties, OdfName.get(OdfNamespace.STYLE, "vertical-align"));
    public final static OdfStyleProperty WritingMode = 
        OdfStyleProperty.get(OdfStylePropertiesSet.ParagraphProperties, OdfName.get(OdfNamespace.STYLE, "writing-mode"));
    public final static OdfStyleProperty WritingModeAutomatic = 
        OdfStyleProperty.get(OdfStylePropertiesSet.ParagraphProperties, OdfName.get(OdfNamespace.STYLE, "writing-mode-automatic"));
    public final static OdfStyleProperty LineNumber = 
        OdfStyleProperty.get(OdfStylePropertiesSet.ParagraphProperties, OdfName.get(OdfNamespace.TEXT, "line-number"));
    public final static OdfStyleProperty NumberLines = 
        OdfStyleProperty.get(OdfStylePropertiesSet.ParagraphProperties, OdfName.get(OdfNamespace.TEXT, "number-lines"));
}
