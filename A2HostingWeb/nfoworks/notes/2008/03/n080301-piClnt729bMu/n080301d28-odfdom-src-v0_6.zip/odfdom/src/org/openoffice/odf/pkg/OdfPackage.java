/************************************************************************
 *
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS FILE HEADER.
 * 
 * Copyright 2008 by Sun Microsystems, Inc.
 *
 * OpenOffice.org - a multi-platform office productivity suite
 *
 * $RCSfile: $
 * $Revision: $
 *
 *
 * OpenOffice.org is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License version 3
 * only, as published by the Free Software Foundation.
 *
 * OpenOffice.org is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License version 3 for more details
 * (a copy is included in the LICENSE file that accompanied this code).
 *
 * You should have received a copy of the GNU Lesser General Public License
 * version 3 along with OpenOffice.org.  If not, see
 * <http://www.openoffice.org/license.html>
 * for a copy of the LGPLv3 License.
 *
 ************************************************************************/
package org.openoffice.odf.pkg;

import java.io.IOException;
import org.openoffice.odf.*;
import java.io.File;
import java.io.OutputStream;
import java.io.InputStream;
import java.io.FileOutputStream;
import java.io.FileInputStream;
import java.io.ByteArrayOutputStream;
import java.io.ByteArrayInputStream;
import java.io.BufferedOutputStream;
import java.io.BufferedInputStream;
import java.io.PipedOutputStream;
import java.io.PipedInputStream;
import java.io.UnsupportedEncodingException;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.zip.ZipOutputStream;
import java.util.zip.ZipEntry;
import java.util.zip.CRC32;
import java.util.StringTokenizer;
import java.util.List;
import java.util.LinkedList;
import java.util.HashMap;
import java.util.Iterator;
import javax.xml.parsers.SAXParserFactory;
import javax.xml.parsers.SAXParser;
import javax.xml.parsers.ParserConfigurationException;
import org.xml.sax.XMLReader;
import org.xml.sax.EntityResolver;
import org.xml.sax.InputSource;
import org.xml.sax.ContentHandler;
import org.xml.sax.Locator;
import org.xml.sax.SAXException;
import org.xml.sax.Attributes;
import org.xml.sax.InputSource;
import javax.xml.transform.Source;
import javax.xml.transform.stream.StreamSource;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerConfigurationException;
import javax.xml.transform.URIResolver;
import java.net.URL;
import java.net.MalformedURLException;
import java.net.URI;
import java.net.URISyntaxException;
import java.net.JarURLConnection;
import java.util.Enumeration;
import java.util.zip.ZipFile;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.Result;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import org.openoffice.odf.doc.OdfDocument;
import org.w3c.dom.Document;


import org.openoffice.odf.pkg.manifest.FileEntry;
import org.openoffice.odf.pkg.manifest.EncryptionData;
import org.openoffice.odf.pkg.manifest.KeyDerivation;
import org.openoffice.odf.pkg.manifest.Algorithm;

/**
 * OdfPackage represents the package view to an OpenDocument document.
 */
public class OdfPackage {

    public static final String STREAMNAME_CONTENT = "content.xml";
    public static final String STREAMNAME_STYLES = "styles.xml";
    public static final String STREAMNAME_META = "meta.xml";
    public static final String STREAMNAME_SETTINGS = "settings.xml";
    public static final String STREAMNAME_MANIFEST = "META-INF/manifest.xml";

    // global parent Directory for tempDirs
    private static File mTempDirParent = null;
    // temp Dir for this ODFpackage
    private File mTempDir = null;
    // some well known streams inside ODF packages    
    private String mMimetype;
    private List mEntries;
    private ZipFile mZipFile;
    private HashMap mDoms;
    private HashMap mZipEntries;
    private HashMap mContents;
    private HashMap mTempFiles;    
    private List mManifestList;
    private HashMap mManifestEntries;
    private String mBaseURI;
    private Resolver mResolver;

    
    
    /**
     * Creates an empty package.
     */
    public OdfPackage() {
        initialize();
    }

    /**
     * Creates an OdfPackage from the OpenDocument provided by a path.
     *
     * @param path - the path to the ODF document.
     * @throws java.lang.Exception - if the package could not be created
     */
    public OdfPackage(String path) throws Exception {
        initialize(path);
    }

    /**
     * Creates an OdfPackage from the OpenDocument provided by a File.
     *
     * @param file - a file representing the ODF document
     * @throws java.lang.Exception - if the package could not be created
     */
    public OdfPackage(File file) throws Exception {
        initialize(file);
    }

    /**
     * Load a package from given path.
     *
     * @param path - the local path to the file
     * @return the OpenDocument represented by an OdfPackage
     * @throws java.lang.Exception - if the package could not be loaded
     */
    public static OdfPackage load(String path) throws Exception {
        return new OdfPackage(path);
    }

    /**
     * Loads an OdfPackage from the OpenDocument provided by a File.
     *
     * @param file - a File to load content from
     * @return the OpenDocument represented by an OdfPackage
     * @throws java.lang.Exception - if the package could not be loaded
     */
    public static OdfPackage load(File file) throws Exception {
        return new OdfPackage(file);
    }

    private void initialize(String path) throws Exception{
        initialize(new File(path));
    }        
        
    private void initialize(File f) throws Exception{      
        initialize();
        mBaseURI = getBaseURIFromFile(f);
        
        mZipFile = new ZipFile(f);
        Enumeration<? extends ZipEntry>  zipEntries = mZipFile.entries();      
        try {
            ZipEntry zipEntry;                            
            while (zipEntries.hasMoreElements()) {
                zipEntry = zipEntries.nextElement();
                if (zipEntry.isDirectory()) {
                    insert(zipEntry, (byte[]) null);
                } else {
                    OutputStream os = null;
                    if (zipEntry.getName().endsWith(".xml") || zipEntry.getName().equals("mimetype")) {
                        os = new StoreContentOutputStream(zipEntry);
                    } else {
                        os = new StoreTempOutputStream(zipEntry);
                    }
                    if (os != null) {
                        byte[] buf = new byte[4096];
                        int r = 0;
                        InputStream is = mZipFile.getInputStream(zipEntry);
                        while ((r = is.read(buf, 0, 4096)) > -1) {
                            os.write(buf, 0, r);
                        }
                        os.close();
                    }                    
                }
            }
            parseManifest();
//          decryptAll();
            
        } catch (SAXException se) {
            throw new Exception("SAXException:" + se.getMessage());
        } catch (ParserConfigurationException pce) {
            throw new Exception("ParserConfigurationException:" + pce.getMessage());
        } catch (TransformerConfigurationException tce) {
            throw new Exception("TransformerConfigurationException:" + tce.getMessage());
        } catch (TransformerException te) {
            throw new Exception("TransformerException:" + te.getMessage());
        }
    }

    /**
     * Set the baseURI for this package. NOTE: Should only be set during saving the package.
     */
    void setBaseURI(String baseURI) {
        mBaseURI = baseURI;
    }

   /**
     * Get the URI, where this ODF package is stored. 
     * @return the URI to the ODF package. Returns null if package is not stored yet.
     */
    public String getBaseURI() {
        return mBaseURI;
    }

    /**
     * Removes all content, resets to not password protected
     * <p>This basically transforms the ODFPackage to an empty Package</p>
     */
    void initialize() {
        mMimetype = null;
        mEntries = new LinkedList();
        mZipEntries = new HashMap();
        mDoms = new HashMap();
        mContents = new HashMap();
        mTempFiles = new HashMap();
        mManifestList = new LinkedList();
        mManifestEntries = null;
        if (mTempDir != null) {
            TempDir.release(mTempDir);
            mTempDir = null;
        }
    }

    /**
     * Get the mimetype
     * 
     * @return the MIMETYPE string of this package
     */
    public String getMimetype() {
        return mMimetype;
    }

    /**
     * Set the mimetype
     * 
     * @param mimetype string of this package
     */
    public void setMimetype(String mimetype) {
        mMimetype = mimetype;
        if (mMimetype == null) {
            mEntries.remove("mimetype");
        } else {
            if (!mEntries.contains("mimetype")) {
                mEntries.add(0, "mimetype");
            }
        }
    }

    /**
     * 
     * Get FileEntry for path
     * NOTE: This method should be better moved to a DOM inherited Manifest class
     */
    public FileEntry getFileEntry(String path) {
        if (mManifestEntries == null) {
            try {
                parseManifest();
            } catch (Exception ex) {
                Logger.getLogger(OdfPackage.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        return (FileEntry) mManifestEntries.get(path);
    }

    /**
     * Save the package to given path.
     *
     * @param path - the path to the file
     * @throws java.lang.Exception - if the package could not be saved
     */
    public void save(String path) throws Exception {

        File f = new File(path);
        save(f);
    }

    /**
     * Save package to a given File.
     *
     * @param file - a File to save the package to.
     * @throws java.lang.Exception - if the package could not be saved
     */
    public void save(File file) throws Exception {

        FileOutputStream fos = new FileOutputStream(file);
        String baseURI = file.getCanonicalFile().toURI().toString();
        if (File.separatorChar == '\\') {
            baseURI = baseURI.replaceAll("\\\\", "/");
        }
        save(fos, baseURI);
    }

    /**
     * Save to OutputStream
     *
     * @param os - the OutputStream to insert content to
     * @param baseURI - a URI for the package to be stored
     * @throws java.lang.Exception - if the package could not be saved
     */
    public void save(OutputStream os, String baseURI) throws Exception {

        mBaseURI = baseURI;

        if (mManifestEntries == null) {
            try {
                parseManifest();
            } catch (Exception e) {
                throw new RuntimeException(e);
            }
        }

        FileEntry slashEntry = (FileEntry) mManifestEntries.get("/");
        if (slashEntry == null) {
            slashEntry = new FileEntry("/", mMimetype);
            mManifestList.add(0, slashEntry);
        } else {
            slashEntry.setMediaType(mMimetype);
        }

        ZipOutputStream zos = new ZipOutputStream(os);
        long modTime = (new java.util.Date()).getTime();

        Iterator it = mEntries.iterator();
        while (it.hasNext()) {
            String key = (String) it.next();
            byte[] data = getBytes(key);

            ZipEntry ze = (ZipEntry) mZipEntries.get(key);
            if (ze == null) {
                ze = new ZipEntry(key);
            }
            ze.setTime(modTime);

            if (key.equals("mimetype") || key.equals("meta.xml")) {
                ze.setMethod(ZipEntry.STORED);
            } else {
                ze.setMethod(ZipEntry.DEFLATED);
            }

            CRC32 crc = new CRC32();
            if (data != null) {
                crc.update(data);
                ze.setSize(data.length);
            } else {
                ze.setMethod(ZipEntry.STORED);
                ze.setSize(0);
            }
            ze.setCrc(crc.getValue());
            ze.setCompressedSize(-1);
            zos.putNextEntry(ze);
            if (data != null) {
                zos.write(data, 0, data.length);
            }
            zos.closeEntry();

            mZipEntries.put(key, ze);

        }

        zos.close();

        os.flush();
    }


    /*
    public DocumentProperties getDocumentProperties() {
    return new DocumentProperties(this);
    }
//     */
//    /**
//     * get ODFDOM Document for docuemnt in this package
//     */
//    OdfDocument getOdfDocument() throws SAXException, Exception {
//        OdfDocumentFactory builder = OdfDocumentFactory.newInstance();
//        OdfDocument doc = builder.parse(this);
//        // the OdfDocument reads content and styles, so those need to be detached
//        // from the package
//        if (doc != null) {
//            mDoms.put(STREAMNAME_CONTENT, doc);
//            mDoms.put(STREAMNAME_STYLES, doc);
//            mContents.remove(STREAMNAME_CONTENT);
//            mContents.remove(STREAMNAME_STYLES);
//        }
//        return doc;
//    }

 
//    /**
//     * get Stream for XML Subcontent
//     *
//     * @throws IllegalArgumentException
//     * if filetype of subcontent is not text/xmlo
//     */
//    public InputStream getXMLInputStream(String path)
//            throws Exception {
//
//        if (path.equals("META-INF/manifest.xml")) {
//            if (mContents.get(path) == null) {
//                throw new Exception(mBaseURI + ": " + path + " not found in package");
//            }
//        } else {
//            if (mManifestEntries == null) {
//                try {
//                    parseManifest();
//                } catch (Exception ex) {
//                    Logger.getLogger(OdfPackage.class.getName()).log(Level.SEVERE, null, ex);
//                }
//            }
//            FileEntry fileEntry = (FileEntry) mManifestEntries.get(path);
//            if (fileEntry == null) {
//                throw new Exception(mBaseURI + ": " + path + " not found in package");
//            }
//            if (!"text/xml".equals(fileEntry.getMediaType())) {
//                throw new IllegalArgumentException(mBaseURI + ": " + path + " is not of type text/xml");
//            }
//        }
//        InputStream is = getInputStream(path);
//        if (is == null) {
//            throw new Exception(mBaseURI + ": " + path + " not found in package");
//        }
//        return is;
//    }

    /**
     * data was updated, update mZipEntry and FileEntry as well
     */
    private void entryUpdate(String path)
            throws Exception, SAXException,
            TransformerConfigurationException, TransformerException,
            ParserConfigurationException {

        byte[] data = getBytes(path);
        int size = 0;
        if (data == null) {
            size = 0;
        } else {
            size = data.length;
        }
        if (mManifestEntries == null) {
            parseManifest();
        }
        FileEntry fileEntry = (FileEntry) mManifestEntries.get(path);
        ZipEntry zipEntry = (ZipEntry) mZipEntries.get(path);
        if (zipEntry == null) {
            return;
        }
        if (fileEntry != null) {
            if ("text/xml".equals(fileEntry.getMediaType())) {
                fileEntry.setSize(-1);
            } else {
                fileEntry.setSize(size);
            }
        }
        zipEntry.setSize(size);
        CRC32 crc = new CRC32();
        if ((data != null) && size > 0) {
            crc.update(data);
        }
        zipEntry.setCrc(crc.getValue());
        zipEntry.setCompressedSize(-1);
        long modTime = (new java.util.Date()).getTime();
        zipEntry.setTime(modTime);

    }

    /**
     * parse the Manifest file
     */
    void parseManifest()
            throws SAXException, ParserConfigurationException,
            Exception,
            TransformerConfigurationException, TransformerException {

        InputStream is = getInputStream("META-INF/manifest.xml");
        if (is == null) {
            mManifestList = null;
            mManifestEntries = null;
            return;
        }

        mManifestList = new LinkedList();

        SAXParserFactory factory = SAXParserFactory.newInstance();
        factory.setNamespaceAware(true);
        factory.setValidating(false);
        factory.setFeature("http://apache.org/xml/features/nonvalidating/load-external-dtd", false);

        SAXParser parser = factory.newSAXParser();
        XMLReader reader = parser.getXMLReader();

        String uri = mBaseURI + "/META-INF/manifest.xml";
        reader.setEntityResolver(getEntityResolver());
        reader.setContentHandler(new ManifestContentHandler());

        InputSource ins = new InputSource(is);
        ins.setSystemId(uri);

        reader.parse(ins);

        mContents.remove("META-INF/manifest.xml");
        entryUpdate("META-INF/manifest.xml");
    }

    /**
     * add a directory to the OdfPackage
     */
    private void addDirectory(String path) throws Exception {

        if ((path.length() < 1) || (path.charAt(path.length() - 1) != '/')) {
            path = path + "/";
        }
        insert((byte[]) null, null, path);

    }

    /**
     * insert DOM tree into OdfPackage
     * @param path - relative path where the DOM tree should be inserted as XML file
     * @param dom - dom tree to be inserted as file
     * @throws java.lang.Exception when the DOM tree could not be inserted
     */
    public void insert(Document dom, String path) throws Exception {

        if (mManifestEntries == null) {
            try {
                parseManifest();
            } catch (Exception e) {
                throw new RuntimeException(e);
            }
        }

        String mediaType = "text/xml";
        String d = "";
        StringTokenizer tok = new StringTokenizer(path, "/");
        {
            while (tok.hasMoreTokens()) {
                String s = tok.nextToken();
                if ("".equals(d)) {
                    d = s + "/";
                } else {
                    d = d + s + "/";
                }
                if (tok.hasMoreTokens()) {
                    if (!mEntries.contains(d)) {
                        addDirectory(d);
                    }
                }
            }
        }

        mContents.remove(path);
        if (dom == null) {
            mDoms.remove(path);
        } else {
            mDoms.put(path, dom);
        }

        if (!mEntries.contains(path)) {
            mEntries.add(path);
        }

        try {
            if (!"META-INF/manifest.xml".equals(path)) {
                if (mManifestEntries.get(path) == null) {
                    FileEntry fileEntry = new FileEntry(path, mediaType);
                    mManifestEntries.put(path, fileEntry);
                    mManifestList.add(path);
                }
            } else {
                parseManifest();
            }

            ZipEntry ze = (ZipEntry) mZipEntries.get(path);
            if (ze != null) {
                ze = new ZipEntry(path);
                ze.setMethod(ZipEntry.DEFLATED);
                mZipEntries.put(path, ze);
            }
            if (path.equals("mimetype") || path.equals("meta.xml")) {
                ze.setMethod(ZipEntry.STORED);
            }

            entryUpdate(path);
        } catch (SAXException se) {
            throw new Exception("SAXException:" + se.getMessage());
        } catch (ParserConfigurationException pce) {
            throw new Exception("ParserConfigurationException:" + pce.getMessage());
        } catch (TransformerConfigurationException tce) {
            throw new Exception("TransformerConfigurationException:" + tce.getMessage());
        } catch (TransformerException te) {
            throw new Exception("TransformerException:" + te.getMessage());
        }
    }
    
        
     /**
     * returns true if a DOM tree has been requested
     * for given sub-content of OdfPackage
     */
    boolean hasDom(String path) {
        return (mDoms.get(path) != null);
    }   
    
  /**
     * Gets org.w3c.dom.Document for XML file contained in package.
     */
    Document getDom(String path)
            throws SAXException, ParserConfigurationException,
            Exception, IllegalArgumentException,
            TransformerConfigurationException, TransformerException {

        Document doc = (Document) mDoms.get(path);
        if (doc != null) {
            return doc;
        }

        InputStream is = getInputStream(path);

        DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
        factory.setNamespaceAware(true);
        factory.setValidating(false);

        DocumentBuilder builder = factory.newDocumentBuilder();
        builder.setEntityResolver(getEntityResolver());

        String uri = getBaseURI() + path;

//        if (mErrorHandler != null) {
//            builder.setErrorHandler(mErrorHandler);
//        }

        InputSource ins = new InputSource(is);
        ins.setSystemId(uri);

        doc = builder.parse(ins);

        if (doc != null) {
            mDoms.put(path, doc);
//            mContents.remove(path);
        }
        return doc;
    }
    
    /**
     * Inserts InputStream into an OdfPackage.
     * @param is - the stream of the file to be inserted into the package.
     * @param mediaType - MIME type of stream
     * @param path - relative path, where the stream should be saved 
     * @throws java.lang.Exception
     */
    public void insert(InputStream is, String mediaType, String path)
            throws Exception {
        if (path.indexOf('\\') != -1) {
            path = path.replace('\\', '/');
        }
        if (is == null) {
            insert((byte[]) null, mediaType,path);
        } else {
            ByteArrayOutputStream baos = new ByteArrayOutputStream();
            BufferedInputStream bis = new BufferedInputStream(is);
            byte[] buf = new byte[4096];
            int r = 0;
            while ((r = bis.read(buf, 0, 4096)) > -1) {
                baos.write(buf, 0, r);
            }
            byte[] data = baos.toByteArray();
            insert(data, mediaType,path);
            // image should not be stored in memory but on disc
            if ((!path.endsWith(".xml")) && (!path.equals("mimetype"))) {
                // insert to filesystem
                File tempFile = new File(getTempDir(), path);
                File parent = tempFile.getParentFile();
                parent.mkdirs();
                OutputStream fos = new BufferedOutputStream(new FileOutputStream(tempFile));
                fos.write(data);
                fos.close();
                mTempFiles.put(path, tempFile);
                mContents.remove(path);
            }

        }
    }

    /**
     * Inserts an byte array into the OdfPackage.
     */
    public void insert(byte[] data, String mediaType, String path) throws Exception {
        if (path.indexOf('\\') != -1) {
            path = path.replace('\\', '/');
        }
        String d = "";
        //2DO: Test tokenizer for whitespaces..
        StringTokenizer tok = new StringTokenizer(path, "/");
        {
            while (tok.hasMoreTokens()) {
                String s = tok.nextToken();
                if ("".equals(d)) {
                    d = s + "/";
                } else {
                    d = d + s + "/";
                }
                if (tok.hasMoreTokens()) {
                    if (!mEntries.contains(d)) {
                        addDirectory(d);
                    }
                }
            }
        }

        try {
            if ("mimetype".equals(path)) {
                try {
                    setMimetype(new String(data, "UTF-8"));
                } catch (UnsupportedEncodingException use) {
                }
                return;
            }
            if (data == null) {
                mContents.remove(path);
            } else {
                mContents.put(path, data);
            }
            if (!mEntries.contains(path)) {
                mEntries.add(path);
            }
            if (!"META-INF/manifest.xml".equals(path)) {
                if (mediaType != null) {
                    if (mManifestEntries.get(path) == null) {
                        FileEntry fileEntry = new FileEntry(path, mediaType);
                        mManifestEntries.put(path, fileEntry);
                        if (mManifestList.contains(path)) {
                            mManifestList.add(path);
                        }
                    }
                }
            } else {
                parseManifest();
            }
            ZipEntry ze = (ZipEntry) mZipEntries.get(path);
            if (ze != null) {
                ze = new ZipEntry(path);
                ze.setMethod(ZipEntry.DEFLATED);
                mZipEntries.put(path, ze);
            }
            if (path.equals("mimetype") || path.equals("meta.xml")) {
                ze.setMethod(ZipEntry.STORED);
            }

            entryUpdate(path);

        } catch (SAXException se) {
            throw new Exception("SAXException:" + se.getMessage());
        } catch (ParserConfigurationException pce) {
            throw new Exception("ParserConfigurationException:" + pce.getMessage());
        } catch (TransformerConfigurationException tce) {
            throw new Exception("TransformerConfigurationException:" + tce.getMessage());
        } catch (TransformerException te) {
            throw new Exception("TransformerException:" + te.getMessage());
        }
    }

    private void insert(ZipEntry zipe, byte[] content) {
        if (content != null) {
            if (zipe.getName().equals("mimetype")) {
                try {
                    mMimetype = new String(content, 0, content.length, "UTF-8");
                } catch (UnsupportedEncodingException ex) {
                    Logger.getLogger(OdfPackage.class.getName()).log(Level.SEVERE, null, ex);
                }
            } else {
                mContents.put(zipe.getName(), content);
            }
        }
        if (!mEntries.contains(zipe.getName())) {
            mEntries.add(zipe.getName());
        }
        mZipEntries.put(zipe.getName(), zipe);
    }

    private void insert(ZipEntry zipe, File file) {
        if (file != null) {
            mTempFiles.put(zipe.getName(), file);
        }
        if (!mEntries.contains(zipe.getName())) {
            mEntries.add(zipe.getName());
        }
        mZipEntries.put(zipe.getName(), zipe);
    }

    /**
     * Get Manifest as String
     * NOTE: This functionality should better be moved to a DOM based Manifest class
     */
    String getManifestAsString() {
        if (mManifestEntries == null) {
            try {
                parseManifest();
                if (mManifestEntries == null) {
                    return null;
                }
            } catch (Exception e) {
                throw new RuntimeException(e);
            }
        }
        StringBuffer buf = new StringBuffer();

        buf.append("<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n");
        buf.append("<manifest:manifest xmlns:manifest=\"urn:oasis:names:tc:opendocument:xmlns:manifest:1.0\">\n");

        Iterator it = mManifestList.iterator();
        while (it.hasNext()) {
            String key = (String) it.next();
            String s = null;
            FileEntry fileEntry = (FileEntry) mManifestEntries.get(key);
            if (fileEntry != null) {
                buf.append(" <manifest:file-entry");
                s = fileEntry.getMediaType();
                if (s == null) {
                    s = "";
                }
                buf.append(" manifest:media-type=\"");
                buf.append(encodeXMLAttributes(s));
                buf.append("\"");
                s = fileEntry.getPath();

                if (s == null) {
                    s = "";
                }
                buf.append(" manifest:full-path=\"");
                buf.append(encodeXMLAttributes(s));
                buf.append("\"");
                int i = fileEntry.getSize();
                if (i > 0) {
                    buf.append(" manifest:size=\"");
                    buf.append(i);
                    buf.append("\"");
                }
                EncryptionData enc = fileEntry.getEncryptionData();

                if (enc != null) {
                    buf.append(">\n");
                    buf.append("  <manifest:encryption-data>\n");
                    Algorithm alg = enc.getAlgorithm();
                    if (alg != null) {
                        buf.append("   <manifest:algorithm");
                        s = alg.getName();
                        if (s == null) {
                            s = "";
                        }
                        buf.append(" manifest:algorithm-name=\"");
                        buf.append(encodeXMLAttributes(s));
                        buf.append("\"");
                        s = alg.getInitializationVector();
                        if (s == null) {
                            s = "";
                        }
                        buf.append(" manifest:initialization-vector=\"");
                        buf.append(encodeXMLAttributes(s));
                        buf.append("\"/>\n");
                    }
                    KeyDerivation keyDerivation = enc.getKeyDerivation();
                    if (keyDerivation != null) {
                        buf.append("   <manifest:key-derivation");
                        s = keyDerivation.getName();
                        if (s == null) {
                            s = "";
                        }
                        buf.append(" manifest:key-derivation-name=\"");
                        buf.append(encodeXMLAttributes(s));
                        buf.append("\"");
                        s = keyDerivation.getSalt();
                        if (s == null) {
                            s = "";
                        }
                        buf.append(" manifest:salt=\"");
                        buf.append(encodeXMLAttributes(s));
                        buf.append("\"");

                        buf.append(" manifest:iteration-count=\"");
                        buf.append(keyDerivation.getIterationCount());
                        buf.append("\"/>\n");
                    }
                    buf.append("  </manifest:encryption-data>\n");
                    buf.append(" </<manifest:file-entry>\n");
                } else {
                    buf.append("/>\n");
                }
            }
        }
        buf.append("</manifest:manifest>");

        return buf.toString();
    }

    /**
     * Get package (sub-) content as byte array
     * 
     * @param path relative path to the package content
     * @return the unzipped package content as byte array
     * @throws java.lang.Exception
     */
    public byte[] getBytes(String path)
            throws Exception {

        byte[] data = null;

        try {

            if (path == null || path.equals("")) {
                ByteArrayOutputStream baos = new ByteArrayOutputStream();
                save(baos, mBaseURI);
                return baos.toByteArray();
            }
            if (path.equals("mimetype")) {
                if (mMimetype == null) {
                    return null;
                }
                try {
                    data = mMimetype.getBytes("UTF-8");
                } catch (UnsupportedEncodingException use) {
                    return null;
                }
            } else if (mEntries.contains(path) && mDoms.get(path) != null) {
                if ((path.equals(STREAMNAME_CONTENT) || path.equals(STREAMNAME_STYLES)) && mDoms.get(STREAMNAME_CONTENT) instanceof OdfDocument) {
                    OdfDocument odfdoc = (OdfDocument) mDoms.get(STREAMNAME_CONTENT);
                    Document doc = null;
                    if (path.equals(STREAMNAME_CONTENT)) {
                        doc = odfdoc.getContent();
                    } else {
                        doc = odfdoc.getStyles();
                    }
                    ByteArrayOutputStream baos = new ByteArrayOutputStream();
                    Transformer trans = TransformerFactory.newInstance().newTransformer();
                    trans.transform(new DOMSource(doc), new StreamResult(baos));
                    data = baos.toByteArray();
                } else {
                    ByteArrayOutputStream baos = new ByteArrayOutputStream();
                    OdfXMLHelper helper = new OdfXMLHelper();
                    Result result = new StreamResult(baos);
                    EntityResolver resolver = getEntityResolver();
                    InputSource ins = resolver.resolveEntity(null, "resource:/resources/identity.xsl");
                    if (ins == null) {
                        throw new Exception("Resource not found: resource:/resources/identity.xsl");
                    }
                    Source source = new StreamSource(ins.getByteStream());
                    source.setSystemId(ins.getSystemId());
                    helper.transform(this, path, source, result);
                    data = baos.toByteArray();
                }
            } else if (mEntries.contains(path) && mTempFiles.get(path) != null) {
                ByteArrayOutputStream os = new ByteArrayOutputStream();
                InputStream is = new BufferedInputStream(new FileInputStream((File) mTempFiles.get(path)));
                byte[] buf = new byte[4096];
                int r = 0;
                while ((r = is.read(buf, 0, 4096)) > 0) {
                    os.write(buf, 0, r);
                }
                is.close();
                os.close();
                data = os.toByteArray();
            } else if (mEntries.contains(path) && mContents.get(path) != null) {
                data = (byte[]) mContents.get(path);
            } else if (path.equals("META-INF/manifest.xml")) {
                if (mManifestEntries == null) {
                    // manifest was not present
                    return null;
                }
                String s = getManifestAsString();
                if (s == null) {
                    return null;
                } else {
                    data = s.getBytes("UTF-8");
                }
            }
        } catch (Exception e) {
            throw new Exception("Exception:" + e.getMessage());
        } 
        return data;
    }

    /**
     * get subcontent as InputStream
     */
    public InputStream getInputStream(String path)
            throws Exception {

        if (path == null || "".equals(path)) {
            return getInputStream();
        }

        if (mEntries.contains(path) && mTempFiles.get(path) != null) {
            return new BufferedInputStream(new FileInputStream((File) mTempFiles.get(path)));
        }

        byte[] data = getBytes(path);
        if (data != null && data.length != 0) {
            ByteArrayInputStream bais = new ByteArrayInputStream(data);
            return bais;
        }
        return null;
    }

    /**
     * Gets the InputStream containing whole OdfPackage.
     * 
     * @return the ODF package as input stream
     * @throws java.lang.Exception - if the package could not be read
     */
    public InputStream getInputStream() throws Exception {
        final PipedOutputStream os = new PipedOutputStream();
        final PipedInputStream is = new PipedInputStream();

        is.connect(os);

        Thread thread1 = new Thread() {

            @Override
            public void run() {
                try {
                    save(os, mBaseURI);
                } catch (Exception e) {
                }
            }
        };

        Thread thread2 = new Thread() {

            @Override
            public void run() {
                try {
                    BufferedInputStream bis = new BufferedInputStream(is, 4096);
                    BufferedOutputStream bos = new BufferedOutputStream(os, 4096);
                    byte[] buf = new byte[4096];
                    int r = 0;
                    while ((r = bis.read(buf, 0, 4096)) > 0) {
                        bos.write(buf, 0, r);
                    }
                    is.close();
                    os.close();
                } catch (Exception ie) {
                }
            }
        };

        thread1.start();
        thread2.start();

        return is;
    }

    /**
     * get OutputStream for writing new sub-content into OdfPackage
     */
    OutputStream getOutputStream(String path) throws Exception {

        if (path == null || "".equals(path)) {
            throw new IllegalArgumentException("empty path not allowed");
        }

        final String fPath = path;
        final FileEntry fFileEntry = getFileEntry(path);

        ByteArrayOutputStream baos = new ByteArrayOutputStream() {

            @Override
            public void close()  {
                try {
                    super.close();
                    byte[] data = this.toByteArray();
                    insert(data, fFileEntry == null ? null : fFileEntry.getMediaType(), fPath);
                } catch (Exception ex) {
                    Logger.getLogger(OdfPackage.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
        };
        return baos;
    }

    /**
     * Gets the Odf content as stream.
     *
     * @return - a stream of the ODF content 'content.xml' file
     * @throws java.lang.Exception - if the stream can not be extracted
     */
    public InputStream getContentStream() throws Exception {
        return getInputStream(STREAMNAME_CONTENT);
    }

    /**
     * Gets the Odf style as stream.
     *
     * @return - a stream of the ODF style 'styles.xml' file
     * @throws java.lang.Exception - if the stream can not be extracted
     */
    public InputStream getStylesStream() throws Exception {
        return getInputStream(STREAMNAME_STYLES);
    }

     /**
     * Gets the Odf settings as stream.
     *
     * @return - a stream of the ODF metadata 'setting.xml' file
     * @throws java.lang.Exception - if the stream can not be extracted
     */
    public InputStream getSettingsStream() throws Exception {
        return getInputStream(STREAMNAME_SETTINGS);
    }   
    
    /**
     * Gets the Odf metadata as stream.
     *
     * @return - a stream of the ODF metadata 'meta.xml' file
     * @throws java.lang.Exception - if the stream can not be extracted
     */
    public InputStream getMetaStream() throws Exception {
        return getInputStream(STREAMNAME_META);
    }

//    /**
//     * get an InputStream with a specific path from the package.
//     *
//     * @throws IllegalArgumentException if sub-content is not XML
//     */
//    public InputStream getInputStream(String path) throws Exception {
//        return mZipFile.getInputStream(mZipFile.getEntry(path));
////        OdfPackageStream stream = new OdfPackageStream(this, path);
////        return stream;
//    }

    public void remove(String path) {
        if (mManifestList.contains(path)) {
            mManifestList.remove(path);
        }
        if (mManifestEntries.containsKey(path)) {
            mManifestEntries.remove(path);
        }
        if (mZipEntries.containsKey(path)) {
            mZipEntries.remove(path);
        }
        if (mTempFiles.containsKey(path)) {
            File file = (File) mTempFiles.remove(path);
            file.delete();
        }
        if (mEntries.contains(path)) {
            mEntries.remove(path);
        }
    }

    /**
     * get Temp Directory
     */
    private File getTempDir()
            throws Exception {

        if (mTempDir == null) {
            mTempDir = TempDir.createGeneratedName("ODF", mTempDirParent);
        }
        return mTempDir;
    }

    /**
     * encoded XML Attributes
     */
    private String encodeXMLAttributes(String s) {
        String r = s.replaceAll("\"", "&quot;");
        r = r.replaceAll("'", "&apos;");
        return r;
    }

    private class StoreContentOutputStream extends ByteArrayOutputStream {

        private ZipEntry mZipEntry1;

        public StoreContentOutputStream(ZipEntry zipEntry) {
            super();
            this.mZipEntry1 = zipEntry;
        }

        @Override
        public void close(){

            byte[] content = toByteArray();
            if (mZipEntry1 != null) {
                insert(mZipEntry1, content);
            }
        }
    }

    private class StoreTempOutputStream extends OutputStream {

        private ZipEntry mZipEntry2;
        private File mTempFile2;
        OutputStream mOs;
        private String mMediaType;

        public StoreTempOutputStream(ZipEntry zipEntry)
                throws Exception {

            super();
            this.mZipEntry2 = zipEntry;
            String fname = zipEntry.getName();
            if (File.separatorChar == '\\') {
                fname = fname.replaceAll("\\\\", "/");
            }
            mTempFile2 = new File(getTempDir(), fname);
            File parent = mTempFile2.getParentFile();
            parent.mkdirs();
            mOs = new BufferedOutputStream(new FileOutputStream(mTempFile2));
        }

        @Override
        public void write(byte[] b) {
            try {

                mOs.write(b);
            } catch (IOException ex) {
                Logger.getLogger(OdfPackage.class.getName()).log(Level.SEVERE, null, ex);
            }
        }

        @Override
        public void write(byte[] b, int off, int len){
            try {

                mOs.write(b, off, len);
            } catch (IOException ex) {
                Logger.getLogger(OdfPackage.class.getName()).log(Level.SEVERE, null, ex);
            }
        }

        public void write(int b){
            try {

                mOs.write(b);
            } catch (IOException ex) {
                Logger.getLogger(OdfPackage.class.getName()).log(Level.SEVERE, null, ex);
            }
        }

        public void close() {
            try {

                mOs.close();
                if (mZipEntry2 != null) {
                    insert(mZipEntry2, mTempFile2);
                }
            } catch (IOException ex) {
                Logger.getLogger(OdfPackage.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    private class ManifestContentHandler implements ContentHandler {

        private FileEntry _currentFileEntry;
        private EncryptionData _currentEncryptionData;

        /**
         * Receive an object for locating the origin of SAX document events.
         */
        public void setDocumentLocator(Locator locator) {
        }

        /**
         * Receive notification of the beginning of a document.
         */
        public void startDocument() throws SAXException {
            mManifestList = new LinkedList();
            mManifestEntries = new HashMap();
        }

        /**
         * Receive notification of the end of a document.
         */
        public void endDocument() throws SAXException {
        }

        /**
         * Begin the scope of a prefix-URI Namespace mapping.
         */
        public void startPrefixMapping(String prefix, String uri)
                throws SAXException {
        }

        /**
         * End the scope of a prefix-URI mapping.
         */
        public void endPrefixMapping(String prefix)
                throws SAXException {
        }

        /**
         * Receive notification of the beginning of an element.
         */
        public void startElement(String namespaceURI, String localName, String qName, Attributes atts)
                throws SAXException {

            if (localName.equals("file-entry")) {
                _currentFileEntry = new FileEntry();
                _currentFileEntry.setPath(atts.getValue("manifest:full-path"));
                _currentFileEntry.setMediaType(atts.getValue("manifest:media-type"));
                if (atts.getValue("manifest:size") != null) {
                    try {
                        _currentFileEntry.setSize(Integer.parseInt(atts.getValue("manifest:size")));
                    } catch (NumberFormatException nfe) {
                        throw new SAXException("not a number: " + atts.getValue("manifest:size"));
                    }
                }
            } else if (localName.equals("encryption-data")) {
                _currentEncryptionData = new EncryptionData();
                if (_currentFileEntry != null) {
                    _currentEncryptionData.setChecksumType(atts.getValue("manifest:checksum-type"));
                    _currentEncryptionData.setChecksum(atts.getValue("manifest:checksum"));
                    _currentFileEntry.setEncryptionData(_currentEncryptionData);
                }
            } else if (localName.equals("algorithm")) {
                Algorithm algorithm = new Algorithm();
                algorithm.setName(atts.getValue("manifest:algorithm-name"));
                algorithm.setInitializationVector(atts.getValue("manifest:initialization-vector"));
                if (_currentEncryptionData != null) {
                    _currentEncryptionData.setAlgorithm(algorithm);
                }
            } else if (localName.equals("key-derivation")) {
                KeyDerivation keyDerivation = new KeyDerivation();
                keyDerivation.setName(atts.getValue("manifest:key-derivation-name"));
                keyDerivation.setSalt(atts.getValue("manifest:salt"));
                if (atts.getValue("manifest:iteration-count") != null) {
                    try {
                        keyDerivation.setIterationCount(Integer.parseInt(atts.getValue("manifest:iteration-count")));
                    } catch (NumberFormatException nfe) {
                        throw new SAXException("not a number: " + atts.getValue("manifest:iteration-count"));
                    }
                }
                if (_currentEncryptionData != null) {
                    _currentEncryptionData.setKeyDerivation(keyDerivation);
                }
            }

        }

        /**
         * Receive notification of the end of an element.
         */
        public void endElement(String namespaceURI, String localName, String qName)
                throws SAXException {
            if (localName.equals("file-entry")) {
                if (_currentFileEntry.getPath() != null) {
                    mManifestEntries.put(_currentFileEntry.getPath(), _currentFileEntry);
                }
                mManifestList.add(_currentFileEntry.getPath());
                _currentFileEntry = null;
            } else if (localName.equals("encryption-data")) {
                _currentEncryptionData = null;
            }
        }

        /**
         * Receive notification of character data.
         */
        public void characters(char[] ch, int start, int length)
                throws SAXException {
        }

        /**
         * Receive notification of ignorable whitespace in element content.
         */
        public void ignorableWhitespace(char[] ch, int start, int length)
                throws SAXException {
        }

        /**
         * Receive notification of a processing instruction.
         */
        public void processingInstruction(String target, String data)
                throws SAXException {
        }

        /**
         * Receive notification of a skipped entity.
         */
        public void skippedEntity(String name) throws SAXException {
        }
    }

    /**
     * resolve external entities
     */
    private class Resolver implements EntityResolver, URIResolver {

        /**
         * Resolver constructor.
         */
        public Resolver() {
        }

        /**
         * Allow the application to resolve external entities.
         *
         * The Parser will call this method before opening any external entity except
         * the top-level document entity (including the external DTD subset,
         * external entities referenced within the DTD, and external entities referenced
         * within the document element): the application may request that the parser
         * resolve the entity itself, that it use an alternative URI,
         * or that it use an entirely different input source.
         */
        public InputSource resolveEntity(String publicId, String systemId)
                throws SAXException {

            if (systemId != null) {
                if ((mBaseURI != null) && systemId.startsWith(mBaseURI)) {
                    if (systemId.equals(mBaseURI)) {
                        InputStream in = null;
                        try {
                            in = getInputStream();
                        } catch (Exception e) {
                            throw new SAXException(e);
                        }
                        InputSource ins;
                        ins = new InputSource(in);

                        if (ins == null) {
                            return null;
                        }
                        ins.setSystemId(systemId);
                        return ins;
                    } else {
                        if (systemId.length() > mBaseURI.length() + 1) {
                            InputStream in = null;
                            try {
                                String path = systemId.substring(mBaseURI.length() + 1);
                                in = getInputStream(path);
                                InputSource ins = new InputSource(in);
                                ins.setSystemId(systemId);
                                return ins;
                            } catch (Exception ex) {
                                Logger.getLogger(OdfPackage.class.getName()).log(Level.SEVERE, null, ex);
                            } finally {
                                try {
                                    in.close();
                                } catch (IOException ex) {
                                    Logger.getLogger(OdfPackage.class.getName()).log(Level.SEVERE, null, ex);
                                }
                            }
                        }
                        return null;
                    }
                } else if (systemId.startsWith("resource:/")) {
                    int i = systemId.indexOf('/');
                    if ((i > 0) && systemId.length() > i + 1) {
                        String res = systemId.substring(i + 1);
                        ClassLoader cl = OdfPackage.class.getClassLoader();
                        InputStream in = cl.getResourceAsStream(res);
                        if (in != null) {
                            InputSource ins = new InputSource(in);
                            ins.setSystemId(systemId);
                            return ins;
                        }
                    }
                    return null;
                } else if (systemId.startsWith("jar:")) {
                    try {
                        URL url = new URL(systemId);
                        JarURLConnection jarConn = (JarURLConnection) url.openConnection();
                        InputSource ins = new InputSource(jarConn.getInputStream());
                        ins.setSystemId(systemId);
                        return ins;
                    } catch (IOException ex) {
                        Logger.getLogger(OdfPackage.class.getName()).log(Level.SEVERE, null, ex);
                    } 
                }
            }
            return null;
        }

        public Source resolve(String href, String base)
                throws TransformerException {
            try {
                URI uri = null;
                if (base != null) {
                    URI baseuri = new URI(base);
                    uri = baseuri.resolve(href);
                } else {
                    uri = new URI(href);
                }

                InputSource ins = null;
                try {
                    ins = resolveEntity(null, uri.toString());
                } catch (Exception e) {
                    throw new TransformerException(e);
                }
                if (ins == null) {
                    return null;
                }
                InputStream in = ins.getByteStream();
                StreamSource src = new StreamSource(in);
                return src;
            } catch (URISyntaxException use) {
                return null;
            }
        }
    }    
    
    /**
     * get EntityResolver to be used in XML Parsers
     * which can resolve content inside the OdfPackage
     */
    EntityResolver getEntityResolver() {
        if (mResolver == null) {
            mResolver = new Resolver();
        }
        return mResolver;
    }

    /**
     * get URIResolver to be used in XSL Transformations
     * which can resolve content inside the OdfPackage
     */
    URIResolver getURIResolver() {
        if (mResolver == null) {
            mResolver = new Resolver();
        }
        return mResolver;
    }      
 
    private static String getBaseURIFromFile(File file) throws Exception {
        String baseURI = file.getCanonicalFile().toURI().toString();
        if (File.separatorChar == '\\') {
            baseURI = baseURI.replaceAll("\\\\", "/");
        }
        return baseURI;
    }    
}

