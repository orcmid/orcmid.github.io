/************************************************************************
 *
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS FILE HEADER.
 * 
 * Copyright 2008 by Sun Microsystems, Inc.
 *
 * OpenOffice.org - a multi-platform office productivity suite
 *
 * $RCSfile: $
 * $Revision: $
 *
 *
 * OpenOffice.org is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License version 3
 * only, as published by the Free Software Foundation.
 *
 * OpenOffice.org is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License version 3 for more details
 * (a copy is included in the LICENSE file that accompanied this code).
 *
 * You should have received a copy of the GNU Lesser General Public License
 * version 3 along with OpenOffice.org.  If not, see
 * <http://www.openoffice.org/license.html>
 * for a copy of the LGPLv3 License.
 *
 ************************************************************************/
package org.openoffice.odf.dom.test;

import org.junit.Assert;
import org.junit.Test;
import org.openoffice.odf.dom.OdfNamespace;
import org.openoffice.odf.doc.OdfDocument;
import org.openoffice.odf.doc.element.draw.OdfImage;
import org.openoffice.odf.dom.util.NodeAction;
import org.openoffice.odf.pkg.OdfPackage;
import org.w3c.dom.Node;

public class ImageTest {

    public ImageTest() {
    }

    @Test
    public void testRemoveImage() {
        try {
            OdfDocument doc = new OdfDocument("test/resources/image.odt");
            final OdfPackage pkg = doc.getOdfPackage();
            NodeAction removeImages = new NodeAction() {

                protected void apply(Node node, Object arg, int depth) {
                    if (node instanceof OdfImage) {
                        OdfImage img = (OdfImage) node;
                        String ref = img.getAttributeNS(OdfNamespace.XLINK.getUri(), "href");
                        pkg.remove(ref);
                        img.getParentNode().removeChild(img);
                    }
                }
            };
            removeImages.performAction(doc.getContentCached().getDocumentElement(), null);
            pkg.save("build/remove-images.odt");
        } catch (Exception e) {
            e.printStackTrace();
            Assert.fail(e.getMessage());
        }
    }
}
