/* getpwd00.h 0.4 alpha        ISO 8859-1 encoding            dh:2006-07-29
 *
 *  Obtain Password Entry Directly from Console (version 0.4 alpha)
 *  - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
 *
 * This is an alpha-test C/C++ Language header version for a custom user
 * function.  For the latest status of the development of this header
 * and the interface that is specified herein, consult the web page at
 * http://TROSTing.org/dev/2006/07/d060701f.htm
 *
 *          Copyright � 2006, NuovoDoc <http://NuovoDoc.com>
 *
 *     Attribution: 
 *       Hamilton, Dennis E.  getpwd00.h version 0.04 alpha header
 *       for declaring getpwd00.h implementations.  Latest version 
 *       available at http://TROSTing.org/dev/2006/07/d060701f.htm
 *       as part of package d060701f.zip.  
 *
 *    This work is licensed under the Creative Commons Attribution 
 *    License.  To view a copy of this license, visit web site
 *    http://creativecommons.org/licenses/by/2.5/ or send a letter 
 *    to Creative Commons, 559 Nathan Abbott Way, Stanford, 
 *    California 94305, USA.
 */
 
#ifndef GETPWD_H
#define GETPWD_H

#ifdef  __cplusplus
extern "C" {
#endif

#include <stddef.h>
    /* for implementation of size_t. */
 
int getpwd00(char buffer[ ], size_t maxpwd, size_t maxfield);
 
#ifdef  __cplusplus
}
#endif

/* TO DO AND EXPLAIN FURTHER:
   1. This header file specifies a function prototype for the syntax
      and type agreement of function getpwd00().
   2. This header file will also evolve to carry the contract for the
      specific behavior of platform-isolating function definitions 
      that implement getpwd10().
   3. The use of the versioned name getpwd00() is to emphasize that 
      all use is at the provisional alpha level and is not at the
      desired level of portable usage until getpwd10() is attained.
   4. Consult the web pages that describe this header file for details
      on how implementations are isolated for portable usage. 
*/   
 
#endif /* GETPWD_H */
/*
 * $Header: /MyProjects/getpwd/getpwd00.h 3     06-07-30 0:08 Orcmid $
 *
 *                        *** end of getpwd00.h ***
 */