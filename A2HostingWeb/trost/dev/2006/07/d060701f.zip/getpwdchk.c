/* getpwdchk.c 0.03         ISO 8859-1 encoding             dh:2006-07-29
 *
 * Exercise getpwd00 Implementations
 * - - - - - - - - - - - - - - - - -
 *
 * This is a simple test of the getpwd00.h header file that is part of the
 * early development of getpwd.c implementations.  Developing getpwd00.c
 * is also an experiment in patterns for isolation of platform dependencies
 * when software functions must rely on platform-specific capabilities.
 *
 */
 
#include "getpwd00.h"
    /* Confirm that we can compile with this header */
       
int main(const int argc, char* argv[])
{ /* dummy program that is just enough to do nothing. */
  return 0;
  }
  
/* 0.03 2006-07-29-23:40 adjust for use of the simplified header file name.
        Developers are responsible for sorting out the progression of alpha-
        beta getpwd00 versions and then upgrading to getpwd10 when it
        is declared complete. Some wording changes have been made too.
           
   0.00 2006-07-29-17:19 create trivial version that is just enough to
        get a compiler check on inclusion of getpwd00-0.3alpha.h   

            Copyright � 2006, NuovoDoc <http://NuovoDoc.com>
            
     Attribution: 
        Hamilton, Dennis E.  getpwdchk.c version 0.03 program for
        exercising getpwd00.h implementations.  Latest version 
        available at http://TROSTing.org/dev/2006/07/d060701f.htm
        as part of package d060701f.zip.  
 
     This work is licensed under the Creative Commons Attribution 
     License.  To view a copy of this license, visit web site
     http://creativecommons.org/licenses/by/2.5/ or send a letter 
     to Creative Commons, 559 Nathan Abbott Way, Stanford, 
     California 94305, USA.

   $Header: /MyProjects/getpwd/getpwdchk.c 3     06-07-30 0:08 Orcmid $
   */
  
/*                 *** end of getpwdchk.c ***                   */       