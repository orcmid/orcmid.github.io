/* document.cpp - Document class for ODMA sample DMS.
 *
 * COPYRIGHT (C) 1994, 1995
 * AIIM International
 * All Rights Reserved
 */

#include <windows.h>
#include <dos.h>
#include "odmasamp.h"


Document::Document()
{
	Init();
}


Document::Document(LPSTR lpszFormat, LPSTR lpszDocLocation)
{
	Init();
	strncpy(Format, lpszFormat, sizeof(Format));
	Format[sizeof(Format)-1] = '\0';

	if(lpszDocLocation) {
		strncpy(DocLocation, lpszDocLocation, sizeof(DocLocation));
		DocLocation[sizeof(DocLocation)-1] = '\0';
		DocAccessed = 1;
	}
}


Document::Document(Document *pOldDoc)
{
	Init();
	strcpy(Author, pOldDoc->Author);
	strcpy(Name, pOldDoc->Name);
	strcpy(DocType, pOldDoc->DocType);
	strcpy(Format, pOldDoc->Format);
}


// Load a document saved from a previous session
Document::Document(LPSTR lpszDocId)
{
	strcpy(DocId, lpszDocId);
	SaveFlag = 0;
	OpenCount = 0;
	DocAccessed = 1;	// It was accessed in a previous session.
	GetPrivateProfileString(DocId, "Author", "", Author, sizeof(Author), DMSINI);
	GetPrivateProfileString(DocId, "Name", "", Name, sizeof(Name), DMSINI);
	GetPrivateProfileString(DocId, "DocType", "", DocType, sizeof(DocType), DMSINI);
	GetPrivateProfileString(DocId, "Format", "", Format, sizeof(Format), DMSINI);
	GetPrivateProfileString(DocId, "DocLocation", "", DocLocation, sizeof(DocLocation), DMSINI);
}


void Document::Init(void)
{
#ifdef WIN32
SYSTEMTIME tm;
#elif __BORLANDC__
	struct time tm;
#else
	struct _dostime_t tm;
#endif

	SaveFlag = 0;
	Author[0] = '\0';
	Name[0] = '\0';
	DocType[0] = '\0';
	OpenCount = 0;
	Format[0] = '\0';
	DocLocation[0] = '\0';
	DocAccessed = 0;

#ifdef WIN32
	GetLocalTime(&tm);

	if(tm.wMilliseconds > 99)
		tm.wMilliseconds /= 10;

	wsprintf(DocId, "%02d-%02d-%02d-%02d", tm.wHour, tm.wMinute, tm.wSecond, tm.wMilliseconds);
#elif __BORLANDC__
	gettime(&tm);
	wsprintf(DocId, "%02d-%02d-%02d-%02d", tm.ti_hour, tm.ti_min, tm.ti_sec, tm.ti_hund);
#else
	_dos_gettime(&tm);
	wsprintf(DocId, "%02d-%02d-%02d-%02d", tm.hour, tm.minute, tm.second, tm.hsecond);
#endif
}


ODMSTATUS Document::Open(LPSTR lpszFileName)
{
	OpenCount++;

	if(DocLocation[0] == '\0') {
#ifdef WIN32
		char szTmpPath[256];

		// WIN32 requires you to get a temp path first, then pass it to get
		// a temp filename.
		GetTempPath(256, (LPTSTR) szTmpPath);
		GetTempFileName(szTmpPath, "ODM", 0, DocLocation);
#else
		GetTempFileName(0, "ODM", 0, DocLocation);
#endif
	}

	strcpy(lpszFileName, DocLocation);
	DocAccessed = 1;
	return 0;
}


ODMSTATUS Document::Close(DWORD activeTime, DWORD pagesPrinted,
LPVOID sessionData, WORD dataLen)
{
	OpenCount--;
	return 0;
}


ODMSTATUS Document::EditAttributes(HWND hParent)
{
ProDlgData pdData;
int err;

	pdData.pDocument = this;
	pdData.Mode = PROFILE_EDIT;

	err = DialogBoxParam(hInst, MAKEINTRESOURCE(PROFILE_DIALOG), hParent,
				(DLGPROC)ProfileProc, (LPARAM)&pdData);

	if(err == IDOK)
		err = 0;
	else
		err = ODM_E_CANCEL;

	return err;
}


ODMSTATUS Document::ShowAttributes(HWND hParent)
{
ProDlgData pdData;

	pdData.pDocument = this;
	pdData.Mode = 0;

	DialogBoxParam(hInst, MAKEINTRESOURCE(PROFILE_DIALOG), hParent,
		(DLGPROC)ProfileProc, (LPARAM)&pdData);

	return 0;
}


ODMSTATUS Document::GetInfo( WORD item, LPSTR lpszData, WORD dataLen )
{
ODMSTATUS err;
char *dataSource;
char buff[165];

	switch(item) {
		case ODM_AUTHOR: dataSource = Author; break;
		case ODM_NAME: dataSource = Name; break;
		case ODM_TYPE: dataSource = DocType; break;
		case ODM_TITLETEXT:
			wsprintf(buff, "%s - %s", (LPSTR)DocId, (LPSTR)Name);
			dataSource = buff;
			break;

		case ODM_CONTENTFORMAT: dataSource = Format; break;
		default: dataSource = NULL;
	}

	if(dataSource) {
		strncpy(lpszData, dataSource, dataLen);
		lpszData[dataLen-1] = '\0';
		err = 0;
	} else
		err = ODM_E_ITEM;

	return err;
}


ODMSTATUS Document::SetInfo( WORD item, LPSTR lpszData )
{
char *target;
int len;
ODMSTATUS err;

	switch(item) {
		case ODM_AUTHOR: target = Author; len = sizeof(Author); break;
		case ODM_NAME: target = Name; len = sizeof(Name); break;
		case ODM_TYPE: target = DocType; len = sizeof(DocType); break;
		case ODM_CONTENTFORMAT: target = Format; len = sizeof(Format); break;
		default: target = NULL;
	}

	if(target) {
		strncpy(target, lpszData, len);
		target[len-1] = '\0';
		err = 0;
	} else
		err = ODM_E_ITEM;

	return err;
}


void Document::SaveInfo(void)
{
	// Put the docId into the DocList section.
	WritePrivateProfileString("DocList", DocId, "", DMSINI);

	// Put the document's info. into its own section
	WritePrivateProfileString(DocId, "Author", Author, DMSINI);
	WritePrivateProfileString(DocId, "Name", Name, DMSINI);
	WritePrivateProfileString(DocId, "DocType", DocType, DMSINI);
	WritePrivateProfileString(DocId, "Format", Format, DMSINI);
	WritePrivateProfileString(DocId, "DocLocation", DocLocation, DMSINI);
}


