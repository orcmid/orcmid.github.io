/***************************************************************************
*	TABS(3,3)																					*
*																									*
*	MODULE:		MpFile.c																		*
*																									*
*	PURPOSE:		Contains the code for File I/O for MultODMA						*
*																									*
*	FUNCTIONS:	AlreadyOpen	-	Determines if a file is already open.			*
*																									*
*					AddFile		-	Creates a new MDI window and, if specified,	*
*										loads a file into it.								*
*																									*
*					LoadFile		-	Loads a file into a MDI window.					*
*																									*
*					SelectFile	-	Calls File/Open dialog and appropriately		*
*										responds to the user's input.						*
*																									*
*					SaveFile		-	Saves the contents of a MDI window's edit		*
*									  	control to a file.									*
*																									*
*					SetSaveFrom	-	Formats the "Save 'file' to" string.			*
*																									*
*				 SaveAsDlgProc -	Dialog function for the File/SaveAs dialog.	*
*																									*
*					ChangeFile	- Calls File/SaveAs dialog.							*
*																									*
**************************************************************************/
#include "multipad.h"
#include "commdlg.h"

/* local OF variable for parsing DOS filenames */
OFSTRUCT	of;

/* routine prototype for CallBack function  */
LPSTR FAR OptionsCallBack(DWORD dwEnvData, LPSTR lpszFormat, LPVOID lpData);


/***************************************************************************
*																									*
*	FUNCTION:  	AlreadyOpen(szFile)													 	*
*																									*
*	PURPOSE:		Checks to see if the file described by the string pointed	*
*					to by 'szFile' is already open.										*
*																									*
*	RETURNS:		a handle to the described file's window if that file is		*
*					already open;  NULL otherwise.										*
*																									*
***************************************************************************/
HWND AlreadyOpen(char *szFile)
{
int iDiff;
HFILE hFileTemp;
HWND hwndCheck;
LPSTR lpFile;
LPSTR	lpCurFile;
HGLOBAL hFile;
BOOL bODMA;

	/* NULL pointer passed in? */
	if(szFile == (char *)NULL || szFile[0] == '\0')
		return (HWND)0;

	/* ODMA docID passed in? */
	if(szFile[0] == ':' && szFile[1] == ':') {
		bODMA = TRUE;
	}
	else {
		bODMA = FALSE;
		/* Open the file with the OF_PARSE flag to obtain the fully qualified
		 * pathname in the OFSTRUCT structure. */
		hFileTemp = OpenFile((LPSTR)szFile, (LPOFSTRUCT)&of, OF_PARSE);

		if(hFileTemp == HFILE_ERROR)
			return(NULL);

		_lclose(hFileTemp);
	}

	/* Check each MDI child window in MultODMA */
	for(hwndCheck = GetWindow(hwndMDIClient, GW_CHILD); hwndCheck;
	hwndCheck = GetWindow(hwndCheck, GW_HWNDNEXT)) {
		/* Initialization  for comparison */
		if(bODMA)
			lpFile = AnsiUpper(szFile);
		else
			lpFile = AnsiUpper((LPSTR) of.szPathName);

		iDiff = 0;

		/* Skip icon title windows */
		if(GetWindow(hwndCheck, GW_OWNER))
			continue;

		/* ODMA docID? */
		if(bODMA)
			/* Get current child window's ODMA docID */
			hFile = (HGLOBAL) GetProp(hwndCheck, "ODMADOCID");
		else
			/* Get current child window's name */
			hFile = (HGLOBAL) GetProp(hwndCheck, "FILEPTR");

		if(hFile == (HGLOBAL)0)
			continue;

		lpCurFile =  AnsiUpper((LPSTR) GlobalLock(hFile));

		/* Compare window name with given name */
		while((*lpCurFile) && (*lpFile) && (!iDiff)) {
			if(*lpCurFile++ != *lpFile++)
				iDiff = 1;
		}

		/* Release global filename memory */
		GlobalUnlock(hFile);

		/* If the two names matched, the file is already   */
		/* open -- return handle to matching child window. */
		if(!iDiff)
			return(hwndCheck);
	}/* for */

	/* No match found -- file is not open -- return NULL handle */
	return(NULL);
}


/***************************************************************************
*																									*
*  FUNCTION:	AddFile(lpName)															*
*																									*
*	PURPOSE:		Creates a new MDI window. If the lpName parameter is not		*
*					NULL, it loads a file into the window.								*
*																									*
*	RETURNS:		HWND - A handle to the new window.									*
*																									*
***************************************************************************/
HWND WINAPI AddFile(char* pName)
{
HWND hwnd;
char sz[160];
MDICREATESTRUCT mcs;

	if(!pName || *pName == '\0') {
		/* The pName parameter is NULL -- load the "Untitled" string from */
		/* STRINGTABLE and set the title field of the MDI CreateStruct. */
		LoadString(hInst, IDS_UNTITLED, sz, sizeof(sz));
		mcs.szTitle = (LPSTR)sz;
	}
	else {
		/* default to using fully qualified path */
		mcs.szTitle = of.szPathName;

		/* if ODMA docID - set title with correct text */
		if(pName[0] == ':' && pName[1] == ':') {
			if(ODMGetDocInfo(odmHandle, pName, ODM_TITLETEXT, sz, 160) == 0)
				mcs.szTitle = (LPSTR) sz;
		}
	}

	mcs.szClass = szChild;
	mcs.hOwner	= hInst;

	/* Use the default size for the window */
	mcs.x = mcs.cx = CW_USEDEFAULT;
	mcs.y = mcs.cy = CW_USEDEFAULT;

	/* Set the style DWORD of the window to default */
	mcs.style = styleDefault;

	/* tell the MDI Client to create the child */
	hwnd = (HWND)(UINT) SendMessage(hwndMDIClient, WM_MDICREATE, 0,
									(LPARAM)(LPMDICREATESTRUCT)&mcs);

	/* Did we get a file? Read it into the window */
	if(pName && *pName != '\0'){
		if(!LoadFile(hwnd, pName)){
			/* File couldn't be loaded -- close window */
			SendMessage(hwndMDIClient, WM_MDIDESTROY, (WPARAM) hwnd, 0L);
		}
	}

	return hwnd;
}


/***************************************************************************
*																									*
*	FUNCTION:		LoadFile(lpName)														*
*																									*
*	PURPOSE:			Given the handle to a MDI window and a filename,			*
*						reads the file into the window's edit control child.     *
*																									*
*	RETURNS:			TRUE - If file is sucessfully loaded.							*
*						FALSE - Otherwise.													*
*																									*
***************************************************************************/
int WINAPI LoadFile(HWND hwnd, char *pName)
{
LONG lLength;
HGLOBAL hGlbl;
HLOCAL hLcl;
LPSTR lpB;
HWND hwndEdit;
HFILE fh;
char szFName[256];


	hwndEdit = (HWND) GetProp(hwnd, "HWNDEDIT");

	/* The file has a title, so reset the UNTITLED flag. */
	SetProp(hwnd, "UNTITLED", FALSE);

	/* ODMA docID passed in? */
	if(pName[0] == ':' && pName[1] == ':') {
		/* Place docID into global memory */
		hGlbl = GlobalAlloc(GHND, (DWORD) (lstrlen(pName) + 1));

		if(hGlbl == (HGLOBAL)0) {
			/* Report the error and quit */
			MPError(hwnd, MB_OK | MB_ICONHAND, IDS_NOMEM, (LPSTR)pName);
			return FALSE;
		}

		lpB = (LPSTR) GlobalLock(hGlbl);
		lstrcpy(lpB, pName);
		GlobalUnlock(hGlbl);
		SetProp(hwnd, "ODMADOCID", hGlbl);
	}

	/* default to opening the passed in filename */
	lstrcpy(szFName, pName);

	/* filename an ODMA docID? */
	if(pName[0] == ':' && pName[1] == ':') {
		/* convert docID into DOS filename */
		switch((ODMSTATUS)ODMOpenDoc(odmHandle, ODM_MODIFYMODE, pName, szFName)) {
			case 0:	/* SUCCESS! */
				/* set flag to READ-WRITE access */
				SetProp(hwnd, "READ_ONLY", FALSE);
				break;

			case ODM_E_ACCESS: /* User doesn't have rights to open doc */
			case ODM_E_INUSE: /* Can't open in modify mode - try read only */
				if(MPError(hwnd, MB_YESNO | MB_ICONQUESTION, IDS_READONLY,
				(LPSTR) pName) == IDNO)
					return FALSE;	/* don't try opening read-only */

				if(ODMOpenDoc(odmHandle, ODM_VIEWMODE, pName, szFName) == 0) {
					/* set window flag to READ ONLY access */
					SetProp(hwnd, "READ_ONLY", (HANDLE)TRUE);
					break;
				}

			/* error opening file in ANY mode - fall thru to error */
			default:
				/* error getting filename */
				MPError(hwnd, MB_OK | MB_ICONHAND, IDS_NOMEM, (LPSTR)pName);
				return FALSE;
		}/* switch */
	}/* if */

	/* Place filename into global memory */
	hGlbl = GlobalAlloc(GHND, (DWORD) (lstrlen(szFName) + 1));

	if(hGlbl == (HGLOBAL)0) {
		MPError(hwnd, MB_OK | MB_ICONHAND, IDS_NOMEM, (LPSTR)pName);
		return FALSE;
	}

	lpB = (LPSTR) GlobalLock(hGlbl);
	lstrcpy(lpB, szFName);
	GlobalUnlock(hGlbl);
	SetProp(hwnd, "FILEPTR", hGlbl);       /* store fileptr */

	fh = _lopen(szFName, 0);

	/* Make sure file has been opened correctly */
	if(fh == HFILE_ERROR) {
		MPError(hwnd, MB_OK | MB_ICONHAND, IDS_CANTOPEN, (LPSTR)pName);
		return FALSE;
	}

	/* Find the length of the file */
	lLength = _llseek(fh, 0L, 2);
	_llseek(fh, 0L, 0);

	hLcl = LocalAlloc(LHND, (UINT)lLength+1);

	if(hLcl == NULL) {
		/* Couldn't allocate -- error */
		_lclose(fh);
		MPError(hwnd, MB_OK | MB_ICONHAND, IDS_CANTOPEN, (LPSTR)pName);
		return FALSE;
	}

	lpB = (LPSTR) LocalLock(hLcl);

	/* read the file into the buffer */
	if(lLength != (LONG)_lread(fh, lpB, (UINT)lLength))
		MPError(hwnd, MB_OK | MB_ICONHAND, IDS_CANTREAD, (LPSTR)pName);

	/* Zero terminate the edit buffer */
	lpB[(UINT)lLength] = 0;
	LocalUnlock(hLcl);

	SetWindowText(hwndEdit, lpB);
	LocalFree(hLcl);
	_lclose(fh);

	/* set title bar text */
	/* default will use DOS filename */
	if(pName[0] == ':' && pName[1] == ':') {
		char sz[MAXFILE];
		/* get ODMA document title text */
		if(ODMGetDocInfo(odmHandle, pName, ODM_TITLETEXT, sz, MAXFILE) == 0)
			lstrcpy(szFName, sz);
	}

	/* if read-only flag set - append READONLY to title */
	if(GetProp(hwnd, "READ_ONLY") != FALSE) {
		char sz[MAXFILE];
		LoadString(hInst, IDS_RDONLY_TITLE, sz, MAXFILE-1);
		lstrcat(szFName, sz);
	}

	SetWindowText(hwnd, szFName);
	return TRUE;
}


/***************************************************************************
*																									*
*	FUNCTION:	SelectFile(hwnd)															*
*																									*
*	PURPOSE:		Called in response to a File/Open menu selection. It asks	*
*					the user for a file name and responds appropriately.			*
*																									*
*	MODS:			BHC 8/9/94 - Renamed from ReadFile to avoid conflict with	*
*					Win32 function of the same name.										*
***************************************************************************/
VOID WINAPI SelectFile(HWND hwnd)
{
char szFile[MAXFILE];
#ifdef FILE_TO_FRONT
HWND hwndFile;
#endif
OPENFILENAME of;
DWORD	dwFlags;
ODMSTATUS iRet;


	iRet = ODM_E_APPSELECT;				/* default to APPSELECT(no ODMA present) */

	if(odmHandle) {
		dwFlags = 0;
      /* call ODMA for open dialog */
		iRet = ODMSelectDoc(odmHandle, szFile, (LPDWORD)&dwFlags);
	}

	switch(iRet) {
		case 0:
			/* ODMA handled FileOpen dialog - and passed back an ODMA docID */
		break;

		case ODM_E_APPSELECT: /* normal DOS file open dialog */
		case ODM_E_NODMS:
			lstrcpy(szFile, "*.TXT");

			of.lStructSize = sizeof(OPENFILENAME);
			of.hwndOwner = hwnd;
			of.lpstrFilter = (LPSTR)"Text Files (*.TXT)\0*.TXT\0";
			of.lpstrCustomFilter = NULL;
			of.nFilterIndex = 1;
			of.lpstrFile = (LPSTR)szFile;
			of.nMaxFile = MAXFILE;
			of.lpstrInitialDir = NULL;
			of.lpstrTitle = NULL;
			of.Flags = OFN_HIDEREADONLY|OFN_FILEMUSTEXIST;
			of.lpstrDefExt = NULL;

			if(!GetOpenFileName(&of))
				return;
			break;
		case ODM_E_CANCEL:
			/* user cancelled dialog */
			szFile[0] = '\0';
			break;
		default:
			/* ODMA error - possibly display error message here */
			szFile[0] = '\0';
			break;
	}


	/* If the result is not the empty string -- take appropriate action */
	if (*szFile) {
/* undefine this section if you want multiple open requests to simply */
/* bring the window with the file to the front. Otherwise this code */
/* will allow the file to be opened in read-only mode. */

#ifdef FILE_TO_FRONT
		 /* Is file already open?? */
		 hwndFile = AlreadyOpen(szFile);
		 if (hwndFile) {
			/* Yes -- bring the file's window to the top */
			BringWindowToTop(hwndFile);
		 }
		 else {
			/* No -- make a new window and load file into it */
			AddFile(szFile);
		 }
#endif /* FILE_TO_FRONT */
		AddFile(szFile);
	}
}


/***************************************************************************
*																									*
*	FUNCTION: 	SaveFile(hwnd)																*
*																									*
*	PURPOSE:		Saves contents of current edit control to disk.					*
*																									*
***************************************************************************/
VOID WINAPI SaveFile(HWND hwnd)
{
LPSTR lpFile, lpT;
char szFile[MAXFILE];
int cch;
HFILE fh;
OFSTRUCT of;
HWND hwndEdit;
HCURSOR hCurs;
POINT	ptCaret;
HLOCAL hLcl;
HGLOBAL hGlbl;
HGLOBAL hFile;


	hwndEdit = (HWND) GetProp(hwnd, "HWNDEDIT");
	hFile = (HGLOBAL) GetProp(hwnd, "FILEPTR");

	if(hFile == (HGLOBAL) 0) {
		szFile[0] = '\0';
		MPError(hwnd, MB_OK | MB_ICONHAND, IDS_NOTNAMED, (LPSTR) szFile);
		return;
	}
	else {
		lpFile = (LPSTR) GlobalLock(hFile);
		lstrcpy(szFile, lpFile);
		GlobalUnlock(hFile);
	}

	if(GetProp(hwnd, "ODMADOCID") == 0) {	/* ODMA docID? */
		lpFile = (LPSTR) GlobalLock(hFile);	/* normal DOS filename, add extension */
		lstrcpy(szFile, lpFile);				/* store temporary copy of filename */

		/* If there is no extension (control is 'Untitled')
			add .TXT as extension */
		for(cch=FALSE; *lpFile; lpFile++)
			switch(*lpFile) {
				case '.':
					cch = TRUE;
					break;

				case '\\':
				case ':' :
					cch = FALSE;
					break;
			}/* switch */

		if(!cch) {
			char szExt[5];
			LoadString(hInst, IDS_ADDEXT, szExt, 4);/* Get default ext from res file */
			lstrcat(szFile, szExt);					/* Append extension to filename */
		}

		GlobalUnlock(hFile);
	}

	fh = OpenFile(szFile, &of, OF_WRITE | OF_CREATE);

	if(fh == HFILE_ERROR) {   /* If file could not be opened, quit */
		MPError (hwnd, MB_OK | MB_ICONHAND, IDS_CANTCREATE, (LPSTR)szFile);
		return;
	}


	GetCaretPos((POINT FAR *)&ptCaret);		/* Get the current caret position */
	HideCaret(hwnd);								/* Hide the caret */
	hCurs = SetCursor(LoadCursor(NULL, IDC_WAIT));   /* Display WAIT cursor */
	cch = GetWindowTextLength(hwndEdit) + 1;	/* Get length of text in edit control */

	hLcl = LocalAlloc(LHND, cch);
	lpT = (LPSTR) LocalLock(hLcl);
	GetWindowText(hwndEdit, lpT, cch);

	/* Write out the contents of the buffer to the file. */
	if(cch != (int)_lwrite(fh, (LPCSTR)lpT, cch))
		MPError(hwnd, MB_OK | MB_ICONHAND, IDS_CANTWRITE, (LPSTR)szFile);
	else {
		SetProp(hwnd, "CHANGED", FALSE);
		SetProp(hwnd, "ODMA_SAVE", (HANDLE)TRUE);
	}

	/* Clean up */
	LocalUnlock(hLcl);
	LocalFree(hLcl);
	_lclose(fh);

	/* put new filename into global memory */
	hGlbl = GlobalAlloc(GHND, (DWORD)(lstrlen(szFile) + 1));

	if(hGlbl) {
		lpT = (LPSTR) GlobalLock(hGlbl);
		lstrcpy(lpT, szFile);
		GlobalUnlock(hGlbl);
		SetProp(hwnd, "FILEPTR", hGlbl);
		GlobalFree(hFile);
		hFile = hGlbl;
	}

	/* ODMA docID present? */
	hGlbl = (HGLOBAL) GetProp(hwnd, "ODMADOCID");

	/* put new title text? (not if ODMA docID) */
	if ((hGlbl == (HGLOBAL) 0) && hFile) {
		lpT = (LPSTR) GlobalLock(hFile);
		SetWindowText(hwnd, lpT);
		GlobalUnlock(hFile);
	}

	ShowCaret(hwnd);
	SetCaretPos((int)ptCaret.x, (int)ptCaret.y); /* Set the original caret pos */
	SetCursor(hCurs);										/* Redisplay original cursor */

	return;
}


/***************************************************************************
*																									*
*	FUNCTION:	ChangeFile(hwnd)															*
*																									*
*	PURPOSE:		Invokes the File/SaveAs dialog.										*
*																									*
*	RETURNS:		TRUE  - if user selected OK or NO.									*
*					FALSE - otherwise.														*
*																								 	*
***************************************************************************/
BOOL WINAPI ChangeFile(HWND hwnd)
{
char szFile[128];
OPENFILENAME of;
HGLOBAL hGlbl;
LPSTR	lpT;
ODMSTATUS iRet;
BOOL bNewDoc;


	iRet = ODM_E_APPSELECT; /* default to application select (no ODMA present) */
	bNewDoc = FALSE;			/* Default to not a new doc */

	if(odmHandle && GetProp(hwnd, "UNTITLED")) {     /* new document? */
		iRet = ODMNewDoc(odmHandle, szFile, 0, "TEXT", NULL);

		switch(iRet) {
			case 0:		/* SUCCESS! new docID */
				/* store new docID in window handle */
				hGlbl = GlobalAlloc(GHND, (DWORD) (lstrlen(szFile) + 1));

				if(hGlbl == (HGLOBAL)0) {
					/* Report the error and quit */
					MPError(hwnd, MB_OK | MB_ICONHAND, IDS_NOMEM, (LPSTR)szFile);
					return FALSE;
				}

				lpT = (LPSTR) GlobalLock(hGlbl);
				lstrcpy(lpT, szFile);
				GlobalUnlock(hGlbl);
				SetProp(hwnd, "ODMADOCID", hGlbl);	/* store fileptr in window word */
				bNewDoc = TRUE;
				break;

			case ODM_E_APPSELECT:	 	/* let normal DOS handle it */
			case ODM_E_NODMS:
				break;

			case ODM_E_CANCEL:
				return(FALSE);

			default:						 	/* display possible error message here */
				return(FALSE);
		}/* switch */
	}/* if */

	/* ODMA docID? */
	hGlbl = (HGLOBAL) GetProp(hwnd, "ODMADOCID");

	if(hGlbl) {
		FARPROC	fpCallBack;

		/* get procedure address for call back routine */
		fpCallBack = (FARPROC) MakeProcInstance((FARPROC)OptionsCallBack, hInst);
		lpT = (LPSTR) GlobalLock(hGlbl);

		/* call ODMA for SaveAs */
		iRet = ODMSaveAs(odmHandle, lpT, szFile, "TEXT",
				 (ODMSAVEASCALLBACK) fpCallBack, (LPVOID) "App Instance Data here");
#ifndef WIN32
		FreeProcInstance((FARPROC)fpCallBack);
#endif
		/* is passed out docID same as passed in? */
		if(szFile[0] == '\0' && iRet == 0) {
			/* YES! Make sure file is not opened read-only */
			if((BOOL)GetProp(hwnd, "READ_ONLY") == TRUE) {
				MPError(hwnd, MB_OK | MB_ICONHAND, IDS_SAVE_RDONLY, lpT);
				iRet = ODM_E_CANCEL; /* fake CANCEL so save-as does not continue */
			}
			else {
				bNewDoc = TRUE;			/* fake bNewDoc flag */
				lstrcpy(szFile, lpT);	/* copy original docID into szFile */
			}
		}
		GlobalUnlock(hGlbl);
	}

	switch(iRet) {
		case 0: /* ODMA handled FileSaveAs dialog and passed back new ODMA docID */
			break;

		case ODM_E_NODMS:
		case ODM_E_APPSELECT:    /* normal DOS file saveas */
			if(GetProp(hwnd, "UNTITLED"))
				lstrcpy(szFile, "*.TXT");
			else {
				GetWindowText(hwnd, szFile, MAXFILE);
			}

			of.lStructSize = sizeof(OPENFILENAME);
			of.hwndOwner = hwnd;
			of.lpstrFilter = (LPSTR)"Text Files (*.TXT)\0*.TXT\0";
			of.lpstrCustomFilter = NULL;
			of.nFilterIndex = 1;
			of.lpstrFile = (LPSTR)szFile;
			of.nMaxFile = MAXFILE;
			of.lpstrInitialDir = NULL;
			of.lpstrTitle = NULL;
			of.Flags = OFN_HIDEREADONLY;
			of.lpstrDefExt = NULL;

			if(!GetSaveFileName(&of))
				return(FALSE);

			break;

		case ODM_E_CANCEL:
			return(FALSE);

		default:
			/* add possible error message display here */
			return(FALSE);
	}

	SetProp(hwnd, "UNTITLED", 0);   /* Clear untitled flag */

	if(bNewDoc == TRUE) {				/* new ODMA document? */
		/* DOS filename allready received? */
		hGlbl = (HGLOBAL) GetProp(hwnd, "FILEPTR");
		if(hGlbl == (HGLOBAL)0)
			ODMOpenDoc(odmHandle, ODM_MODIFYMODE, szFile, szFile); /* get DOS filename */
		else {
			lpT = (LPSTR) GlobalLock(hGlbl); /* load szFile with stored DOS filename */
			lstrcpy(szFile, lpT);
			GlobalUnlock(hGlbl);
		}
	}
	else {
		hGlbl = (HGLOBAL) GetProp(hwnd, "ODMADOCID");	/* clear old ODMA docID */

		if(hGlbl) {
			lpT = (LPSTR) GlobalLock(hGlbl);

			if(GetProp(hwnd, "ODMA_SAVE")) {			/* file saved? */
				ODMSaveDoc(odmHandle, lpT, lpT);
			}

			ODMCloseDoc( odmHandle, lpT, 0, 0, (LPVOID) 0, 0 );
			GlobalUnlock(hGlbl);
			GlobalFree(hGlbl);
			SetProp(hwnd, "ODMA_SAVE", 0);
			SetProp(hwnd, "ODMADOCID", 0);
		}

		if(szFile[0] == ':' && szFile[1] == ':') {	/* new file an ODMA docID? */

			hGlbl = GlobalAlloc(GHND, (DWORD)(lstrlen(szFile) + 1));

			if(hGlbl == (HGLOBAL) 0) {
				/* Report the error and quit */
				MPError(hwnd, MB_OK | MB_ICONHAND, IDS_NOMEM, (LPSTR)szFile);
				return FALSE;
			}

			lpT = (LPSTR) GlobalLock(hGlbl);
			lstrcpy(lpT, szFile);
			GlobalUnlock(hGlbl);
			SetProp(hwnd, "ODMADOCID", hGlbl); /* store ODMA docID in win memory */
			ODMOpenDoc(odmHandle, ODM_MODIFYMODE, szFile, szFile); /*get DOS filename*/
		}
	}

	hGlbl = (HGLOBAL) GetProp(hwnd, "FILEPTR");

	if(hGlbl) {
		GlobalFree(hGlbl);
	}

	hGlbl = GlobalAlloc(GHND, (DWORD) (lstrlen(szFile) + 1));

	if(hGlbl) {
		lpT = (LPSTR) GlobalLock(hGlbl);
		lstrcpy(lpT, szFile);
		GlobalUnlock(hGlbl);
	}

	SetProp(hwnd, "FILEPTR", hGlbl);	/* store fileptr in win memory */
	hGlbl = (HGLOBAL) GetProp(hwnd, "ODMADOCID");    /* ODMA docID? */

	if(hGlbl) {
		char sz[MAXFILE];
		lpT = (LPSTR) GlobalLock(hGlbl);

		if(ODMGetDocInfo(odmHandle, lpT, ODM_TITLETEXT, sz, MAXFILE) == 0)
			lstrcpy(szFile, sz);

		GlobalUnlock(hGlbl);
	}

	SetWindowText(hwnd, szFile);
	SetProp(hwnd, "READ_ONLY", FALSE);       /* clear read-only flag */

	return(TRUE);
}


/***************************************************************************
*																									*
*	FUNCTION:	ParseCmdLine(char *)														*
*																									*
*	PURPOSE:		Parse any DOS filename on the command line into the			*
*					OF struct.																	*
*																									*
*	RETURNS:		NONE																		 	*
*																									*
***************************************************************************/
VOID WINAPI ParseCmdLine(char * pCmdLine)
{
int wFileTemp;


	if(pCmdLine == (char *) 0 || pCmdLine[0] == '\0') /* NULL ptr passed in? */
		return;


	if(pCmdLine[0] == ':' && pCmdLine[1] == ':')     /* ODMA docID passed in? */
		return;

	/* Open the file with the OF_PARSE flag to obtain the fully qualified
	 * pathname in the OFSTRUCT structure. */
	wFileTemp = OpenFile((LPSTR) pCmdLine, (LPOFSTRUCT)&of, OF_PARSE);

	if(wFileTemp)
		_lclose (wFileTemp);
}


/***************************************************************************
*																									*
*	FUNCTION:	OptionsCallBack															*
*																									*
*	PURPOSE:		Serve as callback function for ODMASaveAs.						*
*					Currently this only displays a message box with the			*
*					passed in text.															*
*																									*
*	RETURNS:		NONE																			*
*																								 	*
***************************************************************************/
LPSTR FAR OptionsCallBack(DWORD dwEnvData, LPSTR lpszFormat, LPVOID lpData)
{
	if(lpData)
		MessageBox((HWND) dwEnvData, lpData, "MultODMA",
			MB_OK | MB_ICONINFORMATION);
	else
		MessageBox((HWND) dwEnvData, "App Specific info not given",	"MultODMA",
			MB_OK | MB_ICONINFORMATION);

	return lpszFormat;				/* return a pointer at the 'format' string */
}

