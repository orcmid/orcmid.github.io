/***************************************************************************
* TABS(3,3)																						*
*																									*
*	MODULE:		MpFind.c																		*
*																									*
*	PURPOSE:		Code to do text searches in MultiODMA.								*
*																									*
*	FUNCTIONS:	RealSlowCompare() - Compares subject string with target		*
*												string.											*
*																									*
*					MyFindText()		- Looks for the search string in the		*
*											  active window.									*
*																									*
*					FindPrev()			- Find previous occurence of search			*
*											  string.											*
*																									*
*					FindNext()			- Find next occurence of search string		*
*																									*
*					FindDlgProc()		- Dialog function for Search/Find.			*
*																									*
*					Find()				- Invokes FindDlgProc()							*
*																									*
***************************************************************************/
#include "multipad.h"
#undef HIWORD
#undef LOWORD

#define HIWORD(l) (((WORD*)&(l))[1])
#define LOWORD(l) (((WORD*)&(l))[0])

BOOL fCase = FALSE;				/* Turn case sensitivity off */
char szSearch[160] = "";		/* Initialize search string  */

/***************************************************************************
*																									*
*	FUNCTION:	RealSlowCompare()															*
*																									*
*	PURPOSE:		Compares subject string with the target string. This funct	*
*					is called repeatedly so that all substrings are compared,	*
*					which makes it O(n ** 2), hence it's name.						*
*																									*
*	RETURNS:		TRUE  - If pSubject is identical to pTarget.						*
*					FALSE - otherwise.														*
*																									*
***************************************************************************/
BOOL WINAPI RealSlowCompare(register PSTR pSubject, register PSTR pTarget)
{
	if(fCase) {
		while(*pTarget)
			if(*pTarget++ != *pSubject++)
				return FALSE;
	}
	else {
	/* If case-insensitive, convert both subject and target to lowercase
		before comparing. */
		AnsiLower((LPSTR)pTarget);
		while(*pTarget)
			if(*pTarget++ != (char)(DWORD)AnsiLower((LPSTR)(DWORD)(BYTE)*pSubject++))
				return FALSE;
	}

	return TRUE;
}


/***************************************************************************
*																									*
*	FUNCTION:	MyFindText()																*
*																									*
*	PURPOSE:		Finds the search string in the active window according to	*
*					search direction (dch) specified ( -1 for reverse and 1 for	*
*					forward searches).														*
*																									*
***************************************************************************/
VOID WINAPI MyFindText(register int dch)
{
/*register*/ LPSTR lpText;
WORD	wStart, wEnd;
DWORD dwGetSel;
HLOCAL hT;
int cch;
int i;


	if(!*szSearch)
		return;

	dwGetSel = Edit_GetSel(hwndActiveEdit); /*Find the current selection range*/
	wStart = LOWORD(dwGetSel);
	wEnd = HIWORD(dwGetSel);

	cch = Edit_GetTextLength(hwndActiveEdit) + 1;	/* Get the length of the text */
	hT = LocalAlloc(LHND, cch);
	lpText = (LPSTR) LocalLock(hT);
	Edit_GetText(hwndActiveEdit, lpText, cch);

	lpText += (int) wStart + dch;		/* Start with the next char in sel range */

	/* Compute how many characters are before/after the current selection*/
	if(dch < 0)
		i = (int) wEnd;
	else
		i = cch - (int) wStart + 1 - lstrlen(szSearch);

	while(i > 0) {						/* While there are uncompared substrings... */
		wStart += (WORD)dch;

		if(RealSlowCompare((PSTR)lpText, szSearch)) {    /* Does this substring match? */
			LocalUnlock(hT);
			LocalFree(hT);
			wEnd = wStart;
			wEnd += (WORD)lstrlen(szSearch);		/* Select the located string */
			Edit_SetSel(hwndActiveEdit, wStart, wEnd);
			return;
		}

		i--;
		lpText += dch;					/* increment/decrement start position by 1 */
	}

	LocalUnlock(hT);					/* Not found... unlock buffer. */
	LocalFree(hT);
	MPError(hwndFrame, MB_OK | MB_ICONEXCLAMATION, IDS_CANTFIND, (LPSTR)szSearch);
	return;
}


/***************************************************************************
*																									*
*	FUNCTION:	FindPrev()																	*
*																									*
*	PURPOSE:		Finds the previous occurence of the search string. Calls		*
*					MyFindText () with a negative search direction.					*
*																									*
***************************************************************************/
VOID WINAPI FindPrev(void)
{
	 MyFindText(-1);
}


/***************************************************************************
*																									*
*	FUNCTION:	FindNext()																	*
*																									*
*	PURPOSE:		Finds the next occurence of search string. Calls				*
*					MyFindText () with a positive search direction.					*
*																									*
***************************************************************************/
VOID WINAPI FindNext(void)
{
	 MyFindText(1);
}


/***************************************************************************
*																									*
*	FUNCTION:	FindDlgProc(hwnd, message, wParam, lParam)						*
*																									*
*	PURPOSE:		Dialog function for the Search/Find command. Prompts user	*
*					for target string, case flag and search direction.				*
*																									*
***************************************************************************/
BOOL WINAPI FindDlgProc(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam)
{
	switch(msg) {
		case WM_INITDIALOG: {
			CheckDlgButton(hwnd, IDD_CASE, fCase);  /* Check/uncheck case button */
			/* Set default search string to most recently searched string */
			SetDlgItemText(hwnd, IDD_SEARCH, szSearch);

			/* Allow search only if target is nonempty */
			if(!lstrlen (szSearch)) {
				EnableWindow (GetDlgItem (hwnd, IDOK), FALSE);
				EnableWindow (GetDlgItem (hwnd, IDD_PREV), FALSE);
			}
			break;
		}

		case WM_COMMAND: {
			int i = 1;				/* Search forward by default (see IDOK below) */

			switch(GET_WM_COMMAND_ID(wParam, lParam)) {
				/* if the search target becomes non-empty, enable searching */
				case IDD_SEARCH:
					if(GET_WM_COMMAND_CMD(wParam, lParam) == EN_CHANGE) {
						if(!(WORD) SendDlgItemMessage(hwnd, IDD_SEARCH,
						WM_GETTEXTLENGTH, 0, 0L))
							i = FALSE;
						else
							i = TRUE;

						EnableWindow(GetDlgItem (hwnd, IDOK), i);
						EnableWindow(GetDlgItem (hwnd, IDD_PREV), i);
					}
					break;

				case IDD_CASE:
					/* Toggle state of case button */
					CheckDlgButton(hwnd, IDD_CASE, !IsDlgButtonChecked(hwnd, IDD_CASE));
					break;

				case IDD_PREV:
					/* Set direction to backwards */
					i =- 1;
					/*** FALL THRU ***/

				case IDOK:
					/* Save case selection */
					fCase = IsDlgButtonChecked(hwnd, IDD_CASE);

					/* Get search string */
					GetDlgItemText(hwnd, IDD_SEARCH, szSearch, sizeof (szSearch));

					/* Find the text */
					MyFindText(i);
					/*** FALL THRU ***/

				/* End the dialog */
				case IDCANCEL:
					EndDialog(hwnd, 0);
					break;

				default:
					return FALSE;
			}
			break;
		}
		default:
			return FALSE;
	}
	return TRUE;
}


/***************************************************************************
*																									*
*	FUNCTION:	Find()																		*
*																									*
*	PURPOSE:		Invokes the Search/Find dialog.										*
*																									*
***************************************************************************/
VOID WINAPI Find()
{
FARPROC lpfn;

	lpfn = (FARPROC) MakeProcInstance((FARPROC)FindDlgProc, hInst);
	DialogBox(hInst, IDD_FIND, hwndFrame, (DLGPROC)lpfn);
#ifndef WIN32
	FreeProcInstance(lpfn);
#endif
}

