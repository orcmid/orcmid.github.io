VERSION 5.00
Begin VB.Form SelectForm 
   Caption         =   "Select Flag and Set Value"
   ClientHeight    =   3915
   ClientLeft      =   60
   ClientTop       =   345
   ClientWidth     =   6120
   LinkTopic       =   "Form1"
   ScaleHeight     =   3915
   ScaleWidth      =   6120
   StartUpPosition =   3  'Windows Default
   Begin VB.CommandButton CancelBtn 
      Cancel          =   -1  'True
      Caption         =   "Cancel"
      Height          =   375
      Left            =   3120
      TabIndex        =   5
      Top             =   3480
      Width           =   1455
   End
   Begin VB.CommandButton OkBtn 
      Caption         =   "Ok"
      Height          =   375
      Left            =   1200
      TabIndex        =   4
      Top             =   3480
      Width           =   1455
   End
   Begin VB.Frame Frame2 
      Caption         =   "Values"
      Height          =   3135
      Left            =   3120
      TabIndex        =   1
      Top             =   120
      Width           =   2895
      Begin VB.TextBox ValueText 
         Height          =   375
         Left            =   120
         TabIndex        =   3
         Top             =   360
         Width           =   2655
      End
   End
   Begin VB.Frame Frame1 
      Caption         =   "Flags"
      Height          =   3135
      Left            =   120
      TabIndex        =   0
      Top             =   120
      Width           =   2895
      Begin VB.ListBox FlagList 
         Height          =   2595
         Left            =   120
         TabIndex        =   2
         Top             =   240
         Width           =   2655
      End
   End
End
Attribute VB_Name = "SelectForm"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Option Explicit

Public Index As Integer

Private Sub CancelBtn_Click()
    Index = -1
    Me.Hide
End Sub

Private Sub OkBtn_Click()
    
    Index = FlagList.ListIndex
    Me.Hide
End Sub
