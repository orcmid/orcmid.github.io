VERSION 5.00
Begin VB.Form MainForm 
   Caption         =   "ODMA OCX test"
   ClientHeight    =   6270
   ClientLeft      =   60
   ClientTop       =   345
   ClientWidth     =   8865
   LinkTopic       =   "Form1"
   ScaleHeight     =   6270
   ScaleWidth      =   8865
   StartUpPosition =   3  'Windows Default
   Begin VB.CommandButton SetAlternateContent 
      Caption         =   "Set Alter.Content"
      Height          =   375
      Left            =   7200
      TabIndex        =   39
      Top             =   2160
      Width           =   1575
   End
   Begin VB.CommandButton GetAlternateContent 
      Caption         =   "Get Alter.Content"
      Height          =   375
      Left            =   7200
      TabIndex        =   38
      Top             =   1680
      Width           =   1575
   End
   Begin VB.CommandButton Activate 
      Caption         =   "Activate"
      Height          =   375
      Left            =   7200
      TabIndex        =   37
      Top             =   1200
      Width           =   1575
   End
   Begin VB.CommandButton GetResults 
      Caption         =   "GetResults"
      Height          =   375
      Left            =   7200
      TabIndex        =   36
      Top             =   3600
      Width           =   1575
   End
   Begin VB.CommandButton QueryExecute 
      Caption         =   "QueryExecute"
      Height          =   375
      Left            =   5760
      TabIndex        =   35
      Top             =   3600
      Width           =   1335
   End
   Begin VB.CommandButton QueryClose 
      Caption         =   "QueryClose"
      Height          =   375
      Left            =   4320
      TabIndex        =   34
      Top             =   3600
      Width           =   1335
   End
   Begin VB.CommandButton QueryCapablility 
      Caption         =   "QueryCapablility"
      Height          =   375
      Left            =   2880
      TabIndex        =   33
      Top             =   3600
      Width           =   1335
   End
   Begin VB.CommandButton SetDocEvent 
      Caption         =   "SetDocEvent"
      Height          =   375
      Left            =   5760
      TabIndex        =   32
      Top             =   3120
      Width           =   1335
   End
   Begin VB.CommandButton SetDocRelation 
      Caption         =   "SetDocRelation"
      Height          =   375
      Left            =   5760
      TabIndex        =   31
      Top             =   2640
      Width           =   1335
   End
   Begin VB.CommandButton GetDocRelation 
      Caption         =   "GetDocRelation"
      Height          =   375
      Left            =   5760
      TabIndex        =   30
      Top             =   2160
      Width           =   1335
   End
   Begin VB.CommandButton SetDocInfo 
      Caption         =   "SetDocInfo"
      Height          =   375
      Left            =   5760
      TabIndex        =   29
      Top             =   1680
      Width           =   1335
   End
   Begin VB.CommandButton GetDocInfo 
      Caption         =   "GetDocInfo"
      Height          =   375
      Left            =   5760
      TabIndex        =   28
      Top             =   1200
      Width           =   1335
   End
   Begin VB.CommandButton SelectDocEx 
      Caption         =   "SelectDocEx"
      Height          =   375
      Left            =   4320
      TabIndex        =   27
      Top             =   3120
      Width           =   1335
   End
   Begin VB.CommandButton SelectDoc 
      Caption         =   "SelectDoc"
      Height          =   375
      Left            =   4320
      TabIndex        =   26
      Top             =   2640
      Width           =   1335
   End
   Begin VB.CommandButton CloseDocEx 
      Caption         =   "CloseEx"
      Height          =   375
      Left            =   4320
      TabIndex        =   25
      Top             =   2160
      Width           =   1335
   End
   Begin VB.CommandButton CloseDoc 
      Caption         =   "Close"
      Height          =   375
      Left            =   4320
      TabIndex        =   24
      Top             =   1680
      Width           =   1335
   End
   Begin VB.CommandButton SaveDocEx 
      Caption         =   "SaveEx"
      Height          =   375
      Left            =   2880
      TabIndex        =   23
      Top             =   3120
      Width           =   1335
   End
   Begin VB.CommandButton SaveDoc 
      Caption         =   "Save"
      Height          =   375
      Left            =   2880
      TabIndex        =   22
      Top             =   2640
      Width           =   1335
   End
   Begin VB.CommandButton SaveAsEx 
      Caption         =   "SaveAsEx"
      Height          =   375
      Left            =   2880
      TabIndex        =   21
      Top             =   2160
      Width           =   1335
   End
   Begin VB.Frame Frame4 
      Caption         =   "Current Document"
      Height          =   1095
      Left            =   2880
      TabIndex        =   16
      Top             =   0
      Width           =   5895
      Begin VB.Label CurrentQueryId 
         Height          =   255
         Left            =   1080
         TabIndex        =   20
         Top             =   600
         Width           =   4335
      End
      Begin VB.Label Label5 
         Caption         =   "QueryId:"
         Height          =   255
         Left            =   120
         TabIndex        =   19
         Top             =   600
         Width           =   735
      End
      Begin VB.Label CurrentDocumentId 
         Height          =   255
         Left            =   1080
         TabIndex        =   18
         Top             =   240
         Width           =   4335
      End
      Begin VB.Label Label4 
         Caption         =   "Id:"
         Height          =   255
         Left            =   120
         TabIndex        =   17
         Top             =   240
         Width           =   375
      End
   End
   Begin VB.CommandButton SaveAs 
      Caption         =   "SaveAs"
      Height          =   375
      Left            =   2880
      TabIndex        =   15
      Top             =   1680
      Width           =   1335
   End
   Begin VB.CommandButton OpenDoc 
      Caption         =   "Open Document"
      Height          =   375
      Left            =   4320
      TabIndex        =   14
      Top             =   1200
      Width           =   1335
   End
   Begin VB.CommandButton NewDoc 
      Caption         =   "New Document"
      Height          =   375
      Left            =   2880
      TabIndex        =   13
      Top             =   1200
      Width           =   1335
   End
   Begin VB.Frame Frame3 
      Caption         =   "Default DMS Info"
      Height          =   1095
      Left            =   0
      TabIndex        =   6
      Top             =   2880
      Width           =   2775
      Begin VB.Label DMSExtensions 
         Caption         =   "q"
         Height          =   255
         Left            =   1080
         TabIndex        =   12
         Top             =   720
         Width           =   1215
      End
      Begin VB.Label DMSVerNo 
         Caption         =   "q"
         Height          =   255
         Left            =   1080
         TabIndex        =   11
         Top             =   480
         Width           =   1215
      End
      Begin VB.Label DMSId 
         Caption         =   "q"
         Height          =   255
         Left            =   1080
         TabIndex        =   10
         Top             =   240
         Width           =   1215
      End
      Begin VB.Label Label3 
         Caption         =   "Extension:"
         Height          =   255
         Left            =   120
         TabIndex        =   9
         Top             =   720
         Width           =   735
      End
      Begin VB.Label Label2 
         Caption         =   "Ver. No:"
         Height          =   255
         Left            =   120
         TabIndex        =   8
         Top             =   480
         Width           =   615
      End
      Begin VB.Label Label1 
         Caption         =   "DMS id:"
         Height          =   255
         Left            =   120
         TabIndex        =   7
         Top             =   240
         Width           =   615
      End
   End
   Begin VB.CommandButton SetDefaultDMS 
      Caption         =   "Set As Default"
      Height          =   375
      Left            =   0
      TabIndex        =   5
      Top             =   2400
      Width           =   1815
   End
   Begin VB.Frame Frame2 
      Caption         =   "OCX Calls"
      Height          =   2175
      Left            =   0
      TabIndex        =   3
      Top             =   4080
      Width           =   8775
      Begin VB.ListBox OCXCalls 
         Height          =   1815
         Left            =   120
         TabIndex        =   4
         Top             =   240
         Width           =   8535
      End
   End
   Begin VB.Frame Frame1 
      Caption         =   "DMS list"
      Height          =   2295
      Left            =   0
      TabIndex        =   0
      Top             =   0
      Width           =   2775
      Begin VB.ListBox DMSListBox 
         Height          =   1620
         Left            =   120
         TabIndex        =   1
         Top             =   240
         Width           =   2535
      End
      Begin VB.Label DMSCountLabel 
         Caption         =   "DMS count: "
         Height          =   255
         Left            =   120
         TabIndex        =   2
         Top             =   1920
         Width           =   1695
      End
   End
End
Attribute VB_Name = "MainForm"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Dim Wrapper As New ODMAWrapper

Private Sub Activate_Click()
Dim lRetVal As Long
Dim Flag As Long
    
    Flags = Array("ODM_NONE", "ODM_DELETE", "ODM_SHOWATTRIBUTES", "ODM_EDITATTRIBUTES", "ODM_VIEWDOC", "ODM_OPENDOC", "ODM_NEWDOC", "ODM_CHECKOUT", "ODM_CANCELCHECKOUT", "ODM_CHECKIN", "ODM_SHOWHISTORY")

    lB = LBound(Flags)
    uB = UBound(Flags)
    SelectForm.FlagList.Clear
    SelectForm.ValueText = "0"
    
    For i = lB To uB
        SelectForm.FlagList.AddItem Flags(i)
    Next i
    SelectForm.Show 1
    
    nIndex = SelectForm.Index
    If nIndex >= 0 Then
        lFlag = nIndex
   
        Dim s As String
        s = SelectForm.ValueText
        If CurrentDocumentId <> "" Then
            lRetVal = Wrapper.Activate(lFlag, CurrentDocumentId)
            LogCallResult "Activate", lRetVal, Flags(lFlag) + ", " + CurrentDocumentId, ""

        End If
    End If
End Sub

Private Sub CloseDoc_Click()
Dim lRetVal As Long
Dim NewDocId As String
Dim l As Long
    
    l = 2147483647
    If CurrentDocumentId <> "" Then
        lRetVal = Wrapper.CloseDoc(CurrentDocumentId, l, l, 0)
        LogCallResult "CloseDoc", lRetVal, CurrentDocumentId + ", FFFFFFFF, FFFFFFFF, 0", ""
        CurrentDocumentId = ""
    End If

End Sub

Private Sub CloseDocEx_Click()
Dim lRetVal As Long
Dim NewDocId As String
Dim l As Long
    
     l = 2147483647
    If CurrentDocumentId <> "" Then
        lRetVal = Wrapper.CloseDocEx(CurrentDocumentId, 0, l, l, 0)
        LogCallResult "CloseDocEx", lRetVal, CurrentDocumentId + ", 0, FFFFFFFF, FFFFFFFF, 0", ""
        CurrentDocumentId = ""
    End If

End Sub

Private Sub Form_Load()
Dim lRetVal As Long
Dim lDMSCount As Long
Dim buf, s As String
Dim i, k, l As Integer
Dim strDMSID As String
Dim lExtensions As Long
Dim lVerNo As Long
Dim DMSarray

    lRetVal = Wrapper.RegisterApp(ODM_API_VERSION, "ODMATest", 0, 0)
    LogCallResult "RegisterApp", lRetVal, "200, ODMATest, 0, 0", ""
    
    lDMSCount = Wrapper.GetDMSCount
    LogCallResult "GetDMSCount", lDMSCount, "", ""
    
    lRetVal = Wrapper.GetDMSList(DMSarray)
    
    s = ""
    For i = 0 To lRetVal - 1
        DMSListBox.AddItem DMSarray(i)
        s = s + DMSarray(i)
    Next i
    LogCallResult "GetDMSList", lRetVal, "", s
    
    DMSCountLabel = DMSCountLabel + Str(i - 1)
    
    lRetVal = Wrapper.GetDMS("ODMATest", strDMSID)
    LogCallResult "GetDMS", lRetVal, "ODMATest", strDMSID
    
    lRetVal = Wrapper.GetDMSInfo(strDMSID, lVerNo, lExtensions)
    LogCallResult "GetDMSInfo", lRetVal, "", strDMSID + ", " + Str(lVerNo) + ", " + Str(lExtensions)
    
    DMSId = strDMSID
    DMSVerNo = Str(lVerNo)
    Select Case lExtensions
    Case 1:
        DMSExtensions = "Query"
    Case 2:
        DMSExtensions = "Workflow"
    Case 3:
        DMSExtensions = "Query;Workflow"
    End Select
End Sub

Private Sub Form_Unload(Cancel As Integer)
    Wrapper.UnRegisterApp
End Sub

Public Sub LogCallResult(MethodName As String, lRetVal As Long, InParams As String, OutParams As String)
Dim strRetVal As String

    If ((MethodName <> "GetDMSList") And (MethodName <> "GetDMSCount")) Then
        Select Case lRetVal
        Case ODM_SUCCESS:
            strRetVal = "OK"
        Case ODM_E_FAIL:
            strRetVal = "E_FAIL"
        Case ODM_E_CANCEL:
            strRetVal = "E_CANCEL"
        Case ODM_E_NODMS:
            strRetVal = "E_NODMS"
        Case ODM_E_CANTINIT:
            strRetVal = "E_CANTINIT"
        Case ODM_E_VERSION:
            strRetVal = "E_VERSION"
        Case ODM_E_APPSELECT:
            strRetVal = "E_APPSELECT"
        Case ODM_E_USERINT:
            strRetVal = "E_USERINT"
        Case ODM_E_HANDLE:
            strRetVal = "E_HANDLE"
        Case ODM_E_ACCESS:
            strRetVal = "E_ACCESS"
        Case ODM_E_INUSE:
            strRetVal = "E_INUSE"
        Case ODM_E_DOCID:
            strRetVal = "E_DOCID"
        Case ODM_E_OPENMODE:
            strRetVal = "E_OPENMODE"
        Case ODM_E_NOOPEN:
            strRetVal = "E_NOOPEN"
        Case ODM_E_ITEM:
            strRetVal = "E_ITEM"
        Case ODM_E_OTHERAPP:
            strRetVal = "E_OTHERAPP"
        Case ODM_E_NOMOREDATA:
            strRetVal = "E_NOMOREDATA"
        Case ODM_E_PARTIALSUCCESS:
            strRetVal = "E_PARTIALSUCCESS"
        Case ODM_E_REQARG:
            strRetVal = "E_REQARG"
        Case ODM_E_NOSUPPORT:
            strRetVal = "E_NOSUPPORT"
        Case ODM_E_TRUNCATED:
            strRetVal = "E_TRUNCATED"
        Case ODM_E_INVARG:
            strRetVal = "E_INVARG"
        Case ODM_E_OFFLINE:
            strRetVal = "E_OFFLINE"
        End Select
    Else
        strRetVal = Str(lRetVal)
    End If
    
    If InParams = "" Then
        strIn = "empty"
    Else
        strIn = InParams
    End If

    If OutParams = "" Then
        strOut = "empty"
    Else
        strOut = OutParams
    End If

    OCXCalls.AddItem MethodName + " - " + strRetVal + "  In: " + strIn + "; Out: " + strOut
    OCXCalls.Selected(OCXCalls.ListCount - 1) = True
End Sub

Private Sub GetAlternateContent_Click()
Dim lRetVal As Long
Dim Format As String
Dim Location As String
Dim Flag As Long
    
    Flag = 0
    Format = "Text"
    
    If CurrentDocumentId <> "" Then
        lRetVal = Wrapper.GetAlternateContent(CurrentDocumentId, Flag, Format, Location)
        LogCallResult "GetAlternateContent", lRetVal, CurrentDocumentId + ", 0, " + Format, Str(Flag) + ", " + Location
    End If

End Sub

Private Sub GetDocInfo_Click()
Dim lRetVal As Long
Dim Data As String

    Flags = Array("ODM_AUTHOR", "ODM_NAME", "ODM_TYPE", "ODM_TITLETEXT", "ODM_DMS_DEFINED", "ODM_CONTENTFORMAT", "ODM_ALTERNATE_RENDERINGS", "ODM_CHECKEDOUTBY", "ODM_CHECKOUTCOMMENT", "ODM_CHECKOUTDATE", "ODM_CREATEDBY", "ODM_CREATEDDATE", "ODM_DOCID_LATEST", "ODM_DOCID_RELEASED", "ODM_DOCVERSION", "ODM_DOCVERSION_LATEST", "ODM_DOCVERSION_RELEASED", "ODM_LOCATION", "ODM_KEYWORDS", "ODM_LASTCHECKINBY", "ODM_LASTCHECKINDATE", "ODM_MODIFYDATE", "ODM_MODIFYDATE_LATEST", "ODM_MODIFYDATE_RELEASED", "ODM_OWNER", "ODM_SUBJECT", "ODM_TITLETEXT_RO", "ODM_URL")

    lB = LBound(Flags)
    uB = UBound(Flags)
    SelectForm.FlagList.Clear
    SelectForm.ValueText = "0"
    
    For i = lB To uB
        SelectForm.FlagList.AddItem Flags(i)
    Next i
    SelectForm.Show 1
    
    nIndex = SelectForm.Index
    If nIndex >= 0 Then
        lFlag = nIndex + 1
   
        Dim s As String
        s = SelectForm.ValueText
        If CurrentDocumentId <> "" Then
            lRetVal = Wrapper.GetDocInfo(CurrentDocumentId, lFlag, Data)
            LogCallResult "GetDocInfo", lRetVal, CurrentDocumentId + ", " + Flags(lFlag - 1), Data
        End If
    End If
    
End Sub

Private Sub GetDocRelation_Click()
Dim lRetVal As Long
Dim Flags As Long
Dim LinkedId As String
Dim Format As String
Dim PreviousId As String
    
    Flags = 0
    'LinkedId = "18-46-08-56"
    LinkedId = ""
    Format = ""
    PreviousId = ""
    
    If CurrentDocumentId <> "" Then
        lRetVal = Wrapper.GetDocRelation(CurrentDocumentId, Flags, LinkedId, Format, PreviousId)
        LogCallResult "GetDocRelation", lRetVal, CurrentDocumentId + ", 0, , ", Str(Flags) + ", " + LinkedId + ", " + Format
    End If

End Sub

Private Sub GetResults_Click()
Dim lRetVal As Long
Dim Count As Long
Dim DocId
Dim DocName
Dim sId As String
Dim sName As String
        
    Count = 20
    If CurrentQueryId <> "" Then
        lRetVal = Wrapper.QueryGetResults(CurrentQueryId, DocId, DocName, Count)
        Count = UBound(DocId)
        For i = 0 To Count - 1
            sId = sId + DocId(i)
        Next i
        
        Count = UBound(DocName)
        For i = 0 To Count - 1
            sName = sName + DocName(i)
        Next i
        If Count > 0 Then
            CurrentDocumentId = DocId(0)
        End If
        LogCallResult "QueryGetResults", lRetVal, CurrentQueryId + ", 20 ", sId + ", " + sName + ", " + Str(Count)
    End If
End Sub

Private Sub NewDoc_Click()
Dim lRetVal As Long
Dim DocId As String
Dim l As Long

    l = 2147483647
    If CurrentDocumentId <> "" Then
        lRetVal = Wrapper.CloseDoc(CurrentDocumentId, l, l, 0)
    End If

    lRetVal = Wrapper.NewDoc(DocId, ODM_SILENT, "Text", "")
    LogCallResult "NewDoc", lRetVal, "ODM_SILENT, Text, ", DocId
    If DocId <> "" Then
        CurrentDocumentId = DocId
    End If

End Sub

Private Sub OpenDoc_Click()
Dim lRetVal As Long
Dim DocLocation As String

    Flags = Array("ODM_MODIFYMODE", "ODM_VIEWMODE", "ODM_REFCOPY", "ODM_SILENT")
    lB = LBound(Flags)
    uB = UBound(Flags)
    SelectForm.FlagList.Clear
    SelectForm.ValueText = "0"
    
    For i = lB To uB
        SelectForm.FlagList.AddItem Flags(i)
    Next i
    SelectForm.Show 1
    
    nIndex = SelectForm.Index
    If nIndex >= 0 Then
        lFlag = nIndex
        If lFlag > 3 Then
            lFlag = ODM_SILENT
        End If
    
        If CurrentDocumentId <> "" Then
            lRetVal = Wrapper.OpenDoc(lFlag, CurrentDocumentId, DocLocation)
            
            Dim s2 As String
            If lFlag > 3 Then
                lFlag = 3
            End If
            
            LogCallResult "OpenDoc", lRetVal, Flags(lFlag) + ", " + CurrentDocumentId, DocLocation
        End If
    End If

End Sub

Private Sub QueryCapablility_Click()
Dim lRetVal As Long
Dim Flags As Long
Dim Item As Long
Dim lFunction As Long
    
    Flags = 0
    Item = 0
    lFunction = ODM_QC_NEWDOC
    
    If CurrentDocumentId <> "" Then
        lRetVal = Wrapper.QueryCapability("ODMASAMP", lFunction, Item, Flags)
        LogCallResult "QueryCapability", lRetVal, "ODMASAMP, ODM_QC_NEWDOC, 0, 0", ""
    End If


End Sub

Private Sub QueryClose_Click()
Dim lRetVal As Long

    If CurrentQueryId <> "" Then
        lRetVal = Wrapper.QueryClose(CurrentQueryId)
        LogCallResult "QueryClose", lRetVal, CurrentQueryId, ""
        CurrentQueryId = ""
    End If

End Sub

Private Sub QueryExecute_Click()
Dim lRetVal As Long
Dim Flag As Long
Dim QueryStr As String
Dim s As String
Dim DMSList
Dim QueryId As String
    
    QueryStr = "SELECT ODM_DOCID, ODM_NAME"
    Flag = ODM_SPECIFIC
    DMSList = Array("ODMASAMP", "ODMASAMP")
    'DMSList = Array("ODMASAMP")
    Dim l As Long
    Dim lB As Long
    Dim uB As Long
    lB = LBound(DMSList)
    uB = UBound(DMSList)
    For l = lB To uB
        s = s + DMSList(l)
    Next l
    
    lRetVal = Wrapper.QueryExecute(QueryStr, Flag, DMSList, QueryId)
    
    LogCallResult "QueryExecute", lRetVal, QueryStr + ", ODM_SPECIFIC, " + s, QueryId
    If QueryId <> "" Then
        CurrentQueryId = QueryId
    End If
    
End Sub

Private Sub SaveDoc_Click()
Dim lRetVal As Long
Dim NewDocId As String

    If CurrentDocumentId <> "" Then
        lRetVal = Wrapper.SaveDoc(CurrentDocumentId, NewDocId)
        LogCallResult "SaveDoc", lRetVal, CurrentDocumentId, NewDocId
        If NewDocId <> "" Then
            CurrentDocumentId = NewDocId
        End If
    End If
End Sub

Private Sub SaveAs_Click()
Dim lRetVal As Long
Dim NewDocId As String

    If CurrentDocumentId <> "" Then
        lRetVal = Wrapper.SaveAs(CurrentDocumentId, NewDocId, "Text(SaveAs)", AddressOf Callback, "")
        LogCallResult "SaveAs", lRetVal, CurrentDocumentId + ", Text, ", NewDocId
        If NewDocId <> "" Then
            CurrentDocumentId = NewDocId
        End If
    End If
End Sub

Private Sub SaveAsEx_Click()
Dim lRetVal As Long
Dim NewDocId As String

    If CurrentDocumentId <> "" Then
        lRetVal = Wrapper.SaveAsEx(CurrentDocumentId, NewDocId, "Text(SaveAsEx)", AddressOf Callback, "", 0)
        LogCallResult "SaveAsEx", lRetVal, CurrentDocumentId + ", Text, ,0", NewDocId
        If NewDocId <> "" Then
            CurrentDocumentId = NewDocId
        End If
    End If
End Sub

Private Sub SaveDocEx_Click()
Dim lRetVal As Long
Dim NewDocId As String

    If CurrentDocumentId <> "" Then
        lRetVal = Wrapper.SaveDocEx(CurrentDocumentId, NewDocId, 0)
        LogCallResult "SaveDocEx", lRetVal, CurrentDocumentId + ", 0", NewDocId
        If NewDocId <> "" Then
            CurrentDocumentId = NewDocId
        End If
    End If
End Sub

Private Sub SelectDoc_Click()
Dim lRetVal As Long
Dim NewDocId As String
Dim lFlag As Long
Dim l As Long
Dim Flags
Dim lB As Long
Dim uB As Long
Dim nIndex As Integer

    Flags = Array("ODM_MODIFYMODE", "ODM_VIEWMODE", "ODM_SILENT")
    lB = LBound(Flags)
    uB = UBound(Flags)
    SelectForm.FlagList.Clear
    SelectForm.ValueText = ""
    For i = lB To uB
        SelectForm.FlagList.AddItem Flags(i)
    Next i
    SelectForm.Show 1
    
    nIndex = SelectForm.Index
    If nIndex >= 0 Then
        lFlag = nIndex
        If lFlag > 2 Then
            lFlag = ODM_SILENT
        End If
        
        l = 2147483647
        
        lRetVal = Wrapper.SelectDoc(NewDocId, lFlag)
        Dim s As String
        s = Flags(nIndex)
        Dim s2 As String
        If lFlag > 2 Then
            lFlag = 2
        End If
        s2 = Flags(lFlag)
        LogCallResult "SelectDoc", lRetVal, s, NewDocId + ", " + s2
        If CurrentDocumentId <> "" Then
            lRetVal = Wrapper.CloseDoc(CurrentDocumentId, l, l, 0)
        End If
        CurrentDocumentId = NewDocId
    
        
    End If
End Sub

Private Sub SelectDocEx_Click()
Dim lRetVal As Long
Dim NewDocId
Dim lFlag As Long
Dim lCount As Long
Dim s As String
Dim l As Long

    Flags = Array("ODM_MODIFYMODE", "ODM_VIEWMODE", "ODM_SILENT")
    lB = LBound(Flags)
    uB = UBound(Flags)
    SelectForm.FlagList.Clear
    SelectForm.ValueText = "0"
    
    For i = lB To uB
        SelectForm.FlagList.AddItem Flags(i)
    Next i
    SelectForm.Show 1
    
    nIndex = SelectForm.Index
    If nIndex >= 0 Then
        lFlag = nIndex
        If lFlag > 2 Then
            lFlag = ODM_SILENT
        End If
    
        lCount = SelectForm.ValueText
        If lCount > 0 Then
    
            l = 2147483647
            If CurrentDocumentId <> "" Then
                lRetVal = Wrapper.CloseDoc(CurrentDocumentId, l, l, 0)
                lRetVal = Wrapper.SelectDocEx(NewDocId, lCount, lFlag, "")
                For i = 0 To lCount - 1
                    s = s + NewDocId(i)
                Next i
                
                Dim s1 As String
                s1 = Flags(nIndex)
                Dim s2 As String
                If lFlag > 2 Then
                    lFlag = 2
                End If
                s2 = Flags(lFlag)

                CurrentDocumentId = NewDocId(0)
                LogCallResult "SelectDocEx", lRetVal, Str(lCount) + ", " + s1 + ", empty", s + ", " + Str(lCount) + ", " + s2
            End If
        
        End If
    End If
End Sub

Private Sub SetAlternateContent_Click()
Dim lRetVal As Long
Dim Format As String
Dim Location As String
Dim Flag As Long
    
    Flag = 0
    Format = "Text"
    If CurrentDocumentId <> "" Then
        Location = InputBox("Enter Location", "Document Location")
        If Location <> "" Then
            lRetVal = Wrapper.SetAlternateContent(CurrentDocumentId, Flag, Format, Location)
            LogCallResult "SetAlternateContent", lRetVal, CurrentDocumentId + ", 0, " + Format + ", " + Location, Str(Flag)
        End If
    End If

End Sub

Private Sub SetDefaultDMS_Click()
Dim i As Integer
Dim lRetVal As Long

    If DMSListBox.SelCount = 1 Then
        i = DMSListBox.ListIndex
        lRetVal = Wrapper.SetDMS("ODMATest", DMSListBox.List(i))
        LogCallResult "SetDMS", lRetVal, "ODMATest, " + DMSListBox.List(i), ""
    End If
End Sub

Private Sub SetDocEvent_Click()
Dim lRetVal As Long
    
    If CurrentDocumentId <> "" Then
        lRetVal = Wrapper.SetDocEvent(CurrentDocumentId, 0, 0, "", "")
        LogCallResult "SetDocEvent", lRetVal, CurrentDocumentId + ", 0, 0, , ", ""
    End If

End Sub

Private Sub SetDocInfo_Click()
Dim lRetVal As Long
Dim Data As String
    
    Flags = Array("ODM_AUTHOR", "ODM_NAME", "ODM_TYPE", "ODM_TITLETEXT", "ODM_DMS_DEFINED", "ODM_CONTENTFORMAT", "ODM_ALTERNATE_RENDERINGS", "ODM_CHECKEDOUTBY", "ODM_CHECKOUTCOMMENT", "ODM_CHECKOUTDATE", "ODM_CREATEDBY", "ODM_CREATEDDATE", "ODM_DOCID_LATEST", "ODM_DOCID_RELEASED", "ODM_DOCVERSION", "ODM_DOCVERSION_LATEST", "ODM_DOCVERSION_RELEASED", "ODM_LOCATION", "ODM_KEYWORDS", "ODM_LASTCHECKINBY", "ODM_LASTCHECKINDATE", "ODM_MODIFYDATE", "ODM_MODIFYDATE_LATEST", "ODM_MODIFYDATE_RELEASED", "ODM_OWNER", "ODM_SUBJECT", "ODM_TITLETEXT_RO", "ODM_URL")

    lB = LBound(Flags)
    uB = UBound(Flags)
    SelectForm.FlagList.Clear
    SelectForm.ValueText = "0"
    
    For i = lB To uB
        SelectForm.FlagList.AddItem Flags(i)
    Next i
    SelectForm.Show 1
    Data = SelectForm.ValueText
    
    nIndex = SelectForm.Index
    If nIndex >= 0 Then
        lFlag = nIndex + 1
   
        Dim s As String
        s = SelectForm.ValueText
        If CurrentDocumentId <> "" Then
            lRetVal = Wrapper.SetDocInfo(CurrentDocumentId, lFlag, Data)
            LogCallResult "SetDocInfo", lRetVal, CurrentDocumentId + ", " + Flags(lFlag - 1) + ", " + Data, ""
        End If
    End If
    


End Sub

Private Sub SetDocRelation_Click()
Dim lRetVal As Long
Dim Flags As Long
Dim LinkedId As String
Dim Format As String
Dim PreviousId As String
    
    Flags = 0
    LinkedId = "18-46-08-56"
    Format = ""
    PreviousId = ""
    
    If CurrentDocumentId <> "" Then
        lRetVal = Wrapper.SetDocRelation(CurrentDocumentId, Flags, LinkedId, Format, PreviousId)
        LogCallResult "SetDocRelation", lRetVal, CurrentDocumentId + ", 0, , ", Str(Flags) + ", " + Format
    End If


End Sub
