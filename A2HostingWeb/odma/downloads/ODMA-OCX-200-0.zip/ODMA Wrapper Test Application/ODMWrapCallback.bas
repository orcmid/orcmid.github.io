Attribute VB_Name = "ODMWrapCallback"
Option Explicit

Public Function Callback(ByVal dwEnvData As Long, ByVal strFormat As String, ByVal pInstanceData As Long) As String
    MsgBox "Callback procedure parameter - " + strFormat, , "ODMA Callback function call"
    Callback = "Format for" + strFormat
End Function
