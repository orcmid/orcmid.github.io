OUTPUTDIR=ODMASetup

all :	mkdir \
	ODMA32.dll \
	ODMASamp32.dll \
	ODMATest32.exe \
	ODMA32Wrapper.ocx \

ODMASamp32.dll : ODMA32.dll
ODMATest32.exe : ODMA32.dll
ODMA32Wrapper.ocx : ODMA32.dll

mkdir : 
	if not exist "$(OUTPUTDIR)" mkdir "$(OUTPUTDIR)"

ODMA32.dll:
	@cd "Connection Manager"
	nmake  /f "$*.mak" CFG="odma32 - Win32 Release"
	@cd ..

ODMASamp32.dll:
	@cd "ODMA 2.0 Sample DMS"
	nmake  /f "$*.mak" CFG="ODMASamp - Win32 Release"
	@cd ..

ODMATest32.exe:
	@cd "ODMA Test Application"
	nmake  /f "$*.mak" CFG="ODMATest32 - Win32 Release"
	@cd ..

ODMA32Wrapper.ocx:
	@cd "ODMA32Wrapper"
	nmake  /f "$*.mak" CFG="ODMA32Wrapper - Win32 Release MinDependency"
	@cd ..

