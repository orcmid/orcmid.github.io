// ODMAWrapper.cpp : Implementation of CODMAWrapper
#include "stdafx.h"
#include "ODMA32Wrapper.h"
#include "ODMAWrapper.h"
#include <string.h>

typedef BSTR (__stdcall* LPODM_WRAP_SAVEASCALLBACK)(long dwEnvData, BSTR lpszFormat, long pInstanceData);  
LPODM_WRAP_SAVEASCALLBACK g_pcbCallBack = NULL; //address VB callback function
	
LPSTR ODMAWrapCollback(DWORD dwEnvData, LPSTR lpszFormat, LPVOID pInstanceData)
{
	AFX_MANAGE_STATE(AfxGetStaticModuleState())
	USES_CONVERSION;		
	
	BSTR bstrValue;
	CString strFormat(lpszFormat);
	BSTR bstrFormat = strFormat.AllocSysString();
	
	if (g_pcbCallBack)
	{
		bstrValue = (g_pcbCallBack)(dwEnvData, bstrFormat, (long)pInstanceData);
		g_pcbCallBack = NULL;
	}
	
	return OLE2T(bstrValue);
}

/////////////////////////////////////////////////////////////////////////////
// CODMAWrapper
#define BUFFER_MAX_LEN		255
#define ODM_NAME_MAX		64

STDMETHODIMP CODMAWrapper::RegisterApp( long nVersion, BSTR lpszAppId, long lEnvData, VARIANT Reserved, long* lRetVal)
{
	AFX_MANAGE_STATE(AfxGetStaticModuleState())
	USES_CONVERSION;
	*lRetVal = ODMRegisterApp( &m_ODMHandle, nVersion, OLE2T(lpszAppId), lEnvData, (LPVOID) &Reserved );
	return S_OK;
}

STDMETHODIMP CODMAWrapper::GetDMSCount(long * lRetVal)
{
	AFX_MANAGE_STATE(AfxGetStaticModuleState())
	*lRetVal = ODMGetDMSCount();
	return S_OK;
}

STDMETHODIMP CODMAWrapper::GetDMSList(VARIANT* Buffer, long * lRetVal)
{
	AFX_MANAGE_STATE(AfxGetStaticModuleState())

	CString strDmsList;
	long lDMSCount;
	GetDMSCount(&lDMSCount);
	int nLen = lDMSCount*ODM_DMSID_MAX + 1;
	LPSTR lpszDmsList = strDmsList.GetBuffer( nLen );
	*lRetVal = ODMGetDMSList((LPSTR)*&lpszDmsList, nLen );
	strDmsList.ReleaseBuffer();

	// create safe array
	SAFEARRAY* psa = SafeArrayCreateVector(VT_BSTR, 0, lDMSCount);

	char* szDms = lpszDmsList;
	CString strList;
	BSTR bstr;
	long i = 0;
	while(*szDms) 
	{
		strList = szDms;
		bstr = strList.AllocSysString();
		SafeArrayPutElement(psa, &i, (BSTR) bstr);
		i++;
		szDms = strchr(szDms, 0) + 1;
	}

	// put safe array into returning variant
	VariantInit(Buffer);	
	V_VT(Buffer) = VT_ARRAY | VT_BSTR;
	V_ARRAY(Buffer) = psa;

	return S_OK;
}

STDMETHODIMP CODMAWrapper::UnRegisterApp()
{
	AFX_MANAGE_STATE(AfxGetStaticModuleState())
	ODMUnRegisterApp( m_ODMHandle );
	return S_OK;
}

STDMETHODIMP CODMAWrapper::GetDMS(BSTR lpszAppId, BSTR * lpszDMSId, long * lRetVal)
{
	AFX_MANAGE_STATE(AfxGetStaticModuleState())
	USES_CONVERSION;

	CString strDmsId;
	LPSTR lpszDmsId = strDmsId.GetBuffer( ODM_DMSID_MAX );
	*lRetVal = ODMGetDMS( OLE2T(lpszAppId), (LPSTR)*&lpszDmsId );
	strDmsId.ReleaseBuffer();
	*lpszDMSId = strDmsId.AllocSysString();
	return S_OK;
}

STDMETHODIMP CODMAWrapper::GetDMSInfo(BSTR * lpszDMSid, long * lVerNo, long * lExtensions, long * lRetVal)
{
	AFX_MANAGE_STATE(AfxGetStaticModuleState())
	USES_CONVERSION;

	CString strDmsId;
	LPSTR lpszDmsId = strDmsId.GetBuffer( ODM_DMSID_MAX );
	*lRetVal = ODMGetDMSInfo( m_ODMHandle, (LPSTR)*&lpszDmsId, (WORD*)lVerNo, (DWORD*)lExtensions );
	strDmsId.ReleaseBuffer();
	*lpszDMSid = strDmsId.AllocSysString();
	return S_OK;
}

STDMETHODIMP CODMAWrapper::SetDMS(BSTR lpszAppId, BSTR lpszDMSId,  long* lRetVal)
{
	AFX_MANAGE_STATE(AfxGetStaticModuleState())
	USES_CONVERSION;
	*lRetVal = ODMSetDMS( OLE2T(lpszAppId), OLE2T(lpszDMSId) );
	return S_OK;
}

STDMETHODIMP CODMAWrapper::NewDoc(BSTR * lpszDocID, long lFlags, BSTR lpszFormat, BSTR lpszDocLocation, long * lRetVal)
{
	AFX_MANAGE_STATE(AfxGetStaticModuleState())
	USES_CONVERSION;
	CString strDocId;
	LPSTR lpszId = strDocId.GetBuffer( ODM_DOCID_MAX );
	*lRetVal = ODMNewDoc( m_ODMHandle, (LPSTR)*&lpszId, lFlags,  OLE2T(lpszFormat),  OLE2T(lpszDocLocation) );
	strDocId.ReleaseBuffer();
	*lpszDocID = strDocId.AllocSysString();

	return S_OK;
}

STDMETHODIMP CODMAWrapper::CloseDoc(BSTR lpszDocId, long lActiveTime, long lPagesPrinted, VARIANT SessionData, long * lRetVal)
{
	AFX_MANAGE_STATE(AfxGetStaticModuleState())
	USES_CONVERSION;
	*lRetVal = ODMCloseDoc( m_ODMHandle, OLE2T(lpszDocId), lActiveTime, lPagesPrinted,  (LPVOID)&SessionData, sizeof(SessionData) );
	return S_OK;
}

STDMETHODIMP CODMAWrapper::CloseDocEx(BSTR lpszDocId, long* lFlags, long lActiveTime, long lPagesPrinted, VARIANT SessionData, long * lRetVal)
{
	AFX_MANAGE_STATE(AfxGetStaticModuleState())
	USES_CONVERSION;
	*lRetVal = ODMCloseDocEx( m_ODMHandle, OLE2T(lpszDocId), (DWORD*)lFlags, lActiveTime, lPagesPrinted,  (LPVOID)&SessionData, sizeof(SessionData) );
	return S_OK;
}

STDMETHODIMP CODMAWrapper::OpenDoc( long lFlags,  BSTR lpszDocId,  BSTR* lpszDocLocation,   long* lRetVal)
{
	AFX_MANAGE_STATE(AfxGetStaticModuleState())
	USES_CONVERSION;

	CString strDocLocation;
	LPSTR lpszLocation = strDocLocation.GetBuffer( ODM_FILENAME_MAX );
	*lRetVal = ODMOpenDoc( m_ODMHandle, lFlags, OLE2T(lpszDocId),  (LPSTR)*& lpszLocation);
	strDocLocation.ReleaseBuffer();
	*lpszDocLocation = strDocLocation.AllocSysString();

	return S_OK;
}

STDMETHODIMP CODMAWrapper::SaveDoc(BSTR lpszDocId, BSTR * lpszNewDocId, long * lRetVal)
{
	AFX_MANAGE_STATE(AfxGetStaticModuleState())
	USES_CONVERSION;

	CString strDocId;
	LPSTR lpszId = strDocId.GetBuffer( ODM_DOCID_MAX );
	*lRetVal = ODMSaveDoc( m_ODMHandle, OLE2T(lpszDocId), (LPSTR)*&lpszId );
	strDocId.ReleaseBuffer();
	*lpszNewDocId = strDocId.AllocSysString();

	return S_OK;
}

STDMETHODIMP CODMAWrapper::SaveDocEx(BSTR lpszDocId, BSTR * lpszNewDocId, long* lFlags, long * lRetVal)
{
	AFX_MANAGE_STATE(AfxGetStaticModuleState())
	USES_CONVERSION;

	CString strDocId;
	LPSTR lpszId = strDocId.GetBuffer( ODM_DOCID_MAX );
	*lRetVal = ODMSaveDocEx( m_ODMHandle, OLE2T(lpszDocId), (LPSTR)*&lpszId, (DWORD*)lFlags );
	strDocId.ReleaseBuffer();
	*lpszNewDocId = strDocId.AllocSysString();

	return S_OK;
}

STDMETHODIMP CODMAWrapper::SaveAs( BSTR lpszDocId,  BSTR* lpszNewDocId,  BSTR lpszFormat, LONG pcbCallBack, VARIANT InstanceData,  long* lRetVal)
{
	AFX_MANAGE_STATE(AfxGetStaticModuleState())
	USES_CONVERSION;		
	
	g_pcbCallBack = (LPODM_WRAP_SAVEASCALLBACK)pcbCallBack;
	
	CString strDocId;
	LPSTR lpszBuffer = strDocId.GetBuffer( ODM_DOCID_MAX );
	*lRetVal = ODMSaveAs( m_ODMHandle, OLE2T(lpszDocId), (LPSTR)*&lpszBuffer, 
					OLE2T(lpszFormat), (ODMSAVEASCALLBACK)ODMAWrapCollback, (LPVOID)&InstanceData);
	strDocId.ReleaseBuffer();
	*lpszNewDocId = strDocId.AllocSysString();
	return S_OK;
}

STDMETHODIMP CODMAWrapper::SaveAsEx( BSTR lpszDocId,  BSTR* lpszNewDocId,  BSTR lpszFormat, LONG pcbCallBack, VARIANT InstanceData,  long* lFlags, long* lRetVal)
{
	AFX_MANAGE_STATE(AfxGetStaticModuleState())
	USES_CONVERSION;		

	g_pcbCallBack = (LPODM_WRAP_SAVEASCALLBACK)pcbCallBack;

	CString strDocId;
	LPSTR lpszId = strDocId.GetBuffer( ODM_DOCID_MAX );
	*lRetVal = ODMSaveAsEx( m_ODMHandle, OLE2T(lpszDocId), (LPSTR)*&lpszId, 
					OLE2T(lpszFormat), (ODMSAVEASCALLBACK)ODMAWrapCollback, (LPVOID)&InstanceData, (DWORD*)lFlags );
	strDocId.ReleaseBuffer();
	*lpszNewDocId = strDocId.AllocSysString();
	return S_OK;
}

STDMETHODIMP CODMAWrapper::SelectDoc(BSTR* lpszDocId,  long* lFlags, long* lRetVal)
{
	AFX_MANAGE_STATE(AfxGetStaticModuleState())
	USES_CONVERSION;		

	CString strDocId;
	LPSTR lpszId = strDocId.GetBuffer( ODM_DOCID_MAX );
	*lRetVal = ODMSelectDoc( m_ODMHandle, (LPSTR)*&lpszId, (DWORD*)lFlags );
	strDocId.ReleaseBuffer();
	*lpszDocId = strDocId.AllocSysString();
	return S_OK;
}

STDMETHODIMP CODMAWrapper::SelectDocEx( VARIANT* DocIds, long* lDocCount, long* lFlags, BSTR lpszFormatFilter,  long* lRetVal)
{
	AFX_MANAGE_STATE(AfxGetStaticModuleState())
	USES_CONVERSION;		

	CString strDocIds;
	LPSTR lpszIds;
	long lCount = *lDocCount;
	if ( lCount > 0 )
		lCount = lCount * ODM_DOCID_MAX ;
	else
		lCount = ODM_DOCID_MAX ;

	lpszIds = strDocIds.GetBuffer( lCount );
	*lRetVal = ODMSelectDocEx( m_ODMHandle, (LPSTR)*&lpszIds, (WORD*)&lCount, (WORD*)lDocCount, (DWORD*)&lFlags, OLE2T(lpszFormatFilter) );
	strDocIds.ReleaseBuffer();

	// create safe array
	SAFEARRAY* psa = SafeArrayCreateVector(VT_BSTR, 0, *lDocCount);

	char* szIds = lpszIds;
	CString strList;
	BSTR bstrList;
	long i = 0;
	while(*szIds) 
	{
		strList = szIds;
		bstrList = strList.AllocSysString();
		SafeArrayPutElement(psa, &i, (BSTR) bstrList);
		i++;
		szIds = strchr(szIds, 0) + 1;
	}

	// put safe array into returning variant
	VariantInit(DocIds);	
	V_VT(DocIds) = VT_ARRAY | VT_BSTR;
	V_ARRAY(DocIds) = psa;

	return S_OK;
}

STDMETHODIMP CODMAWrapper::Activate(long lAction, BSTR lpszDocId, long * lRetVal)
{
	AFX_MANAGE_STATE(AfxGetStaticModuleState())
	USES_CONVERSION;		

	*lRetVal = ODMActivate( m_ODMHandle, (WORD) lAction, OLE2T(lpszDocId));

	return S_OK;
}

STDMETHODIMP CODMAWrapper::GetAlternateContent(BSTR lpszDocId, long * lFlags, BSTR lpszFormat, BSTR* lpszDocLocation, long * lRetVal)
{
	AFX_MANAGE_STATE(AfxGetStaticModuleState())
	USES_CONVERSION;		

	CString strDocLoc;
	LPSTR lpszLocation = strDocLoc.GetBuffer( ODM_FILENAME_MAX );

	*lRetVal = ODMGetAlternateContent( m_ODMHandle, OLE2T(lpszDocId), (DWORD*)lFlags, OLE2T(lpszFormat),  (LPSTR)*&lpszLocation);
	strDocLoc.ReleaseBuffer();
	*lpszDocLocation = strDocLoc.AllocSysString();

	return S_OK;
}

STDMETHODIMP CODMAWrapper::SetAlternateContent(BSTR lpszDocId, long * lFlags, BSTR lpszFormat, BSTR lpszDocLocation, long * lRetVal)
{
	AFX_MANAGE_STATE(AfxGetStaticModuleState())
	USES_CONVERSION;		

	*lRetVal = ODMSetAlternateContent( m_ODMHandle, OLE2T(lpszDocId), (DWORD*)lFlags, OLE2T(lpszFormat),  OLE2T(lpszDocLocation));

	return S_OK;
}

STDMETHODIMP CODMAWrapper::SetDocEvent( BSTR lpszDocId,  long lFlags,  long lEvent, VARIANT Data,  BSTR lpszComment,  long* lRetVal)
{
	AFX_MANAGE_STATE(AfxGetStaticModuleState())
	USES_CONVERSION;		

	*lRetVal = ODMSetDocEvent( m_ODMHandle, OLE2T(lpszDocId), lFlags, lEvent, (LPVOID) &Data, sizeof(Data), OLE2T(lpszComment));

	return S_OK;
}

STDMETHODIMP CODMAWrapper::GetDocRelation( BSTR lpszDocId,  long* lFlags,  BSTR* lpszLinkedId,  BSTR* lpszFormat,  BSTR lpszPreviousId,  long* lRetVal)
{
	AFX_MANAGE_STATE(AfxGetStaticModuleState())
	USES_CONVERSION;		

	CString strLinked = " ";
	LPSTR lpszLinked = strLinked.GetBuffer( ODM_DOCID_MAX );
	CString strFormat;
	LPSTR lpszRetFormat = strFormat.GetBuffer( ODM_FORMAT_MAX );

	*lRetVal = ODMGetDocRelation( m_ODMHandle, OLE2T(lpszDocId), (DWORD*) lFlags,  (LPSTR)*&lpszLinked,   (LPSTR)*&lpszRetFormat, OLE2T(lpszPreviousId));

	strLinked.ReleaseBuffer();
	*lpszLinkedId = strLinked.AllocSysString();
	strFormat.ReleaseBuffer();
	*lpszFormat = strFormat.AllocSysString();

	return S_OK;
}

STDMETHODIMP CODMAWrapper::SetDocRelation( BSTR lpszDocId,  long* lFlags,  BSTR lpszLinkedId,  BSTR* lpszFormat,  BSTR lpszPreviousId,  long* lRetVal)
{
	AFX_MANAGE_STATE(AfxGetStaticModuleState())
	USES_CONVERSION;		

	CString strFormat;
	LPSTR lpszRetFormat = strFormat.GetBuffer( ODM_FORMAT_MAX );

	*lRetVal = ODMSetDocRelation( m_ODMHandle, OLE2T(lpszDocId), (DWORD*) lFlags,  OLE2T(lpszLinkedId),   (LPSTR)*&lpszRetFormat, OLE2T(lpszPreviousId));

	strFormat.ReleaseBuffer();
	*lpszFormat = strFormat.AllocSysString();

	return S_OK;
}

STDMETHODIMP CODMAWrapper::QueryCapability( BSTR lpszDMSId,  long lFunction,  long lItem,  long lFlags,  long* lRetVal)
{
	AFX_MANAGE_STATE(AfxGetStaticModuleState())
	USES_CONVERSION;		

	*lRetVal = ODMQueryCapability( m_ODMHandle, OLE2T(lpszDMSId), (DWORD) lFunction, (DWORD) lItem, (DWORD) lFlags);
	return S_OK;
}


STDMETHODIMP CODMAWrapper::QueryClose(BSTR lpszQueryId, long * lRetVal)
{
	AFX_MANAGE_STATE(AfxGetStaticModuleState())
	USES_CONVERSION;		

	*lRetVal = ODMQueryClose( m_ODMHandle, OLE2T(lpszQueryId));

	return S_OK;
}

STDMETHODIMP CODMAWrapper::QueryExecute(BSTR lpszQuery, long lFlags, VARIANT DMSList, BSTR* lpszQueryId, long* lRetVal)
{
	AFX_MANAGE_STATE(AfxGetStaticModuleState())
	USES_CONVERSION;		

	CString strQueryId;
	LPSTR lpszId = strQueryId.GetBufferSetLength( ODM_QUERYID_MAX );

	CString strDMSList;
	LPTSTR lpszDMS = strDMSList.GetBufferSetLength(ODM_DMSID_MAX);

	UINT nDim = SafeArrayGetDim(DMSList.parray);

	long lUBound;
	HRESULT hr;
	hr = SafeArrayGetUBound( DMSList.parray, 1, &lUBound);

	long ix[1];
	for (int i = 0; i <= lUBound; i++)
	{
		VARIANT var;
		ix[0] = i;
		VERIFY(SUCCEEDED(::SafeArrayGetElement(DMSList.parray, ix, &var)));
		if ( i > 0 )
		{
			lpszDMS = strcat(lpszDMS, "#" );
			int nIndex = strlen(lpszDMS); 
			lpszDMS = strcat(lpszDMS, OLE2T(var.bstrVal) );
			lpszDMS[strlen(lpszDMS)+1] = '\0';	
			lpszDMS[nIndex-1] = '\0';	
		}
		else
			lpszDMS = OLE2T(var.bstrVal);

		VERIFY(SUCCEEDED(::VariantClear(&var)));
	}
	*lRetVal = ODMQueryExecute( m_ODMHandle, OLE2T(lpszQuery), (DWORD) lFlags, lpszDMS, (LPSTR)*&lpszId);

	strDMSList.ReleaseBuffer();
	strQueryId.ReleaseBuffer();

	*lpszQueryId = strQueryId.AllocSysString();
	return S_OK;
}

STDMETHODIMP CODMAWrapper::QueryGetResults(BSTR lpszQueryId, /*[out]*/ VARIANT* DocIds, /*[out]*/ VARIANT* DocNames, long* lDocCount, long* lRetVal )
{
	AFX_MANAGE_STATE(AfxGetStaticModuleState())
	USES_CONVERSION;		

	CString strDocId, strDocName;
	long lLen = *lDocCount; 
	LPTSTR lpszDocId = strDocId.GetBufferSetLength(ODM_DOCID_MAX*lLen);
	LPTSTR lpszName = strDocName.GetBufferSetLength(ODM_NAME_MAX*lLen);
	
	*lRetVal = ODMQueryGetResults( m_ODMHandle, OLE2T(lpszQueryId), lpszDocId, lpszName, ODM_NAME_MAX, (WORD*)&lLen);

	// create safe array
	SAFEARRAY* psa = SafeArrayCreateVector(VT_BSTR, 0, *lDocCount);
	CString strList;
	BSTR bstrList;
	for ( long i = 0; i < lLen; i++ )
	{
		strList = &lpszDocId[ODM_DOCID_MAX*i];
		bstrList = strList.AllocSysString();
		SafeArrayPutElement(psa, &i, (BSTR) bstrList);
	}
	// put safe array into returning variant
	VariantInit(DocIds);	
	V_VT(DocIds) = VT_ARRAY | VT_BSTR;
	V_ARRAY(DocIds) = psa;

	// create safe array
	SAFEARRAY* psaName = SafeArrayCreateVector(VT_BSTR, 0, *lDocCount);
	CString strNameList;
	BSTR bstrNameList;
	for ( i = 0; i < lLen; i++ )
	{
		strNameList = &lpszName[ODM_NAME_MAX*i];
		bstrNameList = strNameList.AllocSysString();
		SafeArrayPutElement(psaName, &i, (BSTR) bstrNameList);
	}
	// put safe array into returning variant
	VariantInit(DocNames);	
	V_VT(DocNames) = VT_ARRAY | VT_BSTR;
	V_ARRAY(DocNames) = psaName;

	*lDocCount = lLen;
	strDocId.ReleaseBuffer();
	strDocName.ReleaseBuffer();
	
	return S_OK;
}

STDMETHODIMP CODMAWrapper::GetDocInfo(BSTR lpszDocId, long lItem, BSTR * lpszData, long * lRetVal)
{
	AFX_MANAGE_STATE(AfxGetStaticModuleState())
	USES_CONVERSION;		

	CString strData;
	LPSTR lpszBuffer = strData.GetBuffer( BUFFER_MAX_LEN );

	*lRetVal = ODMGetDocInfo( m_ODMHandle, OLE2T(lpszDocId),   (WORD) lItem, (LPSTR)*&lpszBuffer, BUFFER_MAX_LEN);

	strData.ReleaseBuffer();
	*lpszData = strData.AllocSysString();

	return S_OK;
}

STDMETHODIMP CODMAWrapper::SetDocInfo(BSTR lpszDocId, long lItem, BSTR  lpszData, long * lRetVal)
{
	AFX_MANAGE_STATE(AfxGetStaticModuleState())
	USES_CONVERSION;		

	*lRetVal = ODMSetDocInfo( m_ODMHandle, OLE2T(lpszDocId),   (WORD) lItem, OLE2T(lpszData) );

	return S_OK;
}

