// ODMAWrapper.h : Declaration of the CODMAWrapper

#ifndef __ODMAWRAPPER_H_
#define __ODMAWRAPPER_H_

#include "resource.h"       // main symbols
#include "odma.h"


/////////////////////////////////////////////////////////////////////////////
// CODMAWrapper
class ATL_NO_VTABLE CODMAWrapper : 
	public CComObjectRootEx<CComSingleThreadModel>,
	public CComCoClass<CODMAWrapper, &CLSID_ODMAWrapper>,
	public IDispatchImpl<IODMAWrapper, &IID_IODMAWrapper, &LIBID_ODMA32WRAPPERLib>
{
public:
	CODMAWrapper()
	{
	}

	ODMHANDLE m_ODMHandle;

DECLARE_REGISTRY_RESOURCEID(IDR_ODMAWRAPPER)

BEGIN_COM_MAP(CODMAWrapper)
	COM_INTERFACE_ENTRY(IODMAWrapper)
	COM_INTERFACE_ENTRY(IDispatch)
END_COM_MAP()

// IODMAWrapper
public:
	STDMETHOD(SetDocInfo)(/*[in]*/ BSTR lpszDocId, /*[in]*/ long lItem, /*[in]*/ BSTR lpszData, /*[out,retval]*/ long* lRetVal);
	STDMETHOD(GetDocInfo)(/*[in]*/ BSTR lpszDocId, /*[in]*/ long lItem, /*[out]*/ BSTR* lpszData, /*[out,retval]*/ long* lRetVal);
	STDMETHOD(QueryGetResults)(/*[in]*/BSTR lpszQueryId, /*[out]*/ VARIANT* DocIds, /*[out]*/ VARIANT* DocNames,   /*[out]*/ long* lDocCount, /*[out, retval]*/ long* lRetVal );
	STDMETHOD(QueryExecute)(/*[in]*/ BSTR lpszQuery, /*[in]*/ long lFlags, /*[in]*/ VARIANT DMSList, /*[out]*/ BSTR* lpszQueryId, /*[out, retval]*/ long* lRetVal);
	STDMETHOD(QueryClose)(/*[in]*/ BSTR lpszQueryId, /*[out, retval]*/ long* lRetVal);
	STDMETHOD(QueryCapability)(/*[in]*/ BSTR lpszDMSId, /*[in]*/ long lFunction, /*[in]*/ long lItem, /*[in]*/ long lFlags, /*[out,retval]*/ long* lRetVal);
	STDMETHOD(SetDocRelation)(/*[in]*/ BSTR lpszDocId, /*[out]*/ long* lFlags, /*[in]*/ BSTR lpszLinkedId, /*[out]*/ BSTR* lpszFormat, /*[in]*/ BSTR lpszPreviousId, /*[out,retval]*/ long* lRetVal);
	STDMETHOD(GetDocRelation)(/*[in]*/ BSTR lpszDocId, /*[out]*/ long* lFlags, /*[out]*/ BSTR* lpszLinkedId, /*[out]*/ BSTR* lpszFormat, /*[in]*/ BSTR lpszPreviousId, /*[out,retval]*/ long* lRetVal);
	STDMETHOD(SetDocEvent)(/*[in]*/ BSTR lpszDocId, /*[in]*/ long lFlags, /*[in]*/ long lEvent, /*[in]*/ VARIANT Data, /*[in]*/ BSTR lpszComment, /*[out,retval]*/ long* lRetVal);
	STDMETHOD(SetAlternateContent)(/*[in]*/ BSTR lpszDocId, /*[out]*/ long* lFlags, /*[in]*/ BSTR lpszFormat, /*[in]*/ BSTR lpszDocLocation, /*[out,retval]*/ long* lRetVal);
	STDMETHOD(GetAlternateContent)(/*[in]*/ BSTR lpszDocId, /*[out]*/ long* lFlags, /*[in]*/ BSTR lpszFormat, /*[out]*/ BSTR* lpszDocLocation, /*[out,retval]*/ long* lRetVal);
	STDMETHOD(Activate)(/*[in]*/ long lAction, /*[in]*/ BSTR lpszDocId, /*[out, retval]*/ long* lRetVal);
	STDMETHOD(SelectDocEx)(/*[out]*/ VARIANT* DocIds, /*[out]*/long* lDocCount, /*[out]*/long* lFlags, /*[in]*/ BSTR lpszFormatFilter, /*[out, retval]*/ long* lRetVal);
	STDMETHOD(SelectDoc)(/*[out]*/  BSTR* lpszDocId, /*[out]*/ long* lFlags, /*[out, retval]*/ long* lRetVal);
	STDMETHOD(SaveAsEx)(/*[in]*/ BSTR lpszDocId, /*[out]*/ BSTR* lpszNewDocId, /*[in]*/ BSTR lpszFormat, /*[in]*/ LONG pcbCallBack, /*[in]*/ VARIANT InstanceData, /*[out]*/ long* lFlags, /*[out, retval]*/ long* lRetVal);
	STDMETHOD(SaveAs)(/*[in]*/ BSTR lpszDocId, /*[out]*/ BSTR* lpszNewDocId, /*[in]*/ BSTR lpszFormat, /*[in]*/ LONG pcbCallBack, /*[in]*/ VARIANT InstanceData, /*[out, retval]*/ long* lRetVal);
	STDMETHOD(SaveDocEx)(/*[in]*/ BSTR lpszDocId, /*[out]*/ BSTR* lpszNewDocId, /*[out]*/ long* lFlags, /*[out, retval]*/ long* lRetVal);
	STDMETHOD(SaveDoc)(/*[in]*/ BSTR lpszDocId, /*[out]*/ BSTR* lpszNewDocId, /*[out, retval]*/ long* lRetVal);
	STDMETHOD(OpenDoc)(/*[in]*/ long lFlags, /*[in]*/ BSTR lpszDocId, /* [out]*/ BSTR* lpszDocLocation,  /*[out, retval]*/ long* lRetVal);
	STDMETHOD(CloseDocEx)(/*[in]*/BSTR lpszDocId, /*[out]*/ long* lFlags, /*[in]*/long lActiveTime, /*[in]*/long lPagesPrinted, /*[in]*/VARIANT SessionData, /*[out, retval]*/ long * lRetVal);
	STDMETHOD(CloseDoc)(/*[in]*/ BSTR lpszDocId, /*[in]*/ long lActiveTime, /*[in]*/ long lPagesPrinted, /*[in]*/ VARIANT SessionData, /*[out, retval]*/ long* lRetVal);
	STDMETHOD(NewDoc)(/*[out]*/ BSTR* lpszDocID, /*[in]*/ long lFlags, /*[in]*/ BSTR lpszFormat, /*[in]*/ BSTR lpszDocLocation, /*[out, retval]*/ long* lRetVal);
	STDMETHOD(SetDMS)(/*[in]*/ BSTR lpszAppId, /*[in]*/ BSTR lpszDMSId, /*[out, retval]*/ long* lRetVal);
	STDMETHOD(GetDMSInfo)(/*[out]*/ BSTR* lpszDMSid, /*[out]*/ long* lVerNo, /*[out]*/ long* lExtensions,  /*[out, retval]*/ long* lRetVal);
	STDMETHOD(GetDMS)(/*[in]*/ BSTR lpszAppid, /*[out]*/ BSTR* lpszDMSId, /*[out, retval]*/ long* lRetVal);
	STDMETHOD(UnRegisterApp)();
	STDMETHOD(GetDMSList)(/*[out]*/ VARIANT* Buffer, /*[out, retval]*/ long* lRetVal);
	STDMETHOD(GetDMSCount)(/*[out, retval]*/ long* lRetVal);
	STDMETHOD(RegisterApp)(/*[in]*/ long nVersion, /*[in]*/ BSTR lpszAppId, /*[in]*/ long lEnvData, /*[in]*/ VARIANT Reserved, /*[out, retval]*/ long* lRetVal);
};

#endif //__ODMAWRAPPER_H_
