# Microsoft Developer Studio Generated NMAKE File, Based on ODMA32Wrapper.dsp
!IF "$(CFG)" == ""
CFG=ODMA32Wrapper - Win32 Debug
!MESSAGE No configuration specified. Defaulting to ODMA32Wrapper - Win32 Debug.
!ENDIF 

!IF "$(CFG)" != "ODMA32Wrapper - Win32 Debug" && "$(CFG)" !=\
 "ODMA32Wrapper - Win32 Unicode Debug" && "$(CFG)" !=\
 "ODMA32Wrapper - Win32 Release MinSize" && "$(CFG)" !=\
 "ODMA32Wrapper - Win32 Release MinDependency" && "$(CFG)" !=\
 "ODMA32Wrapper - Win32 Unicode Release MinSize" && "$(CFG)" !=\
 "ODMA32Wrapper - Win32 Unicode Release MinDependency"
!MESSAGE Invalid configuration "$(CFG)" specified.
!MESSAGE You can specify a configuration when running NMAKE
!MESSAGE by defining the macro CFG on the command line. For example:
!MESSAGE 
!MESSAGE NMAKE /f "ODMA32Wrapper.mak" CFG="ODMA32Wrapper - Win32 Debug"
!MESSAGE 
!MESSAGE Possible choices for configuration are:
!MESSAGE 
!MESSAGE "ODMA32Wrapper - Win32 Debug" (based on\
 "Win32 (x86) Dynamic-Link Library")
!MESSAGE "ODMA32Wrapper - Win32 Unicode Debug" (based on\
 "Win32 (x86) Dynamic-Link Library")
!MESSAGE "ODMA32Wrapper - Win32 Release MinSize" (based on\
 "Win32 (x86) Dynamic-Link Library")
!MESSAGE "ODMA32Wrapper - Win32 Release MinDependency" (based on\
 "Win32 (x86) Dynamic-Link Library")
!MESSAGE "ODMA32Wrapper - Win32 Unicode Release MinSize" (based on\
 "Win32 (x86) Dynamic-Link Library")
!MESSAGE "ODMA32Wrapper - Win32 Unicode Release MinDependency" (based on\
 "Win32 (x86) Dynamic-Link Library")
!MESSAGE 
!ERROR An invalid configuration is specified.
!ENDIF 

!IF "$(OS)" == "Windows_NT"
NULL=
!ELSE 
NULL=nul
!ENDIF 

!IF  "$(CFG)" == "ODMA32Wrapper - Win32 Debug"

OUTDIR=.\..\Debug
INTDIR=.\Debug
# Begin Custom Macros
OutDir=.\..\Debug
# End Custom Macros

!IF "$(RECURSE)" == "0" 

ALL : "..\ODMASetup\ODMA32Wrapper.ocx" "$(OutDir)\regsvr32.trg"

!ELSE 

ALL : "..\ODMASetup\ODMA32Wrapper.ocx" "$(OutDir)\regsvr32.trg"

!ENDIF 

CLEAN :
	-@erase "$(INTDIR)\ODMA32Wrapper.obj"
	-@erase "$(INTDIR)\ODMA32Wrapper.pch"
	-@erase "$(INTDIR)\ODMAWrapper.obj"
	-@erase "$(INTDIR)\StdAfx.obj"
	-@erase "$(INTDIR)\vc50.idb"
	-@erase "$(INTDIR)\vc50.pdb"
	-@erase "$(OUTDIR)\ODMA32Wrapper.exp"
	-@erase "$(OUTDIR)\ODMA32Wrapper.lib"
	-@erase "$(OUTDIR)\ODMA32Wrapper.pdb"
	-@erase "..\ODMASetup\ODMA32Wrapper.ilk"
	-@erase "..\ODMASetup\ODMA32Wrapper.ocx"
	-@erase ".\res\ODMA32Wrapper.res"
	-@erase "$(OutDir)\regsvr32.trg"

"$(OUTDIR)" :
    if not exist "$(OUTDIR)/$(NULL)" mkdir "$(OUTDIR)"

"$(INTDIR)" :
    if not exist "$(INTDIR)/$(NULL)" mkdir "$(INTDIR)"

CPP=cl.exe
CPP_PROJ=/nologo /MDd /W3 /Gm /GX /Zi /Od /I "..\Connection Manager" /D "WIN32"\
 /D "_DEBUG" /D "_WINDOWS" /D "_WINDLL" /D "_AFXDLL" /D "_USRDLL"\
 /Fp"$(INTDIR)\ODMA32Wrapper.pch" /Yu"stdafx.h" /Fo"$(INTDIR)\\"\
 /Fd"$(INTDIR)\\" /FD /c 
CPP_OBJS=.\Debug/
CPP_SBRS=.

.c{$(CPP_OBJS)}.obj::
   $(CPP) @<<
   $(CPP_PROJ) $< 
<<

.cpp{$(CPP_OBJS)}.obj::
   $(CPP) @<<
   $(CPP_PROJ) $< 
<<

.cxx{$(CPP_OBJS)}.obj::
   $(CPP) @<<
   $(CPP_PROJ) $< 
<<

.c{$(CPP_SBRS)}.sbr::
   $(CPP) @<<
   $(CPP_PROJ) $< 
<<

.cpp{$(CPP_SBRS)}.sbr::
   $(CPP) @<<
   $(CPP_PROJ) $< 
<<

.cxx{$(CPP_SBRS)}.sbr::
   $(CPP) @<<
   $(CPP_PROJ) $< 
<<

MTL=midl.exe
MTL_PROJ=/nologo /D "_DEBUG" /mktyplib203 /o NUL /win32 
RSC=rc.exe
RSC_PROJ=/l 0x419 /fo".\res/ODMA32Wrapper.res" /d "_DEBUG" /d "_AFXDLL" 
BSC32=bscmake.exe
BSC32_FLAGS=/nologo /o"$(OUTDIR)\ODMA32Wrapper.bsc" 
BSC32_SBRS= \
	
LINK32=link.exe
LINK32_FLAGS=..\Debug\odma32.lib /nologo /subsystem:windows /dll\
 /incremental:yes /pdb:"$(OUTDIR)\ODMA32Wrapper.pdb" /debug /machine:I386\
 /def:".\ODMA32Wrapper.def" /out:"..\ODMASetup/ODMA32Wrapper.ocx"\
 /implib:"$(OUTDIR)\ODMA32Wrapper.lib" /pdbtype:sept 
DEF_FILE= \
	".\ODMA32Wrapper.def"
LINK32_OBJS= \
	"$(INTDIR)\ODMA32Wrapper.obj" \
	"$(INTDIR)\ODMAWrapper.obj" \
	"$(INTDIR)\StdAfx.obj" \
	".\res\ODMA32Wrapper.res"

"..\ODMASetup\ODMA32Wrapper.ocx" : "$(OUTDIR)" $(DEF_FILE) $(LINK32_OBJS)
    $(LINK32) @<<
  $(LINK32_FLAGS) $(LINK32_OBJS)
<<

OutDir=.\..\Debug
TargetPath=\Projects\ODMAWrapper\ODMASetup\ODMA32Wrapper.ocx
InputPath=\Projects\ODMAWrapper\ODMASetup\ODMA32Wrapper.ocx
SOURCE=$(InputPath)

"$(OutDir)\regsvr32.trg"	 : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	regsvr32 /s /c "$(TargetPath)" 
	echo regsvr32 exec. time > "$(OutDir)\regsvr32.trg" 
	

!ELSEIF  "$(CFG)" == "ODMA32Wrapper - Win32 Unicode Debug"

OUTDIR=.\DebugU
INTDIR=.\DebugU
# Begin Custom Macros
OutDir=.\DebugU
# End Custom Macros

!IF "$(RECURSE)" == "0" 

ALL : "$(OUTDIR)\ODMA32Wrapper.dll" "$(OutDir)\regsvr32.trg"

!ELSE 

ALL : "$(OUTDIR)\ODMA32Wrapper.dll" "$(OutDir)\regsvr32.trg"

!ENDIF 

CLEAN :
	-@erase "$(INTDIR)\ODMA32Wrapper.obj"
	-@erase "$(INTDIR)\ODMA32Wrapper.pch"
	-@erase "$(INTDIR)\ODMA32Wrapper.res"
	-@erase "$(INTDIR)\ODMAWrapper.obj"
	-@erase "$(INTDIR)\StdAfx.obj"
	-@erase "$(INTDIR)\vc50.idb"
	-@erase "$(INTDIR)\vc50.pdb"
	-@erase "$(OUTDIR)\ODMA32Wrapper.dll"
	-@erase "$(OUTDIR)\ODMA32Wrapper.exp"
	-@erase "$(OUTDIR)\ODMA32Wrapper.ilk"
	-@erase "$(OUTDIR)\ODMA32Wrapper.lib"
	-@erase "$(OUTDIR)\ODMA32Wrapper.pdb"
	-@erase "$(OutDir)\regsvr32.trg"

"$(OUTDIR)" :
    if not exist "$(OUTDIR)/$(NULL)" mkdir "$(OUTDIR)"

CPP=cl.exe
CPP_PROJ=/nologo /MDd /W3 /Gm /GX /Zi /Od /D "WIN32" /D "_DEBUG" /D "_WINDOWS"\
 /D "_WINDLL" /D "_AFXDLL" /D "_USRDLL" /D "_UNICODE"\
 /Fp"$(INTDIR)\ODMA32Wrapper.pch" /Yu"stdafx.h" /Fo"$(INTDIR)\\"\
 /Fd"$(INTDIR)\\" /FD /c 
CPP_OBJS=.\DebugU/
CPP_SBRS=.

.c{$(CPP_OBJS)}.obj::
   $(CPP) @<<
   $(CPP_PROJ) $< 
<<

.cpp{$(CPP_OBJS)}.obj::
   $(CPP) @<<
   $(CPP_PROJ) $< 
<<

.cxx{$(CPP_OBJS)}.obj::
   $(CPP) @<<
   $(CPP_PROJ) $< 
<<

.c{$(CPP_SBRS)}.sbr::
   $(CPP) @<<
   $(CPP_PROJ) $< 
<<

.cpp{$(CPP_SBRS)}.sbr::
   $(CPP) @<<
   $(CPP_PROJ) $< 
<<

.cxx{$(CPP_SBRS)}.sbr::
   $(CPP) @<<
   $(CPP_PROJ) $< 
<<

MTL=midl.exe
MTL_PROJ=/nologo /D "_DEBUG" /mktyplib203 /o NUL /win32 
RSC=rc.exe
RSC_PROJ=/l 0x419 /fo"$(INTDIR)\ODMA32Wrapper.res" /d "_DEBUG" /d "_AFXDLL" 
BSC32=bscmake.exe
BSC32_FLAGS=/nologo /o"$(OUTDIR)\ODMA32Wrapper.bsc" 
BSC32_SBRS= \
	
LINK32=link.exe
LINK32_FLAGS=/nologo /subsystem:windows /dll /incremental:yes\
 /pdb:"$(OUTDIR)\ODMA32Wrapper.pdb" /debug /machine:I386\
 /def:".\ODMA32Wrapper.def" /out:"$(OUTDIR)\ODMA32Wrapper.dll"\
 /implib:"$(OUTDIR)\ODMA32Wrapper.lib" /pdbtype:sept 
DEF_FILE= \
	".\ODMA32Wrapper.def"
LINK32_OBJS= \
	"$(INTDIR)\ODMA32Wrapper.obj" \
	"$(INTDIR)\ODMA32Wrapper.res" \
	"$(INTDIR)\ODMAWrapper.obj" \
	"$(INTDIR)\StdAfx.obj"

"$(OUTDIR)\ODMA32Wrapper.dll" : "$(OUTDIR)" $(DEF_FILE) $(LINK32_OBJS)
    $(LINK32) @<<
  $(LINK32_FLAGS) $(LINK32_OBJS)
<<

OutDir=.\DebugU
TargetPath=.\DebugU\ODMA32Wrapper.dll
InputPath=.\DebugU\ODMA32Wrapper.dll
SOURCE=$(InputPath)

"$(OutDir)\regsvr32.trg"	 : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	regsvr32 /s /c "$(TargetPath)" 
	echo regsvr32 exec. time > "$(OutDir)\regsvr32.trg" 
	

!ELSEIF  "$(CFG)" == "ODMA32Wrapper - Win32 Release MinSize"

OUTDIR=.\..\Release
INTDIR=.\Release
# Begin Custom Macros
OutDir=.\..\Release
# End Custom Macros

!IF "$(RECURSE)" == "0" 

ALL : "..\ODMASetup\ODMA32Wrapper.ocx" "$(OutDir)\regsvr32.trg"

!ELSE 

ALL : "..\ODMASetup\ODMA32Wrapper.ocx" "$(OutDir)\regsvr32.trg"

!ENDIF 

CLEAN :
	-@erase "$(INTDIR)\ODMA32Wrapper.obj"
	-@erase "$(INTDIR)\ODMA32Wrapper.pch"
	-@erase "$(INTDIR)\ODMAWrapper.obj"
	-@erase "$(INTDIR)\StdAfx.obj"
	-@erase "$(INTDIR)\vc50.idb"
	-@erase "$(OUTDIR)\ODMA32Wrapper.exp"
	-@erase "$(OUTDIR)\ODMA32Wrapper.lib"
	-@erase "..\ODMASetup\ODMA32Wrapper.ocx"
	-@erase ".\res\ODMA32Wrapper.res"
	-@erase "$(OutDir)\regsvr32.trg"

"$(OUTDIR)" :
    if not exist "$(OUTDIR)/$(NULL)" mkdir "$(OUTDIR)"

"$(INTDIR)" :
    if not exist "$(INTDIR)/$(NULL)" mkdir "$(INTDIR)"

CPP=cl.exe
CPP_PROJ=/nologo /MD /W3 /GX /O1 /I "..\Connection Manager" /D "WIN32" /D\
 "NDEBUG" /D "_WINDOWS" /D "_WINDLL" /D "_AFXDLL" /D "_USRDLL" /D "_ATL_DLL"\
 /Fp"$(INTDIR)\ODMA32Wrapper.pch" /Yu"stdafx.h" /Fo"$(INTDIR)\\"\
 /Fd"$(INTDIR)\\" /FD /c 
CPP_OBJS=.\Release/
CPP_SBRS=.

.c{$(CPP_OBJS)}.obj::
   $(CPP) @<<
   $(CPP_PROJ) $< 
<<

.cpp{$(CPP_OBJS)}.obj::
   $(CPP) @<<
   $(CPP_PROJ) $< 
<<

.cxx{$(CPP_OBJS)}.obj::
   $(CPP) @<<
   $(CPP_PROJ) $< 
<<

.c{$(CPP_SBRS)}.sbr::
   $(CPP) @<<
   $(CPP_PROJ) $< 
<<

.cpp{$(CPP_SBRS)}.sbr::
   $(CPP) @<<
   $(CPP_PROJ) $< 
<<

.cxx{$(CPP_SBRS)}.sbr::
   $(CPP) @<<
   $(CPP_PROJ) $< 
<<

MTL=midl.exe
MTL_PROJ=/nologo /D "NDEBUG" /mktyplib203 /o NUL /win32 
RSC=rc.exe
RSC_PROJ=/l 0x419 /fo".\res/ODMA32Wrapper.res" /d "NDEBUG" /d "_AFXDLL" 
BSC32=bscmake.exe
BSC32_FLAGS=/nologo /o"$(OUTDIR)\ODMA32Wrapper.bsc" 
BSC32_SBRS= \
	
LINK32=link.exe
LINK32_FLAGS=..\Release\odma32.lib /nologo /subsystem:windows /dll\
 /incremental:no /pdb:"$(OUTDIR)\ODMA32Wrapper.pdb" /machine:I386\
 /def:".\ODMA32Wrapper.def" /out:"..\ODMASetup/ODMA32Wrapper.ocx"\
 /implib:"$(OUTDIR)\ODMA32Wrapper.lib" 
DEF_FILE= \
	".\ODMA32Wrapper.def"
LINK32_OBJS= \
	"$(INTDIR)\ODMA32Wrapper.obj" \
	"$(INTDIR)\ODMAWrapper.obj" \
	"$(INTDIR)\StdAfx.obj" \
	".\res\ODMA32Wrapper.res"

"..\ODMASetup\ODMA32Wrapper.ocx" : "$(OUTDIR)" $(DEF_FILE) $(LINK32_OBJS)
    $(LINK32) @<<
  $(LINK32_FLAGS) $(LINK32_OBJS)
<<

OutDir=.\..\Release
TargetPath=\Projects\ODMAWrapper\ODMASetup\ODMA32Wrapper.ocx
InputPath=\Projects\ODMAWrapper\ODMASetup\ODMA32Wrapper.ocx
SOURCE=$(InputPath)

"$(OutDir)\regsvr32.trg"	 : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	regsvr32 /s /c "$(TargetPath)" 
	echo regsvr32 exec. time > "$(OutDir)\regsvr32.trg" 
	

!ELSEIF  "$(CFG)" == "ODMA32Wrapper - Win32 Release MinDependency"

OUTDIR=.\..\Release
INTDIR=.\Release
# Begin Custom Macros
OutDir=.\..\Release
# End Custom Macros

!IF "$(RECURSE)" == "0" 

ALL : "..\ODMASetup\ODMA32Wrapper.ocx" "$(OutDir)\regsvr32.trg"

!ELSE 

ALL : "..\ODMASetup\ODMA32Wrapper.ocx" "$(OutDir)\regsvr32.trg"

!ENDIF 

CLEAN :
	-@erase "$(INTDIR)\ODMA32Wrapper.obj"
	-@erase "$(INTDIR)\ODMA32Wrapper.pch"
	-@erase "$(INTDIR)\ODMA32Wrapper.res"
	-@erase "$(INTDIR)\ODMAWrapper.obj"
	-@erase "$(INTDIR)\StdAfx.obj"
	-@erase "$(INTDIR)\vc50.idb"
	-@erase "$(OUTDIR)\ODMA32Wrapper.exp"
	-@erase "$(OUTDIR)\ODMA32Wrapper.lib"
	-@erase "..\ODMASetup\ODMA32Wrapper.ocx"
	-@erase "$(OutDir)\regsvr32.trg"

"$(OUTDIR)" :
    if not exist "$(OUTDIR)/$(NULL)" mkdir "$(OUTDIR)"

"$(INTDIR)" :
    if not exist "$(INTDIR)/$(NULL)" mkdir "$(INTDIR)"

CPP=cl.exe
CPP_PROJ=/nologo /MD /W3 /GX /O1 /I "..\Connection Manager" /D "WIN32" /D\
 "NDEBUG" /D "_WINDOWS" /D "_WINDLL" /D "_AFXDLL" /D "_USRDLL" /D\
 "_ATL_STATIC_REGISTRY" /Fp"$(INTDIR)\ODMA32Wrapper.pch" /Yu"stdafx.h"\
 /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 
CPP_OBJS=.\Release/
CPP_SBRS=.

.c{$(CPP_OBJS)}.obj::
   $(CPP) @<<
   $(CPP_PROJ) $< 
<<

.cpp{$(CPP_OBJS)}.obj::
   $(CPP) @<<
   $(CPP_PROJ) $< 
<<

.cxx{$(CPP_OBJS)}.obj::
   $(CPP) @<<
   $(CPP_PROJ) $< 
<<

.c{$(CPP_SBRS)}.sbr::
   $(CPP) @<<
   $(CPP_PROJ) $< 
<<

.cpp{$(CPP_SBRS)}.sbr::
   $(CPP) @<<
   $(CPP_PROJ) $< 
<<

.cxx{$(CPP_SBRS)}.sbr::
   $(CPP) @<<
   $(CPP_PROJ) $< 
<<

MTL=midl.exe
MTL_PROJ=/nologo /D "NDEBUG" /mktyplib203 /o NUL /win32 
RSC=rc.exe
RSC_PROJ=/l 0x419 /fo"$(INTDIR)\ODMA32Wrapper.res" /d "NDEBUG" /d "_AFXDLL" 
BSC32=bscmake.exe
BSC32_FLAGS=/nologo /o"$(OUTDIR)\ODMA32Wrapper.bsc" 
BSC32_SBRS= \
	
LINK32=link.exe
LINK32_FLAGS=..\Release\odma32.lib /nologo /subsystem:windows /dll\
 /incremental:no /pdb:"$(OUTDIR)\ODMA32Wrapper.pdb" /machine:I386\
 /def:".\ODMA32Wrapper.def" /out:"..\ODMASetup/ODMA32Wrapper.ocx"\
 /implib:"$(OUTDIR)\ODMA32Wrapper.lib" 
DEF_FILE= \
	".\ODMA32Wrapper.def"
LINK32_OBJS= \
	"$(INTDIR)\ODMA32Wrapper.obj" \
	"$(INTDIR)\ODMA32Wrapper.res" \
	"$(INTDIR)\ODMAWrapper.obj" \
	"$(INTDIR)\StdAfx.obj"

"..\ODMASetup\ODMA32Wrapper.ocx" : "$(OUTDIR)" $(DEF_FILE) $(LINK32_OBJS)
    $(LINK32) @<<
  $(LINK32_FLAGS) $(LINK32_OBJS)
<<

OutDir=.\..\Release
TargetPath=\Projects\ODMAWrapper\ODMASetup\ODMA32Wrapper.ocx
InputPath=\Projects\ODMAWrapper\ODMASetup\ODMA32Wrapper.ocx
SOURCE=$(InputPath)

"$(OutDir)\regsvr32.trg"	 : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	regsvr32 /s /c "$(TargetPath)" 
	echo regsvr32 exec. time > "$(OutDir)\regsvr32.trg" 
	

!ELSEIF  "$(CFG)" == "ODMA32Wrapper - Win32 Unicode Release MinSize"

OUTDIR=.\ReleaseUMinSize
INTDIR=.\ReleaseUMinSize
# Begin Custom Macros
OutDir=.\ReleaseUMinSize
# End Custom Macros

!IF "$(RECURSE)" == "0" 

ALL : "$(OUTDIR)\ODMA32Wrapper.dll" "$(OutDir)\regsvr32.trg"

!ELSE 

ALL : "$(OUTDIR)\ODMA32Wrapper.dll" "$(OutDir)\regsvr32.trg"

!ENDIF 

CLEAN :
	-@erase "$(INTDIR)\ODMA32Wrapper.obj"
	-@erase "$(INTDIR)\ODMA32Wrapper.pch"
	-@erase "$(INTDIR)\ODMA32Wrapper.res"
	-@erase "$(INTDIR)\ODMAWrapper.obj"
	-@erase "$(INTDIR)\StdAfx.obj"
	-@erase "$(INTDIR)\vc50.idb"
	-@erase "$(OUTDIR)\ODMA32Wrapper.dll"
	-@erase "$(OUTDIR)\ODMA32Wrapper.exp"
	-@erase "$(OUTDIR)\ODMA32Wrapper.lib"
	-@erase "$(OutDir)\regsvr32.trg"

"$(OUTDIR)" :
    if not exist "$(OUTDIR)/$(NULL)" mkdir "$(OUTDIR)"

CPP=cl.exe
CPP_PROJ=/nologo /MD /W3 /GX /O1 /D "WIN32" /D "NDEBUG" /D "_WINDOWS" /D\
 "_WINDLL" /D "_AFXDLL" /D "_USRDLL" /D "_UNICODE" /D "_ATL_DLL"\
 /Fp"$(INTDIR)\ODMA32Wrapper.pch" /Yu"stdafx.h" /Fo"$(INTDIR)\\"\
 /Fd"$(INTDIR)\\" /FD /c 
CPP_OBJS=.\ReleaseUMinSize/
CPP_SBRS=.

.c{$(CPP_OBJS)}.obj::
   $(CPP) @<<
   $(CPP_PROJ) $< 
<<

.cpp{$(CPP_OBJS)}.obj::
   $(CPP) @<<
   $(CPP_PROJ) $< 
<<

.cxx{$(CPP_OBJS)}.obj::
   $(CPP) @<<
   $(CPP_PROJ) $< 
<<

.c{$(CPP_SBRS)}.sbr::
   $(CPP) @<<
   $(CPP_PROJ) $< 
<<

.cpp{$(CPP_SBRS)}.sbr::
   $(CPP) @<<
   $(CPP_PROJ) $< 
<<

.cxx{$(CPP_SBRS)}.sbr::
   $(CPP) @<<
   $(CPP_PROJ) $< 
<<

MTL=midl.exe
MTL_PROJ=/nologo /D "NDEBUG" /mktyplib203 /o NUL /win32 
RSC=rc.exe
RSC_PROJ=/l 0x419 /fo"$(INTDIR)\ODMA32Wrapper.res" /d "NDEBUG" /d "_AFXDLL" 
BSC32=bscmake.exe
BSC32_FLAGS=/nologo /o"$(OUTDIR)\ODMA32Wrapper.bsc" 
BSC32_SBRS= \
	
LINK32=link.exe
LINK32_FLAGS=/nologo /subsystem:windows /dll /incremental:no\
 /pdb:"$(OUTDIR)\ODMA32Wrapper.pdb" /machine:I386 /def:".\ODMA32Wrapper.def"\
 /out:"$(OUTDIR)\ODMA32Wrapper.dll" /implib:"$(OUTDIR)\ODMA32Wrapper.lib" 
DEF_FILE= \
	".\ODMA32Wrapper.def"
LINK32_OBJS= \
	"$(INTDIR)\ODMA32Wrapper.obj" \
	"$(INTDIR)\ODMA32Wrapper.res" \
	"$(INTDIR)\ODMAWrapper.obj" \
	"$(INTDIR)\StdAfx.obj"

"$(OUTDIR)\ODMA32Wrapper.dll" : "$(OUTDIR)" $(DEF_FILE) $(LINK32_OBJS)
    $(LINK32) @<<
  $(LINK32_FLAGS) $(LINK32_OBJS)
<<

OutDir=.\ReleaseUMinSize
TargetPath=.\ReleaseUMinSize\ODMA32Wrapper.dll
InputPath=.\ReleaseUMinSize\ODMA32Wrapper.dll
SOURCE=$(InputPath)

"$(OutDir)\regsvr32.trg"	 : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	regsvr32 /s /c "$(TargetPath)" 
	echo regsvr32 exec. time > "$(OutDir)\regsvr32.trg" 
	

!ELSEIF  "$(CFG)" == "ODMA32Wrapper - Win32 Unicode Release MinDependency"

OUTDIR=.\ReleaseUMinDependency
INTDIR=.\ReleaseUMinDependency
# Begin Custom Macros
OutDir=.\ReleaseUMinDependency
# End Custom Macros

!IF "$(RECURSE)" == "0" 

ALL : "$(OUTDIR)\ODMA32Wrapper.dll" "$(OutDir)\regsvr32.trg"

!ELSE 

ALL : "$(OUTDIR)\ODMA32Wrapper.dll" "$(OutDir)\regsvr32.trg"

!ENDIF 

CLEAN :
	-@erase "$(INTDIR)\ODMA32Wrapper.obj"
	-@erase "$(INTDIR)\ODMA32Wrapper.pch"
	-@erase "$(INTDIR)\ODMA32Wrapper.res"
	-@erase "$(INTDIR)\ODMAWrapper.obj"
	-@erase "$(INTDIR)\StdAfx.obj"
	-@erase "$(INTDIR)\vc50.idb"
	-@erase "$(OUTDIR)\ODMA32Wrapper.dll"
	-@erase "$(OUTDIR)\ODMA32Wrapper.exp"
	-@erase "$(OUTDIR)\ODMA32Wrapper.lib"
	-@erase "$(OutDir)\regsvr32.trg"

"$(OUTDIR)" :
    if not exist "$(OUTDIR)/$(NULL)" mkdir "$(OUTDIR)"

CPP=cl.exe
CPP_PROJ=/nologo /MD /W3 /GX /O1 /D "WIN32" /D "NDEBUG" /D "_WINDOWS" /D\
 "_WINDLL" /D "_AFXDLL" /D "_USRDLL" /D "_UNICODE" /D "_ATL_STATIC_REGISTRY"\
 /Fp"$(INTDIR)\ODMA32Wrapper.pch" /Yu"stdafx.h" /Fo"$(INTDIR)\\"\
 /Fd"$(INTDIR)\\" /FD /c 
CPP_OBJS=.\ReleaseUMinDependency/
CPP_SBRS=.

.c{$(CPP_OBJS)}.obj::
   $(CPP) @<<
   $(CPP_PROJ) $< 
<<

.cpp{$(CPP_OBJS)}.obj::
   $(CPP) @<<
   $(CPP_PROJ) $< 
<<

.cxx{$(CPP_OBJS)}.obj::
   $(CPP) @<<
   $(CPP_PROJ) $< 
<<

.c{$(CPP_SBRS)}.sbr::
   $(CPP) @<<
   $(CPP_PROJ) $< 
<<

.cpp{$(CPP_SBRS)}.sbr::
   $(CPP) @<<
   $(CPP_PROJ) $< 
<<

.cxx{$(CPP_SBRS)}.sbr::
   $(CPP) @<<
   $(CPP_PROJ) $< 
<<

MTL=midl.exe
MTL_PROJ=/nologo /D "NDEBUG" /mktyplib203 /o NUL /win32 
RSC=rc.exe
RSC_PROJ=/l 0x419 /fo"$(INTDIR)\ODMA32Wrapper.res" /d "NDEBUG" /d "_AFXDLL" 
BSC32=bscmake.exe
BSC32_FLAGS=/nologo /o"$(OUTDIR)\ODMA32Wrapper.bsc" 
BSC32_SBRS= \
	
LINK32=link.exe
LINK32_FLAGS=/nologo /subsystem:windows /dll /incremental:no\
 /pdb:"$(OUTDIR)\ODMA32Wrapper.pdb" /machine:I386 /def:".\ODMA32Wrapper.def"\
 /out:"$(OUTDIR)\ODMA32Wrapper.dll" /implib:"$(OUTDIR)\ODMA32Wrapper.lib" 
DEF_FILE= \
	".\ODMA32Wrapper.def"
LINK32_OBJS= \
	"$(INTDIR)\ODMA32Wrapper.obj" \
	"$(INTDIR)\ODMA32Wrapper.res" \
	"$(INTDIR)\ODMAWrapper.obj" \
	"$(INTDIR)\StdAfx.obj"

"$(OUTDIR)\ODMA32Wrapper.dll" : "$(OUTDIR)" $(DEF_FILE) $(LINK32_OBJS)
    $(LINK32) @<<
  $(LINK32_FLAGS) $(LINK32_OBJS)
<<

OutDir=.\ReleaseUMinDependency
TargetPath=.\ReleaseUMinDependency\ODMA32Wrapper.dll
InputPath=.\ReleaseUMinDependency\ODMA32Wrapper.dll
SOURCE=$(InputPath)

"$(OutDir)\regsvr32.trg"	 : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	regsvr32 /s /c "$(TargetPath)" 
	echo regsvr32 exec. time > "$(OutDir)\regsvr32.trg" 
	

!ENDIF 


!IF "$(CFG)" == "ODMA32Wrapper - Win32 Debug" || "$(CFG)" ==\
 "ODMA32Wrapper - Win32 Unicode Debug" || "$(CFG)" ==\
 "ODMA32Wrapper - Win32 Release MinSize" || "$(CFG)" ==\
 "ODMA32Wrapper - Win32 Release MinDependency" || "$(CFG)" ==\
 "ODMA32Wrapper - Win32 Unicode Release MinSize" || "$(CFG)" ==\
 "ODMA32Wrapper - Win32 Unicode Release MinDependency"
SOURCE=.\ODMA32Wrapper.cpp

!IF  "$(CFG)" == "ODMA32Wrapper - Win32 Debug"

DEP_CPP_ODMA3=\
	"..\connection manager\odma.h"\
	".\ODMA32Wrapper.h"\
	".\ODMA32Wrapper_i.c"\
	".\ODMAWrapper.h"\
	

"$(INTDIR)\ODMA32Wrapper.obj" : $(SOURCE) $(DEP_CPP_ODMA3) "$(INTDIR)"\
 "$(INTDIR)\ODMA32Wrapper.pch" ".\ODMA32Wrapper_i.c" ".\ODMA32Wrapper.h"


!ELSEIF  "$(CFG)" == "ODMA32Wrapper - Win32 Unicode Debug"

DEP_CPP_ODMA3=\
	".\ODMA32Wrapper.h"\
	".\ODMA32Wrapper_i.c"\
	".\ODMAWrapper.h"\
	".\StdAfx.h"\
	
NODEP_CPP_ODMA3=\
	".\odma.h"\
	

"$(INTDIR)\ODMA32Wrapper.obj" : $(SOURCE) $(DEP_CPP_ODMA3) "$(INTDIR)"\
 "$(INTDIR)\ODMA32Wrapper.pch" ".\ODMA32Wrapper.h" ".\ODMA32Wrapper_i.c"


!ELSEIF  "$(CFG)" == "ODMA32Wrapper - Win32 Release MinSize"

DEP_CPP_ODMA3=\
	"..\connection manager\odma.h"\
	".\ODMA32Wrapper.h"\
	".\ODMA32Wrapper_i.c"\
	".\ODMAWrapper.h"\
	

"$(INTDIR)\ODMA32Wrapper.obj" : $(SOURCE) $(DEP_CPP_ODMA3) "$(INTDIR)"\
 "$(INTDIR)\ODMA32Wrapper.pch" ".\ODMA32Wrapper_i.c" ".\ODMA32Wrapper.h"


!ELSEIF  "$(CFG)" == "ODMA32Wrapper - Win32 Release MinDependency"

DEP_CPP_ODMA3=\
	"..\connection manager\odma.h"\
	".\ODMA32Wrapper.h"\
	".\ODMA32Wrapper_i.c"\
	".\ODMAWrapper.h"\
	

"$(INTDIR)\ODMA32Wrapper.obj" : $(SOURCE) $(DEP_CPP_ODMA3) "$(INTDIR)"\
 "$(INTDIR)\ODMA32Wrapper.pch" ".\ODMA32Wrapper_i.c" ".\ODMA32Wrapper.h"


!ELSEIF  "$(CFG)" == "ODMA32Wrapper - Win32 Unicode Release MinSize"

DEP_CPP_ODMA3=\
	".\ODMA32Wrapper.h"\
	".\ODMA32Wrapper_i.c"\
	".\ODMAWrapper.h"\
	".\StdAfx.h"\
	
NODEP_CPP_ODMA3=\
	".\odma.h"\
	

"$(INTDIR)\ODMA32Wrapper.obj" : $(SOURCE) $(DEP_CPP_ODMA3) "$(INTDIR)"\
 "$(INTDIR)\ODMA32Wrapper.pch" ".\ODMA32Wrapper.h" ".\ODMA32Wrapper_i.c"


!ELSEIF  "$(CFG)" == "ODMA32Wrapper - Win32 Unicode Release MinDependency"

DEP_CPP_ODMA3=\
	".\ODMA32Wrapper.h"\
	".\ODMA32Wrapper_i.c"\
	".\ODMAWrapper.h"\
	".\StdAfx.h"\
	
NODEP_CPP_ODMA3=\
	".\odma.h"\
	

"$(INTDIR)\ODMA32Wrapper.obj" : $(SOURCE) $(DEP_CPP_ODMA3) "$(INTDIR)"\
 "$(INTDIR)\ODMA32Wrapper.pch" ".\ODMA32Wrapper.h" ".\ODMA32Wrapper_i.c"


!ENDIF 

SOURCE=.\ODMA32Wrapper.idl

!IF  "$(CFG)" == "ODMA32Wrapper - Win32 Debug"

InputPath=.\ODMA32Wrapper.idl

".\ODMA32Wrapper.tlb"	".\ODMA32Wrapper.h"	".\ODMA32Wrapper_i.c"	 : $(SOURCE)\
 "$(INTDIR)" "$(OUTDIR)"
	midl /Oicf /h "ODMA32Wrapper.h" /iid "ODMA32Wrapper_i.c" "ODMA32Wrapper.idl"

!ELSEIF  "$(CFG)" == "ODMA32Wrapper - Win32 Unicode Debug"

InputPath=.\ODMA32Wrapper.idl

".\ODMA32Wrapper.tlb"	".\ODMA32Wrapper.h"	".\ODMA32Wrapper_i.c"	 : $(SOURCE)\
 "$(INTDIR)" "$(OUTDIR)"
	midl /Oicf /h "ODMA32Wrapper.h" /iid "ODMA32Wrapper_i.c" "ODMA32Wrapper.idl"

!ELSEIF  "$(CFG)" == "ODMA32Wrapper - Win32 Release MinSize"

InputPath=.\ODMA32Wrapper.idl

".\ODMA32Wrapper.tlb"	".\ODMA32Wrapper.h"	".\ODMA32Wrapper_i.c"	 : $(SOURCE)\
 "$(INTDIR)" "$(OUTDIR)"
	midl /Oicf /h "ODMA32Wrapper.h" /iid "ODMA32Wrapper_i.c" "ODMA32Wrapper.idl"

!ELSEIF  "$(CFG)" == "ODMA32Wrapper - Win32 Release MinDependency"

InputPath=.\ODMA32Wrapper.idl

".\ODMA32Wrapper.tlb"	".\ODMA32Wrapper.h"	".\ODMA32Wrapper_i.c"	 : $(SOURCE)\
 "$(INTDIR)" "$(OUTDIR)"
	midl /Oicf /h "ODMA32Wrapper.h" /iid "ODMA32Wrapper_i.c" "ODMA32Wrapper.idl"

!ELSEIF  "$(CFG)" == "ODMA32Wrapper - Win32 Unicode Release MinSize"

InputPath=.\ODMA32Wrapper.idl

".\ODMA32Wrapper.tlb"	".\ODMA32Wrapper.h"	".\ODMA32Wrapper_i.c"	 : $(SOURCE)\
 "$(INTDIR)" "$(OUTDIR)"
	midl /Oicf /h "ODMA32Wrapper.h" /iid "ODMA32Wrapper_i.c" "ODMA32Wrapper.idl"

!ELSEIF  "$(CFG)" == "ODMA32Wrapper - Win32 Unicode Release MinDependency"

InputPath=.\ODMA32Wrapper.idl

".\ODMA32Wrapper.tlb"	".\ODMA32Wrapper.h"	".\ODMA32Wrapper_i.c"	 : $(SOURCE)\
 "$(INTDIR)" "$(OUTDIR)"
	midl /Oicf /h "ODMA32Wrapper.h" /iid "ODMA32Wrapper_i.c" "ODMA32Wrapper.idl"

!ENDIF 

SOURCE=.\ODMA32Wrapper.rc
DEP_RSC_ODMA32=\
	".\ODMA32Wrapper.tlb"\
	".\ODMAWrapper.rgs"\
	

!IF  "$(CFG)" == "ODMA32Wrapper - Win32 Debug"


".\res\ODMA32Wrapper.res" : $(SOURCE) $(DEP_RSC_ODMA32) "$(INTDIR)"\
 ".\ODMA32Wrapper.tlb"
	$(RSC) $(RSC_PROJ) $(SOURCE)


!ELSEIF  "$(CFG)" == "ODMA32Wrapper - Win32 Unicode Debug"


"$(INTDIR)\ODMA32Wrapper.res" : $(SOURCE) $(DEP_RSC_ODMA32) "$(INTDIR)"\
 ".\ODMA32Wrapper.tlb"
	$(RSC) $(RSC_PROJ) $(SOURCE)


!ELSEIF  "$(CFG)" == "ODMA32Wrapper - Win32 Release MinSize"


".\res\ODMA32Wrapper.res" : $(SOURCE) $(DEP_RSC_ODMA32) "$(INTDIR)"\
 ".\ODMA32Wrapper.tlb"
	$(RSC) $(RSC_PROJ) $(SOURCE)


!ELSEIF  "$(CFG)" == "ODMA32Wrapper - Win32 Release MinDependency"


"$(INTDIR)\ODMA32Wrapper.res" : $(SOURCE) $(DEP_RSC_ODMA32) "$(INTDIR)"\
 ".\ODMA32Wrapper.tlb"
	$(RSC) $(RSC_PROJ) $(SOURCE)


!ELSEIF  "$(CFG)" == "ODMA32Wrapper - Win32 Unicode Release MinSize"


"$(INTDIR)\ODMA32Wrapper.res" : $(SOURCE) $(DEP_RSC_ODMA32) "$(INTDIR)"\
 ".\ODMA32Wrapper.tlb"
	$(RSC) $(RSC_PROJ) $(SOURCE)


!ELSEIF  "$(CFG)" == "ODMA32Wrapper - Win32 Unicode Release MinDependency"


"$(INTDIR)\ODMA32Wrapper.res" : $(SOURCE) $(DEP_RSC_ODMA32) "$(INTDIR)"\
 ".\ODMA32Wrapper.tlb"
	$(RSC) $(RSC_PROJ) $(SOURCE)


!ENDIF 

SOURCE=.\ODMAWrapper.cpp

!IF  "$(CFG)" == "ODMA32Wrapper - Win32 Debug"

DEP_CPP_ODMAW=\
	"..\connection manager\odma.h"\
	".\ODMA32Wrapper.h"\
	".\ODMAWrapper.h"\
	

"$(INTDIR)\ODMAWrapper.obj" : $(SOURCE) $(DEP_CPP_ODMAW) "$(INTDIR)"\
 "$(INTDIR)\ODMA32Wrapper.pch" ".\ODMA32Wrapper.h"


!ELSEIF  "$(CFG)" == "ODMA32Wrapper - Win32 Unicode Debug"

DEP_CPP_ODMAW=\
	".\ODMA32Wrapper.h"\
	".\ODMAWrapper.h"\
	".\StdAfx.h"\
	
NODEP_CPP_ODMAW=\
	".\odma.h"\
	

"$(INTDIR)\ODMAWrapper.obj" : $(SOURCE) $(DEP_CPP_ODMAW) "$(INTDIR)"\
 "$(INTDIR)\ODMA32Wrapper.pch" ".\ODMA32Wrapper.h"


!ELSEIF  "$(CFG)" == "ODMA32Wrapper - Win32 Release MinSize"

DEP_CPP_ODMAW=\
	"..\connection manager\odma.h"\
	".\ODMA32Wrapper.h"\
	".\ODMAWrapper.h"\
	

"$(INTDIR)\ODMAWrapper.obj" : $(SOURCE) $(DEP_CPP_ODMAW) "$(INTDIR)"\
 "$(INTDIR)\ODMA32Wrapper.pch" ".\ODMA32Wrapper.h"


!ELSEIF  "$(CFG)" == "ODMA32Wrapper - Win32 Release MinDependency"

DEP_CPP_ODMAW=\
	"..\connection manager\odma.h"\
	".\ODMA32Wrapper.h"\
	".\ODMAWrapper.h"\
	

"$(INTDIR)\ODMAWrapper.obj" : $(SOURCE) $(DEP_CPP_ODMAW) "$(INTDIR)"\
 "$(INTDIR)\ODMA32Wrapper.pch" ".\ODMA32Wrapper.h"


!ELSEIF  "$(CFG)" == "ODMA32Wrapper - Win32 Unicode Release MinSize"

DEP_CPP_ODMAW=\
	".\ODMA32Wrapper.h"\
	".\ODMAWrapper.h"\
	".\StdAfx.h"\
	
NODEP_CPP_ODMAW=\
	".\odma.h"\
	

"$(INTDIR)\ODMAWrapper.obj" : $(SOURCE) $(DEP_CPP_ODMAW) "$(INTDIR)"\
 "$(INTDIR)\ODMA32Wrapper.pch" ".\ODMA32Wrapper.h"


!ELSEIF  "$(CFG)" == "ODMA32Wrapper - Win32 Unicode Release MinDependency"

DEP_CPP_ODMAW=\
	".\ODMA32Wrapper.h"\
	".\ODMAWrapper.h"\
	".\StdAfx.h"\
	
NODEP_CPP_ODMAW=\
	".\odma.h"\
	

"$(INTDIR)\ODMAWrapper.obj" : $(SOURCE) $(DEP_CPP_ODMAW) "$(INTDIR)"\
 "$(INTDIR)\ODMA32Wrapper.pch" ".\ODMA32Wrapper.h"


!ENDIF 

SOURCE=.\StdAfx.cpp
DEP_CPP_STDAF=\
	".\StdAfx.h"\
	

!IF  "$(CFG)" == "ODMA32Wrapper - Win32 Debug"

CPP_SWITCHES=/nologo /MDd /W3 /Gm /GX /Zi /Od /I "..\Connection Manager" /D\
 "WIN32" /D "_DEBUG" /D "_WINDOWS" /D "_WINDLL" /D "_AFXDLL" /D "_USRDLL"\
 /Fp"$(INTDIR)\ODMA32Wrapper.pch" /Yc"stdafx.h" /Fo"$(INTDIR)\\"\
 /Fd"$(INTDIR)\\" /FD /c 

"$(INTDIR)\StdAfx.obj"	"$(INTDIR)\ODMA32Wrapper.pch" : $(SOURCE)\
 $(DEP_CPP_STDAF) "$(INTDIR)"
	$(CPP) @<<
  $(CPP_SWITCHES) $(SOURCE)
<<


!ELSEIF  "$(CFG)" == "ODMA32Wrapper - Win32 Unicode Debug"

CPP_SWITCHES=/nologo /MDd /W3 /Gm /GX /Zi /Od /D "WIN32" /D "_DEBUG" /D\
 "_WINDOWS" /D "_WINDLL" /D "_AFXDLL" /D "_USRDLL" /D "_UNICODE"\
 /Fp"$(INTDIR)\ODMA32Wrapper.pch" /Yc"stdafx.h" /Fo"$(INTDIR)\\"\
 /Fd"$(INTDIR)\\" /FD /c 

"$(INTDIR)\StdAfx.obj"	"$(INTDIR)\ODMA32Wrapper.pch" : $(SOURCE)\
 $(DEP_CPP_STDAF) "$(INTDIR)"
	$(CPP) @<<
  $(CPP_SWITCHES) $(SOURCE)
<<


!ELSEIF  "$(CFG)" == "ODMA32Wrapper - Win32 Release MinSize"

CPP_SWITCHES=/nologo /MD /W3 /GX /O1 /I "..\Connection Manager" /D "WIN32" /D\
 "NDEBUG" /D "_WINDOWS" /D "_WINDLL" /D "_AFXDLL" /D "_USRDLL" /D "_ATL_DLL"\
 /Fp"$(INTDIR)\ODMA32Wrapper.pch" /Yc"stdafx.h" /Fo"$(INTDIR)\\"\
 /Fd"$(INTDIR)\\" /FD /c 

"$(INTDIR)\StdAfx.obj"	"$(INTDIR)\ODMA32Wrapper.pch" : $(SOURCE)\
 $(DEP_CPP_STDAF) "$(INTDIR)"
	$(CPP) @<<
  $(CPP_SWITCHES) $(SOURCE)
<<


!ELSEIF  "$(CFG)" == "ODMA32Wrapper - Win32 Release MinDependency"

CPP_SWITCHES=/nologo /MD /W3 /GX /O1 /I "..\Connection Manager" /D "WIN32" /D\
 "NDEBUG" /D "_WINDOWS" /D "_WINDLL" /D "_AFXDLL" /D "_USRDLL" /D\
 "_ATL_STATIC_REGISTRY" /Fp"$(INTDIR)\ODMA32Wrapper.pch" /Yc"stdafx.h"\
 /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 

"$(INTDIR)\StdAfx.obj"	"$(INTDIR)\ODMA32Wrapper.pch" : $(SOURCE)\
 $(DEP_CPP_STDAF) "$(INTDIR)"
	$(CPP) @<<
  $(CPP_SWITCHES) $(SOURCE)
<<


!ELSEIF  "$(CFG)" == "ODMA32Wrapper - Win32 Unicode Release MinSize"

CPP_SWITCHES=/nologo /MD /W3 /GX /O1 /D "WIN32" /D "NDEBUG" /D "_WINDOWS" /D\
 "_WINDLL" /D "_AFXDLL" /D "_USRDLL" /D "_UNICODE" /D "_ATL_DLL"\
 /Fp"$(INTDIR)\ODMA32Wrapper.pch" /Yc"stdafx.h" /Fo"$(INTDIR)\\"\
 /Fd"$(INTDIR)\\" /FD /c 

"$(INTDIR)\StdAfx.obj"	"$(INTDIR)\ODMA32Wrapper.pch" : $(SOURCE)\
 $(DEP_CPP_STDAF) "$(INTDIR)"
	$(CPP) @<<
  $(CPP_SWITCHES) $(SOURCE)
<<


!ELSEIF  "$(CFG)" == "ODMA32Wrapper - Win32 Unicode Release MinDependency"

CPP_SWITCHES=/nologo /MD /W3 /GX /O1 /D "WIN32" /D "NDEBUG" /D "_WINDOWS" /D\
 "_WINDLL" /D "_AFXDLL" /D "_USRDLL" /D "_UNICODE" /D "_ATL_STATIC_REGISTRY"\
 /Fp"$(INTDIR)\ODMA32Wrapper.pch" /Yc"stdafx.h" /Fo"$(INTDIR)\\"\
 /Fd"$(INTDIR)\\" /FD /c 

"$(INTDIR)\StdAfx.obj"	"$(INTDIR)\ODMA32Wrapper.pch" : $(SOURCE)\
 $(DEP_CPP_STDAF) "$(INTDIR)"
	$(CPP) @<<
  $(CPP_SWITCHES) $(SOURCE)
<<


!ENDIF 


!ENDIF 

