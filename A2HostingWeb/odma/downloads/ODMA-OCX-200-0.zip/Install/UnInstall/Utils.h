#include <windows.h>
//#include <stdio.h>
//#include "tchar.h"
void RenameFile(LPCTSTR pszBaseDir, LPCTSTR lpszName);
LONG SetRegistryString(HKEY,LPCTSTR lpszKey, LPCTSTR lpszEntry, LPCTSTR lpszValue);
BOOL GetPowerDOCSPath(LPTSTR pszPath, DWORD* pdwCount);

