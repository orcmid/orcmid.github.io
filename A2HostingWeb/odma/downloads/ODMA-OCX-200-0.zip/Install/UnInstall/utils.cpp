#include <windows.h>
#include <stdio.h>
#include "tchar.h"

void RenameFile(LPCTSTR pszBaseDir, LPCTSTR lpszName)
{
	char szOldName[_MAX_PATH*sizeof(TCHAR)];
	char szNewName[_MAX_PATH*sizeof(TCHAR)];

	_tcscpy(szOldName, pszBaseDir);
	_tcscat(szOldName, lpszName);
	_tcscat(szOldName, _T("_"));

	_tcscpy(szNewName, pszBaseDir);
	_tcscat(szNewName, lpszName);

	_trename(szOldName, szNewName);
}

LONG SetRegistryString(HKEY hkeyParent, LPCTSTR lpszKey, LPCTSTR lpszEntry, LPCTSTR lpszValue)
{
	HKEY hkey;
	LONG lResult;
	DWORD dw;
	lResult = RegCreateKeyEx(hkeyParent, lpszKey, 0, REG_NONE,
						  REG_OPTION_NON_VOLATILE, KEY_WRITE|KEY_READ, NULL,
			              &hkey, &dw);
	if (lResult != ERROR_SUCCESS)
		return lResult;

	lResult = RegSetValueEx(hkey, lpszEntry, NULL, REG_SZ,
				            (LPBYTE)lpszValue, (lstrlen(lpszValue)+1)*sizeof(TCHAR));

	RegCloseKey(hkey);  

	return lResult;
}

BOOL GetPowerDOCSPath(LPTSTR pszPath, DWORD* pdwCount)
{
	DWORD dwAttribute;
	BOOL bRetCode = FALSE;
	HKEY hKey = NULL;
	TCHAR szSubKey[] = _T("Software\\PC DOCS Inc.\\PowerDOCS\\Core\\Components");
	if (ERROR_SUCCESS != RegOpenKeyEx(HKEY_LOCAL_MACHINE, szSubKey, 0, KEY_READ, &hKey))
		return FALSE;
	
	DWORD dwType;
	LONG lResult = RegQueryValueEx(hKey, _T("DERes"), NULL, &dwType, (unsigned char*)pszPath, pdwCount);
	if (lResult != ERROR_SUCCESS)
		goto err;

	dwAttribute = GetFileAttributes(pszPath);
	if ( (-1 != dwAttribute) && (dwAttribute & FILE_ATTRIBUTE_DIRECTORY))
		bRetCode = TRUE;	

err:
	RegCloseKey(hKey);  
	return bRetCode;
}

