@echo off
ECHO --- Build ODMAWrapper Installation

cd "UnInstall"
nmake /f "Uninst.mak" CFG="Uninst - Win32 Release"
if errorlevel 1 goto error
cd ..

"%InstallShield5%\Program\Compile.exe"  "Script Files\setup.rul" -I"Script Files" -v0
if errorlevel 1 goto error

"%InstallShield5%\Program\ISBuild.exe" -m"Default" -p"D:\projects\ODMAWrapper\Install"
if errorlevel 1 goto error

cd "Media\Default\Disk Images\disk1"
"%WinZip%\winzip32.exe" -min -a -r "ODMAWrapperSetup.zip"  "*.*"
if errorlevel 1 goto error
cd "..\..\..\..\"

if exist "..\ODMAWrapperSetup.zip" del "..\ODMAWrapperSetup.zip" /Q 
move "Media\Default\Disk Images\disk1\ODMAWrapperSetup.zip" "..\ODMAWrapperSetup.zip"
if errorlevel 1 goto error

ECHO - Process completed successfully.
goto return

:error
ECHO Process completed abnormaly.

:return
