prototype ChangeExt(STRING);
prototype insConfigureUninstInfo(STRING/*szUninstallName*/,STRING /*szUninstDll*/,STRING /*szUninstIconName*/);
prototype insIsExplorer();
prototype UpdateRegistry();

