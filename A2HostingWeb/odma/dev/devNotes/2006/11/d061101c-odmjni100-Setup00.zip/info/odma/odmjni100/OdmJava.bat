@echo off
rem OdmJava.bat 0.00                   UTF-8                  dh:2006-11-11
ECHO OdmJava.bat 0.00 ESTABLISH JAVA ENVIRONMENT FOR ODMJNI

rem **** TO CUSTOMIZE THIS SCRIPT, ADJUST THE THREE VALUES BELOW.
rem ****    Please make a backup copy of any modified script.  Code updates
rem ****    will reset this file to the previous or a later version.  Check
rem ****    the updates to see how to merge any further changes with your
rem ****    modifications.

rem LOCATION OF THE JAVA JDK ON THIS COMPUTER:
SET OdmJava=C:\Program Files\Java\jdk1.5.0_09
rem         ---------------------------------

rem LOCATION OF THE FOLDER WHERE ODMJNI CLASSPATHS START
SET OdmClasses=C:\MyProjects\java\ODMdev
rem            -------------------------
SET OdmPackage=info\odma\odmjni100
rem            -------------------

rem NO CHANGES ARE REQUIRED BELOW HERE.

IF NOT "%OdmJDK%" == "" GOTO :REPORT
rem    Don't set these if that's already been done.
rem    XXX: Can end up being contradictory settings to what we want.

SET OdmJDK=%OdmJava%
IF NOT EXIST "%OdmJDK%\bin\javac.exe" GOTO :FAIL1
PATH %OdmJDK%\bin;%PATH%

:REPORT
IF NOT EXIST "%OdmJDK%\bin\javac.exe" GOTO :FAIL1
ECHO:    Using the Java SDK installed at %OdmJDK%
ECHO:    Using package class path at %OdmClasses%
ECHO:    and default package path %OdmPackage%
EXIT /B 0

:FAIL1
ECHO: **** NO JAVA COMPILER AT %OdmJDK%\bin
ECHO: ****    Please adjust this OdmJava.bat file to correctly locate
ECHO: ****    The directory in which the Java JDK is installed.
SET OdmJDK=
ECHO /B 2

rem -----1---------2---------3---------4---------5---------6---------7----*

rem SET ENVIRONMENT TO USE JAVA JDK.  Customize the SET statement here to
rem locate the JDK that is to be used for compiling and executing the
rem software in this folder.


rem 0.00 2006-11-11-21:17 Adaptation of MyJava.bat 0.05 used with
rem      practical100.

rem $Header: /MyProjects/java/ODMdev/info/odma/odmjni100/OdmJava.bat 1     06-11-11 21:56 Orcmid $

rem                     *** end of OdmJava.bat ***