@echo off
rem BuildClass00.bat 0.01            UTF-8                    dh:2006-11-12
echo BuildClass00.bat 0.01 COMPILING Setup00.java FOR SIMPLE JNI TEST

IF NOT EXIST ..\..\OdmJava.bat GOTO :FAIL0
pushd ..\..\
CALL OdmJava.bat
popd
IF NOT ERRORLEVEL 2 GOTO :Compile
ECHO:  **** BuildClass00.bat ABORTED.  SEE OdmJava.bat ERROR MESSAGES.
ECHO:
EXIT /B %ERRORLEVEL%

:Compile
IF NOT EXIST Setup00.java GOTO :FAIL1

SET ERRORLEVEL=
javac Setup00.java
if "%ERRORLEVEL%"=="1" GOTO :FAIL2

echo:
echo: **** Setup00.class COMPILED ****
echo:
echo: There are no errors or warnings.  This program can be run
echo: via RunSetup00.bat after the Setup00.dll is also built
echo:
EXIT /B 0


:FAIL0
ECHO:
ECHO:  **** EXECUTE BuildClass00.bat IN THE DIRECTORY THAT HOLDS IT.
ECHO:  ****   The OdmJava.bat script must be available two levels above.
ECHO:  ****   Verify your Setup00 configuration and ensure that the
ECHO:  ****   directory holding BuildClass00.bat is the current working
ECHO:  ****   directory before the script is invoked.
ECHO:
EXIT /B 2


:FAIL1
ECHO:
ECHO:  **** THE Setup00.java FILE IS NOT PRESENT IN THE CURRENT DIRECTORY
ECHO:  ****   The file should be in the same directory as this BuildClass00
ECHO:  ****   script.  BuildClass00 cannot be completed.
ECHO:
EXIT /B 2


:FAIL2
echo:
echo: **** ERRORS OR WARNINGS IN COMPILATION, ERRORLEVEL = %ERRORLEVEL% ****
echo: To capture a log, run with redirection to a file or pipe the result
echo: of BuildClass00 into a program like "more."
echo:
EXIT /B %ERRORLEVEL%


rem -----1---------2---------3---------4---------5---------6---------7----*

rem BUILD JAVA CLASS TO CONFIRM BASIC JNI OPERATION
rem This script confirms the odmjni100 use of OdmJava and the compiling of
rem Setup00.java.


rem 0.01 2006-11-12-18:12 Correct typos noticed while adapting to make
rem      BuildDLL00 0.00
rem 0.00 2006-11-12-17:49 customized from the OdmNative100 BuildSetup02.bat
rem      0.02.

rem $Header: /MyProjects/java/ODMdev/info/odma/odmjni100/test/setup00/BuildClass00.bat 2     06-11-12 18:28 Orcmid $

rem                     *** end of BuildClass00.bat ***