@echo off
rem RunSetup00.bat 0.00              UTF-8                    dh:2006-11-12
echo RunSetup00.bat 0.00 RUNNING Setup00.class FOR SIMPLE JNI CONFIRMATION

IF NOT EXIST ..\..\OdmJava.bat GOTO :FAIL0
pushd ..\..\
CALL OdmJava.bat
popd
IF NOT ERRORLEVEL 2 GOTO :Run
ECHO:  **** RunSetup00.bat ABORTED.  SEE OdmJava.bat ERROR MESSAGES.
ECHO:
EXIT /B %ERRORLEVEL%

:Run
IF NOT EXIST Setup00.class GOTO :FAIL1

SET ERRORLEVEL=
ECHO:
java Setup00
if "%ERRORLEVEL%"=="1" GOTO :FAIL2
EXIT /B 0


:FAIL0
ECHO:
ECHO:  **** EXECUTE RunSetup00.bat IN THE DIRECTORY THAT HOLDS IT.
ECHO:  ****   The OdmJava.bat script must be available two levels above.
ECHO:  ****   Verify your Setup00 configuration and ensure that the
ECHO:  ****   directory holding RunSetup00.bat is the current working
ECHO:  ****   directory before the script is invoked.
ECHO:
EXIT /B 2


:FAIL1
ECHO:
ECHO:  **** THE Setup00.class FILE IS NOT PRESENT IN THE CURRENT DIRECTORY
ECHO:  ****   The file should be in the same directory as this RunSetup00
ECHO:  ****   script.  Use BuildClass00.bat to compile the class.
ECHO:
EXIT /B 2


:FAIL2
ECHO:
ECHO: **** ERRORS IN EXECUTION, ERRORLEVEL = %ERRORLEVEL% ****
ECHO: ****   Make sure that the Setup00.dll that matches Setup00.java has
ECHO: ****   been compiled.  You can use BuildDLL00.bat to do that.
ECHO:
EXIT /B %ERRORLEVEL%


rem -----1---------2---------3---------4---------5---------6---------7----*

rem CONFIRM BASIC JNI OPERATION
rem This script confirms the odmjni100 use of OdmJava and the execution
rem of Setup00.class with its Setup00.dll JNI implementation.


rem 0.00 2006-11-12-17:49 customized from BuildClass00.bat 0.01.

rem $Header: /MyProjects/java/ODMdev/info/odma/odmjni100/test/setup00/RunSetup00.bat 1     06-11-12 19:13 Orcmid $

rem                     *** end of RunSetup00.bat ***