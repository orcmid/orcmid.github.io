@echo off
rem BuildDLL00.bat 0.02              UTF-8                    dh:2006-11-13
ECHO BuildDLL00.bat 0.02 COMPILING Setup00.dll FOR SIMPLE JNI TEST

IF NOT EXIST ..\..\OdmJNI.bat GOTO :FAIL0
pushd ..\..\
CALL OdmJNI.bat
popd
IF NOT ERRORLEVEL 2 GOTO :Compile
ECHO:  **** BuildDLL00.bat ABORTED.  SEE THE OdmJNI.bat ERROR MESSAGES.
ECHO:
EXIT /B %ERRORLEVEL%

:Compile
IF NOT EXIST Setup00.c GOTO :FAIL1

SET ERRORLEVEL=
cl /LD /MT /WX Setup00.c /link /MANIFEST:NO
if ERRORLEVEL 1 GOTO :FAIL2

echo:
echo:  **** Setup00.dll COMPILED ****
echo:
echo:       There are no errors or warnings.  This DLL can be run
echo:       via RunSetup00.bat when Setup00.class is also available.
echo:
EXIT /B 0


:FAIL0
ECHO:
ECHO:  **** EXECUTE BuildDLL00.bat IN THE DIRECTORY THAT HOLDS IT.
ECHO:  ****   The OdmJNI.bat script must be available two levels above.
ECHO:  ****   Verify your Setup00 configuration and ensurere that the
ECHO:  ****   directory holding BuildDLL00.bat is the current working
ECHO:  ****   directory before the script is invoked.
ECHO:
EXIT /B 2


:FAIL1
ECHO:
ECHO:  **** THE Setup00.c FILE IS NOT PRESENT IN THE CURRENT DIRECTORY
ECHO:  ****   The file should be in the same directory as this BuildDLL00
ECHO:  ****   script.  BuildDLL00 aborted.
ECHO:
EXIT /B 2


:FAIL2
echo:
echo: **** ERRORS OR WARNINGS IN COMPILATION, ERRORLEVEL = %ERRORLEVEL% ****
echo: To capture a log, run with redirection to a file or pipe the result
echo: of BuildDLL00 into a program like "more."
echo:
EXIT /B %ERRORLEVEL%


rem -----1---------2---------3---------4---------5---------6---------7----*

rem BUILD JAVA CLASS TO CONFIRM BASIC JNI OPERATION
rem This script confirms the odmjni100 use of OdmJava and the compiling of
rem Setup00.java.


rem 0.02 2006-11-13-17:37 Correct handling of ERRORLEVEL after compiles and
rem      remove /Za so that <windows.h> processes properly.
rem 0.01 2006-11-13-16:51 See how to build without a manifest.  I have left
rem      that in although it does not seem to make any difference.
rem 0.00 2006-11-12-17:49 customized from BuildClass00.bat 0.00

rem $Header: /MyProjects/java/ODMdev/info/odma/odmjni100/test/setup00/BuildDLL00.bat 3     06-11-13 17:51 Orcmid $

rem                       *** end of BuildDLL00.bat ***