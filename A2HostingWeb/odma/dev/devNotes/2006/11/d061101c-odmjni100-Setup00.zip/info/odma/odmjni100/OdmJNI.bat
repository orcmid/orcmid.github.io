@echo off
rem OdmJNI.bat 0.00                   UTF-8                  dh:2006-11-11
ECHO OdmJNI.bat 0.00 SET JNI COMMAND-LINE COMPILING ENVIRONMENT
rem
rem     This script requires the environments for the JDK, Visual C++,
rem     and the Microsoft Platform SDK.  It uses existing scripts for
rem     and then adds the additional INCLUDE libraries for JNI compiling.

rem   **** THERE ARE NO MODIFICATIONS NECESSARY FOR THIS SCRIPT.

IF NOT "%OdmJNI%" == "" GOTO :HaveJNI
IF NOT EXIST OdmJava.bat GOTO :FAIL0
IF NOT EXIST OdmPSDK.bat GOTO :FAIL1
CALL OdmJava
IF ERRORLEVEL 2 GOTO :FAIL2
CALL OdmPSDK
IF ERRORLEVEL 2 GOTO :FAIL3

SET INCLUDE=%OdmJDK%\include;%OdmJDK%\include\win32;%INCLUDE%

:HaveJNI
ECHO: **** OdmJNI COMPILING ENVIRONMENT IS SET UP.
ECHO:
EXIT /B 0


:FAIL0
ECHO:
ECHO:  **** THE OdmJNI.bat SCRIPT MUST BE EXECUTED IN THE SAME DIRECTORY
ECHO:  ****   AS OdmJava.bat.  Please verify that both files are present
ECHO:  ****   and execute OdmJNI from that directory.
ECHO:
EXIT /B 2

:FAIL1
ECHO:
ECHO:  **** THE OdmJNI.bat SCRIPT MUST BE EXECUTED IN THE SAME DIRECTORY
ECHO:  ****   AS OdmPSDK.bat.  Please verify that both files are present
ECHO:  ****   and execute OdmJNI from that directory.
ECHO:
EXIT /B 2

:FAIL2
ECHO:
ECHO:  **** OdmJava SCRIPT FAILED.  Please troubleshoot that script.
ECHO:  ****   The OdmJNI script depends on OdmJava.bat and did not succeed.
EXIT /B 2

:FAIL3
ECHO:
ECHO:  **** OdmPSDK SCRIPT FAILED.  Please troubleshoot that script.
ECHO:  ****   The OdmJNI script depends on OdmPSDK.bat and did not succeed.
EXIT /B 2

rem -----1---------2---------3---------4---------5---------6---------7----*

rem SET ENVIRONMENT FOR COMPILING JNI PROJECTS.  This script can be executed
rem in a batch session to set the environment for performing a VC++ 2005
rem console project using the JNI liraries and the Microsoft Platform SDK.

rem 0.00 2006-11-11-21:58 Adapt OdmNative OdmPSDK.bat 0.02 for addition
rem      of the JNI files to be used in compiling JNI DLLs.

rem $Header: /MyProjects/java/ODMdev/info/odma/odmjni100/OdmJNI.bat 1     06-11-11 22:34 Orcmid $

rem                     *** end of OdmJNI.bat ***
