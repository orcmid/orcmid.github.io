@echo off
rem BuildDLL01b.bat 0.03             UTF-8                    dh:2006-11-27
ECHO **** BuildDLL0b.bat 0.03 COMPILING Setup00.dll USING C++

IF NOT EXIST ..\..\OdmJNI.bat GOTO :FAIL0
pushd ..\..\
CALL OdmJNI.bat
popd
IF NOT ERRORLEVEL 2 GOTO :Compile
ECHO **** BuildDLL01b.bat ABORTED.  SEE THE OdmJNI.bat ERROR MESSAGES.
ECHO:
EXIT /B %ERRORLEVEL%

:Compile
IF NOT EXIST Setup01.cpp GOTO :FAIL1

SET ERRORLEVEL=
cl /WX /MT /LD Setup01.cpp /link /MANIFEST:NO
if ERRORLEVEL 1 GOTO :FAIL2

echo:
echo **** Setup01.dll COMPILED
echo **** ********************
echo:
echo:     There are no errors or warnings.  This DLL can be run via
echo:     RunSetup01.bat when the Setup01.class is also available.
echo:
EXIT /B 0


:FAIL0
ECHO:
ECHO **** EXECUTE BuildDLL01b.bat IN THE DIRECTORY THAT HOLDS IT.
ECHO ****     The OdmJNI.bat script must be available two levels above.
ECHO ****     Verify your Setup01 configuration and ensure that the
ECHO ****     directory holding BuildDLL01b.bat is the current working
ECHO ****     directory before the script is invoked.
ECHO:
EXIT /B 2


:FAIL1
ECHO:
ECHO **** THE Setup01.cpp FILE IS NOT PRESENT IN THE CURRENT DIRECTORY
ECHO ****     The file should be in the same directory as this BuildDLL01b
ECHO ****     script.  BuildDLL01b is aborted.
ECHO:
EXIT /B 2


:FAIL2
echo:
echo **** ERRORS OR WARNINGS IN COMPILATION, ERRORLEVEL = %ERRORLEVEL% ****
echo ****     To capture a log, run with redirection to a file or pipe the
echo ****     result of BuildDLL01b into a program like "more."
echo:
EXIT /B %ERRORLEVEL%


rem -----1---------2---------3---------4---------5---------6---------7----*

rem BUILD DLL FROM C++ LANGUAGE IMPLEMENTATION OF MASTER JNI EXEMPLARS
rem This script builds the Setup01.dll from a C++ Language program.


rem 0.03 2006-11-27-18:30 Customize as BuildDLL00b.bat and construction
rem      of the DLL using C++.  The style desired for 0.20alpha integration
rem      is also instituted.
rem 0.02 2006-11-14-23:11 Allow Microsoft VC++ Extensions so that
rem      <windows.h> can be used in the C Language version.
rem 0.01 2006-11-13-21:57 Adjusted to compile Setup01.c as the DLL and
rem      complete customization of the messages for BuildDLL01a.
rem 0.00 2006-11-13-00:12 customized from BuildDLL00.bat 0.00

rem $Header: /ODMdev/info/odma/odmjni100/test/setup01/BuildDLL01b.bat 6     06-11-27 19:36 Orcmid $

rem                       *** end of BuildDLL01b.bat ***