@echo off
rem RunSetup01.bat 0.01              UTF-8                    dh:2006-11-13
echo RunSetup01.bat 0.01 RUNNING Setup01.class FOR MASTER JNI CONFIRMATION

IF NOT EXIST ..\..\OdmJava.bat GOTO :FAIL0
pushd ..\..\
CALL OdmJava.bat
popd
IF NOT ERRORLEVEL 2 GOTO :Run
ECHO:  **** RunSetup01.bat ABORTED.  SEE OdmJava.bat ERROR MESSAGES.
ECHO:
EXIT /B %ERRORLEVEL%

:Run
IF NOT EXIST Setup01.class GOTO :FAIL1

SET ERRORLEVEL=
ECHO:
java Setup01
if "%ERRORLEVEL%"=="1" GOTO :FAIL2
EXIT /B 0


:FAIL0
ECHO:
ECHO:  **** EXECUTE RunSetup01.bat IN THE DIRECTORY THAT HOLDS IT.
ECHO:  ****   The OdmJava.bat script must be available two levels above.
ECHO:  ****   Verify your Setup01 configuration and ensure that the
ECHO:  ****   directory holding RunSetup01.bat is the current working
ECHO:  ****   directory before the script is invoked.
ECHO:
EXIT /B 2


:FAIL1
ECHO:
ECHO:  **** THE Setup01.class FILE IS NOT PRESENT IN THE CURRENT DIRECTORY
ECHO:  ****   The file should be in the same directory as this RunSetup01
ECHO:  ****   script.  Use BuildClass01.bat to compile the class.
ECHO:
EXIT /B 2


:FAIL2
ECHO:
ECHO: **** ERRORS IN EXECUTION, ERRORLEVEL = %ERRORLEVEL% ****
ECHO: ****   Make sure that the Setup01.dll that matches Setup01.java has
ECHO: ****   been compiled.  You can use BuildDLL01a.bat or alternative
ECHO: ****   BuildDLL01b.bat to do that.
ECHO:
EXIT /B %ERRORLEVEL%


rem -----1---------2---------3---------4---------5---------6---------7----*

rem CONFIRM MASTER JNI OPERATION
rem This script confirms the odmjni100 use of JNI implementations
rem by exercising all of the interface varieties needed for odmjni100.


rem 0.01 2006-11-13-00:20 correction in the title to refer to
rem      Setup01.class.
rem 0.00 2006-11-12-22:59 customized from RunSetup00.bat 0.00.

rem $Header: /MyProjects/java/ODMdev/info/odma/odmjni100/test/setup01/RunSetup01.bat 4     06-11-13 0:21 Orcmid $

rem                     *** end of RunSetup01.bat ***