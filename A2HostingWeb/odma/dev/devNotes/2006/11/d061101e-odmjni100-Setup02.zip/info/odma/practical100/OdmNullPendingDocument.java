/* info.odma.practical100.OdmNullPendingDocument.java           0.05alpha
 *
 * The OdmNullPendingDocument class implements the default null behaviors
 * for OdmPendingDocument interfaces.  This class extends OdmNullDocument
 * to provide the standard default null behavior for pending documents.
 */

package info.odma.practical100;

class OdmNullPendingDocument
          extends OdmNullDocument
          implements OdmPendingDocument

{   /* Class instance construction */

    /* FIXME: There are no instance variables or special constructors
       for the default OdmNullPendingDocument.  Additional flavors will
       be introduced as needed as we evolve ODMJNI functionality.
       */


    /* OdmInterface Interface Method Implementations
     * ---------------------------------------------
     */

    public java.lang.String interfaceImplementation()
    {   /* Return a text string describing this implementation */

        return "ODMJNI 1.0 0.05alpha OdmNullPendingDocument Implementation";
            /* Over-ride with our identification. */
        }


    /* OdmDocument Interface Method Implementations
     * --------------------------------------------
     *
     * The implementations of OdmNullDocument are all applicable here.
     */


    /* OdmPendingDocument Interface Method Implementations
     * ---------------------------------------------------
     */


     public java.lang.String docSubmissionLocation()
     {  /* There is no location available with this null document. */

        return null;
        }


    /* FIX ME: Additional operations will be added as the interface
       is evolved.  This implementation must be kept in step with
       those additions.
       */


    } /* OdmNullPendingDocument */


/* 0.02 2006-10-23-15:17 Eliminate linking to the connection instance from
        the null document.  The cyclic dependency is unnecessary.
   0.01 2006-10-22-23:51 Correct access privileges to support interfaces.
   0.00 2006-10-22-22:53 alpha-level version for the first evolutionary
        prototype of the OdmNullPendingDocument implementation.  This class
        will be maintained consistent with the OdmPendingDocument interface
        and its null behaviors as the prototype package is evolved.

   $Header: /MyProjects/java/ODMdev/info/odma/practical100/OdmNullPendingDocument.java 3     06-10-23 15:30 Orcmid $
   */

/*   *** end of info.odma.practical100.OdmNullPendingDocument.java ***   */