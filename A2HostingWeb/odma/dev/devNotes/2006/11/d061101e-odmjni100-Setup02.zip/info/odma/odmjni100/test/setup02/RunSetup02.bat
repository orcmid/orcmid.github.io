@echo off
rem RunSetup02.bat 0.00              UTF-8                    dh:2006-10-28
echo **   RunSetup02.bat 0.00 PERFORMING odmjni100 Setup02 CONFIRMATION

IF NOT EXIST ..\..\OdmJava.bat GOTO :FAIL0
pushd ..\..\
CALL OdmJava.bat
popd
IF NOT ERRORLEVEL 2 GOTO :Run
ECHO:
ECHO **   RunSetup02.bat ABORTED.  SEE OdmJava.bat ERROR MESSAGES.
ECHO:
EXIT /B %ERRORLEVEL%

:Run
IF NOT EXIST Setup02.class GOTO :FAIL1
SET ERRORLEVEL=
rem         This version sets the library path on the command line.
rem         We need a better way to do this in the future.
rem         FIXME: We might want to check for the odmjni100.dll too.
ECHO:
java -cp ".;%OdmClasses%" -Djava.library.path=..\..\ Setup02
IF ERRORLEVEL 1 GOTO :FAIL2
EXIT /B 0

:FAIL0
ECHO:
ECHO **   EXECUTE RunSetup02.bat IN THE DIRECTORY THAT HOLDS IT.
ECHO **       The OdmJava.bat script must be available two levels above.
ECHO **       Verify your Setup02 configuration and ensure that the
ECHO **       directory holding RunSetup02.bat is the current working
ECHO **       directory before the script is invoked.
ECHO:
EXIT /B 2


:FAIL1
ECHO:
ECHO **   THE Setup02.class FILE IS NOT PRESENT IN THE CURRENT DIRECTORY
ECHO **       The file should be in the same directory as this RunSetup02
ECHO **       script.  Use BuildSetup02.bat to compile the class.
ECHO:
EXIT /B 2


:FAIL2
ECHO:
ECHO **   ERRORS IN EXECUTION, ERRORLEVEL = %ERRORLEVEL%
ECHO **       Remedy depends on the available error messages from Java.
ECHO:
EXIT /B %ERRORLEVEL%

rem -----1---------2---------3---------4---------5---------6---------7----*

rem RUNNING odmjni100 INTEGRATION CONFIRMATION PROGRAM SETUP02.

rem 0.00 2006-11-28-19:13 Adapt practical100 RunTest.bat 0.01 for this
rem      purpose.  Add some error checking of the integrity of the setup.
rem      Set the libpath on the command-line for now.

rem $Header: /ODMdev/info/odma/odmjni100/test/setup02/RunSetup02.bat 1     06-11-28 19:44 Orcmid $

rem                      *** end of RunSetup02.bat ***