/* OdmError.java 0.03                UTF-8                   dh:2006-12-18
 *
 * The OdmError class implements the package-wide unchecked exception
 * for use in verification of parameter strings and for rejection of
 * erroneous document-manipulation operations in null documents.
 *
 * This package-local class extends java.lang.Exception and produces
 * unchecked exceptions.  Thrown exceptions provide a string that describes
 * the triggering behavior and source of the exception.
 *
 * FIXME: The format of these exceptions should be normalized for how they
 *    will appear on call trace reports, logs, and other failure-reporting
 *    mechanisms.
 *
 */


package info.odma.practical100;

public class OdmError extends java.lang.Error
{
    /* Instance Variables and Constructor
     * ----------------------------------
     *
     * There are no new elements in OdmError.
     *
     * FIXME: Consider overloading the constructor or adding more flavors
     *    as part of simplifying the cases creation of explanatory strings
     *    when these exceptions are thrown.  It is conceivable that there
     *    might be subclasses of OdmError as well.
     *
     */

    public OdmError(java.lang.String message)
    {
        super(message);

        } /* OdmError */


    } /* OdmError */


/* 0.03 2006-12-18-13:53 Make public class and constructor for use by
        odmjni100 implementation, for one.
   0.02 2006-12-17-22:31 make explicit constructor that works here.
        This Class is only package visible and we want it that way until
        we have to do something else. (Part of limiting visibility of
        components as long as possible, and opening up just the minimum.)
   0.01 2006-12-17-20:09 corrections to get clean compile
   0.00 2006-12-17-09:47 Introduction for use in 0.30alpha handling of
        erroneuous document-manipulation operations in null-document
        instances.

   $Header: /ODMdev/info/odma/practical100/OdmError.java 4     06-12-18 13:54 Orcmid $
   */

/*        *** end of info.odma.practical100.OdmError.java ***         */