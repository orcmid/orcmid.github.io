@echo off
rem BuildCheckChoice.bat 0.02        UTF-8                    dh:2007-01-17
ECHO ***  BuildCheckChoice.bat 0.02 OdmBindNative100 0.50beta check

IF NOT EXIST ..\..\OdmPSDK.bat GOTO :FAIL0
pushd ..\..\
CALL OdmPSDK.bat
popd
IF NOT ERRORLEVEL 2 GOTO :Compile
ECHO ***  BuildCheckChoice.bat ABORTED.  SEE THE OdmPSDK.bat ERROR MESSAGES.
ECHO:
EXIT /B %ERRORLEVEL%

:Compile
IF NOT EXIST CheckChoice.cpp GOTO :FAIL1

SET ERRORLEVEL=
cl /WX /MT @BuildCheckChoice.opt
if ERRORLEVEL 1 GOTO :FAIL2

echo:
echo ***  CheckChoice.exe COMPILED
echo ***  ************************
echo:
echo:     There are no errors or warnings.  This program can be run
echo:     as CheckChoice.exe.  This is a standalone program.  It can be
echo:     run anywhere on Windows 2000 or later versions.
echo:
EXIT /B 0


:FAIL0
ECHO:
ECHO ***  EXECUTE BuildCheckChoice.bat IN THE DIRECTORY THAT HOLDS IT.
ECHO ***      The OdmPSDK.bat script must be available two levels above.
ECHO ***      Verify your OdmNative100 configuration and ensure that the
ECHO ***      directory holding BuildCheckChoice.bat is the current working
ECHO ***      directory before the script is invoked.
ECHO:
EXIT /B 2


:FAIL1
ECHO:
ECHO ***  THE CheckChoice.cpp FILE IS NOT PRESENT IN THE CURRENT DIRECTORY
ECHO ***      The file should be in the same directory as this BuildCheck-
ECHO ***      Choice script.  BuildCheckChoice.bat aborted.
ECHO:
EXIT /B 2


:FAIL2
echo:
echo ***  ERRORS OR WARNINGS IN COMPILATION, ERRORLEVEL = %ERRORLEVEL%
echo ***      To capture a log, run with redirection to a file or pipe the
echo ***      result of BuildCheckChoice into a program like "more."
echo:
EXIT /B %ERRORLEVEL%


rem -----1---------2---------3---------4---------5---------6---------7----*

rem 0.02 2007-01-17-18:37 Introduce CheckUtils into the build, and use an
rem      options file for the parameters of the build.
rem 0.01 2007-01-17-17:41 Correct messages and layout.
rem 0.00 2007-01-17-16:52 Customized from BuildCheck05 0.01.

rem $Header: /ODMdev/info/odma/OdmNative100/test/Check06/BuildCheckChoice.bat 17    07-01-17 19:04 Orcmid $

rem                     *** end of BuildCheckChoice.bat ***