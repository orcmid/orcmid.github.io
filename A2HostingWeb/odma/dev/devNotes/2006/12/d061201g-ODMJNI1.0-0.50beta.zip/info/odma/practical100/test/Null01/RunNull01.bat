@echo off
rem RunNull01.bat 0.00               UTF-8                    dh:2006-12-17
echo **   RunNull01.bat 0.00 PERFORMING practical100 Null01 CONFIRMATION

IF NOT EXIST ..\..\OdmJava.bat GOTO :FAIL0
pushd ..\..\
CALL OdmJava.bat
popd
IF NOT ERRORLEVEL 2 GOTO :Run
ECHO:
ECHO **   RunNull01.bat ABORTED.  SEE OdmJava.bat ERROR MESSAGES.
ECHO:
EXIT /B %ERRORLEVEL%

:Run
IF NOT EXIST Null01.class GOTO :FAIL1
SET ERRORLEVEL=
ECHO:
java -cp ".;%OdmClasses%" Null01
IF ERRORLEVEL 1 GOTO :FAIL2
EXIT /B 0

:FAIL0
ECHO:
ECHO **   EXECUTE RunNull01.bat IN THE DIRECTORY THAT HOLDS IT.
ECHO **       The OdmJava.bat script must be available two levels above.
ECHO **       Verify your practical100\test\Null01 configuration and ensure
ECHO **       that the directory holding RunNull01.bat is the current
ECHO **       working directory before the script is invoked.
ECHO:
EXIT /B 2


:FAIL1
ECHO:
ECHO **   THE Null01.class FILE IS NOT PRESENT IN THE CURRENT DIRECTORY
ECHO **       The file should be in the same directory as this RunNull01
ECHO **       script.  Use BuildNull01.bat to compile the class.
ECHO:
EXIT /B 2


:FAIL2
ECHO:
ECHO **   ERRORS IN EXECUTION, ERRORLEVEL = %ERRORLEVEL%
ECHO **       Remedy depends on the available error messages from Java.
ECHO:
EXIT /B %ERRORLEVEL%

rem -----1---------2---------3---------4---------5---------6---------7----*

rem RUNNING practical100 INTEGRATION CONFIRMATION PROGRAM Null01.

rem 0.00 2006-12-17-20:55 Customize RunNull00 0.01 for use as initial
rem      RunNull01 script.

rem $Header: /ODMdev/info/odma/practical100/test/Null01/RunNull01.bat 5     06-12-17 20:57 Orcmid $

rem                       *** end of RunNull01.bat ***