@echo off
rem BuildOdmPending100.bat 0.00      UTF-8                    dh:2007-01-15
ECHO ***  BuildOdmPending100.bat 0.00 COMPILE OdmPending100.obj

IF NOT EXIST OdmPSDK.bat GOTO :FAIL0
CALL OdmPSDK.bat
IF NOT ERRORLEVEL 2 GOTO :Compile
ECHO *** BuildOdmPending100.bat ABORTED.  SEE OdmPSDK.bat ERROR MESSAGES.
ECHO:
EXIT /B %ERRORLEVEL%

:Compile
IF NOT EXIST OdmPending100.cpp GOTO :FAIL1

SET ERRORLEVEL=
cl /WX /c OdmPending100.cpp
rem     Compile only and fail on all warnings
rem     FIXME: Try optimization settings at some point.
if ERRORLEVEL 1 GOTO :FAIL2

echo:
echo ***  OdmPending100.obj COMPILED SUCCESSFULLY
echo ***  ***************************************
echo:
echo:     There are no errors or warnings.  This .obj is included directly
echo:     in builds of other programs and in OdmNative100.lib.
echo:
EXIT /B 0


:FAIL0
ECHO:
ECHO ***  EXECUTE BuildOdmPending100.bat IN THE DIRECTORY THAT HOLDS IT.
ECHO ***      The OdmPSDK.bat script must be available in the same place.
ECHO ***      Verify your OdmNative100 configuration and ensure that the
ECHO ***      directory holding BuildOmdPending100.bat is the current
ECHO ***      working directory before the script is invoked.
ECHO:
EXIT /B 2


:FAIL1
ECHO:
ECHO ***  FILE OdmPending100.cpp IS NOT PRESENT IN THE CURRENT DIRECTORY
ECHO ***      BuildOdmPending100.bat aborted.  OdmPending100.cpp is expected
ECHO ***      to be in the same directory.
ECHO:
EXIT /B 2


:FAIL2
echo:
echo ***  ERRORS OR WARNINGS IN COMPILATION, ERRORLEVEL = %ERRORLEVEL% ****
echo ***      To capture a log, run with redirection to a file or pipe the
echo ***      result of BuildOdmPending100.bat into a program like "more."
echo:
EXIT /B %ERRORLEVEL%


rem -----1---------2---------3---------4---------5---------6---------7----*

rem COMPILE OBJECT CODE FOR THE OdmPending100 Implementation.

rem 0.00 2007-01-15-21:52 Customized directly from BuildOdmWorking100 0.00

rem $Header: /ODMdev/info/odma/OdmNative100/BuildOdmPending100.bat 1     07-01-15 22:04 Orcmid $

rem                 *** end of BuildOdmPending100.bat ***