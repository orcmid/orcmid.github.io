/* CheckUtilx.h 0.00                 UTF-8                   dh:2007-01-24
 *
 * This is the header file that defines all of the native-method entries
 * for CheckUtil.class in the default package at odmjni100\test\Check04\
 *
 * This copy of the machine-generated CheckUtil.h file is used for source-
 * code control and a little annotation.  It is synchronized with the
 * CheckUtil.h file by hand.
 */


#include <jni.h>
/* Header for class CheckUtil */

#ifndef _Included_CheckUtil
#define _Included_CheckUtil
#ifdef __cplusplus
extern "C" {
#endif
/*
 * Class:     CheckUtil
 * Method:    doCommand
 * Signature: (Ljava/lang/String;)I
 */
JNIEXPORT jint JNICALL Java_CheckUtil_doCommand
  (JNIEnv *, jclass, jstring);

#ifdef __cplusplus
}
#endif
#endif

/* 0.00 2007-01-24-15:08 Initial version from CheckUtil.class 0.01

   $Header: /ODMdev/info/odma/odmjni100/test/Check04/CheckUtilx.h 1     07-01-24 15:09 Orcmid $
   */

/*                         *** end of CheckUtilx.h ***                */
