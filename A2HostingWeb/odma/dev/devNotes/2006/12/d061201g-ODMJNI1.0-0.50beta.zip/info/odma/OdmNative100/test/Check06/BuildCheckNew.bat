@echo off
rem BuildCheckNew.bat 0.00           UTF-8                    dh:2007-01-17
ECHO ***  BuildCheckNew.bat 0.00 OdmNative 100 0.50beta check

IF NOT EXIST ..\..\OdmPSDK.bat GOTO :FAIL0
pushd ..\..\
CALL OdmPSDK.bat
popd
IF NOT ERRORLEVEL 2 GOTO :Compile
ECHO ***  BuildCheckNew.bat ABORTED.  SEE THE OdmPSDK.bat ERROR MESSAGES.
ECHO:
EXIT /B %ERRORLEVEL%

:Compile
IF NOT EXIST CheckNew.cpp GOTO :FAIL1

SET ERRORLEVEL=
cl /WX /MT @BuildCheckNew.opt
if ERRORLEVEL 1 GOTO :FAIL2

echo:
echo ***  CheckNew.exe COMPILED
echo ***  *********************
echo:
echo:     There are no errors or warnings.  This program can be run
echo:     as CheckNew.exe.  This is a standalone program.  It can be
echo:     run anywhere on Windows 2000 or later versions.
echo:
EXIT /B 0


:FAIL0
ECHO:
ECHO ***  EXECUTE BuildCheckNew.bat IN THE DIRECTORY THAT HOLDS IT.
ECHO ***      The OdmPSDK.bat script must be available two levels above.
ECHO ***      Verify your OdmNative100 configuration and ensure that the
ECHO ***      directory holding BuildCheckNew.bat is the current working
ECHO ***      directory before the script is invoked.
ECHO:
EXIT /B 2


:FAIL1
ECHO:
ECHO ***  THE CheckNew.cpp FILE IS NOT PRESENT IN THE CURRENT DIRECTORY
ECHO ***      The file should be in the same directory as this BuildCheck-
ECHO ***      New script.  BuildCheckNew.bat aborted.
ECHO:
EXIT /B 2


:FAIL2
echo:
echo ***  ERRORS OR WARNINGS IN COMPILATION, ERRORLEVEL = %ERRORLEVEL%
echo ***      To capture a log, run with redirection to a file or pipe the
echo ***      result of BuildCheckNew into a program like "more."
echo:
EXIT /B %ERRORLEVEL%


rem -----1---------2---------3---------4---------5---------6---------7----*

rem 0.00 2007-01-17-21:43 Customized from BuildCheckChoice 0.02.

rem $Header: /ODMdev/info/odma/OdmNative100/test/Check06/BuildCheckNew.bat 1     07-01-18 16:03 Orcmid $

rem                      *** end of BuildCheckNew.bat ***