@echo off
rem BuildNull01.bat 0.00             UTF-8                    dh:2006-12-17
ECHO **   BuildNull01.bat 0.00 COMPILING Null01.java practical100 TEST
ECHO:         This Java application exercises the basic functions of
ECHO:         the practical100 classes and interfaces to confirm correct
ECHO:         operation of OdmNullConnection and its dependent classes.

IF NOT EXIST ..\..\OdmJava.bat GOTO :FAIL0
pushd ..\..\
CALL OdmJava.bat
popd
IF NOT ERRORLEVEL 2 GOTO :Compile
ECHO **   BuildNull01.bat ABORTED.  SEE OdmJava.bat ERROR MESSAGES.
ECHO:
EXIT /B %ERRORLEVEL%

:Compile
IF NOT EXIST Null01.java GOTO :FAIL1

SET ERRORLEVEL=
javac -cp ".;%OdmClasses%" Null01.java
if ERRORLEVEL 1 GOTO :FAIL2

echo:
echo **   Null01.class COMPILED
ECHO **   *********************
echo:
echo:     There are no errors or warnings.  This program can be run
echo:     via RunNull01.bat.
echo:
EXIT /B 0


:FAIL0
ECHO:
ECHO **   EXECUTE BuildNull01.bat IN THE DIRECTORY THAT HOLDS IT.
ECHO **       The OdmJava.bat script must be available two levels above.
ECHO **       Verify your practical100\test\Null01 configuration and ensure
ECHO **       that the directory holding BuildNull01.bat is the current
ECHO **       working directory before the script is invoked.
ECHO:
EXIT /B 2


:FAIL1
ECHO:
ECHO **   THE Null01.java FILE IS NOT PRESENT IN THE CURRENT DIRECTORY
ECHO **       The file should be in the same directory as this BuildNull01
ECHO **       script.  BuildNull01 has aborted.
ECHO:
EXIT /B 2


:FAIL2
echo:
echo **   ERRORS OR WARNINGS IN COMPILATION, ERRORLEVEL = %ERRORLEVEL% ****
echo **       To capture a log, run with redirection to a file or pipe the
echo **       result of BuildNull01 into a program like "more."
echo:
EXIT /B %ERRORLEVEL%


rem -----1---------2---------3---------4---------5---------6---------7----*

rem BUILD JAVA CLASS TO CONFIRM BASIC practical100 NULL INTEGRATION
rem      Confirm basic cases of practical100 operation, using Null01 to
rem      exercise the basic setup and confirm operation through to the
rem      OdmNullConnection implementation.

rem 0.01 2006-12-17-20:53 Customized from the practical100 BuildNull00
rem      script for application to practical100\test\Null01.

rem $Header: /ODMdev/info/odma/practical100/test/Null01/BuildNull01.bat 5     06-12-17 20:54 Orcmid $

rem                     *** end of BuildNull01.bat ***