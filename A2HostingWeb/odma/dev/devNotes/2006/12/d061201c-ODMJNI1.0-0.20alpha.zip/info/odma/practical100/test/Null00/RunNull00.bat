@echo off
rem RunNull00.bat 0.01               UTF-8                    dh:2006-12-01
echo **   RunNull00.bat 0.00 PERFORMING practical100 Null00 CONFIRMATION

IF NOT EXIST ..\..\OdmJava.bat GOTO :FAIL0
pushd ..\..\
CALL OdmJava.bat
popd
IF NOT ERRORLEVEL 2 GOTO :Run
ECHO:
ECHO **   RunNull00.bat ABORTED.  SEE OdmJava.bat ERROR MESSAGES.
ECHO:
EXIT /B %ERRORLEVEL%

:Run
IF NOT EXIST Null00.class GOTO :FAIL1
SET ERRORLEVEL=
ECHO:
java -cp ".;%OdmClasses%" Null00
IF ERRORLEVEL 1 GOTO :FAIL2
EXIT /B 0

:FAIL0
ECHO:
ECHO **   EXECUTE RunNull00.bat IN THE DIRECTORY THAT HOLDS IT.
ECHO **       The OdmJava.bat script must be available two levels above.
ECHO **       Verify your practical100\test\Null00 configuration and ensure
ECHO **       that the directory holding RunNull00.bat is the current
ECHO **       working directory before the script is invoked.
ECHO:
EXIT /B 2


:FAIL1
ECHO:
ECHO **   THE Null00.class FILE IS NOT PRESENT IN THE CURRENT DIRECTORY
ECHO **       The file should be in the same directory as this RunNull00
ECHO **       script.  Use BuildNull00.bat to compile the class.
ECHO:
EXIT /B 2


:FAIL2
ECHO:
ECHO **   ERRORS IN EXECUTION, ERRORLEVEL = %ERRORLEVEL%
ECHO **       Remedy depends on the available error messages from Java.
ECHO:
EXIT /B %ERRORLEVEL%

rem -----1---------2---------3---------4---------5---------6---------7----*

rem RUNNING practical100 INTEGRATION CONFIRMATION PROGRAM Null00.

rem 0.01 2006-12-01-21:01 Customize for practical100 RunNull00.bat
rem 0.00 2006-11-28-19:13 Adapt practical100 RunTest.bat 0.01 for this
rem      purpose.  Add some error checking of the integrity of the setup.
rem      Set the libpath on the command-line for now.

rem $Header: /ODMdev/info/odma/practical100/test/Null00/RunNull00.bat 3     06-12-01 21:20 Orcmid $

rem                       *** end of RunNull00.bat ***