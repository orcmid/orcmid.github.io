@echo off
rem BuildNull00.bat 0.00             UTF-8                    dh:2006-12-01
ECHO **   BuildNull00.bat 0.00 COMPILING Null00.java practical100 TEST
ECHO:         This Java application exercises the basic functions of
ECHO:         the practical100 classes and interfaces to confirm correct
ECHO:         operation of OdmNullConnection and its dependent classes.

IF NOT EXIST ..\..\OdmJava.bat GOTO :FAIL0
pushd ..\..\
CALL OdmJava.bat
popd
IF NOT ERRORLEVEL 2 GOTO :Compile
ECHO **   BuildNull00.bat ABORTED.  SEE OdmJava.bat ERROR MESSAGES.
ECHO:
EXIT /B %ERRORLEVEL%

:Compile
IF NOT EXIST Null00.java GOTO :FAIL1

SET ERRORLEVEL=
javac -cp ".;%OdmClasses%" Null00.java
if ERRORLEVEL 1 GOTO :FAIL2

echo:
echo **   Null00.class COMPILED
ECHO **   *********************
echo:
echo:     There are no errors or warnings.  This program can be run
echo:     via RunNull00.bat.
echo:
EXIT /B 0


:FAIL0
ECHO:
ECHO **   EXECUTE BuildNull00.bat IN THE DIRECTORY THAT HOLDS IT.
ECHO **       The OdmJava.bat script must be available two levels above.
ECHO **       Verify your practical100\test\Null00 configuration and ensure
ECHO **       that the directory holding BuildNull00.bat is the current
ECHO **       working directory before the script is invoked.
ECHO:
EXIT /B 2


:FAIL1
ECHO:
ECHO **   THE Null00.java FILE IS NOT PRESENT IN THE CURRENT DIRECTORY
ECHO **       The file should be in the same directory as this BuildNull00
ECHO **       script.  BuildNull00 has aborted.
ECHO:
EXIT /B 2


:FAIL2
echo:
echo **   ERRORS OR WARNINGS IN COMPILATION, ERRORLEVEL = %ERRORLEVEL% ****
echo **       To capture a log, run with redirection to a file or pipe the
echo **       result of BuildNull00 into a program like "more."
echo:
EXIT /B %ERRORLEVEL%


rem -----1---------2---------3---------4---------5---------6---------7----*

rem BUILD JAVA CLASS TO CONFIRM BASIC practical100 NULL INTEGRATION
rem      Confirm basic cases of practical100 operation, using Null00 to
rem      exercise the basic setup and confirm operation through to the
rem      OdmNullConnection implementation.

rem 0.00 2006-12-01-20:36 Customized from the odmjni100 BuildSetup02
rem      script for application to practical100\test\Null00.

rem $Header: /ODMdev/info/odma/practical100/test/Null00/BuildNull00.bat 3     06-12-01 21:19 Orcmid $

rem                     *** end of BuildNull00.bat ***