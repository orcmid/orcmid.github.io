/* OdmNullFormat.java 0.06           UTF-8                   dh:2007-11-06
 *
 * The OdmNullFormat class provides null-behavior static methods for
 * verifying string parameters to ODMJNI 1.0 methods.
 *
 * The null behaviors use default rules that generally should not permit
 * more cases than an implementation allows.  In practice, the direct use
 * of OdmNullFormat for null connections and documents is irrelevant
 * because those null implementations are indifferent to the quality of
 * such string parameters.
 *
 * OdmNullFormat is intended to be instantiated so that it can deliver the
 * required interface.
 *
 * FIXME: Straighten out the commentary and also decide what should be done
 *        as more appropriate null implementations.
 */

package info.odma.practical100;

public class OdmNullFormat implements OdmFormatCheck

{   /* This class is intended for use exclusively in practical100, and
       it is public to provide the interface.
       */

    protected OdmNullFormat()
    {   /* Allow to be inherited from in building more interesting
           Format Checkers in odmjni100 and similar implementations.
           */

        } /* OdmNullFormat */


    private static final int MAX_DOCFORMAT_LENGTH = 80;
        /* One less than the Odma32types100.h ODM_FORMAT_MAX value that
           also includes a terminal '\0' character.

           FIXME: See if the class can refer to the interface-defined
                  constants.
           */

    public boolean wfDocFormatName(java.lang.String docFormatName)
    {   /* Use the definition in section 1.2 of the 0.30alpha Pre-
           Release Notes.

           See <http://ODMA.info/dev/devNotes/2006/10/d061001f.htm>.
           */

        if (docFormatName == null) return false;

        if (  docFormatName.length() < 2
                || docFormatName.length() > MAX_DOCFORMAT_LENGTH )
             return false;

        if (docFormatName.charAt(0) != '.') return false;

        for (int i = 1; i < docFormatName.length(); i++)
            {   char code = docFormatName.charAt(i);
                if (  code < '0'|| code > 'z'
                        || ( code > 'Z' && code < 'a' )
                        || ( code > '9' && code < 'A' )
                      )
                     return false;
                } /* remaining characters same as for appId */

        return true;

        } /* wfDocFormatName */



    private static final int MAX_DOCID_LENGTH = 254;
        /* One less than the Odma32types.h ODM_DOCID_MAX value, which
           includes allowance for a terminal '\0' not used in the Java
           String form. */


    private static final int MAX_DMSID_LENGTH = 8;
        /* One less than the Odma32types.h ODM_DMSID_MAX value. */


    private static final java.lang.String ODMPREFIX = "::ODMA\\";
        /* The ODMA Document ID is case insensitive, although
           applications are not to change case of docId values.
           Remember that '\\' is a single \-character.
           */


    private static final int MAX_DOCIDPREFIX_LENGTH = 16;
    /* "::ODMA\\12345678\\".length() */


    public boolean wfDocIdPrefix(java.lang.String docId)
    {
        if (docId == null) return false;

        if (docId.length() < ODMPREFIX.length()+2) return false;
            /* No room for prefix when < "::ODMA\\?\\".length() */

        /* There's room, let's match the ODMPREFIX first. */
        if (  docId.substring(0, ODMPREFIX.length())
                .compareToIgnoreCase(ODMPREFIX)
              != 0)
             return false;

        /* The prefix is present, now let's see about the DMS ID */

        java.lang.String dmsId = "";

        int m = (docId.length() > MAX_DOCID_LENGTH
                    ? MAX_DOCID_LENGTH
                    : docId.length()
                    );

        for (int i = ODMPREFIX.length(); i < m; i++ )
            {   /* Accumulate valid characters until "\" or end. */

                char code = docId.charAt(i);

                if (code == '\\')
                     /* We're done:  */
                     return !( dmsId.length() < 1
                               || dmsId.length() > MAX_DMSID_LENGTH );

                /* Allow appId characters as DMS ID characters */
                if (  code < '0'|| code > 'z'
                        || ( code > 'Z' && code < 'a' )
                        || ( code > '9' && code < 'A' )
                      )
                     return false;

                dmsId = dmsId + code;
                }

        return false;
            /* Because we never found the prefix-ending '\\' */

        } /* wfDocIdPrefix */



    public java.lang.String prefixDmsId(java.lang.String docId)

    {   /* Give a valid prefix, extract the dmsId portion */

        if (!wfDocIdPrefix(docId)) return null;

        java.lang.String dmsId = "";

        for (int i = ODMPREFIX.length(); ; i++ )
            {   /* Accumulate valid characters until '\\' */

                char code = docId.charAt(i);

                if (code == '\\') return dmsId;

                dmsId = dmsId + code;

                }

        } /* prefixDmsId */



    public boolean wfDocId(java.lang.String docId)

    {   /* Technically, the only thing required for a valid ODMA Document
           ID is a valid prefix.

           Any finer restriction will be with a DMS determining that the
           format is not an acceptable form for it.

           FIXME: This format accepts all graphical characters beyond a
                  valid prefix so long as the length is acceptable.

                  A native version of this filter will be introduced in
                  0.58beta after openKnownDocument is implemented in
                  0.57beta.  The 0.57 openKnownDocument will filter and
                  silently fail for Document IDs that don't translate to
                  the default Windows ANSI Code Page.

                  The 0.58 openKnownDocument will throw an exception for
                  Document IDs that don't translate, and the 0.58beta
                  version of wfDocId will filter for exactly the same
                  permissible format.
           */

        if (docId.length() > MAX_DOCID_LENGTH) return false;

        if (!wfDocIdPrefix(docId)) return false;

        for (int i = 0; i < docId.length(); i++)

            {   char code = docId.charAt(i);

                if (code < 0x20
                       || (code > 0x7e && code < 0xa1)
                       || code == 0xad
                       )
                     return false;
                     /* XXX: Although the non-break space (0xa0) and
                             the soft hyphen (0xad) are technically not
                             control characters, their allowance in
                             Document IDs would be pernicious.
                        */
                }

        return true;

        } /* wfDocId */



    public boolean safeDocId(java.lang.String docId)

    {   /* Ensure that the Document ID is actually safe for a large
           number of interchange applications by restricting as many
           characters as I can imagine.

           XXX: This is one of those features for which restrictions
                are easier to remove rather than increase, later.

           FIXME: I am nervous about the few non-alphanumeric
                characters that I allow even here.  If there are to be
                *fewer* this must be resolved before 0.60beta and opening
                of ODMJNI to widespread download and review.
           */

        if (!wfDocId(docId)) return false;

        for (int i = ODMPREFIX.length(); i < docId.length(); i++)

            {   /* rule out everything but Basic Latin alphanumberic
                   characters so that precautions can be taken in the
                   case of other character-code occurrences.

                   XXX: The idea is that this can always be relaxed,
                        but we will never have to tighten it further.
                   */

                char code = docId.charAt(i);

                switch (code)
                   {    case   ':':
                        case   '-':
                        case   '_':
                        case   '.':
                        case  '\\':
                        case   '/': continue;

                        default:
                            if (  code < '0'|| code > 'z'
                                    || ( code > 'Z' && code < 'a' )
                                    || ( code > '9' && code < 'A' )
                                  )
                                 return false;

                        }
                }

        return true;

        } /* safeDocId */


    } /* OdmNullFormat */



/* 0.06 2007-11-06-18:29 Copy the OdmFormat methods here for review and
        adjudication of what is appropriate for null and what is better
        later.
   0.05 2007-11-06-18:05 Clean up the access conditions to allow subclassing
        and also to usurp some OdmFormat implementations when that class
        goes away.
   0.04 2007-11-06-16:30 Remove the deprecation and depend on OdmFormat
        as a way to have that one compile as part of the 0.59 package.
   0.03 2007-11-05-18:21 Mark the class as deprecated.
   0.02 2007-03-02-13:52 Add safeDocId method.
   0.01 2007-02-28-21:39 Correct for clean compile.
   0.00 2007-02-25-13:43 Make a null-behavior version and see if I can
        inherit from it as an armature for progressive addition of the
        correct filters.  If that works, I have adapted the null-behavior
        pattern to the creation of static classes.

   $Header: /ODMdev/info/odma/practical100/OdmNullFormat.java 6     07-11-06 18:06 Orcmid $
   */

/*       *** end of info.odma.practical100.OdmNullFormat.java ***        */