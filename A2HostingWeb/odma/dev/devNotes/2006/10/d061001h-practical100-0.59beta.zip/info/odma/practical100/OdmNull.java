/* OdmNull.java 0.02                 UTF-8                   dh:2007-11-06
 *
 * The OdmNull interface delivers the six null-behavior cases.  It also
 * delivers the null and the non-null format check interface implementa-
 * tions by which the proper format checking occurs.
 *
 * The interface is intended to be implemented by a class that caches these
 * particular instances so they can be reused wherever and as often they
 * are needed for delivery by ODMJNI 1.0 methods.
 */


package info.odma.practical100;

public interface OdmNull
{

    OdmPendingDocument pendingFailed();
        /* returns a null OdmPendingDocument with failure status */


    OdmPendingDocument pendingCancelled();
        /* returns a null OdmPendingDocument with cancelled status */


    OdmPendingDocument pendingLocalOperation();
       /* returns a null OdmPendingDocument with local-operation requested
          status */


    OdmWorkingDocument workingFailed();
       /* returns a null OdmWorkingDocument with failure status */


    OdmWorkingDocument workingCancelled();
       /* returns a null OdmWorkingDocument with cancelled status */


    OdmWorkingDocument workingLocalOperation();
       /* returns a null OdmWorkingDocument with local-operation requested
          status */


    OdmFormatCheck nullCheck();
       /* returns the format checking implementation appropriate to null
          connections and null documents, and determined by practical100.
          */

    OdmFormatCheck formatCheck();
       /* returns the format checking implementation appropriate to non-
          null connections and document interfaces and determined by the
          implementations of non-null connections (i.e., odmjni100).  The
          null implementations return nullCheck() from formatCheck().
          */

    } /* OdmNull */


/* 0.02 2007-11-06-17:05 Introduce nullCheck() and formatCheck() as the
        means for delivering cached implementations to those places where
        check interfaces are offered.
   0.01 2006-12-18-20:29 removed unnecessary access specifiers from the
        interface methods.
   0.00 2006-12-18-19:44 derive by extracting material from the 0.08 version
        of OdmNullConnection.

   $Header: /ODMdev/info/odma/practical100/OdmNull.java 3     06-12-18 20:30 Orcmid $
   */

/*         *** end of info.odma.practical100.OdmNull.java ***          */