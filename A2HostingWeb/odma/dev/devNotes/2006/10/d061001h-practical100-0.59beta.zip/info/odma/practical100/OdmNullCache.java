/* OdmNullCache.java 0.04            UTF-8                  dh:2007-11-06
 *
 * OdmNullCache implements the OdmNull interface by creating an automatic
 * cache of the eight cases.  No case is constructed until it is requested.
 * Thereafter, the same implementation is delivered repeatedly.  None of
 * these implementations hold resources or change anything on a release()
 *
 * There are three flavors of null implementation for any class of
 * OdmDocument implementation:
 *
 *      0 Failed with false returned by all of operationSucceeded(),
 *        operationCancelled(), and localOperationRequested()
 *
 *      1 with only operationCancelled() returning true
 *
 *      2 with only localOperationRequested() returning true
 *
 * These parameters to the Null Document constructors will return the
 * appropriate null behavior.
 *
 * There is only one flavor for each of nullCheck() and formatCheck(),
 * and in OdmNullCache formatCheck() is the same as nullCheck().
 *
 */



package info.odma.practical100;

class OdmNullCache implements OdmNull
{

    /* Instance Variables and Constructor
     * ----------------------------------
       */

    private OdmPendingDocument pendingFail;
        /* interface to a null Pending Document in failed state */

    private OdmPendingDocument pendingCancel;
        /* interface to a null Pending Document in cancel state */

    private OdmPendingDocument pendingLocal;
        /* interface to a null Pending Document implementation in
           localOperationRequested state
           */

    private OdmWorkingDocument workingFail;
        /* interface to a null Working Document in failed state */

    private OdmWorkingDocument workingCancel;
        /* interface to a null Working Document in cancel state */

    private OdmWorkingDocument workingLocal;
        /* interface to a null Working Document implementation in
           localOperationRequested state
           */

    private OdmFormatCheck nullChecker;
        /* interface to a null implementation for the OdmFormatCheck.
           */

    protected OdmNullCache()
    {   /* Clear the cache for filling as needed */

        pendingFail = null;
        pendingCancel = null;
        pendingLocal = null;

        workingFail = null;
        workingCancel = null;
        workingLocal = null;

        nullChecker = null;

        } /* OdmNullCache */


    /* Null-Behavior Document Delivery
     * -------------------------------
     *
     * These methods construct and cache the null-behavior document
     * interface implementations.  They are used to avoid excessive
     * class creation and destruction for trivial cases, including when
     * there is no access to ODMA or there is no default DMS.
     *
     * XXX: Constructor recursion is prevented by two techniques.
     *      1. These instantiations do not occur on demand and
               not in any constructor (generally).
            2. No null-document implementation delivers a null-
               document from any of its methods.  Those that would
               do so for a non-null document throw an unchecked
               OdmError exception for the null-document case.
     */


    public final OdmPendingDocument pendingFailed()
    {
        if (pendingFail == null)
             pendingFail = new OdmNullPendingDocument(0, nullCheck());

        return pendingFail;

        } /* pendingFailed */


    public final OdmPendingDocument pendingCancelled()
    {
        if (pendingCancel == null)
             pendingCancel = new OdmNullPendingDocument(1, nullCheck());

        return pendingCancel;

        } /* pendingCancelled */


    public final OdmPendingDocument pendingLocalOperation()
    {
        if (pendingLocal == null)
             pendingLocal = new OdmNullPendingDocument(2, nullCheck());

        return pendingLocal;

        } /* pendingLocalOperation */


    public final OdmWorkingDocument workingFailed()
    {
        if (workingFail == null)
             workingFail = new OdmNullWorkingDocument(0, nullCheck());

        return workingFail;

        } /* workingFailed */


    public final OdmWorkingDocument workingCancelled()
    {
        if (workingCancel == null)
             workingCancel = new OdmNullWorkingDocument(1, nullCheck());

        return workingCancel;

        } /* workingCancelled */


    public final OdmWorkingDocument workingLocalOperation()
    {
        if (workingLocal == null)
             workingLocal = new OdmNullWorkingDocument(2, nullCheck());

        return workingLocal;

        } /* workingLocalOperation */


    /* Null-Behavior Checking Functions
     * --------------------------------
     *
     * These methods construct and cache the null-behavior checking
     * implementation.  They provide caching across the connection and all
     * document implementations off of a single OdmConnection implementa-
     * tation instance.
     */


     public final OdmFormatCheck nullCheck()
     {  /* Provide definitive implementation of the null case for
           formatCheck() method responses.
           */

        if (nullChecker == null)
             nullChecker = new OdmNullFormat();

        return nullChecker;

        } /* nullCheck */


    public OdmFormatCheck formatCheck()
    {   /* This method must be over-loaded for a non-null connection
           to implement its specific checker cases.  Even then, this
           method is usually used only when an implementation confirms
           that it has a connection. */

        return nullCheck();

        } /* formatCheck */


    } /* OdmNullCache */


/* 0.04 2007-11-06-20:12 Add nullCheck() as parameter to the cached null
        document implementations.
   0.03 2007-11-06-17:14 Add nullCheck() and formatCheck() implementations.
   0.02 2006-12-18-21:07 Corrections for clean compile
   0.01 2006-12-18-20:43 Make the interface method implementations public
        as required.
   0.00 2006-12-18-20:16 Extract the implementations from the 0.08 version
        of OdmNullConnection and decorate as implementations of OdmNull.

   $Header: /ODMdev/info/odma/practical100/OdmNullCache.java 5     07-11-06 18:33 Orcmid $
   */

/*       *** end of info.odma.practical100.OdmNullCache.java ***        */