/* OdmNullWorkingDocument.java 0.12  UTF-8                  dh:2007-11-13
 *
 * The OdmNullWorkingDocument class implements the default null behaviors
 * for OdmWorkingDocument interfaces.  OdmNullDocument is extended
 * to provide the standard default null behavior for working documents,
 * including all of the OdmViewingDocument and OdmEditingDocument methods.
 */

package info.odma.practical100;

public class OdmNullWorkingDocument
            extends OdmNullDocument
            implements OdmWorkingDocument

{   /* Class instance construction */

    protected OdmNullWorkingDocument(int myFlavor,
                                     OdmFormatCheck myChecker)
    {   /* We simply expand the OdmNullDocument operation */

        super(myFlavor, myChecker);

        } /* OdmNullWorkingDocument */


    /* OdmInterface Interface Method Implementations
     * ---------------------------------------------
     */

    public java.lang.String interfaceImplementation()
    {   /* Return a text string describing this implementation */

        return "ODMJNI 1.0 " + flavor[nullFlavor]
                             + " OdmNullWorkingDocument 0.12";
            /* Over-ride with our identification. */

        }

        /* The remaining implementations by OdmDocument and OdmInterface
           apply here.
           */


    /* OdmDocument Interface Method Implementations
     * --------------------------------------------
     *
     * The implementations of OdmNullDocument are all applicable here.
     */


    /* OdmViewingDocumentDocument Interface Method Implementations
     * ---------------------------------------------------
     */

    public boolean viewOnly()
    {   /* We report the default, which is not particularly meaningful
           for a null-document either way. */

        return true;
            /* This is a more-valid result even though meaningless.

            XXX: This is a breaking change to the previously-specified
                 null behavior.  Since it should be irrelevant to any
                 application, actually encountering the change in an
                 application is a bug.  This method is deprecated and
                 will not survive into 0.60.  The break is limited to
                 ODMJNI 1.0 0.59.
               */

        } /* viewOnly */


    public boolean notChangeable()
    {   /* We report the default, which is not particularly meaningful
           for a null-document either way. */

        return viewOnly();

        } /* notChangeable */



    public java.lang.String docID()
    {   /* No document connection has been established */

        return null;

        } /* docID */



    public java.lang.String docLocation()
    {   /* No document content has been delivered and there is no
           location. */

        return null;

        } /* docLocation */


    public java.lang.String windowTitle()
    {   /* We have no recommendation of a windowTitle for a no-document
           situation */

        return null;

        } /* windowTitle */



    public java.lang.String dmsAuthor()
    {   /* An invisible document has an invisible author ... */

        return null;

        } /* dmsAuthor */



    public java.lang.String dmsDocName()
    {
        return null;

        } /* dmsDocName */



    public java.lang.String dmsDocType()
    {
        return null;

        } /* dmsDocType */



    public java.lang.String dmsFormatName()
    {
        return null;

        } /* dmsFormatName */



    public OdmPendingDocument transferToNewDocument
                                    (java.lang.String docFormatName)
                              throws OdmError
    {   /* There is no document to transfer and attempting to do so
           is invalid. */

        throw new OdmError("Invalid transferToNewDocument operation: "
                            + interfaceImplementation() );

        } /* transferToNewDocument */


    /* OdmWorkingDocument Interface Method Implementations
     * ---------------------------------------------------
     */


    public boolean commitChanges()
                        throws OdmError

    {   /* There is no document for which a commit can be entertained,
           and the request is an unrecoverable defect of the application.
           */

        throw new OdmError("Invalid commitChanges operation: "
                            + interfaceImplementation() );

        } /* commitChanges */



    } /* OdmNullWorkingDocument */


/* 0.12 2007-11-13-16:30 Clean up the commentary around the viewOnly change.
   0.11 2007-11-12-18:39 Add notChangeable and change default for the
        viewOnly result.
   0.10 2007-11-06-21:07 Accept the OdmFormatCheck to use as part of the
        constructor.
   0.09 2007-10-16-19:03 Indicate [nullFlavor] in interfaceImplementation
        and clean up the messages and documentation comments.
   0.08 2007-03-01-16:15 Clean up error exceptions and use standard
        interfaceImplementation() string format.
   0.07 2007-01-07-23:14 Make constructor protected.
   0.06 2007-01-07-22:59 Make public for use by OdmJniView.
   0.05 2006-12-17-22:28 Correct visibility of viewOnly() for clean
        compile.
   0.04 2006-12-17-18:52 Adjust to use the simplified null-document model
        and with unchecked exceptions and null-on-null behavior.
   0.03 2006-12-16-23:16 Change to implement all of the OdmViewingDocument
        and OdmWorkingDocument interface elements, caching null implementa-
        tions internal to the instance.
   0.02 2006-10-23-15:23 Eliminate linking to the connection instance from
        the null document.  The cyclic dependency is unnecessary.
   0.01 2006-10-23-00:47 adjust access privileges of methods to be public
        for the interface implementation, although the class remains
        package-private.
   0.00 2006-10-22-23:13 alpha-level version for the first evolutionary
        prototype of the OdmNullWorkingDocument implementation.  This class
        will be maintained consistent with the OdmWorkingDocument interface
        and its null behaviors as the prototype package is evolved.

   $Header: /ODMdev/info/odma/practical100/OdmNullWorkingDocument.java 13    07-11-13 16:30 Orcmid $
   */

/*   *** end of info.odma.practical100.OdmNullWorkingDocument.java ***   */