@echo off
rem RunNull01.bat 0.02               UTF-8                    dh:2007-11-21

echo **   RunNull01.bat 0.02 PERFORM 0.30-practical100 Null01 CONFIRMATION
rem       Usage: RunNull01 %1
rem
rem              %1 is the name of any Jar (in form "\name.jar")
rem                 to append to the %OdmClasses% class path
rem                 (set by OdmJava)
rem
rem       If no jar is named, the class path is used as the directory having
rem       info\odma\practical100 subfolders and the practical100 classes
rem       to be used in the confirmation test.
rem
rem       For more information about the 0.30-practical regression set,
rem       setup instructions, and use in ODMJNI confirmation tests, consult
rem       <http://odma.info/dev/devNotes/2007/10/d071001d.htm>.

IF NOT EXIST OdmJava.bat GOTO :FAIL0
CALL OdmJava.bat
IF NOT ERRORLEVEL 2 GOTO :Run
ECHO:
ECHO **   RunNull01.bat ABORTED.  SEE OdmJava.bat ERROR MESSAGES.
ECHO:
EXIT /B %ERRORLEVEL%

:Run
IF NOT EXIST Null01.class GOTO :FAIL1
SET ERRORLEVEL=
ECHO:
java -cp ".;%OdmClasses%%1" Null01
IF ERRORLEVEL 1 GOTO :FAIL2
EXIT /B 0

:FAIL0
ECHO:
ECHO **   EXECUTE RunNull01.bat IN THE DIRECTORY THAT HOLDS IT.
ECHO **       The OdmJava.bat script must be available in the same place.
ECHO **       Verify your 0.30-regression\Null01 configuration.  Ensure
ECHO **       that the directory holding RunNull01.bat is the current
ECHO **       working directory.  Then invoke the script.
ECHO:
EXIT /B 2


:FAIL1
ECHO:
ECHO **   THE Null01.class FILE IS NOT PRESENT IN THE CURRENT DIRECTORY
ECHO **       The file should be in the same directory as this RunNull01
ECHO **       script.
ECHO:
EXIT /B 2


:FAIL2
ECHO:
ECHO **   ERRORS IN EXECUTION, ERRORLEVEL = %ERRORLEVEL%
ECHO **       Remedy depends on the available error messages from Java.
ECHO:
EXIT /B %ERRORLEVEL%

rem -----1---------2---------3---------4---------5---------6---------7----*

rem RUNNING practical100 CONFIRMATION PROGRAM Null01.

rem 0.02 2007-11-21-16:38 Changed to refer to 0.30-practical100 and to
rem      rely on a local copy of OdmJava.bat
rem 0.01 2007-11-18-20:54 Adjust to allow optional jar parameter so this
rem      test is usable with either practical100 development tree or
rem      with a jar at the classpath location.
rem 0.00 2006-12-17-20:55 Customize RunNull00 0.01 for use as initial
rem      RunNull01 script.

rem $Header: /ODMdev/info/odma/practical100/0.30-practical100/null01/RunNull01.bat 7     07-11-21 16:39 Orcmid $

rem                       *** end of RunNull01.bat ***