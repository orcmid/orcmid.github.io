/* OdmBasicDocumentMetadata.java 0.00 UTF-8                 dh:2007-11-12
 *
 * The OdmBasicDocumentMetadata interface is an independent interface that
 * defines delivery of common metadata available along with access to
 * document content and that may be independently delivered without any
 * access to the content.
 */


package info.odma.practical100;

public interface OdmBasicDocumentMetadata
{

    java.lang.String docID();
        /* For a known DMS-managed document, this method returns a string
           with the ODMA Document ID.

           ODMA Document IDs are intended to be opaque identifiers used in
           communication between ODMA-aware applications and ODMA-compliant
           DMS systems.  The ODMA Document ID is not intended to be human
           understandable.  In general, the ODMA Document ID is not to be
           displayed to users, although it may need to be recorded for
           future re-access to the same DMS-managed document.  It may also
           be transmitted in e-mail, stored as a link from another document,
           and provided to applications on their command lines as part of
           an automated application initiation in a workflow or other
           document-management related operation.

           Where possible, the dmsDocName() string is preferable for visible
           display to the user, with the docID restricted to technical
           purposes.

           WARNING: Each time content changes are commited to a DMS,
               docID() may change.

               Null response: null
           */


    java.lang.String dmsAuthor();
        /* For an available known document, dmsAuthor() is an user-readable
           text that is the name of the document's author as held by the
           DMS.  This name is in the localized form delivered by the DMS.

           It is valid for there to be a null response even though there has
           been successful document retrieval.

           WARNING: Each time content changes are commited to the DMS,
               dmsAuthor() may change.


               Null response: null

           */

    java.lang.String dmsDocName();
        /* For an available known document, dmsDocName() is an user-
           readable text that is the name of the document as maintained by
           the DMS.  This name is in the localized form delivered by the DMS
           system.

           It is valid for there to be a null response even though there has
           been successful document retrieval.

           When available, the dmsDocName() result is preferable over the
           ODMA Document ID for identification of the document to the user.

           WARNING: Each time content changes are commited to the DMS,
               dmsDocName() may change.


               Null response: null

           */


    java.lang.String dmsDocType();
        /* For a successful document access, dmsDocType() is a descriptive
           text that identifies the type of document from the perspective
           of the DMS system.  The document type is not related to the
           format of the document but to its application or use (invoice,
           pleading, memorandum, report, etc.)  This text is in the
           localized form delivered by the DMS system.

           It is valid for there to be a null response even though there has
           been successful document retrieval.

           WARNING: Each time content changes are commited to the DMS,
               dmsDocType() may change.


               Null response: null

           */


    java.lang.String dmsFormatName();
        /* For a successful document access, dmsFormatName() is the text
           that the dms employs as the Document Format Name.  This text is
           in the localized form delivered by the DMS system.

           The dmsFormatName() supplied by a DMS is not necessarily in the
           Document Format Name form that ODMJNI will accept from the
           application (e.g., as the parameter of an acceptAsNewDocument
           operation, below).

           It is valid for there to be a null response even though there has
           been successful document retrieval.

           WARNING: Although it would be unusual, it is possible that
               dmsFormatName() might change upon commiting content changes
               to the DMS.


               Null response: null

           */


    } /* OdmBasicDocumentMetadata */


/* 0.00 2007-11-12-17:00 Define by adapting methods originally declared
        directly on OdmViewingDocument.

   $Header: /ODMdev/info/odma/practical100/OdmBasicDocumentMetadata.java 1     07-11-12 17:03 Orcmid $
   */

/*  *** end of info.odma.practical100.OdmBasicDocumentMetadata.java ***  */