/* OdmEditingDocument.java 0.01      UTF-8                   dh:2007-11-13
 *
 * An OdmEditingDocument interface results from any operation that requests
 * access to an existing, editable ODMA DMS managed document.  Interface
 * methods must be used to determine whether or not there is a document
 * available and what further operations are appropriate.
 */


package info.odma.practical100;

public interface OdmEditingDocument extends OdmBasicDocumentMetadata,
                                            OdmViewingDocument
{   /* This extension of OdmViewingDocument provides a means to request
       that the DMS accept the changes made by the application program.

       XXX: The document can be notChangeable even though it is possible to
            open the file at OdmViewingDocument.docLocation for writing or
            appending.
       */


    boolean notChangeable();
        /* If notChangeable() is true, commitChanges is not permitted on
           this document.

           An unchangeable document can still be saved as a new document,
           whether in the local file system or to a DMS.  The DMS from which
           the document is retrieved might also permit the equivalent of a
           Save As ... operation in creating a new managed document derived
           from the first but not replacing the first.  (See the description
           of the OdmWorkingDocument interface.)

               Null response: true

           */


    boolean commitChanges()
                throws OdmError;
        /* This operation is used to deliver changes saved to the file
           at OdmViewingDocument.documentLocation().  The changes must
           be saved and the file closed before requesting this operation.
           The content should not be discarded from the application until
           it is known that the commitChanges() succeeded.

           If OdmDocument.operationSucceeded() is false, an unchecked
           OdmError exception is thrown.  This operation is not permitted
           when there is no actual document being represented by the
           interface.

           commitChanges() returns true when the operation succeeds.  It
           returns false when notChangeable() is true or there is failure
           for some other reason.

           If commitChanges() returns false, the application should
           treat the response as if localOperationRequested() were true,
           providing the user an opportunity to save work in some other way.

           If the commitChanges() succeeds, the OdmViewing document
           interface specifies the characteristics that now apply to the
           document.  All of the OdmViewingDocument information must be
           assumed to have changed, including docID(), docLocation(),
           windowTitle(), and the OdmBasicDocumentMetadata information.

           If an OdmEditingDocument interface is released and there has
           never been a commitChanges() operation, the DMS document is
           unchanged, regardless of anything that has been done using the
           OdmViewingDocument.docLocation().

               Null behavior: throws OdmError with indication that the
                              operation is not permissable with a null
                              document.
           */


    } /* OdmEditingDocument */


/* 0.01 2007-11-13-16:43 Revise the null behavior of notChangeable.
   0.00 2007-11-12-17:53 This new interface, between OdmViewingDocument
        and OdmWorkingDocument adds notChangeable and also takes the
        commitChanges operation from OdmWorkingDocument.

   $Header: /ODMdev/info/odma/practical100/OdmEditingDocument.java 2     07-11-12 18:03 Orcmid $
   */

/*    *** end of info.odma.practical100.OdmEditingDocument.java ***    */