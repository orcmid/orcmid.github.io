/* OdmWorkingDocument.java 0.09      UTF-8                   dh:2007-11-12
 *
 * An OdmWorkingDocument interface results from any operation that requests
 * access to an existing ODMA DMS managed document.  Interface methods must
 * be used to determine whether or not there is a document available and
 * what further operations are appropriate.
 *
 * OdmWorkingDocument extends OdmViewingDocument.  In the case that
 * OdmWorkingDocument.viewOnly() is true, only the OdmViewingDocument
 * operations are meaningful.  The additional OdmWorkingDocument methods
 * present null behavior.
 *
 * If OdmWorkingDocument.operationSucceeded() is false, the additional
 * OdmWorkingDocument methods also present null behavior.
 */

package info.odma.practical100;

public interface OdmWorkingDocument extends OdmBasicDocumentMetadata,
                                            OdmViewingDocument,
                                            OdmEditingDocument

{   /* corresponds to an existing managed DMS document.  If a document
       was successfully accessed, this interface provides for returning
       changes to be reflected in the DMS when changes are permitted.
       */

    /* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
       INTERIM DEFINITION.  When 0.60 is released, the transferTo-
       NewDocument method will be defined here.  It will no longer be
       available by extension from OdmViewingDocument.
       * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
       */

    } /* odmWorkingDocument */


/* 0.09 2007-11-12-18:05 commitChanges is moved to OdmEditingDocument.  This
        interface has no additional methods of its own until transferToNew-
        Document is moved here with release 0.60.
   0.08 2007-10-16-20:22 Corrected wordings and grammar in a number of
        places as part of the review for cases where OdmError will no
        longer be thrown.
   0.07 2006-12-17-20:20 Corrections to get clean compile in BuildClasses
   0.06 2006-12-17-15:17 Adjust null behavior, failure modes, and emphasize
        the consequences of release without committing changes.
   0.05 2006-12-14-14:02 Modify to extend OdmViewingDocument and add the
        commitChanges method.
   0.04 2006-10-22-20:39 Make the interface public.
   0.03 2006-10-22-16:53 Clean up comments for better explanation of how
        OdmWorkingDocument is created and what data is stable when.
   0.02 2006-10-22-16:27 provide clean compile sufficient for 0.05alpha.
   0.01 2006-10-22-15:59 rename as OdmWorkingDocument and extend the
        new OdmDocument intermediate interface.  Treat as separate from
        the OdmPendingDocument interface which is now being added
   0.00 2006-10-18-22:38 alpha-level version for the first evolutionary
        prototype of ODMJNI components.  This interface is intended to
        become stable very quickly during early testing and application
        integration.

   $Header: /ODMdev/info/odma/practical100/OdmWorkingDocument.java 11    07-10-16 20:23 Orcmid $
   */

/*    *** end of info.odma.practical100.OdmWorkingDocument.java ***    */