/* OdmFormatCheck.java 0.02          UTF-8                   dh:2007-11-05
 *
 * The OdmFormatInterface provides methods for verifying the format of
 * string parameters to ODMJNI 1.0 methods.
 *
 * These methods are intended for use by Java applications as a way of
 * verifying data obtained through external input.  If an ill-formed string
 * is submitted to an ODMJNI method, the method will quietly fail, returning
 * an appropriate null/failure response as documented for the method.
 *
 * Consequently, well-behaved applications must be designed to assure
 * that ODMJNI 1.0 methods are never being offered ill-formed string-valued
 * parameters.  The OdmFormatCheck methods are provided to filter
 * input from uncontrolled sources.
 */

 /* FIXME: These descriptions are torn from an implementation and are not
           abstracted enought.  Repair that before 0.60.
           */

package info.odma.practical100;

public interface OdmFormatCheck

{   /* XXX: This interface does not support checking of any string-valued
            parameters that must be supplied prior to the possible
            availability of an OdmFormatCheck interface.  wfAppId is not
            here for that reason.
       */

    int MAX_FORMAT_SIZE = 80;
        /* This measure is in octets using the codepage that applies for
           the DMS to which the Format is being specified.  A Java string
           of this length can still be too long but a string limited to
           this length is never too short.

           XXX: Although there is no additional restriction on the length
                for ODMJNI, there are ODMJNI-originated restrictions on
                the format of the Document Format Name.
           */

    boolean wfDocFormatName(java.lang.String docFormatName);
        /* Determines whether the docFormatName string is of appropriate
           format for specification to the DMS.

           XXX: Recent implementations use the definition in section 1.2 of
                the 0.30alpha Pre-Release Notes.  See
                <http://ODMA.info/dev/devNotes/2006/10/d061001f.htm>.
                There are further concerns to be addressed for 0.60 and
                beyond.
           */


    int MAX_DOCID_SIZE = 254;
        /* This measure is in octets using the codepage that applies for
           the DMS to which the DocId is submitted.  A Java string of
           this length can still be too long but a string limited to this
           length is never too short.

           XXX: One less than the Odma32types.h ODM_DOCID_MAX value, which
                includes allowance for a terminal '\0' not used in the Java
                String form.
           */


    int MAX_DMSID_SIZE = 8;
        /* Another octet-length limitation that a properly-formed Java
           String will also satisfy.  The character set is severely
           restricted for ODMJNI 1.0 for reasons similar to those that
           are applied to Application ID strings.

           XXX: One less than the Odma32types.h ODM_DMSID_MAX value.
                The same consideration apply here as for the coding of
                appId values.  */


    java.lang.String ODMPREFIX = "::ODMA\\";
        /* The ODMA Document ID is case insensitive, although
           applications are not to change case of docId values.
           Remember that '\\' is a single \-character.
           */


    int MAX_DOCIDPREFIX_SIZE = 16;
        /* "::ODMA\\12345678\\".length()
           or "::ODMA\\".length() + MAX_DMSID_SIZE + "\\".length()
           */


    boolean wfDocIdPrefix(java.lang.String docId);
        /* Determines whether the supplied docId has a well-formed prefix
           */


    java.lang.String prefixDmsId(java.lang.String docId);
        /* Given a well-formed prefix, extract the dmsId portion.
           Otherwise, return null */


    boolean wfDocId(java.lang.String docId);

        /* Determine whether the docId maps to the code page of the
           application process, whether the mapped string is of acceptable
           length, and verifies that the string has a well-formed prefix.

           XXX: This does not mean that there is a document with that Id
                and that custom format requirements of the DMS are honored.

           FIXME: A native version of this filter is required to ensure
                  that the only characters accepted are ones that map to
                  the code page applicable for the current DMS.  Not all
                  implementations of this interface are that thorough.
                  */


    boolean safeDocId(java.lang.String docId);

        /* Ensure that the Document ID is not only well-formed but also
           safe for a large number of interchange cases.

           XXX: This is one of those features for which restrictions
                are easier to remove rather than increase, later.

           FIXME: I am nervous about the few non-alphanumeric
                characters that I allow even here.  If there are to be
                *fewer* this must be resolved before 0.60beta and opening
                of ODMJNI to widespread download and review.
           */


    } /* OdmFormatCheck */



/* 0.02 2007-11-05-20:43 Change all _LENGTH constants to _SIZE constants
        to reflect that we are talking about storage, not characters, and
        we mean octets, not shorts or chars.
   0.01 2007-11-05-17:49 Add MAX_FORMAT_LENGTH parameter that was omitted
        for some reason.
   0.00 2007-10-31-20:38 Develop initial interface from the OdmFormat.java
        0.11 method signatures.

   $Header: /ODMdev/info/odma/practical100/OdmFormatCheck.java 3     07-11-05 20:46 Orcmid $
   */

/*      *** end of info.odma.practical100.OdmFormatCheck.java ***       */