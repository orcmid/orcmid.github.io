/* OdmNullBind.java 0.09             UTF-8                   dh:2007-11-10
 *
 * The OdmNullBind class has static methods that mirror the public methods
 * of the odmjni100 OdmJniBind class.
 *
 * This class provides an application() operation that instantiates a null
 * implementation in place of the active implementation of OdmJniBind.  Its
 * public methods mirror those of OdmJniBind even though the null connection
 * does not make use of any of the parameters.
 *
 * Typical start-up is via a statement such as
 *
 *      odmConnection myConnection = OdmNullBind.application("MyAppId");
 *
 * for console applications and
 *
 *      odmConnection myOdma = OdmNullBind.application( "MyAppId",
 *                                                      myWindow );
 *
 * for GUI applications.
 *
 * The class also provides the constant MAX_APPID_SIZE and the static method
 *
 *      boolean wfAppId(java.lang.String appId)
 *
 * for determining whether the appId string is a well-formed Application
 * ID.
 *
 * Any other methods of this class are reserved for private coordination
 * among the practical100 null-implementation classes.
 */

package info.odma.practical100;

public class OdmNullBind
{


    protected OdmNullBind()
    {   /* There is no instantiation of this class
           XXX: There are derived classes but they also have
                only static methods.
           */

        } /* OdmNullBind */


    public static final int MAX_APPID_SIZE = 15;
        /* The maximum size permitted for an Application ID String.

           XXX: The value is one less than the Odma32types100.h value of
                ODM_APPID_MAX, which provides for a terminal null character,
                '\0', that does not appear in Java strings.
           */

    public static boolean wfAppId(java.lang.String appId)

    {   /* determines whether appId is well-formed.  It must be a non-null
           String having no more than MAX_APPID_SIZE Unicode characters
           consisting of Basic Latin letters (a to z, A to Z) and digits
           (0 to 9).  This is an always-safe format, even when the ODMA
           Connection Manager might accept additional characters and even
           longer Application ID values.

           XXX: Implement the same rules as those of verifyAppId in
                 OdmNative100.cpp 0.28 (0.52beta).

           XXX: This filter is not used by OdmNullBind.application methods
                because a null connection implementation is returned
                regardless.  These rules are assured to never be stricter
                although there might be some relaxation in the future.  This
                will be left as a feature of OdmJniBind and other non-null
                implementations to determine.
           */

        if (appId == null) return false;

        if (appId.length() < 1 || appId.length() > MAX_APPID_SIZE)
             return false;

        for (int i = 0; i < appId.length(); i++)
            {   char code = appId.charAt(i);
                if (  code < '0'|| code > 'z'
                        || ( code > 'Z' && code < 'a' )
                        || ( code > '9' && code < 'A' )
                      )
                     return false;
                }

        return true;

        } /* wfAppId */



    public static
        OdmConnection
            application(java.lang.String appId)

    {   /* Associate the specified Application ID with the application
           and deliver an interface appropriate to the achievement of
           a binding or not. */

        return new OdmNullConnection();
             /* XXX: The appId is irrelevant for null implementations
                     and we demonstrate that by discarding it, avoiding
                     any possible reliance on an ill-formed one.
                     */

        } /* application */



    public static
        OdmConnection
            application( java.lang.String appId,
                          java.awt.Window appWindow )
                       throws OdmError

    {   /* Also associate a java application window with the ODMA
           Connection.  An OdmError will be thrown if the appWindow
           parameter is null.
           */

        return new OdmNullConnection(appWindow);
             /* XXX: Rely on the OdmNullConnection constructor
                     to verify that appWindow is non-null.
                     */

        } /* application */


    } /* OdmNullBind */



/* 0.09 2007-11-10-15:50 Make constructor protected so odmjni100 can
        extend this class for the OdmJniBind implementation.
   0.08 2007-11-09-16:13 Update comments on MAX_APPID_SIZE and wfAppId
        to be more generic and reflect the basic agreement.
   0.07 2007-11-06-15:48 Change to MAX_APPID_SIZE along with the change
        being made to all offering of these parameters by these interfaces.
   0.06 2007-11-05-20:28 Add MAX_APPID_LENGTH and the wfAppId method for
        simple use here.
   0.05 2007-10-17-15:42 Adjust to use new OdmNullConnection constructors
        that never see an appId.
   0.04 2007-10-16-17:37 Restore the throws clause on the
        application(appId, appWindow) case because of the possible failure
        with null appWindow and discard all appId parameters all the time.
   0.03 2007-10-15-15:19 Remove throws clauses now that OdmError is not
        thrown for parameter errors.
   0.02 2007-02-28-20:34 Clean up, add second application method.
   0.01 2006-12-17-20:05 corrections for clean compile.
   0.00 2006-12-17-19:35 Derive as an extremely-simplified version of
        odmjni100 OdmJniBind.

   $Header: /ODMdev/info/odma/practical100/OdmNullBind.java 11    07-11-09 16:31 Orcmid $
   */

/*        *** end of info.odma.practical100.OdmNullBind.java ***         */