/* OdmViewingDocument.java 0.11      UTF-8                   dh:2007-11-13
 *
 * An OdmViewingDocument interface results from any operation that requests
 * access to an existing ODMA DMS managed document.  Interface methods must
 * be used to determine whether or not there is a document available and
 * what further operations are appropriate.
 *
 * The OdmViewingDocument interface provides those behaviors that are usable
 * for any accessed document, editable or not.
 */


package info.odma.practical100;

public interface OdmViewingDocument extends OdmDocument,
                                            OdmBasicDocumentMetadata
{   /* corresponds to an existing DMS-managed document.  If the operation
       that delivers this interface is unsuccessful, operationSucceeded()
       will be false and there will be a null response for these functions.
       Otherwise, the original values will persist until a submission of
       changes to the document (e.g., OdmEditingDocument.commitChanges())
       or there is a release().
       */

    boolean viewOnly();
        /* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
           DEPRECATED FUNCTION.  IN 0.60 THIS METHOD IS REPLACED BY THE
           OdmEditingDocument.notChangeable() METHOD.
           * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *

           For a successful document access, viewOnly() returns true when
           any delivered content is not to be returned to the DMS, with or
           without changes.

           When viewOnly() is true, the document is not checked out for
           modification and no changes will be accepted by the DMS.

           When viewOnly() is true, the document should be displayed
           as if it is stored on the file system as a read-only document,
           whether it is or not.

           A view-only document can still be saved as a new document,
           whether in the local file system or to a DMS.  The DMS from which
           the document is retrieved might also permit the equivalent of a
           Save As ... operation in creating a new managed document derived
           from the first but not replacing the first.  (See the
           acceptAsNewDocument operation, below.)

               Null response: true

           XXX: When no document has been accessed, or the interface has
                been released, the result of viewOnly() is meaningless.
                However, true is the best response when there is no document
                available to view or do anything with.

           BREAKING CHANGE: This is a reversal of the previous null
                response.  It is a breaking change only for 0.59, since this
                method will be removed in 0.60.  The reversal was to have
                viewOnly() and notChangeable() be consistent, for now.
           */

           /* BASIC DOCUMENT METADATA
            * Those elements apply to documents whether or not they are
            * accessed or not.  The following additional elements apply
            * only when a document is being accessed.
            */

    java.lang.String docLocation();
        /* For a successful document access, docLocation() is a string
           with the location in the local file system where the ODMA DMS
           has delivered a copy of the DMS-managed document content.

           This is a temporary location and it should not be used as a
           permanent location for the delivered content.  If the document
           file in this location is successfully opened, it must be closed
           by the application, whether or not altered, before this interface
           is released.  It must also be closed before committing any
           changes, if that is allowed.


           Releasing the interface relinquishes all claims to the
           docLocation() file and the DMS or ODMJNI may delete the file at
           that point.

           WARNING: Each time content changes are commited to the DMS,
               docLocation() may change.


               Null response: null
           */


    java.lang.String windowTitle();
        /* For a successful document access, windowTitle() is an user-
           readable text that is the recommended identification of the
           retrieved document in the title bar of a window in which the
           document-file content is displayed for viewing and/or editing.
           This text is in the localized form delivered by the DMS.

           This text may have been truncated in delivery from the DMS.  It
           is permissable for it to be truncated further as part of display
           presentation.  In making such adjustments and accomodating
           possible changes in size of the display area, it is important to
           avoid splitting a Unicode surrogate pair.  Changes in writing
           direction and other accomodations of international language use
           will depend on whether such sophistication is delivered by the
           DMS.  Generally only simple language text is delivered to ODMA
           from DMS implementations.

           It is valid for there to be a null response even though there has
           been successful document retrieval.

           WARNING: Each time content changes are commited to the DMS,
               windowTitle() may change.


               Null response: null

           */


    OdmPendingDocument transferToNewDocument
                            (java.lang.String docFormatName)
                            throws OdmError;

        /* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
           BREAKING CHANGE #1: Although OdmError can be thrown for other
           reasons, there is no longer an exception for ill-formed
           docFormatName parameters.  If docFormatName is not well-formed
           and operationSucceeded() is true, this operation will return
           a failed null document.

           BREAKING CHANGE #2: Starting with release 0.60, this method will
           only be available via the OdmWorkingDocument interface.
           * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *

           For a successful document access, the transferToNewDocument
           operation invites the DMS which supplied the current document
           to create a new document using information known about the
           current document plus anything provided by interaction with the
           user.  This derivative document will be represented by a new
           OdmPendingDocument to be used in completion of content delivery
           for it.

           If the transfer request is accepted, the application must provide
           the desired content file using the returned OdmPendingDocument.

           Ordinarily, the new content will be that obtained from the
           retrieved document file, with or without changes, with or without
           alteration of the Document Format.

           The docFormatName parameter must be expressed in the same format
           accepted by OdmConnection.acceptNewDocument operations.  Don't
           use the dmsFormatName returned for the current document unless it
           has been verified as acceptable and intended.

           If the docFormatName is not a well-formed Document Format Name,
           a failed, null OdmPendingDocument is returned.

           The OdmPendingDocument that is returned will have the same
           characteristics as the OdmPendingDocument returned from an
           OdmConnection.acceptNewDocument(docFormatName) operation.

           IMPORTANT: This operation does not change the status of the
               current document in any way.  Release has not occured and
               if the file at docLocation() is open it must still be
               closed before any release is performed on the current
               interface.  It is permissible to have several new documents
               created by transfer from a single OdmViewingDocument.

               Null behavior: An unchecked OdmError exception is thrown
               if OdmViewingDocument.operationSucceeded() is false (that
               is, this OdmViewingDocument implementation is for a null
               document).

       */

    } /* OdmViewingDocument */


/* 0.11 2007-11-13-16:37 The breaking-change in viewOnly behavior is
        documented.  This should be harmless.
   0.10 2007-11-12-17:36 Revise to extend OdmBasicDocumentMetadata.  The
        viewOnly and transferToNewDocument are deprecated from this
        interface.
   0.09 2007-10-16-19:18 The transferToNewDocument is adjusted for the
        breaking change of no thrown OdmError when docFormatName is ill-
        formed.
   0.08 2006-12-17-14:43 Adjust for the 0.30beta approach to failure modes,
        document release, and null behaviors.
   0.07 2006-12-14-14:27 Change "acceptAsNewDocument" to "transferToNew-
        Document," making the impact a little more clear.
   0.06 2006-12-13-20:51 Customize throughout as OdmViewingDocument and
        expand with the 0.30beta added methods.
   0.05 2006-12-12-18:57 Branch to a new file to be customized from
        OdmWorkingDocument to OdmViewingDocument.
   0.04 2006-10-22-20:39 Make the interface public.
   0.03 2006-10-22-16:53 Clean up comments for better explanation of how
        OdmWorkingDocument is created and what data is stable when.
   0.02 2006-10-22-16:27 provide clean compile sufficient for 0.05alpha.
   0.01 2006-10-22-15:59 rename as OdmWorkingDocument and extend the
        new OdmDocument intermediate interface.  Treat as separate from
        the OdmPendingDocument interface which is now being added
   0.00 2006-10-18-22:38 alpha-level version for the first evolutionary
        prototype of ODMJNI components.  This interface is intended to
        become stable very quickly during early testing and application
        integration.

   $Header: /ODMdev/info/odma/practical100/OdmViewingDocument.java 8     07-11-12 17:38 Orcmid $
   */

/*    *** end of info.odma.practical100.OdmViewingDocument.java ***    */