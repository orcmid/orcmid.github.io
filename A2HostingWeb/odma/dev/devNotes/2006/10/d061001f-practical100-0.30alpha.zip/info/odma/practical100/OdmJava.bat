@echo off
rem OdmJava.bat 0.02                   UTF-8                  dh:2007-02-05
ECHO *    OdmJava.bat 0.02 ESTABLISH JAVA ENVIRONMENT FOR ODMJNI

rem **** TO CUSTOMIZE THIS SCRIPT, ADJUST THE THREE VALUES BELOW.
rem ****    Please make a backup copy of any modified script.  Code updates
rem ****    will reset this file to the previous or a later version.  Check
rem ****    the updates to see how to merge any further changes with your
rem ****    modifications.

rem LOCATION OF THE JAVA JDK ON THIS COMPUTER:
SET OdmJava=C:\Program Files\Java\jdk1.5.0_09
rem         ---------------------------------

rem LOCATION OF THE FOLDER WHERE ODMJNI CLASSPATHS START
SET OdmClasses=C:\MyProjects\java\ODMdev
rem            -------------------------

rem THE PACKAGE FOLDERS BELOW THE OdmClasses LOCATION.
rem THERE IS USUALLY NO NEED TO MODIFY THIS SETTING.
SET OdmPackage=info\odma\odmjni100
rem            -------------------

rem **** NO CHANGES ARE REQUIRED BELOW HERE.
rem **** ***********************************

IF NOT "%OdmJDK%" == "" GOTO :REPORT
rem    Don't set these if that's already been done.
rem    XXX: Can end up being contradictory settings to what we want.

SET OdmJDK=%OdmJava%
IF NOT EXIST "%OdmJDK%\bin\javac.exe" GOTO :FAIL1
PATH %OdmJDK%\bin;%OdmJDK%\jre\bin;%PATH%

:REPORT
IF NOT EXIST "%OdmJDK%\bin\javac.exe" GOTO :FAIL1
ECHO:         Using the Java SDK installed at %OdmJDK%
ECHO:         Using package class path at %OdmClasses%
ECHO:         and default package path %OdmPackage%
EXIT /B 0

:FAIL1
ECHO *    NO JAVA COMPILER AT %OdmJDK%\bin
ECHO *        Please adjust this OdmJava.bat file to correctly locate
ECHO *        The directory in which the Java JDK is installed.
SET OdmJDK=
ECHO /B 2

rem -----1---------2---------3---------4---------5---------6---------7----*

rem SET ENVIRONMENT TO USE JAVA JDK.  Specify the customization that
rem    may be required, and provide validation for any problems getting
rem    the procedure to work.  Note that it doesn't matter where this
rem    procedure is executed from, since all of its references are to
rem    absolute folder paths.


rem 0.02 2007-02-05-20:47 Add jre\bin to PATH for use of jawt.dll.
rem 0.01 2006-11-26-18:44 Review and touch up for consistency as part of
rem      the 0.20alpha odmjni integration.
rem 0.00 2006-11-11-21:17 Adaptation of MyJava.bat 0.05 used with
rem      practical100.

rem $Header: /ODMdev/info/odma/odmjni100/OdmJava.bat 4     07-02-05 21:00 Orcmid $

rem                     *** end of OdmJava.bat ***