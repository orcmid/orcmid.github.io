@echo off
rem CheckSetup00.bat 0.02            UTF-8                    dh:2006-11-04
echo CheckSetup00.bat 0.02
echo:
echo:
echo:    CHECKING YOUR VERSION AGAINST THE TestSetup00-reference VERSION
echo:
echo:    The TestSetup00-reference version was compiled using the current
echo:    BuildSetup00.bat script on the OdmNative development system.  It
echo:    should run on your computer without any special installation or
echo:    setup requirements.
echo:
echo:    The first test is to simply execute the reference version in the
echo:    OdmNative/test/setup00 folder.  Its successful performance is
echo:    confirmation that compilation on the development system resulted
echo:    in a complete, standalone executable.
echo:
if EXIST TestSetup00-reference.exe GOTO :RUNREF
echo:  ***** THE FILE TestSetup00-reference.exe IS NOT PRESENT IN THE
echo:    CURRENT FOLDER.  PLEASE EXECUTE THIS SCRIPT IN THE SAME FOLDER
echo:    AS THE FILE TestSetup00-reference.exe.
EXIT /B 2

:RUNREF
echo **** Ready? (Ctrl-C to exit)
pause
echo:
echo:
echo:
echo:
echo:
echo:
TestSetup00-reference.exe
echo:
echo:  SUCCESSFUL EXECUTION?
echo:
echo:    The file TestSetup00-reference.log lists the output that you
echo:    should see.
echo:
echo **** Ready to Continue? (Ctrl-C to exit)
pause
echo:
echo:
echo:
echo:
echo:
echo:
echo:    The next test is to compare the result of compiling on your machine
echo:    with the reference version.  There should be trivial differences.
echo:    You can compare your output with that in TestSetup00-reference.log.
echo:    The differences should be straightforward.
echo:
echo:    If you have already compiled one, we will use that.  If not, it
echo:    can be compiled as part of the current script.  Your system must
echo:    be set up to provide the expected development environment.
echo:
if EXIST TestSetup00.exe GOTO :RUN00
echo:  ***** THE FILE TestSetup.exe IS NOT PRESENT IN THE CURRENT FOLDER.
echo:    PLEASE ARRANGE TO COMPILE IT USING THE BuildSetup00.bat SCRIPT IN
echo:    THE FOLDER WITH TestSetup00-reference.exe.
echo:
if EXIST BuildSetup00.bat GOTO :BUILD
EXIT /B 2

:BUILD
echo **** Do you want to compile the program now?  (Ctrl-C to exit)
pause
CALL BuildSetup00.bat
if EXIST TestSetup00.exe GOTO :RUN00
echo:
echo:  **** The Build appears to have failed.  PLEASE CORRECT THE BUILD
echo:    AND RETRY AFTER SUCCEEDING
echo:
EXIT /B 2

:RUN00
echo:
echo **** Ready to execute your TestSetup00.exe?  (Ctrl-C to exit)
pause
echo:
echo:
echo:
echo:
echo:

TestSetup00.exe

echo:
echo:  SUCCESSFUL EXECUTION?
echo:    That concludes the CheckSetup00.bat script.
echo:
EXIT /B 1



rem -----1---------2---------3---------4---------5---------6---------7----*

rem COMPARE THE REFERENCE EXECUTION AND THE LOCAL ONE.

rem The script is essentially self-explanatory.

rem It is assumed that the Zip package has been extracted into a folder
rem <folder>, with all of the subdirectories in the Zip.  This script is
rem designed to run at <folder>\info\odma\OdmNative\test\setup00.

rem 0.02 2006-11-04-17:41 Adjust for consistent use of ERRORLEVEL in
rem      BuildSetup00.bat and those scripts that it uses.  Return
rem      ERRORLEVEL from this script to reflect getting to the end or not.
rem 0.01 2006-11-04-15:14 Adjust for the folder being moved to location
rem      test\setup00 in the development tree.
rem 0.00 2006-10-30-20:25 Simple script to confirm present of the files
rem      and simply run them, compiling the setup if necessary.

rem $Header: /MyProjects/java/ODMdev/info/odma/OdmNative100/test/setup00/CheckSetup00.bat 3     06-11-04 18:01 Orcmid $

rem                     *** end of CheckSetup00.bat ***