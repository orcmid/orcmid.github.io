@echo off
rem BuildSetup00.bat 0.04            UTF-8                    dh:2006-11-04
echo:
echo BuildSetup00.bat 0.04
echo:
echo BUILDING TestSetup00.exe CONFIRMATION OF OdmNative BUILD CONFIGURATION

IF NOT EXIST ..\..\OdmVC++.bat GOTO :NOSETTINGS
CALL ..\..\OdmVC++.bat
IF NOT ERRORLEVEL 2 GOTO :COMPILE

:NOSETTINGS
echo:
echo:
echo: **** SETTING VC++ COMMAND-LINE ENVIRONMENT FAILED.
echo: **** The initialization script OdmVC++.bat was not found or
echo: **** It failed to complete successfully.
echo:
echo: **** Folder %CD%
echo: **** should be two levels below the location of OdmVC++.bat.
echo: **** If it produces error messages, it may be necessary to
echo: **** adjust your computer configuration and the script.
echo:
EXIT /B 2

:COMPILE
echo:
echo:
echo: *****************************************************
echo: **** COMPILING TestSetup00.exe, A SIMPLE TEST PROGRAM
echo:

SET ERRORLEVEL=

CL /Za /WX TestSetup00.c

if ERRORLEVEL 1 GOTO :FAIL

echo:
echo: **** END OF COMPILATION ****
echo: ****************************
echo:
echo: There are no errors.  To confirm matching compilation and successful
echo: deployment of executables, execute the ConfirmSetup00.bat script.
EXIT /B %ERRORLEVEL%

:FAIL
echo:
echo: **** ERRORS OR WARNINGS IN COMPILATION, ERRORLEVEL = %ERRORLEVEL% ****
echo: To capture a log, run with redirection to a file or pipe the result
echo: of BuildSetup00 into a program like "more."
echo:
EXIT /B %ERRORLEVEL%

rem -----1---------2---------3---------4---------5---------6---------7----*

rem BUILD TESTSETUP TO CONFIRM MINIMAL OdmNative DEVELOPMENT SETUP
rem This script compiles a simple native console application to verify
rem the basic setup for development of the OdmNative class and interface.

rem It is assumed that the Zip package has been extracted into a folder
rem <folder>, extracting the Zipped subdirectory structure.  This script
rem is designed to run at <folder>\info\odma\OdmNative\test\setup00.

rem This directory can be on the same path as the development of other
rem ODMJNI components, <folder>\info\odma\practical100, the java interfaces
rem and <folder>\info\odma\odmjni, the code for the bridge between the Java
rem interfaces and the native connection class.


rem 0.04 2006-11-04-16:52 Change to use of OdmVC++.bat and add ERRORLEVEL
rem      handling to this procedure also.
rem 0.03 2006-11-04-15:04 Adjust to location in test/setup00 so that the
rem      test level is not cluttered by multiple tests and the setupNN
rem      directories can be used for both command-line compiles and as
rem      VC++ project folders if desired.  (We still only distribute the
rem      command-line versions.)  Have compiler warnings be treated as
rem      errors also.
rem 0.02 2006-10-30-22:05 Adjust to compile Standard C subset without any
rem      Microsoft extensions.
rem 0.01 2006-10-30-16:18 Bracket the compiler output better to make clear
rem      what the compiler output is.  Check the ERRORLEVEL after compiles.
rem 0.00 2006-10-30-14:11 Simple script without any sophistication beyond
rem      use of MyVC++.bat in the superior directory.

rem $Header: /MyProjects/java/ODMdev/info/odma/OdmNative100/test/setup00/BuildSetup00.bat 5     06-11-04 17:29 Orcmid $

rem                     *** end of BuildSetup00.bat ***