/* TestSetup00.c                      UTF-8                 dh:2006-10-30
 *
 * TestSetup00 is intended to provide simple verification of the following
 * aspects of the ODMJNI OdmNative development folder tree.
 *
 *  1. Confirm that the environment variables and paths are set properly
 *     for compilation of the program.
 *  2. Confirm that the simple .exe files compiled in this way will execute
 *     on other machines without having to be compiled there.
 *  3. Confirm some basic presentation data to be re-used for command-line
 *     test programs developed under the ODMJNI effort.
 *
 * This is a C Language program.  We will use C Language and native Windows
 * APIs whenever we do not require C++ classes and COM interfaces accessed
 * as C++ abstract classses.  We also use "Clean C" wherever possible.
 */

 #include <stdio.h>
    /* For FILE, fputs, stdout, ... */


 static void hello(FILE *out)
 {  /* Tell them who's here. */

    fputs("\nTestSetup00> 0.02 Verify Build Setup "
               "for ODMJNI OdmNative Development in VC++\n",
          out);
    }

/*              TestSetup00> */
#define INDENT "             "
#define STARS  "        **** "

static const char indent[] = INDENT;
static const char stars[] =  STARS;


static void goodbye(FILE *out)
{   /* Tell them who's leaving. */

    fputs("\nTestSetup00> exit\n\n", out);
    }


 int main(const int argc, char* argv[])
 {  /* Make simple console application with no command-line parameters.
       This program uses minimalist output statements because we can.
       */

    hello(stdout);

    fputs(INDENT "Program " __FILE__ " dated " __TIMESTAMP__ "\n",
          stdout);
    fputs(INDENT "Compiled at " __TIME__ " on " __DATE__ ,
          stdout);

#if defined(__cplusplus)
    fputs(" as C++", stdout);
#elif defined(__STDC__)
    fputs(" as Standard C", stdout);
#elif defined(_MSC_VER)
    fputs(" as Visual C", stdout);
#else
    fputs(" as C Language", stdout);
#endif
#if defined(_MSC_EXTENSIONS)
    fputs(" extended", stdout);
#endif
    fputs("\n\n", stdout);

    fputs(INDENT "That's all.\n\n", stdout);

    goodbye(stdout);

    return 0;
    } /* main */


/* 0.02 2006-10-30-22:10 Enough is demonstrated for moving on to the
        next stage.
   0.01 2006-10-30-21:44 Add additional descriptive information for
        comparing between a reference compilation and a local recompile.
   0.00 2006-10-30-14:49 Elementary display of successful compilation
        result for confirmation of the setup.

   $Header: /MyProjects/java/ODMdev/info/odma/OdmNative100/test/TestSetup00.c 2     06-10-30 22:17 Orcmid $
   */

/*                          *** end of TestSetup00.c ***                */