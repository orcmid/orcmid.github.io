@echo off
rem BuildOdmWorking100.bat 0.00      UTF-8                    dh:2006-12-31
ECHO ***  BuildOdmWorking.bat 0.02 COMPILE OdmWorking100.obj FOR STATIC USE

IF NOT EXIST OdmPSDK.bat GOTO :FAIL0
CALL OdmPSDK.bat
IF NOT ERRORLEVEL 2 GOTO :Compile
ECHO *** BuildOdmWorking100.bat ABORTED.  SEE OdmPSDK.bat ERROR MESSAGES.
ECHO:
EXIT /B %ERRORLEVEL%

:Compile
IF NOT EXIST OdmWorking100.cpp GOTO :FAIL1

SET ERRORLEVEL=
cl /WX /c OdmWorking100.cpp
rem     Compile only and fail on all warnings
rem     FIXME: Try optimization settings at some point.
if ERRORLEVEL 1 GOTO :FAIL2

echo:
echo ***  OdmWorking100.obj COMPILED SUCCESSFULLY
echo ***  **************************************
echo:
echo:     There are no errors or warnings.  This .obj is included directly
echo:     in builds of other programs and in OdmNative100.lib.
echo:
EXIT /B 0


:FAIL0
ECHO:
ECHO ***  EXECUTE BuildOdmWorking100.bat IN THE DIRECTORY THAT HOLDS IT.
ECHO ***      The OdmPSDK.bat script must be available in the same place.
ECHO ***      Verify your OdmNative100 configuration and ensure that the
ECHO ***      directory holding BuildOmdWorking100.bat is the current
ECHO ***      working directory before the script is invoked.
ECHO:
EXIT /B 2


:FAIL1
ECHO:
ECHO ***  FILE OdmWorking100.cpp IS NOT PRESENT IN THE CURRENT DIRECTORY
ECHO ***      BuildOdmWorking100.bat aborted.  OdmWorking100.cpp is expected
ECHO ***      to be in the same directory.
ECHO:
EXIT /B 2


:FAIL2
echo:
echo ***  ERRORS OR WARNINGS IN COMPILATION, ERRORLEVEL = %ERRORLEVEL% ****
echo ***      To capture a log, run with redirection to a file or pipe the
echo ***      result of BuildOdmWorking100.bat into a program like "more."
echo:
EXIT /B %ERRORLEVEL%


rem -----1---------2---------3---------4---------5---------6---------7----*

rem COMPILE OBJECT CODE FOR THE OdmWorking100 Implementation.

rem 0.00 2006-12-31-18:05 Customized directly from BuildOdmNative100 0.02

rem $Header: /ODMdev/info/odma/OdmNative100/BuildOdmWorking100.bat 1     06-12-31 18:07 Orcmid $

rem                 *** end of BuildOdmWorking100.bat ***