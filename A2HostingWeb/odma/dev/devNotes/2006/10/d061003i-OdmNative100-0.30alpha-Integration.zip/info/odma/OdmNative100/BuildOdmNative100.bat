@echo off
rem BuildOdmNative100.bat 0.03       UTF-8                    dh:2006-12-31
ECHO ***  BuildOdmNative.bat 0.03 COMPILE OdmNative100.obj FOR STATIC USE

IF NOT EXIST OdmPSDK.bat GOTO :FAIL0
CALL OdmPSDK.bat
IF NOT ERRORLEVEL 2 GOTO :Compile
ECHO *** BuildOdmNative100.bat ABORTED.  SEE OdmPSDK.bat ERROR MESSAGES.
ECHO:
EXIT /B %ERRORLEVEL%

:Compile
IF NOT EXIST OdmNative100.cpp GOTO :FAIL1

SET ERRORLEVEL=
cl /WX /c OdmNative100.cpp
rem     Compile only and fail on all warnings
rem     FIXME: Try optimization settings at some point.
if ERRORLEVEL 1 GOTO :FAIL2

echo:
echo ***  OdmNative100.obj COMPILED SUCCESSFULLY
echo ***  **************************************
echo:
echo:     There are no errors or warnings.  This .obj is included directly
echo:     in builds of other programs and in OdmNative100.lib.
echo:
EXIT /B 0


:FAIL0
ECHO:
ECHO ***  EXECUTE BuildOdmNative100.bat IN THE DIRECTORY THAT HOLDS IT.
ECHO ***      The OdmPSDK.bat script must be available in the same place.
ECHO ***      Verify your OdmNative100 configuration and ensure that the
ECHO ***      directory holding BuildOmdNative100.bat is the current working
ECHO ***      directory before the script is invoked.
ECHO:
EXIT /B 2


:FAIL1
ECHO:
ECHO ***  FILE OdmNative100.cpp IS NOT PRESENT IN THE CURRENT DIRECTORY
ECHO ***      BuildOdmNative100.bat aborted.  OdmNative100.cpp is expected
ECHO ***      to be in the same directory.
ECHO:
EXIT /B 2


:FAIL2
echo:
echo ***  ERRORS OR WARNINGS IN COMPILATION, ERRORLEVEL = %ERRORLEVEL% ****
echo ***      To capture a log, run with redirection to a file or pipe the
echo ***      result of BuildOdmNative100.bat into a program like "more."
echo:
EXIT /B %ERRORLEVEL%


rem -----1---------2---------3---------4---------5---------6---------7----*

rem COMPILE OBJECT CODE FOR THE OdmNative100 Entries and Classes.

rem 0.03 2006-12-31-18:12 Clean up text to reflect the current approach,
rem      and correct names of modules in messages.
rem 0.02 2006-11-25-19:07 Modify to be BuildOdmNative100.bat for standalone
rem      building of OdmNative100.obj as part of the 0.20alpha integration.
rem 0.01 2006-11-17-21:56 Correct the success messages to refer to the
rem      .obj file, not any DLL.
rem 0.00 2006-11-16-19:55 customized from odmjni BuildDLL01a.bat 0.02

rem $Header: /ODMdev/info/odma/OdmNative100/BuildOdmNative100.bat 12    06-12-31 18:14 Orcmid $

rem                 *** end of BuildOdmNative100.bat ***