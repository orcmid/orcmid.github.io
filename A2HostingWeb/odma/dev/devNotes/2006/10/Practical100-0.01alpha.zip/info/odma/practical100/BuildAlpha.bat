@echo off
rem BuildAlpha.bat                   UTF-8                    dh:2006-10-18
echo:     Building Package info.odma.practical100 0.01alpha Version
CALL MyJava.bat

echo:
echo:     Compiling info.odma.practical100.Document interface
javac -cp "$CLASSPATH;%MyClasses%" Document.java

echo:
echo:     Compiling info.odma.practical100.Connection interface
javac -cp "$CLASSPATH;%MyClasses%" Connection.java

echo:
echo:     End of compilation.
EXIT /B

rem -----1---------2---------3---------4---------5---------6---------7----*

rem BUILD THE ALPHA PROTOTYPE FOR PACKAGE info.odma.practical100
rem This script compiles everything needed to exercise the alpha-level
rem prototype of ODMJNI 1.0 source code.

rem It is assumed that the Zip package has been extracted into a folder
rem <folder>, and this script is at <folder>\info\odma\practical100\

rem The file-system path <folder> is usable as a CLASSPATH setting.  This
rem script must be executed with <folder>\info\odma\practical101\ as the
rem current working directory.  The MyJava.bat defines <folder> as the
rem value of the %MyClasses% environment variable.


rem 0.01 2006-10-18-23:52 Clean compilation of the two public interface
rem      definitions, initial prototype level.
rem 0.00 2006-10-18-18:45 Null version for verification of the basic.
rem      structure without compiling anything.

rem $Header: /MyProjects/java/ODMdev/info/odma/practical100/BuildAlpha.bat 2     06-10-18 23:54 Orcmid $

rem                      *** end of BuildAlpha.bat ***