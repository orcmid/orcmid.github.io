@echo off
rem MyJava.bat                       UTF-8                  dh:2006-10-18
rem        TO CUSTOMIZE THIS SCRIPT, JUST CHANGE THE SET VALUES BELOW.

rem        Location of your Java JDK:
SET MyJava=C:\Program Files\Java\jdk1.5.0_09
rem        ---------------------------------

rem           Location of the directory containing the subfolders
rem           info\odma\practical100:
SET MyClasses=C:\MyProjects\java\ODMdev
rem           -------------------------

rem        NO CHANGES ARE REQUIRED BELOW HERE.
IF NOT "%MyJDK%" == "" GOTO :REPORT
SET MyJDK=%MyJava%
PATH %MyJDK%\bin;%PATH%

:REPORT
ECHO:     Using the Java SDK installed at %MyJDK%
ECHO:     Using package class path at %MyClasses%
ECHO:     Working at %MyClasses%\info\odma\practical100
cd "%MyClasses%\info\odma\practical100"
EXIT /B

rem -----1---------2---------3---------4---------5---------6---------7----*

rem SET ENVIRONMENT TO USE JAVA JDK.  Customize the SET statement here to
rem locate the JDK that is to be used for compiling and executing the
rem software in this folder.

rem 0.03 2006-10-19-00:00 Expand to automatically switch to the location
rem      of the source code if not already there.
rem 0.02 2006-10-18-18:20 Modification to conditionally define MyJDK
rem      if it is not already defined.  This is avoides redundant
rem      additions to the PATH variable.  It also permits over-riding
rem      from a preceding definition.
rem 0.01 2006-10-15-15:40 Version created for JDK 1.5.0_09 on Win32.
rem      This is the version installed for ODMJNI Java development.

rem $Header: /MyProjects/java/ODMdev/info/odma/practical100/MyJava.bat 3     06-10-19 0:04 Orcmid $

rem                     *** end of MyJava.bat ***