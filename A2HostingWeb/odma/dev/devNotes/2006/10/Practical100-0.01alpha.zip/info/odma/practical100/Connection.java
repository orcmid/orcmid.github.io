/* info.odma.practical100.Connection.java                    0.01alpha
 * The Connection interface provides a simple reference to ODMA that
 * should be held for the duration of an ODMA-aware applications
 * operation.
 */

package info.odma.practical100;

interface Connection
{
    boolean connectionAvailable();
        /* True when there is an ODMA connection available for use.
           When the result is false, all operations provide null
           responses.
           */

    Document acceptNewDocument();
        /* Used to offer content for making a new managed document.
           This is often for a fresh document that has just been
           created in an application.  It can also be for a "Save As ..."
           of content obtained from a different location or DMS.
              Information available through the returned Document interface
           indicates whether the document should be delivered to the
           DMS or some other course of action is required.
              If there is no connection available, a "null-document"
           is returned with indication that the application should use its
           own dialog for determining how to save the new document.
              FIX ME: There are enough differences between this and
           the existing-document cases that a PendingDocument interface
           be defined for the result of this operation.  We're using
           Document for now just so the first two interfaces can
           compile.
           */

    Document chooseDocument();
        /* Requests that the ODMA DMS choose a document for the application
           to use.  This is typically when the application user requests
           opening of a document.  The ODMA connection is given first
           refusal.
              Information available through the returned Document interface
           indicates whether a managed-document has been returned for the
           application's use or a different course of actions is required
              If there is no connection available, a "null-document" is
           returned with indication that the application should use its
           own dialog for choosing a document.
           */

    Document openKnownDocument(java.lang.String docID);
        /* Requests that the ODMA connection open a known managed document
           having the ODMA Document ID supplied for the docID parameter.
              If the identified document is accessible and the application
           account is authorized to obtain it, the request is handled the
           same as if the identified document had been selected in a
           chooseDocument() operation.
              If there is no connection available, a "null-document" is
           returned with indication that there is no DMS for providing
           the document.
              FIX ME: This operation will not accept an ill-formed docID
           and an unchecked exception will be thrown, in the same manner
           as for ill-formed appID.  Although the exception is unchecked,
           its class should be declared in this package and it should
           be documented as thrown by this method.
           */

    void close();
        /* Announces that the application has no further use for this
           interface, permitting connection resources to be released as
           soon as possible.  Following close(), connectionAvailable()
           always returns false and all operations provide their null
           responses.
           */
    } /* Connection */


/* 0.01 2006-10-19-00:09 Obtain clean compilation
   0.00 2006-10-18-21:40 alpha-level version for the first evolutionary
        prototype of ODMJNI components.  This interface is intended to
        become stable very quickly during early testing and application
        integration.

   $Header: /MyProjects/java/ODMdev/info/odma/practical100/Connection.java 3     06-10-19 0:10 Orcmid $
   */

/*         *** end of info.odma.practical100.Connection.java ***        */