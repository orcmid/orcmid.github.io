/* info.odma.practical100.Document.java                    0.00alpha
 * Document interfaces provide the response to document requests of an
 * ODMJNI document-request operation.  Those operations always return
 * a Document interface.  Methods of the interface must be used to
 * determine whether or not there is a document available.
 */

package info.odma.practical100;

interface Document
{
    boolean operationSucceeded();
        /* True when the last operation involving this Document interface
           succeeded.  The first operation with a Document interface is
           always the Connection operation that gives rise to it.  The
           docLocation(), docID(), and related operations only have
           meaningful results when operationSucceeded() is initially true.
           */

    java.lang.String docLocation();
        /* For a successful Document interface creation, this method
           returns a string specifying the location in the local file
           system where the ODMA DMS has delivered a copy of the
           DMS-managed document content for use by the application.
              When the operation that returned this Document interface
           is unsuccessful, a null String reference will be returned.
              FIX ME.  It is clearly appropriate to have a PendingDocument
           interface for the cases docLocation() is the place for the
           application to deliver the content to the ODMA DMS, rather than
           obtain from the DMS.  This will be caught in the next revision
           of the null implementation.
           */

    java.lang.String docID();
        /* For a successful Document interface creation, this method
           returns a string specifying the ODMA Document ID of the
           managed document whose content is delivered at docLocation().
              When the Document interface is returned for an unsuccessful
           operation, this operation returns a null String reference.
           */

    /* FIX ME.  There are further operations for obtaining descriptive
       information about the current document, when the operation that
       delivered the interface was successful.  These will be filled in
       later.  They all produce null results when there is no document
       to use.
       */

    boolean operationCancelled();
        /* True when the operation did not succeed because it was
           cancelled, often at the request of the application operator
           through interaction with the DMS.
           */

    boolean localOperationRequested();
        /* True when the operation did not succeed because the application
           operator, or ODMA, report that the application should provide
           a local operation instead of using an ODMA DMS operation.
           */

    boolean dmsAvailable();
        /* True when there is a connection to  available for use.
           When the result is false, there is no ODMA DMS document
           to work with.  The methods defined above provide details
           on which an appropriate course of action can be based.
              If the Connection that provides this Document has
           connectionAvailable() false, then dmsAvailable is also
           false.  dmsAvailable() can also be false under other
           conditions.
              When dmsAvailable() is false, none of the following
           operations (except close()) have any effect.
           */

    /* FIX ME: There are a few additional operations that can be performed,
       such as returning a modified document, releasing the document
       without any changes, and so on, that need to be defined.  That will
       matter when we have non-null ODMJNI connection-creation classes
       to use.
       */

    void close();
        /* Announces that the application has no further use for this
           interface, permitting document-connection resources to be released as soon as possible.  Following close(), the  connectionAvailable() operation always returns false.
              IMPORTANT: Closing the Document interface does not return
           any changed document to the DMS.  Other methods must be used
           to accomplish that before closing and/or abandoning the
           Document interface
              FIX ME.  Those other operations aren't defined yet.
           */
    } /* Connection */


/* 0.00 2006-10-18-22:38 alpha-level version for the first evolutionary
        prototype of ODMJNI components.  This interface is intended to
        become stable very quickly during early testing and application
        integration.

   $Header: /MyProjects/java/ODMdev/info/odma/practical100/Document.java 2     06-10-18 23:24 Orcmid $
   */

/*         *** end of info.odma.practical100.Connection.java ***        */