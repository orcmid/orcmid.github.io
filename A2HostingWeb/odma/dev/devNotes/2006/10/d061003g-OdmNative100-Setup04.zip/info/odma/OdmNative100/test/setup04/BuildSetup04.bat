@echo off
rem BuildSetup04.bat 0.20            UTF-8                    dh:2006-11-25
ECHO ***  BuildSetup04.bat 0.20alpha Setup04.cpp OdmBindNative100 Regression

IF NOT EXIST ..\..\OdmPSDK.bat GOTO :FAIL0
pushd ..\..\
CALL OdmPSDK.bat
popd
IF NOT ERRORLEVEL 2 GOTO :Compile
ECHO ***  BuildSetup04.bat ABORTED.  SEE THE OdmPSDK.bat ERROR MESSAGES.
ECHO:
EXIT /B %ERRORLEVEL%

:Compile
IF NOT EXIST Setup04.cpp GOTO :FAIL1

SET ERRORLEVEL=
cl /WX /MT /I..\..\ Setup04.cpp ..\..\OdmNative100.obj user32.lib
if ERRORLEVEL 1 GOTO :FAIL2

echo:
echo ***  Setup04.exe COMPILED
echo ***  ********************
echo:
echo:     There are no errors or warnings.  This program can be run
echo:     as Setup04.exe.  This is a standalone program.  It can be
echo:     run anywhere on Windows 2000 or later versions.
echo:
echo:     The program Setup04-reference.exe provides the result of the
echo:     0.20alpha OdmApplication regression check for comparison.
echo:
EXIT /B 0


:FAIL0
ECHO:
ECHO ***  EXECUTE BuildSetup04.bat IN THE DIRECTORY THAT HOLDS IT.
ECHO ***      The OdmPSDK.bat script must be available two levels above.
ECHO ***      Verify your Setup04 configuration and ensure that the
ECHO ***      directory holding BuildSetup04.bat is the current working
ECHO ***      directory before the script is invoked.
ECHO:
EXIT /B 2


:FAIL1
ECHO:
ECHO ***  THE Setup04.cpp FILE IS NOT PRESENT IN THE CURRENT DIRECTORY
ECHO ***      The file should be in the same directory as this BuildSetup04
ECHO ***      script.  BuildSetup04.bat aborted.
ECHO:
EXIT /B 2


:FAIL2
echo:
echo ***  ERRORS OR WARNINGS IN COMPILATION, ERRORLEVEL = %ERRORLEVEL%
echo ***      To capture a log, run with redirection to a file or pipe the
echo ***      result of BuildSetup04 into a program like "more."
echo:
EXIT /B %ERRORLEVEL%


rem -----1---------2---------3---------4---------5---------6---------7----*

rem BUILD C++ Setup04 PROGRAM TO TEST OdmBindNative100 Basic Connection.

rem 0.20 2006-11-25-22:22 Adjust to work as a regression test on the
rem      0.20alpha build of OdmNative100.obj.  The OdmNative directory
rem      is added to the compiler include path and the OdmNative.obj is
rem      obtained from the same directory.
rem 0.02 2006-11-23-20:57 Add user32.lib into the build.
rem 0.01 2006-11-16-20:56 Add OdmNative100.obj into the build.
rem 0.00 2006-11-16-18:29 customized from odmjni100 BuildDLL001a.bat 0.02

rem $Header: /ODMdev/info/odma/OdmNative100/test/setup04/BuildSetup04.bat 10    06-11-25 22:28 Orcmid $

rem                       *** end of BuildSetup04.bat ***