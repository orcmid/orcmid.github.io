@echo off
rem BuildTest.bat                   UTF-8                    dh:2006-10-23
echo:     BUILDING TESTS FOR info.odma.practical100 0.05alpha
echo:

echo:     Initialize the Environment and Build needed Alpha Files First
cd ..
CALL BuildAlpha.bat
cd test

echo:
echo:     Building Tests in %CD%

echo:
echo:     Compiling IConIO Console I-O Helper Interfaces
javac IConIO.java

echo:
echo:     Compiling ConIO Console I-O Helper Implementations
javac ConIO.java

echo:
echo:     Compiling the TestNullConnection test program.
javac -cp ".;%MyClasses%" TestNullConnection.java

echo:
echo:     End of Test Program compilations.  Use the RunTest.bat script
echo:     to see the test results.  The file TestNullConnection.log
echo:     shows typical successful results.
echo:
EXIT /B

rem -----1---------2---------3---------4---------5---------6---------7----*

rem BUILD TEST PROGRAMS FOR PACKAGE info.odma.practical100
rem This script compiles everything needed to test the alpha-level
rem prototype of ODMJNI 1.0 source code.

rem It is assumed that the Zip package has been extracted into a folder
rem <folder>, and this script is at <folder>\info\odma\practical100\test

rem It is also assumed that the MyJava.bat in folder practical100 has
rem been customized as explained in that file.  The present script must be
rem executed with <folder>\info\odma\practical101\test as the current
rem working directory.


rem 0.04 2006-10-24-00:14 Clean up instructions at the end and use for the
rem      0.05alpha delivery.
rem 0.03 2006-10-23-19:37 spell ConIO.java correctly and put this directory
rem      in the explicit class path.
rem 0.02 2006-10-23-17:35 updated to include compilation of the console
rem      input-output helpers and compile TestNullConnection.java
rem 0.01 2006-10-23-16:34 Adapted for 0.05alpha testing by customization
rem      of BuildAlpha.bat 0.08.

rem $Header: /MyProjects/java/ODMdev/info/odma/practical100/test/BuildTest.bat 13    06-10-24 0:15 Orcmid $

rem                      *** end of BuildTest.bat ***