@echo off
rem BuildAlpha.bat                   UTF-8                    dh:2006-10-18
echo:     Building Package info.odma.practical100 0.05alpha Version

CALL MyJava.bat

echo:
echo:     Compiling info.odma.practical100 interfaces and null behaviors
javac -cp "$CLASSPATH;%MyClasses%" OdmNullConnection.java

echo:
echo:     End of compilation.
EXIT /B

rem -----1---------2---------3---------4---------5---------6---------7----*

rem BUILD THE ALPHA PROTOTYPE FOR PACKAGE info.odma.practical100
rem This script compiles everything needed to exercise the alpha-level
rem prototype of ODMJNI 1.0 source code.

rem It is assumed that the Zip package has been extracted into a folder
rem <folder>, and this script is at <folder>\info\odma\practical100\

rem The file-system path <folder> is usable as a CLASSPATH setting.  This
rem script must be executed with <folder>\info\odma\practical101\ as the
rem current working directory.  The MyJava.bat defines <folder> as the
rem value of the %MyClasses% environment variable.


rem 0.08 2006-10-23-00:15 Simplify to build everything from compilation
rem      of the OdmNullConnection.java program.  It draws on all of the
rem      interfaces and other package classes in 0.05 alpha.
rem 0.07 2006-10-22-17:01 Add and verify compilation of the new
rem      OdmConnection interface, completing the 0.05alpha interfaces.
rem 0.06 2006-10-22-16:47 Add and verify compilation of the new
rem      OdmPendingDocument interface.
rem 0.05 2006-10-22-16:25 Add and verify compilation of the new
rem      OdmWorkingDocument interface.
rem 0.04 2006-10-22-15:36 Add and verify compilation of the new
rem      OdmDocument interface.
rem 0.03 2006-10-22-13:55 Add and verify compilation of OdmInterface.
rem 0.02 2006-10-20-17:00 Update with new names for classes.
rem 0.01 2006-10-18-23:52 Clean compilation of the two public interface
rem      definitions, initial prototype level.
rem 0.00 2006-10-18-18:45 Null version for verification of the basic.
rem      structure without compiling anything.

rem $Header: /MyProjects/java/ODMdev/info/odma/practical100/BuildAlpha.bat 7     06-10-23 0:18 Orcmid $

rem                      *** end of BuildAlpha.bat ***