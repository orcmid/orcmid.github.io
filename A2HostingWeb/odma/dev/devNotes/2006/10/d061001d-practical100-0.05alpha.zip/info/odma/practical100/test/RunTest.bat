@echo off
rem RunTest.bat                   UTF-8                    dh:2006-10-23
echo:     PERFORMING NULL CONNECTION TEST
echo:

cd ..
CALL MyJava.bat
cd test

echo:
echo:     Testing in %CD%

echo:
java -cp ".;%MyClasses%" TestNullConnection
EXIT /B

rem -----1---------2---------3---------4---------5---------6---------7----*

rem RUN TEST PROGRAMS FOR PACKAGE info.odma.practical100
rem This script runs the available tests.

rem 0.01 2006-10-23-21:20 Built to use the class path correctly.

rem $Header: /MyProjects/java/ODMdev/info/odma/practical100/test/RunTest.bat 1     06-10-23 21:29 Orcmid $

rem                      *** end of RunTest.bat ***