@echo off
rem CheckSetup01.bat 0.02            UTF-8                    dh:2006-11-07
ECHO: CheckSetup01.bat 0.02
ECHO:
ECHO:    CHECKING YOUR VERSION AGAINST THE TestSetup01-reference VERSION
ECHO:
ECHO:    The TestSetup01-reference version was compiled using the current
ECHO:    BuildSetup01.bat script on the OdmNative development system.  It
ECHO:    should run on your computer without any special installation or
ECHO:    setup requirements.
ECHO:
ECHO:    The first test is to simply execute the reference version in the
ECHO:    OdmNative/test/setup01 folder.  That is to confirm that the
ECHO:    compilation on the development system resulted in a complete,
ECHO:    standalone executable that works when moved to another system.
ECHO:
IF EXIST TestSetup01-reference.exe GOTO :RUNREF
ECHO:  **** THE FILE TestSetup01-reference.exe IS NOT PRESENT IN THE
ECHO:  ****   CURRENT FOLDER.  Please execute this script in the same folder
ECHO:  ****   as the file TestSetup01-reference.exe.
EXIT /B 2

:RUNREF
ECHO **** Ready? (Ctrl-C to exit)
PAUSE
ECHO:
ECHO:
ECHO:
ECHO:
SET ERRORLEVEL=
TestSetup01-reference.exe
ECHO:
ECHO:  SUCCESSFUL EXECUTION?  REPORTED ERRORLEVEL = %ERRORLEVEL%
ECHO:    The file TestSetup01-reference.log lists the output that you
ECHO:    should see.  However, if the ODMA Connection Manager is not
ECHO:    installed on your system, you will see a different result.
echo:
ECHO **** Ready to Continue? (Ctrl-C to exit)
PAUSE
ECHO:
ECHO:
ECHO:
ECHO:
ECHO:    The next test is to compare the result of compiling on your machine
ECHO:    with the reference version.  There should be minor differences.
ECHO:    You can compare your output with that of TestSetup01-reference.
ECHO:    The differences should be straightforward.
ECHO:
IF EXIST TestSetup01.exe GOTO :RUN01
ECHO:  **** THE FILE TestSetup.exe IS NOT PRESENT IN THE CURRENT FOLDER.
ECHO:  ****   Please arrange to compile it using the BuildSetup01.bat script
ECHO:  ****   in the folder with TestSetup01-reference.exe.
ECHO:
if EXIST BuildSetup01.bat GOTO :BUILD
EXIT /B 2

:BUILD
ECHO **** Do you want to compile the program now?  (Ctrl-C to exit)
PAUSE
ECHO:
CALL BuildSetup01.bat
if EXIST TestSetup01.exe GOTO :RUN01
ECHO:
ECHO:  **** THE BUILD APPEARS TO HAVE FAILED WITH ERRORLEVEL = %ERRORLEVEL%.
ECHO:  **** Please correct the build and retry after succeeding.
ECHO:
EXIT /B %ERRORLEVEL%

:RUN01
ECHO:
ECHO **** Ready to execute your TestSetup01.exe?  (Ctrl-C to exit)
PAUSE
ECHO:
ECHO:
ECHO:
ECHO:
SET ERRORLEVEL=
TestSetup01.exe
ECHO:
ECHO:  SUCCESSFUL EXECUTION?  ERRORLEVEL = %ERRORLEVEL%.
ECHO:    That concludes the CheckSetup01.bat script.
ECHO:
EXIT /B %ERRORLEVEL%



rem -----1---------2---------3---------4---------5---------6---------7----*

rem COMPARE THE REFERENCE EXECUTION AND THE LOCAL ONE.

rem The script is essentially self-explanatory.

rem It is assumed that the Zip package has been extracted into <folder>
rem and this script is at <folder>\info\odma\OdmNative\test\setup01


rem 0.02 2006-11-07-14:00 Review and add ERRORLEVEL setting on the
rem      different exit cases.
rem 0.01 2006-10-31-22:39 Adjust slightly for expected differences when
rem      TestSetup01-reference.exe is executed on a computer where the
rem      ODMA Connection Manager is not installed.
rem 0.00 2006-10-31-16:19 Simple script to confirm present of the files
rem      and simply run them, compiling the setup if necessary.  This
rem      first stage is merely a parrot of setup00.

rem $Header: /MyProjects/java/ODMdev/info/odma/OdmNative100/test/setup01/CheckSetup01.bat 4     06-11-07 14:08 Orcmid $

rem                     *** end of CheckSetup01.bat ***