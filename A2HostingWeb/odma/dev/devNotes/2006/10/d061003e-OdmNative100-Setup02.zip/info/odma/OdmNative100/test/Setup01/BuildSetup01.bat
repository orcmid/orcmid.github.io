@echo off
rem BuildSetup01.bat 0.02            UTF-8                    dh:2006-11-06
echo BuildSetup01.bat 0.02 CONFIRMATION OF OdmNative WINDOWS BUILD

IF NOT EXIST ..\..\OdmPSDK.bat GOTO :FAIL0
pushd ..\..\
CALL OdmPSDK.bat
popd
IF NOT ERRORLEVEL 2 GOTO :Compile
ECHO:  **** BuildSetup01.bat ABORTED.  SEE PREVIOUS ERROR MESSAGES.
ECHO:
EXIT /B %ERRORLEVEL%

:Compile
ECHO:
ECHO:
ECHO: **************************************************************
ECHO: **** COMPILING TestSetup01.exe, A SIMPLE WINDOWS-BASED PROGRAM
ECHO:

SET ERRORLEVEL=
cl /WX TestSetup01.c
if ERRORLEVEL 1 GOTO :FAIL1

ECHO:
ECHO: **** END OF COMPILATION ****
ECHO: ****************************
ECHO:
ECHO: There are no errors.  To confirm matching compilation and successful
ECHO: deployment of executables, execute the ConfirmSetup01.bat script.
EXIT /B 0

:FAIL0
ECHO:
ECHO:  **** THE BuildSetup01.bat MUST BE EXECUTED IN THE SAME DIRECTORY.
ECHO:  ****   The OdmPSDK.bat script must be available two levels above.
ECHO:  ****   Verify your Setup01 install configuration and ensure that
ECHO:  ****   the directory holding BuildSetup01.bat is the current working
ECHO:  ****   directory when the script is invoked.
ECHO:
EXIT /B 2

:FAIL1
ECHO:
ECHO:  **** ERRORS OR WARNINGS IN COMPILATION, ERRORLEVEL = %ERRORLEVEL%
ECHO:  ****   To capture a log, run with redirection to a file or pipe the
ECHO:  ****   result of BuildSetup01 into a program like "more."
ECHO:
EXIT /B %ERRORLEVEL%

rem -----1---------2---------3---------4---------5---------6---------7----*

rem BUILD TESTSETUP TO CONFIRM OdmNative WINDOWS DEVELOPMENT SETUP
rem This script compiles a simple native console application to verify
rem the Windows development setup for the OdmNative class and interface.

rem It's assumed that the Zip package has been extracted into <folder> and
rem this script is at <folder>\info\odma\OdmNative\test\Setup01

rem This directory can be on the same path as the development of other
rem ODMJNI components, <folder>\info\odma\practical100, the java interfaces
rem and <folder>\info\odma\odmjni, the code for the bridge between the Java
rem interfaces and the native connection class.


rem 0.02 2006-11-06-15:06 Add /WX compiler option to fail on warnings and
rem      update to work with an upgraded OdmPSDK version.
rem 0.01 2006-10-31-21:16 Remove /Za compiler option to satisfy PSDK.
rem 0.00 2006-10-31-15:59 Simple script without any sophistication beyond
rem      use of MyPSDK.bat from the OdmNative directory and duplication of
rem      TestSetup00.c as the starter for TestSetup01.c.

rem $Header: /MyProjects/java/ODMdev/info/odma/OdmNative100/test/setup01/BuildSetup01.bat 3     06-11-06 15:08 Orcmid $

rem                     *** end of BuildSetup01.bat ***