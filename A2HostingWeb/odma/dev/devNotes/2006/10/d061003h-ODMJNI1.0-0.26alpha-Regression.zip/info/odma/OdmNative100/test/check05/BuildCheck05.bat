@echo off
rem BuildCheck05.bat 0.00            UTF-8                    dh:2006-12-20
ECHO ***  BuildCheck05.bat 0.00 Check05.cpp OdmBindNative100 0.30alpha check

IF NOT EXIST ..\..\OdmPSDK.bat GOTO :FAIL0
pushd ..\..\
CALL OdmPSDK.bat
popd
IF NOT ERRORLEVEL 2 GOTO :Compile
ECHO ***  BuildCheck05.bat ABORTED.  SEE THE OdmPSDK.bat ERROR MESSAGES.
ECHO:
EXIT /B %ERRORLEVEL%

:Compile
IF NOT EXIST Check05.cpp GOTO :FAIL1

SET ERRORLEVEL=
cl /WX /MT /I..\..\ Check05.cpp ..\..\OdmNative100.obj user32.lib
if ERRORLEVEL 1 GOTO :FAIL2

echo:
echo ***  Check05.exe COMPILED
echo ***  ********************
echo:
echo:     There are no errors or warnings.  This program can be run
echo:     as Check05.exe.  This is a standalone program.  It can be
echo:     run anywhere on Windows 2000 or later versions.
echo:
EXIT /B 0


:FAIL0
ECHO:
ECHO ***  EXECUTE BuildCheck05.bat IN THE DIRECTORY THAT HOLDS IT.
ECHO ***      The OdmPSDK.bat script must be available two levels above.
ECHO ***      Verify your Check05 configuration and ensure that the
ECHO ***      directory holding BuildCheck05.bat is the current working
ECHO ***      directory before the script is invoked.
ECHO:
EXIT /B 2


:FAIL1
ECHO:
ECHO ***  THE Check05.cpp FILE IS NOT PRESENT IN THE CURRENT DIRECTORY
ECHO ***      The file should be in the same directory as this BuildCheck05
ECHO ***      script.  BuildCheck05.bat aborted.
ECHO:
EXIT /B 2


:FAIL2
echo:
echo ***  ERRORS OR WARNINGS IN COMPILATION, ERRORLEVEL = %ERRORLEVEL%
echo ***      To capture a log, run with redirection to a file or pipe the
echo ***      result of BuildCheck05 into a program like "more."
echo:
EXIT /B %ERRORLEVEL%


rem -----1---------2---------3---------4---------5---------6---------7----*

rem 0.00 2006-12-20-16:30 Customized from BuildSetup04 0.20.

rem $Header: /ODMdev/info/odma/OdmNative100/test/check05/BuildCheck05.bat 12    06-12-20 16:31 Orcmid $

rem                       *** end of BuildCheck05.bat ***