@echo off
rem RunCheck03.bat 0.00              UTF-8                    dh:2006-12-18
echo **   RunCheck03.bat 0.00 PERFORMING odmjni100 Check03 CONFIRMATION

IF NOT EXIST ..\..\OdmJava.bat GOTO :FAIL0
pushd ..\..\
CALL OdmJava.bat
popd
IF NOT ERRORLEVEL 2 GOTO :Run
ECHO:
ECHO **   RunCheck03.bat ABORTED.  SEE OdmJava.bat ERROR MESSAGES.
ECHO:
EXIT /B %ERRORLEVEL%

:Run
IF NOT EXIST Check03.class GOTO :FAIL1
SET ERRORLEVEL=
rem         This version sets the library path on the command line.
rem         We need a better way to do this in the future.
rem         FIXME: We might want to check for the odmjni100.dll too.
ECHO:
java -cp ".;%OdmClasses%" -Djava.library.path=..\..\ Check03
IF ERRORLEVEL 1 GOTO :FAIL2
EXIT /B 0

:FAIL0
ECHO:
ECHO **   EXECUTE RunCheck03.bat IN THE DIRECTORY THAT HOLDS IT.
ECHO **       The OdmJava.bat script must be available two levels above.
ECHO **       Verify your Check03 configuration and ensure that the
ECHO **       directory holding RunCheck03.bat is the current working
ECHO **       directory before the script is invoked.
ECHO:
EXIT /B 2


:FAIL1
ECHO:
ECHO **   THE Check03.class FILE IS NOT PRESENT IN THE CURRENT DIRECTORY
ECHO **       The file should be in the same directory as this RunCheck03
ECHO **       script.  Use BuildCheck03.bat to compile the class.
ECHO:
EXIT /B 2


:FAIL2
ECHO:
ECHO **   ERRORS IN EXECUTION, ERRORLEVEL = %ERRORLEVEL%
ECHO **       Remedy depends on the available error messages from Java.
ECHO:
EXIT /B %ERRORLEVEL%

rem -----1---------2---------3---------4---------5---------6---------7----*

rem RUNNING odmjni100 INTEGRATION CONFIRMATION PROGRAM SETUP02.

rem 0.00 Customize from the RunSetup02 script of 2006-11-28-19:13.

rem $Header: /ODMdev/info/odma/odmjni100/test/Check03/RunCheck03.bat 3     06-12-18 14:56 Orcmid $

rem                      *** end of RunCheck03.bat ***