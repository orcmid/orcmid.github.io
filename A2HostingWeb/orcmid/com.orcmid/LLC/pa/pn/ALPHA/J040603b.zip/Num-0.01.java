package com.orcmid.cs.pa;

public interface Num
{

    public int next();

    public int pred();

    public boolean is0();
}

/* sent by band@acm.org on 2004-05-22-1846 -0700
   This version reflects an interesting and very instructive
   misunderstanding of what I had in mind.
   $Header: /Java2/com/orcmid/llc/pa/pn/Num.java 1     04-05-23 9:27 Orcmid $
   */