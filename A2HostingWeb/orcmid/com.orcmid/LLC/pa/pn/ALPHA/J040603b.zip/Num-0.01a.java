/* Num-0.01a.java Experimentation with compilation options. */
package com.orcmid.cs.pa;

interface Num
{

    public int next();

    public int pred();

    public boolean is0();
}

/* sent by band@acm.org on 2004-05-22-1846 -0700
   This version reflects an interesting and very instructive
   misunderstanding of what I had in mind.
   2004-09-14-09:52 I corrected the name in a comment.  I have not adjusted
        this file at all.  It is just for experimenting with what the 
        compiler assumes.
   $Header: /Java2/com/orcmid/llc/pa/pn/Num-0.01a.java 2     04-09-14 9:54 Orcmid $
   */
