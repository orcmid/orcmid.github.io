/* Num-0.10.java */

package com.orcmid.LLC.pa.pn;

interface Num
{

    public Num aum();

    public Num dim();

    public boolean allo();
}

/* 0.10 2004-09-18-14:35 create basic package with minimal suggestive namings and
        demonstration of what the compiler makes of it.
   $Header: /Java2/com/orcmid/LLC/pa/pn/Num-0.10.java 2     04-09-18 14:36 Orcmid $
   */
