/* Stubby-0.10.java */

package com.orcmid.LLC.pa.pn;

class Stubby implements com.orcmid.LLC.pa.pn.Num
{

    public com.orcmid.LLC.pa.pn.Num aum()
    {   throw new java.lang.ArithmeticException("No such Stubby Numeral");
        }

    public com.orcmid.LLC.pa.pn.Num dim()
    {   return this; }

    public boolean allo()
    {   return true; }
}

/* 0.10 2004-09-18-18:02 create a basic stub that implements the minimal
        degenerate case (says me).
   $Header: /Java2/com/orcmid/llc/pa/pn/Stubby-0.10.java 2     04-09-18 18:21 Orcmid $
   */
