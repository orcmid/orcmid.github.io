/* StubbyRun.java */

package com.orcmid.LLC.pa.pn;

public class StubbyRun
{
    public static void main(java.lang.String[] arg)
    {   com.orcmid.LLC.pa.pn.Num N = new com.orcmid.LLC.pa.pn.Stubby();
        if (N.dim().allo()) 
            N = N.aum();
        else throw new java.lang.ArithmeticException("Stubby Failed");
        } // main(string[])

    } // StubbyRun

/* 0.10 2004-09-18-20:17 create a Java application that simply lets Stubby do
        its degenerate thing.  All this application does is blow up.
   $Header: /Java2/com/orcmid/LLC/pa/pn/StubbyRun.java 1     04-09-18 20:30 Orcmid $
   */
