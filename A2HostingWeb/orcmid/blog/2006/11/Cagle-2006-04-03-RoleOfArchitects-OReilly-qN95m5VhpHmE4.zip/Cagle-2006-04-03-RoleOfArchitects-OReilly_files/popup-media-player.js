// Pop-Up Embedder Script by David Battino, www.batmosphere.com
// With tweaks by Mark Levitt, http://digitalmedia.oreilly.com
// OK to use if this notice is included
   
var WindowNumber = 1;

function MakePlayer(filedesc,filepath,width,height) 
{
    winPadding = 130; //for the header and caption

    if (!width)
    {
        winWidth = 320;
        width    = 300;
    }
    else
    {
        winWidth = winPadding + Number(width);
    }

    if(!height)
    {
        winHeight = 190;
        height    = 42;
    }
    else
    {
        winHeight = winPadding + Number(height);
    }

    PlayerWin = window.open('',WindowNumber,'width=' + winWidth + ',height=' + winHeight + ',top=0,left=0,resizable=0,scrollbars=0,titlebar=0,toolbar=0,menubar=0,status=0,directories=0');

    PlayerWin.focus();

    PlayerWin.document.write("<html><head><title>" + filedesc + "</title></head>");
    PlayerWin.document.write("<body bgcolor='#9E9E9E' background='http://www.oreillynet.com/blogs/popup-tile-vertical.jpg'>"); // verify image path
    PlayerWin.document.write("<div align='center'>");
    PlayerWin.document.write("<b style ='font-size:18px;font-family:Verdana,sans-serif;line-height:1.5'>" + filedesc + "</b><br />");
    PlayerWin.document.write("<object width='" + width + "' height='" + height + "' >");
    PlayerWin.document.write("<param name='SRC' value='" +  filepath + "'>");
    PlayerWin.document.write("<param name='AUTOPLAY' VALUE='true'>");
    PlayerWin.document.write("<param name='CONTROLLER' VALUE='true'>");
    PlayerWin.document.write("<embed src ='" + filepath + "' autostart='true' loop='false' width='" + width + "' height='" + height + "' controller='true' bgcolor='#9E9E9E'>");
    PlayerWin.document.write("</embed></object></div>");
    PlayerWin.document.write("<p style='font-size:12px;font-family:Verdana,sans-serif;text-align:center'><a href='" + filepath +"'>Download this file</a> <span style='font-size:10px'>(right-click or Option-click)</span></p>");
    PlayerWin.document.write("<form><div align='center'><input type='button' value='Close this window' onclick='javascript:window.close();'></div></form>");
    PlayerWin.document.write("</body></html>");

    PlayerWin.document.close(); // "Finalizes" new window

    WindowNumber = WindowNumber + 1 // prevent subsequent clicks from using same window
}