// Copyright (c) 1996-1997 Athenia Associates.
// http://www.webreference.com/js/
// License is granted if and only if this entire
// copyright notice is included. By Tomer Shiran.

function setCookie (name, value, expires, path, domain, secure) {
    var curCookie = name + "=" + escape(value) + (expires ? "; expires=" + expires : "") +
        (path ? "; path=" + path : "") + (domain ? "; domain=" + domain : "") + (secure ? "secure" : "");
    document.cookie = curCookie;
}

function getCookie (name) {
    var prefix = name + '=';
    var c = document.cookie;
    var nullstring = '';
    var cookieStartIndex = c.indexOf(prefix);
    if (cookieStartIndex == -1)
        return nullstring;
    var cookieEndIndex = c.indexOf(";", cookieStartIndex + prefix.length);
    if (cookieEndIndex == -1)
        cookieEndIndex = c.length;
    return unescape(c.substring(cookieStartIndex + prefix.length, cookieEndIndex));
}

function deleteCookie (name, path, domain) {
    if (getCookie(name))
        document.cookie = name + "=" + ((path) ? "; path=" + path : "") +
            ((domain) ? "; domain=" + domain : "") + "; expires=Thu, 01-Jan-70 00:00:01 GMT";
}

function fixDate (date) {
    var base = new Date(0);
    var skew = base.getTime();
    if (skew > 0)
        date.setTime(date.getTime() - skew);
}

function rememberMe (f) {
    var now = new Date();
    fixDate(now);
    now.setTime(now.getTime() + 365 * 24 * 60 * 60 * 1000);
    now = now.toGMTString();
    if (f.author != undefined)
       setCookie('mtcmtauth', f.author.value, now, '/', '', '');
   // if (f.email != undefined)
   //   setCookie('mtcmtmail', f.email.value, now, '/', '', '');
    if (f.url != undefined)
       setCookie('mtcmthome', f.url.value, now, '/', '', '');
}

function forgetMe (f) {
    //deleteCookie('mtcmtmail', '/', '');
    deleteCookie('mtcmthome', '/', '');
    deleteCookie('mtcmtauth', '/', '');
    //f.email.value = '';
    f.author.value = '';
    f.url.value = '';
}

function hideDocumentElement(id) {
    var el = document.getElementById(id);
    if (el) el.style.display = 'none';
}

function showDocumentElement(id) {
    var el = document.getElementById(id);
    if (el) el.style.display = 'block';
}

var commenter_name;

function individualArchivesOnLoad(commenter_name) {
	comment_form = document.getElementById("comment-form");

	if (comment_form) {
        
		if (comment_form.email != undefined &&  (mtcmtmail = getCookie("mtcmtmail")))
            comment_form.email.value = mtcmtmail;

		if (comment_form.author != undefined && (mtcmtauth = getCookie("mtcmtauth")))
	
            comment_form.author.value = mtcmtauth;
        
		if (comment_form.url != undefined &&    (mtcmthome = getCookie("mtcmthome")))
            comment_form.url.value = mtcmthome;

        if (mtcmtauth || mtcmthome) {
            comment_form.bakecookie.checked = true;

        } else {
            comment_form.bakecookie.checked = false;
        }
    }
}

//custom function to preview comments
function preview_comment(comment_text)
{
    // create popup preview window
    features = 'menubar=0,toolbar=0,location=0,directories=0,scrollbars=0,status=0,resizable=0,width=625,height=200';
    popup = window.open('','commentpreview',features);
    if (popup.focus) popup.focus();
	
    // insert comment text into popup    
    popup.document.write("<html><head><title>Preview Comment</title><link rel=\"stylesheet\" type=\"text/css\" href=\"http://www.oreillynet.com/blogs/style.css\" /></head>");
    popup.document.write("<body>");
    popup.document.write("<div id='blog'><h3>Comment Preview</h3><div class='comments'><div class='comment-preview'>" + wpautop(comment_text) + "</div></div></div><div style='clear:both;text-align:center;'><button onclick='window.close();'>Close</button></div>");
    popup.document.write("</body></html>");
    return true;
}

// helper function for preview_comment
function wpautop(pee) {
	pee = pee + '\n\n';
	
	pee = pee.replace(/(<blockquote[^>]*>)/g, '\n$1');
	pee = pee.replace(/(<\/blockquote[^>]*>)/g, '$1\n');
		
	pee = pee.replace(/\r\n/g, '\n');
	pee = pee.replace(/\r/g, '\n');
	pee = pee.replace(/\n\n+/g, '\n\n');
	pee = pee.replace(/\n?(.+?)(?:\n\s*\n)/g, '<p>$1</p>');
	pee = pee.replace(/<p>\s*?<\/p>/g, '');

	pee = pee.replace(/<p>\s*(<\/?blockquote[^>]*>)\s*<\/p>/g, '$1');
	pee = pee.replace(/<p><blockquote([^>]*)>/ig, '<blockquote$1><p>');
	pee = pee.replace(/<\/blockquote><\/p>/ig, '<p></blockquote>');	
	pee = pee.replace(/<p>\s*<blockquote([^>]*)>/ig, '<blockquote$1>');
	pee = pee.replace(/<\/blockquote>\s*<\/p>/ig, '</blockquote>');			

   // ADDED TO STRIP OUT SCRIPT IN PREVIEW - eparker 20070823
   pee = pee.replace(/<\s*script([^>]*)>.*?<\s*\/\s*script([^>]*)>/ig, '');
   //pee = pee.replace(/<\s*script([^>]*)>/ig, '');
   //pee = pee.replace(/<\s*\/\s*script([^>]*)>/ig, '');
   
	pee = pee.replace(/\s*\n\s*/g, '<br />');
	return pee;
}
