Enclosed in this ZIP file are header files and samples that are aligned with the
DMA 1.0 specification dated 1997-12-31.

The ZIP file should be unzippped preserving the file heirarchy. The make file
sample.zip can be used to compile the samples, but is not expected to build a
runnable artifact. Attempting to link will fail with unbound references. 