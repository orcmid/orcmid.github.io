/* DMAIDVAR.CPP
**
**                  DEFINE DMAIDVAR VARIABLES FOR USE BY QUERY MODULES
**
*/

/*
 *  Copyright 1995, 1996, 1997, 1998 by the
 *  Association for Information and Image Management International
 *      1100 Wayne Avenue
 *      Silver Spring, MD 20910-5603
 *      Tel: 301/587-8202
 *      Fax: 301/587-2711
 *  All Rights Reserved.
 *  DMA (Document Management Alliance) working group.
 */

/*      This is a standard file for programs that simply expect external
**      variables containing all DMA IID and dmaProp_... and dmaClass_...
**      Dma Id values, among others.  (DMAIDS.H only defines the values, it
**      doesn't create stored variables that have been initialized with them.)
**      This file is designed to compile all of the identifiers.  It enables
**      economy of storage, locality of usage, and perhaps more clarity on
**      where this stuff comes from.
*/

#define DMA_INIT_ID 1

#include <dmaidvar.h>

                        /* end of DMAIDVAR.CPP */
