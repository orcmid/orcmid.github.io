/*
 *  Copyright 1995,1996, 1997 by the 
 *  Association for Information and Image Management Int'l
 *                  1100 Wayne Avenue
 *                  Silver Spring, MD 20910-5603
 *                  Tel: 301/587-8202
 *                  Fax: 301/587-2711
 *  All Rights Reserved.
 *      DMA (Document Management Alliance) working group.
 *
 *
 *  Containment Model code example: 
 *      Enumerate InitialContainer objects of a DocSpace in DMA 1.0
 *  
 */

#ifndef NULL
#   define NULL    0
#endif


#include <stdio.h>
#include <dmatypes.h>
#include <dmacom.h>
#include <dmarc.h>
#include <dmaiface.h>
#include <dmaenums.h>
#include <dmaidvar.h>

//
// Assumes that connections to system and doc space have already been made
// (see "System and Document Space Connection Example")
//

////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////

void EnumInitialContainers(LPIdmaDocSpace pIDocSpace)
{
    DmaRC             rc;
    LPIdmaProperties  pIPropsDocSpace = NULL;

    // Get the docSpace's properties interface
    rc = pIDocSpace->QueryInterface( IID_IdmaProperties, 
                              (pDmapv)&pIPropsDocSpace );

    if ( rc == DMARC_OK )
    {
        LPIdmaEnumOfObject pIEnumRootContainers = NULL;

        //
        // Get the list of initial containers in the docSpace using
        // the predefined DMA property Id -- dmaProp_InitialContainers
        //

        rc = pIPropsDocSpace->GetPropValObjectById(
                              &dmaProp_InitialContainers,
                              IID_IdmaEnumOfObject, 
                              (pDmapv)&pIEnumRootContainers );

        if ( (rc == DMARC_OK) && (pIEnumRootContainers != NULL) )
        {
            DmaIndex32  nNumReturn;
            IUnknown    *pIRootContainer;

            // Now enumerate each of these root containers one at a time

            rc = pIEnumRootContainers->GetNextObject( 1, // get one item 
                              &pIRootContainer,
                              &nNumReturn );

            while ( (rc == DMARC_OK) && (nNumReturn == 1) )
            {
                //
                // ### Process this initial container here! ###
                //     For example, the container may be 
                //     enumerated to list the objects contained in it.
                // 

                // Release the initial container interface
                pIRootContainer->Release();

                // Get the next initial container in the enumerator
                rc = pIEnumRootContainers->GetNextObject( 1, // get one item
                              &pIRootContainer,
                              &nNumReturn );
            }

            // Release the enumerator
            pIEnumRootContainers->Release();
        }

        // Release the docSpace properties interface
        pIPropsDocSpace->Release();
    }
}
////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////
