# Microsoft Developer Studio Generated NMAKE File, Format Version 4.20
# ** DO NOT EDIT **

# TARGTYPE "Win32 (x86) Dynamic-Link Library" 0x0102

!IF "$(CFG)" == ""
CFG=sample - Win32 Debug
!MESSAGE No configuration specified.  Defaulting to sample - Win32 Debug.
!ENDIF 

!IF "$(CFG)" != "sample - Win32 Release" && "$(CFG)" != "sample - Win32 Debug"
!MESSAGE Invalid configuration "$(CFG)" specified.
!MESSAGE You can specify a configuration when running NMAKE on this makefile
!MESSAGE by defining the macro CFG on the command line.  For example:
!MESSAGE 
!MESSAGE NMAKE /f "sample.mak" CFG="sample - Win32 Debug"
!MESSAGE 
!MESSAGE Possible choices for configuration are:
!MESSAGE 
!MESSAGE "sample - Win32 Release" (based on "Win32 (x86) Dynamic-Link Library")
!MESSAGE "sample - Win32 Debug" (based on "Win32 (x86) Dynamic-Link Library")
!MESSAGE 
!ERROR An invalid configuration is specified.
!ENDIF 

!IF "$(OS)" == "Windows_NT"
NULL=
!ELSE 
NULL=nul
!ENDIF 
################################################################################
# Begin Project
# PROP Target_Last_Scanned "sample - Win32 Debug"
CPP=cl.exe
RSC=rc.exe
MTL=mktyplib.exe

!IF  "$(CFG)" == "sample - Win32 Release"

# PROP BASE Use_MFC 0
# PROP BASE Use_Debug_Libraries 0
# PROP BASE Output_Dir "Release"
# PROP BASE Intermediate_Dir "Release"
# PROP BASE Target_Dir ""
# PROP Use_MFC 0
# PROP Use_Debug_Libraries 0
# PROP Output_Dir "Release"
# PROP Intermediate_Dir "Release"
# PROP Target_Dir ""
OUTDIR=.\Release
INTDIR=.\Release

ALL : "$(OUTDIR)\sample.dll"

CLEAN : 
	-@erase "$(INTDIR)\cosample1.obj"
	-@erase "$(INTDIR)\cosample2.obj"
	-@erase "$(INTDIR)\ctedit.obj"
	-@erase "$(INTDIR)\ctgetdoc.obj"
	-@erase "$(INTDIR)\ctnewdoc.obj"
	-@erase "$(INTDIR)\incon.obj"
	-@erase "$(INTDIR)\obpretty.obj"
	-@erase "$(INTDIR)\query.obj"
	-@erase "$(INTDIR)\quexp1.obj"
	-@erase "$(INTDIR)\quexp2.obj"
	-@erase "$(INTDIR)\quexp3.obj"
	-@erase "$(INTDIR)\version.obj"
	-@erase "$(OUTDIR)\sample.dll"
	-@erase "$(OUTDIR)\sample.exp"
	-@erase "$(OUTDIR)\sample.lib"

"$(OUTDIR)" :
    if not exist "$(OUTDIR)/$(NULL)" mkdir "$(OUTDIR)"

# ADD BASE CPP /nologo /MT /W3 /GX /O2 /D "WIN32" /D "NDEBUG" /D "_WINDOWS" /YX /c
# ADD CPP /nologo /MT /W3 /GX /O2 /I "..\include" /D "WIN32" /D "NDEBUG" /D "_WINDOWS" /YX /c
CPP_PROJ=/nologo /MT /W3 /GX /O2 /I "..\include" /D "WIN32" /D "NDEBUG" /D\
 "_WINDOWS" /Fp"$(INTDIR)/sample.pch" /YX /Fo"$(INTDIR)/" /c 
CPP_OBJS=.\Release/
CPP_SBRS=.\.
# ADD BASE MTL /nologo /D "NDEBUG" /win32
# ADD MTL /nologo /D "NDEBUG" /win32
MTL_PROJ=/nologo /D "NDEBUG" /win32 
# ADD BASE RSC /l 0x409 /d "NDEBUG"
# ADD RSC /l 0x409 /i "d:\dma\sample\include" /i "d:\dma\sample\src\query" /d "NDEBUG"
BSC32=bscmake.exe
# ADD BASE BSC32 /nologo
# ADD BSC32 /nologo
BSC32_FLAGS=/nologo /o"$(OUTDIR)/sample.bsc" 
BSC32_SBRS= \
	
LINK32=link.exe
# ADD BASE LINK32 kernel32.lib user32.lib gdi32.lib winspool.lib comdlg32.lib advapi32.lib shell32.lib ole32.lib oleaut32.lib uuid.lib odbc32.lib odbccp32.lib /nologo /subsystem:windows /dll /machine:I386
# ADD LINK32 kernel32.lib user32.lib gdi32.lib winspool.lib comdlg32.lib advapi32.lib shell32.lib ole32.lib oleaut32.lib uuid.lib odbc32.lib odbccp32.lib /nologo /subsystem:windows /dll /machine:I386
LINK32_FLAGS=kernel32.lib user32.lib gdi32.lib winspool.lib comdlg32.lib\
 advapi32.lib shell32.lib ole32.lib oleaut32.lib uuid.lib odbc32.lib\
 odbccp32.lib /nologo /subsystem:windows /dll /incremental:no\
 /pdb:"$(OUTDIR)/sample.pdb" /machine:I386 /out:"$(OUTDIR)/sample.dll"\
 /implib:"$(OUTDIR)/sample.lib" 
LINK32_OBJS= \
	"$(INTDIR)\cosample1.obj" \
	"$(INTDIR)\cosample2.obj" \
	"$(INTDIR)\ctedit.obj" \
	"$(INTDIR)\ctgetdoc.obj" \
	"$(INTDIR)\ctnewdoc.obj" \
	"$(INTDIR)\incon.obj" \
	"$(INTDIR)\obpretty.obj" \
	"$(INTDIR)\query.obj" \
	"$(INTDIR)\quexp1.obj" \
	"$(INTDIR)\quexp2.obj" \
	"$(INTDIR)\quexp3.obj" \
	"$(INTDIR)\version.obj"

"$(OUTDIR)\sample.dll" : "$(OUTDIR)" $(DEF_FILE) $(LINK32_OBJS)
    $(LINK32) @<<
  $(LINK32_FLAGS) $(LINK32_OBJS)
<<

!ELSEIF  "$(CFG)" == "sample - Win32 Debug"

# PROP BASE Use_MFC 0
# PROP BASE Use_Debug_Libraries 1
# PROP BASE Output_Dir "Debug"
# PROP BASE Intermediate_Dir "Debug"
# PROP BASE Target_Dir ""
# PROP Use_MFC 0
# PROP Use_Debug_Libraries 1
# PROP Output_Dir "Debug"
# PROP Intermediate_Dir "Debug"
# PROP Target_Dir ""
OUTDIR=.\Debug
INTDIR=.\Debug

ALL : "$(OUTDIR)\sample.dll" "$(OUTDIR)\sample.bsc"

CLEAN : 
	-@erase "$(INTDIR)\cosample1.obj"
	-@erase "$(INTDIR)\cosample1.sbr"
	-@erase "$(INTDIR)\cosample2.obj"
	-@erase "$(INTDIR)\cosample2.sbr"
	-@erase "$(INTDIR)\ctedit.obj"
	-@erase "$(INTDIR)\ctedit.sbr"
	-@erase "$(INTDIR)\ctgetdoc.obj"
	-@erase "$(INTDIR)\ctgetdoc.sbr"
	-@erase "$(INTDIR)\ctnewdoc.obj"
	-@erase "$(INTDIR)\ctnewdoc.sbr"
	-@erase "$(INTDIR)\incon.obj"
	-@erase "$(INTDIR)\incon.sbr"
	-@erase "$(INTDIR)\obpretty.obj"
	-@erase "$(INTDIR)\obpretty.sbr"
	-@erase "$(INTDIR)\query.obj"
	-@erase "$(INTDIR)\query.sbr"
	-@erase "$(INTDIR)\quexp1.obj"
	-@erase "$(INTDIR)\quexp1.sbr"
	-@erase "$(INTDIR)\quexp2.obj"
	-@erase "$(INTDIR)\quexp2.sbr"
	-@erase "$(INTDIR)\quexp3.obj"
	-@erase "$(INTDIR)\quexp3.sbr"
	-@erase "$(INTDIR)\vc40.idb"
	-@erase "$(INTDIR)\vc40.pdb"
	-@erase "$(INTDIR)\version.obj"
	-@erase "$(INTDIR)\version.sbr"
	-@erase "$(OUTDIR)\sample.bsc"
	-@erase "$(OUTDIR)\sample.dll"
	-@erase "$(OUTDIR)\sample.exp"
	-@erase "$(OUTDIR)\sample.ilk"
	-@erase "$(OUTDIR)\sample.lib"
	-@erase "$(OUTDIR)\sample.pdb"

"$(OUTDIR)" :
    if not exist "$(OUTDIR)/$(NULL)" mkdir "$(OUTDIR)"

# ADD BASE CPP /nologo /MTd /W3 /Gm /GX /Zi /Od /D "WIN32" /D "_DEBUG" /D "_WINDOWS" /YX /c
# ADD CPP /nologo /MTd /W3 /Gm /GX /Zi /Od /I "..\include" /D "WIN32" /D "_DEBUG" /D "_WINDOWS" /FR /YX /c
CPP_PROJ=/nologo /MTd /W3 /Gm /GX /Zi /Od /I "..\include" /D "WIN32" /D\
 "_DEBUG" /D "_WINDOWS" /FR"$(INTDIR)/" /Fp"$(INTDIR)/sample.pch" /YX\
 /Fo"$(INTDIR)/" /Fd"$(INTDIR)/" /c 
CPP_OBJS=.\Debug/
CPP_SBRS=.\Debug/
# ADD BASE MTL /nologo /D "_DEBUG" /win32
# ADD MTL /nologo /D "_DEBUG" /win32
MTL_PROJ=/nologo /D "_DEBUG" /win32 
# ADD BASE RSC /l 0x409 /d "_DEBUG"
# ADD RSC /l 0x409 /i "d:\dma\sample\include" /i "d:\dma\sample\src\query" /d "_DEBUG"
BSC32=bscmake.exe
# ADD BASE BSC32 /nologo
# ADD BSC32 /nologo
BSC32_FLAGS=/nologo /o"$(OUTDIR)/sample.bsc" 
BSC32_SBRS= \
	"$(INTDIR)\cosample1.sbr" \
	"$(INTDIR)\cosample2.sbr" \
	"$(INTDIR)\ctedit.sbr" \
	"$(INTDIR)\ctgetdoc.sbr" \
	"$(INTDIR)\ctnewdoc.sbr" \
	"$(INTDIR)\incon.sbr" \
	"$(INTDIR)\obpretty.sbr" \
	"$(INTDIR)\query.sbr" \
	"$(INTDIR)\quexp1.sbr" \
	"$(INTDIR)\quexp2.sbr" \
	"$(INTDIR)\quexp3.sbr" \
	"$(INTDIR)\version.sbr"

"$(OUTDIR)\sample.bsc" : "$(OUTDIR)" $(BSC32_SBRS)
    $(BSC32) @<<
  $(BSC32_FLAGS) $(BSC32_SBRS)
<<

LINK32=link.exe
# ADD BASE LINK32 kernel32.lib user32.lib gdi32.lib winspool.lib comdlg32.lib advapi32.lib shell32.lib ole32.lib oleaut32.lib uuid.lib odbc32.lib odbccp32.lib /nologo /subsystem:windows /dll /debug /machine:I386
# ADD LINK32 kernel32.lib user32.lib gdi32.lib winspool.lib comdlg32.lib advapi32.lib shell32.lib ole32.lib oleaut32.lib uuid.lib odbc32.lib odbccp32.lib /nologo /subsystem:windows /dll /debug /machine:I386
LINK32_FLAGS=kernel32.lib user32.lib gdi32.lib winspool.lib comdlg32.lib\
 advapi32.lib shell32.lib ole32.lib oleaut32.lib uuid.lib odbc32.lib\
 odbccp32.lib /nologo /subsystem:windows /dll /incremental:yes\
 /pdb:"$(OUTDIR)/sample.pdb" /debug /machine:I386 /out:"$(OUTDIR)/sample.dll"\
 /implib:"$(OUTDIR)/sample.lib" 
LINK32_OBJS= \
	"$(INTDIR)\cosample1.obj" \
	"$(INTDIR)\cosample2.obj" \
	"$(INTDIR)\ctedit.obj" \
	"$(INTDIR)\ctgetdoc.obj" \
	"$(INTDIR)\ctnewdoc.obj" \
	"$(INTDIR)\incon.obj" \
	"$(INTDIR)\obpretty.obj" \
	"$(INTDIR)\query.obj" \
	"$(INTDIR)\quexp1.obj" \
	"$(INTDIR)\quexp2.obj" \
	"$(INTDIR)\quexp3.obj" \
	"$(INTDIR)\version.obj"

"$(OUTDIR)\sample.dll" : "$(OUTDIR)" $(DEF_FILE) $(LINK32_OBJS)
    $(LINK32) @<<
  $(LINK32_FLAGS) $(LINK32_OBJS)
<<

!ENDIF 

.c{$(CPP_OBJS)}.obj:
   $(CPP) $(CPP_PROJ) $<  

.cpp{$(CPP_OBJS)}.obj:
   $(CPP) $(CPP_PROJ) $<  

.cxx{$(CPP_OBJS)}.obj:
   $(CPP) $(CPP_PROJ) $<  

.c{$(CPP_SBRS)}.sbr:
   $(CPP) $(CPP_PROJ) $<  

.cpp{$(CPP_SBRS)}.sbr:
   $(CPP) $(CPP_PROJ) $<  

.cxx{$(CPP_SBRS)}.sbr:
   $(CPP) $(CPP_PROJ) $<  

################################################################################
# Begin Target

# Name "sample - Win32 Release"
# Name "sample - Win32 Debug"

!IF  "$(CFG)" == "sample - Win32 Release"

!ELSEIF  "$(CFG)" == "sample - Win32 Debug"

!ENDIF 

################################################################################
# Begin Source File

SOURCE=.\src\content\ctnewdoc.cpp

!IF  "$(CFG)" == "sample - Win32 Release"

DEP_CPP_CTNEW=\
	"..\include\dmacom.h"\
	"..\include\dmaenums.h"\
	"..\include\dmaids.h"\
	"..\include\dmaidvar.h"\
	"..\include\dmaiface.h"\
	"..\include\dmarc.h"\
	"..\include\dmastr.h"\
	"..\include\dmatypes.h"\
	

"$(INTDIR)\ctnewdoc.obj" : $(SOURCE) $(DEP_CPP_CTNEW) "$(INTDIR)"
   $(CPP) $(CPP_PROJ) $(SOURCE)


!ELSEIF  "$(CFG)" == "sample - Win32 Debug"


BuildCmds= \
	$(CPP) $(CPP_PROJ) $(SOURCE) \
	

"$(INTDIR)\ctnewdoc.obj" : $(SOURCE) "$(INTDIR)"
   $(BuildCmds)

"$(INTDIR)\ctnewdoc.sbr" : $(SOURCE) "$(INTDIR)"
   $(BuildCmds)

!ENDIF 

# End Source File
################################################################################
# Begin Source File

SOURCE=.\src\content\ctgetdoc.cpp

!IF  "$(CFG)" == "sample - Win32 Release"

DEP_CPP_CTGET=\
	"..\include\dmacom.h"\
	"..\include\dmaenums.h"\
	"..\include\dmaids.h"\
	"..\include\dmaidvar.h"\
	"..\include\dmaiface.h"\
	"..\include\dmarc.h"\
	"..\include\dmastr.h"\
	"..\include\dmatypes.h"\
	

"$(INTDIR)\ctgetdoc.obj" : $(SOURCE) $(DEP_CPP_CTGET) "$(INTDIR)"
   $(CPP) $(CPP_PROJ) $(SOURCE)


!ELSEIF  "$(CFG)" == "sample - Win32 Debug"


BuildCmds= \
	$(CPP) $(CPP_PROJ) $(SOURCE) \
	

"$(INTDIR)\ctgetdoc.obj" : $(SOURCE) "$(INTDIR)"
   $(BuildCmds)

"$(INTDIR)\ctgetdoc.sbr" : $(SOURCE) "$(INTDIR)"
   $(BuildCmds)

!ENDIF 

# End Source File
################################################################################
# Begin Source File

SOURCE=.\src\content\ctedit.cpp

!IF  "$(CFG)" == "sample - Win32 Release"

DEP_CPP_CTEDI=\
	"..\include\dmacom.h"\
	"..\include\dmaenums.h"\
	"..\include\dmaids.h"\
	"..\include\dmaidvar.h"\
	"..\include\dmaiface.h"\
	"..\include\dmarc.h"\
	"..\include\dmastr.h"\
	"..\include\dmatypes.h"\
	

"$(INTDIR)\ctedit.obj" : $(SOURCE) $(DEP_CPP_CTEDI) "$(INTDIR)"
   $(CPP) $(CPP_PROJ) $(SOURCE)


!ELSEIF  "$(CFG)" == "sample - Win32 Debug"


BuildCmds= \
	$(CPP) $(CPP_PROJ) $(SOURCE) \
	

"$(INTDIR)\ctedit.obj" : $(SOURCE) "$(INTDIR)"
   $(BuildCmds)

"$(INTDIR)\ctedit.sbr" : $(SOURCE) "$(INTDIR)"
   $(BuildCmds)

!ENDIF 

# End Source File
################################################################################
# Begin Source File

SOURCE=.\src\query\query.cpp

!IF  "$(CFG)" == "sample - Win32 Release"

DEP_CPP_QUERY=\
	"..\include\dmacfunc.h"\
	"..\include\dmacom.h"\
	"..\include\dmaenums.h"\
	"..\include\dmaids.h"\
	"..\include\dmaidvar.h"\
	"..\include\dmaiface.h"\
	"..\include\dmarc.h"\
	"..\include\dmatypes.h"\
	".\src\query\query.h"\
	

"$(INTDIR)\query.obj" : $(SOURCE) $(DEP_CPP_QUERY) "$(INTDIR)"
   $(CPP) $(CPP_PROJ) $(SOURCE)


!ELSEIF  "$(CFG)" == "sample - Win32 Debug"

DEP_CPP_QUERY=\
	".\src\query\query.h"\
	

BuildCmds= \
	$(CPP) $(CPP_PROJ) $(SOURCE) \
	

"$(INTDIR)\query.obj" : $(SOURCE) $(DEP_CPP_QUERY) "$(INTDIR)"
   $(BuildCmds)

"$(INTDIR)\query.sbr" : $(SOURCE) $(DEP_CPP_QUERY) "$(INTDIR)"
   $(BuildCmds)

!ENDIF 

# End Source File
################################################################################
# Begin Source File

SOURCE=.\src\query\quexp1.cpp

!IF  "$(CFG)" == "sample - Win32 Release"

DEP_CPP_QUEXP=\
	"..\include\dmacfunc.h"\
	"..\include\dmacom.h"\
	"..\include\dmaenums.h"\
	"..\include\dmaids.h"\
	"..\include\dmaidvar.h"\
	"..\include\dmaiface.h"\
	"..\include\dmarc.h"\
	"..\include\dmatypes.h"\
	".\src\query\query.h"\
	

"$(INTDIR)\quexp1.obj" : $(SOURCE) $(DEP_CPP_QUEXP) "$(INTDIR)"
   $(CPP) $(CPP_PROJ) $(SOURCE)


!ELSEIF  "$(CFG)" == "sample - Win32 Debug"

DEP_CPP_QUEXP=\
	".\src\query\query.h"\
	

BuildCmds= \
	$(CPP) $(CPP_PROJ) $(SOURCE) \
	

"$(INTDIR)\quexp1.obj" : $(SOURCE) $(DEP_CPP_QUEXP) "$(INTDIR)"
   $(BuildCmds)

"$(INTDIR)\quexp1.sbr" : $(SOURCE) $(DEP_CPP_QUEXP) "$(INTDIR)"
   $(BuildCmds)

!ENDIF 

# End Source File
################################################################################
# Begin Source File

SOURCE=.\src\int\incon.cpp

!IF  "$(CFG)" == "sample - Win32 Release"

DEP_CPP_INCON=\
	"..\include\dmacfunc.h"\
	"..\include\dmacom.h"\
	"..\include\dmaenums.h"\
	"..\include\dmaids.h"\
	"..\include\dmaidvar.h"\
	"..\include\dmaiface.h"\
	"..\include\dmarc.h"\
	"..\include\dmatypes.h"\
	

"$(INTDIR)\incon.obj" : $(SOURCE) $(DEP_CPP_INCON) "$(INTDIR)"
   $(CPP) $(CPP_PROJ) $(SOURCE)


!ELSEIF  "$(CFG)" == "sample - Win32 Debug"


BuildCmds= \
	$(CPP) $(CPP_PROJ) $(SOURCE) \
	

"$(INTDIR)\incon.obj" : $(SOURCE) "$(INTDIR)"
   $(BuildCmds)

"$(INTDIR)\incon.sbr" : $(SOURCE) "$(INTDIR)"
   $(BuildCmds)

!ENDIF 

# End Source File
################################################################################
# Begin Source File

SOURCE=.\src\query\quexp2.cpp

!IF  "$(CFG)" == "sample - Win32 Release"

DEP_CPP_QUEXP2=\
	"..\include\dmacfunc.h"\
	"..\include\dmacom.h"\
	"..\include\dmaenums.h"\
	"..\include\dmaids.h"\
	"..\include\dmaidvar.h"\
	"..\include\dmaiface.h"\
	"..\include\dmarc.h"\
	"..\include\dmatypes.h"\
	".\src\query\query.h"\
	

"$(INTDIR)\quexp2.obj" : $(SOURCE) $(DEP_CPP_QUEXP2) "$(INTDIR)"
   $(CPP) $(CPP_PROJ) $(SOURCE)


!ELSEIF  "$(CFG)" == "sample - Win32 Debug"

DEP_CPP_QUEXP2=\
	".\src\query\query.h"\
	

BuildCmds= \
	$(CPP) $(CPP_PROJ) $(SOURCE) \
	

"$(INTDIR)\quexp2.obj" : $(SOURCE) $(DEP_CPP_QUEXP2) "$(INTDIR)"
   $(BuildCmds)

"$(INTDIR)\quexp2.sbr" : $(SOURCE) $(DEP_CPP_QUEXP2) "$(INTDIR)"
   $(BuildCmds)

!ENDIF 

# End Source File
################################################################################
# Begin Source File

SOURCE=.\src\version\version.cpp

!IF  "$(CFG)" == "sample - Win32 Release"

DEP_CPP_VERSI=\
	"..\include\dmacfunc.h"\
	"..\include\dmacom.h"\
	"..\include\dmaenums.h"\
	"..\include\dmaids.h"\
	"..\include\dmaidvar.h"\
	"..\include\dmaiface.h"\
	"..\include\dmarc.h"\
	"..\include\dmatypes.h"\
	

"$(INTDIR)\version.obj" : $(SOURCE) $(DEP_CPP_VERSI) "$(INTDIR)"
   $(CPP) $(CPP_PROJ) $(SOURCE)


!ELSEIF  "$(CFG)" == "sample - Win32 Debug"


BuildCmds= \
	$(CPP) $(CPP_PROJ) $(SOURCE) \
	

"$(INTDIR)\version.obj" : $(SOURCE) "$(INTDIR)"
   $(BuildCmds)

"$(INTDIR)\version.sbr" : $(SOURCE) "$(INTDIR)"
   $(BuildCmds)

!ENDIF 

# End Source File
################################################################################
# Begin Source File

SOURCE=.\src\query\quexp3.cpp

!IF  "$(CFG)" == "sample - Win32 Release"

DEP_CPP_QUEXP3=\
	"..\include\dmacfunc.h"\
	"..\include\dmacom.h"\
	"..\include\dmaenums.h"\
	"..\include\dmaids.h"\
	"..\include\dmaidvar.h"\
	"..\include\dmaiface.h"\
	"..\include\dmarc.h"\
	"..\include\dmatypes.h"\
	".\src\query\query.h"\
	

"$(INTDIR)\quexp3.obj" : $(SOURCE) $(DEP_CPP_QUEXP3) "$(INTDIR)"
   $(CPP) $(CPP_PROJ) $(SOURCE)


!ELSEIF  "$(CFG)" == "sample - Win32 Debug"

DEP_CPP_QUEXP3=\
	".\src\query\query.h"\
	

BuildCmds= \
	$(CPP) $(CPP_PROJ) $(SOURCE) \
	

"$(INTDIR)\quexp3.obj" : $(SOURCE) $(DEP_CPP_QUEXP3) "$(INTDIR)"
   $(BuildCmds)

"$(INTDIR)\quexp3.sbr" : $(SOURCE) $(DEP_CPP_QUEXP3) "$(INTDIR)"
   $(BuildCmds)

!ENDIF 

# End Source File
################################################################################
# Begin Source File

SOURCE=.\src\contain\cosample2.cpp

!IF  "$(CFG)" == "sample - Win32 Release"

DEP_CPP_COSAM=\
	"..\include\dmacaps.h"\
	"..\include\dmacom.h"\
	"..\include\dmaenums.h"\
	"..\include\dmaids.h"\
	"..\include\dmaidvar.h"\
	"..\include\dmaiface.h"\
	"..\include\dmarc.h"\
	"..\include\dmatypes.h"\
	

"$(INTDIR)\cosample2.obj" : $(SOURCE) $(DEP_CPP_COSAM) "$(INTDIR)"
   $(CPP) $(CPP_PROJ) $(SOURCE)


!ELSEIF  "$(CFG)" == "sample - Win32 Debug"


BuildCmds= \
	$(CPP) $(CPP_PROJ) $(SOURCE) \
	

"$(INTDIR)\cosample2.obj" : $(SOURCE) "$(INTDIR)"
   $(BuildCmds)

"$(INTDIR)\cosample2.sbr" : $(SOURCE) "$(INTDIR)"
   $(BuildCmds)

!ENDIF 

# End Source File
################################################################################
# Begin Source File

SOURCE=.\src\contain\cosample1.cpp

!IF  "$(CFG)" == "sample - Win32 Release"

DEP_CPP_COSAMP=\
	"..\include\dmacom.h"\
	"..\include\dmaenums.h"\
	"..\include\dmaids.h"\
	"..\include\dmaidvar.h"\
	"..\include\dmaiface.h"\
	"..\include\dmarc.h"\
	"..\include\dmatypes.h"\
	

"$(INTDIR)\cosample1.obj" : $(SOURCE) $(DEP_CPP_COSAMP) "$(INTDIR)"
   $(CPP) $(CPP_PROJ) $(SOURCE)


!ELSEIF  "$(CFG)" == "sample - Win32 Debug"


BuildCmds= \
	$(CPP) $(CPP_PROJ) $(SOURCE) \
	

"$(INTDIR)\cosample1.obj" : $(SOURCE) "$(INTDIR)"
   $(BuildCmds)

"$(INTDIR)\cosample1.sbr" : $(SOURCE) "$(INTDIR)"
   $(BuildCmds)

!ENDIF 

# End Source File
################################################################################
# Begin Source File

SOURCE=.\src\object\obpretty.cpp

!IF  "$(CFG)" == "sample - Win32 Release"

DEP_CPP_OBPRE=\
	"..\include\dmacom.h"\
	"..\include\dmaenums.h"\
	"..\include\dmaids.h"\
	"..\include\dmaidvar.h"\
	"..\include\dmaiface.h"\
	"..\include\dmarc.h"\
	"..\include\dmastr.h"\
	"..\include\dmatypes.h"\
	

"$(INTDIR)\obpretty.obj" : $(SOURCE) $(DEP_CPP_OBPRE) "$(INTDIR)"
   $(CPP) $(CPP_PROJ) $(SOURCE)


!ELSEIF  "$(CFG)" == "sample - Win32 Debug"


BuildCmds= \
	$(CPP) $(CPP_PROJ) $(SOURCE) \
	

"$(INTDIR)\obpretty.obj" : $(SOURCE) "$(INTDIR)"
   $(BuildCmds)

"$(INTDIR)\obpretty.sbr" : $(SOURCE) "$(INTDIR)"
   $(BuildCmds)

!ENDIF 

# End Source File
# End Target
# End Project
################################################################################
