#ifndef  DMACAPS_H
#define  DMACAPS_H

/* DMA Spec 1.0                                                             */
/*    Classes and Properties DB Version  6,  17-Mar-1998                    */
/*    dmacaps.h produced on: 09-Apr-1998 at 08:20:53                        */
/*                                                                          */
/* Copyright 1995,1996,1997,1998 by                                         */
/*                                                                          */
/* Association for Information and Image Management Int'l                   */
/* 1100 Wayne Avenue                                                        */
/* Silver Spring, MD 20910-5603                                             */
/* Tel: 301/587-8202                                                        */
/* Fax: 301/587-2711                                                        */
/*                                                                          */
/* All Rights Reserved.                                                     */
/* DMA (Document Management Alliance) working group.                        */

/*      DMA Capabilities Definitions                                        */

#define DMA_CAPABILITY_LEVEL_1_0    1
#define DMA_CAPABILITY_COUNT_1_0    73

/*      Capabilities                                                        */


/*      DMA Capabilities Index Defines                                      */

/* DMAC_LEVEL                                                               */
/*                                                                          */
/* The value indicates the version level number of the capabilities         */
/* property for the document repository. It is a positive integer equal to  */
/* 1 for the 1.0 DMA spec. On every subsequent release of the DMA spec. in  */
/* which additional document repository capabilities are introduced, this   */
/* number is increased by one.                                              */
/*                                                                          */
#define DMAC_LEVEL    0

/* DMAC_AUTHENTICATE                                                        */
/*                                                                          */
/* If set, then the document space object supports the IdmaAuthentication   */
/* interface.                                                               */
/*                                                                          */
/* If reset, the document space object does not support the                 */
/* IdmaAuthentication interface.                                            */
/*                                                                          */
#define DMAC_AUTHENTICATE    1

/* DMAC_WRITEABLE_DOCSPACE                                                  */
/*                                                                          */
/* If set, then (1) document space objects can be added, and deleted, and   */
/* modified, and/or (2) document versions can be checked in.                */
/*                                                                          */
/* If reset, the document space is read only.                               */
/*                                                                          */
#define DMAC_WRITEABLE_DOCSPACE    2

/* DMAC_CONNECT_VIA_OIID                                                    */
/*                                                                          */
/* If set, IdmaDocSpace:: ConnectObject is supported on the document space  */
/* object to connect to persistent objects given their OIID.                */
/*                                                                          */
/* If reset, IdmaDocSpace:: ConnectObject is not supported.                 */
/*                                                                          */
#define DMAC_CONNECT_VIA_OIID    3

/* DMAC_CONTENT                                                             */
/*                                                                          */
/* This is set if and only if content is supported: At least some           */
/* documents in the document space can have content. This implies that the  */
/* Rendition class and at least one of the classes Content Transfer and     */
/* Content Reference must be supported.                                     */
/*                                                                          */
/* If reset, the document repository merely catalogs external material,     */
/* e.g., books on a shelf, and no documents have content.                   */
/*                                                                          */
#define DMAC_CONTENT    4

/* DMAC_CONTENT_MULT_RENDITIONS                                             */
/*                                                                          */
/* If set, then content is supported, and documents can have multiple       */
/* renditions.                                                              */
/*                                                                          */
/* If reset, documents can have at most one rendition.                      */
/*                                                                          */
#define DMAC_CONTENT_MULT_RENDITIONS    5

/* DMAC_CONTENT_MULT_ELEMENTS                                               */
/*                                                                          */
/* If set, then content is supported, and renditions can have multiple      */
/* content elements.                                                        */
/*                                                                          */
/* If reset, renditions can not have more than one content element.         */
/*                                                                          */
#define DMAC_CONTENT_MULT_ELEMENTS    6

/* DMAC_CONTENT_MIME_RENDITIONS                                             */
/*                                                                          */
/* If set, then content is supported,                                       */
/*                                                                          */
/* and the document space supports the use of rendition types from          */
/*                                                                          */
/* the MIME rendition type space.                                           */
/*                                                                          */
/* NOTE: The Rendition Type property is a string of the form                */
/* <rendition_type_space>::<typename>. The only <rendition_type_space>      */
/* defined in the DMA 1.0 spec. is 'MIME' (Multipurpose Internet Mail       */
/* Extension) as defined by the IANA. Examples are                          */
/* 'MIME::application/postscript' and 'MIME::text'. END NOTE                */
/*                                                                          */
/* If reset, then the document space does not support MIME reference type   */
/* names.                                                                   */
/*                                                                          */
#define DMAC_CONTENT_MIME_RENDITIONS    7

/* DMAC_CONTENT_UPDATEABLE                                                  */
/*                                                                          */
/* If set, then document content is supported, and document content can be  */
/* edited. Some or all of the following operations can be performed on      */
/* existing persistent Doc Version objects: Renditions can be added;        */
/* renditions can be deleted; renditions can be replaced; content elements  */
/* can be added; content elements can be deleted; content elements can be   */
/* replaced. This implies IdmaConnection:: ExecuteChange is supported.      */
/*                                                                          */
/* If reset, then document cannot be edited. (Note that checking in a new   */
/* version of a document does not count as updating content in the sense    */
/* of this capability. That is viewed as creating a new persistent Doc      */
/* Version object for purposes of discussion of this capability.)           */
/*                                                                          */
#define DMAC_CONTENT_UPDATEABLE    8

/* DMAC_CONTENT_CAPTURE_RESOURCE                                            */
/*                                                                          */
/* If set, then content is supported, and IdmaContentTransfer::             */
/* SetCaptureResource supported. This method allows content to be captured  */
/* from a named resource.                                                   */
/*                                                                          */
/* If reset, then IdmaContentTransfer:: SetCaptureResource is not           */
/* supported.                                                               */
/*                                                                          */
#define DMAC_CONTENT_CAPTURE_RESOURCE    9

/* DMAC_CONTENT_COPY_TO_RESOURCE                                            */
/*                                                                          */
/* If set, then content is supported, and IdmaContentTransfer::             */
/* CopyToResource is supported. This method makes a copy of captured        */
/* content data in a resource of a specified name.                          */
/*                                                                          */
/* If reset, then IdmaContentTransfer:: CopyToResource is not supported.    */
/*                                                                          */
/* Containment                                                              */
/*                                                                          */
#define DMAC_CONTENT_COPY_TO_RESOURCE    10

/* DMAC_CONTAIN_DIR_REQUIRED                                                */
/*                                                                          */
/* If set, then, any directly containable object (except for root direct    */
/* containers) must be contained in a container via direct containment.     */
/* (There are no freestanding directly containable objects except root      */
/* direct containers.)                                                      */
/*                                                                          */
/* If reset, then it is not required that directly containable objects be   */
/* contained in a container via direct containment.                         */
/*                                                                          */
/* If containment is not implemented, the value is reset.                   */
/*                                                                          */
#define DMAC_CONTAIN_DIR_REQUIRED    11

/* DMAC_CONTAIN_REF_REQUIRED                                                */
/*                                                                          */
/* If set, then, any referentially containable object (except for root      */
/* referential containers) must be contained in a container via             */
/* referential containment. (There are no freestanding referentially        */
/* containable objects except root referential containers.)                 */
/*                                                                          */
/* If reset, then it is not required that referentially containable         */
/* objects be contained in a container via referential containment.         */
/*                                                                          */
/* If containment is not implemented, the value is reset.                   */
/*                                                                          */
/* If DMAC_CONTAIN_REF_REQUIRED and DMAC_CONTAIN_DIR_REQUIRED are both      */
/* set, and if there is a class that can be contained both via direct       */
/* containment and referential containment, then objects of that class      */
/* must be directly contained, but need not be referentially contained.     */
/*                                                                          */
#define DMAC_CONTAIN_REF_REQUIRED    12

/* DMAC_CONTAIN                                                             */
/*                                                                          */
/* If DMAC_CONTAIN is set, then containment is supported. The value of      */
/* DMAC_CONTAIN is defined to be DMAC_CONTAIN_REF OR DMAC_CONTAIN_DIR .     */
/*                                                                          */
#define DMAC_CONTAIN    13

/* DMAC_CONTAIN_REF                                                         */
/*                                                                          */
/* If set, then referential containment is supported. The value of          */
/* DMAC_CONTAIN_REF is defined to be DMAC_CONTAIN_REF_CONTAINER OR          */
/* DMAC_CONTAIN_REF_CFG_HISTORY OR DMAC_CONTAIN_REF_VER_SERIES OR           */
/* DMAC_CONTAIN_REF_VER_DESC OR DMAC_CONTAIN_REF_DOC_VER OR                 */
/* DMAC_CONTAIN_REF_OTHER .                                                 */
/*                                                                          */
/* If DMAC_CONTAIN_REF is set, the following optional classes must be       */
/* supported:                                                               */
/*                                                                          */
/* - Referential Containment Relationship                                   */
/*                                                                          */
#define DMAC_CONTAIN_REF    14

/* DMAC_CONTAIN_REF_CONTAINER                                               */
/*                                                                          */
/* If set, then classes of type Container and subclasses of that type may   */
/* be contained referentially.                                              */
/*                                                                          */
/* If reset, classes of type Container and subclasses of that type may not  */
/* be referentially contained.                                              */
/*                                                                          */
#define DMAC_CONTAIN_REF_CONTAINER    15

/* DMAC_CONTAIN_REF_CFG_HISTORY                                             */
/*                                                                          */
/* If set, then classes of type Configuration History and subclasses of     */
/* that type may be contained referentially.                                */
/*                                                                          */
/* If reset, then classes of type Configuration History and subclasses of   */
/* that type may not be referentially contained.                            */
/*                                                                          */
#define DMAC_CONTAIN_REF_CFG_HISTORY    16

/* DMAC_CONTAIN_REF_VER_SERIES                                              */
/*                                                                          */
/* If set, then classes of type Version Series and subclasses of that type  */
/* may be contained referentially.                                          */
/*                                                                          */
/* If reset, then classes of type Version Series and subclasses of that     */
/* type may not be referentially contained.                                 */
/*                                                                          */
#define DMAC_CONTAIN_REF_VER_SERIES    17

/* DMAC_CONTAIN_REF_VERS_DESC                                               */
/*                                                                          */
/* If set, then classes of type Version Description and subclasses of that  */
/* type may be contained referentially.                                     */
/*                                                                          */
/* If reset, then classes of type Version Description and subclasses of     */
/* that type may not be referentially contained.                            */
/*                                                                          */
#define DMAC_CONTAIN_REF_VERS_DESC    18

/* DMAC_CONTAIN_REF_DOC_VER                                                 */
/*                                                                          */
/* If set, then classes of type Doc Version and subclasses of that type     */
/* may be contained referentially.                                          */
/*                                                                          */
/* If reset, then classes of type Doc Version and subclasses of that type   */
/* may not be referentially contained.                                      */
/*                                                                          */
#define DMAC_CONTAIN_REF_DOC_VER    19

/* DMAC_CONTAIN_REF_OTHER                                                   */
/*                                                                          */
/* If set, then a class of type other than Doc Version, Configuration       */
/* History, Version Series, and Version Description and subclasses of       */
/* those classes may be contained referentially.                            */
/*                                                                          */
/* If reset, then no classes of type other than Doc Version, Configuration  */
/* History, Version Series, and Version Description and subclasses of       */
/* those classes may be contained referentially.                            */
/*                                                                          */
#define DMAC_CONTAIN_REF_OTHER    20

/* DMAC_CONTAIN_REF_MAX_DEPTH                                               */
/*                                                                          */
/* This is the maximum number of recursive levels that containers can       */
/* contain other containers referentially. If a container can not be        */
/* contained referentially by another container, the value is zero. If      */
/* there is no limit on the number of levels of referential containment of  */
/* containers, the value is -1.                                             */
/*                                                                          */
/* If referential containment is not supported, the value is zero.          */
/*                                                                          */
#define DMAC_CONTAIN_REF_MAX_DEPTH    21

/* DMAC_CONTAIN_REF_ORDER                                                   */
/*                                                                          */
/* The value of this capability is defined as DMAC_CONTAIN_REF_ORDER_HEAD   */
/* OR DMAC_CONTAIN_REF_ORDER_TAIL .                                         */
/*                                                                          */
#define DMAC_CONTAIN_REF_ORDER    22

/* DMAC_CONTAIN_REF_ORDER_HEAD                                              */
/*                                                                          */
/* If set, the IdmaRelationshipOrdering interface is supported for          */
/* Referential Containment Relationship objects, and the SetOrdering        */
/* method accepts the value DMA_POS_DEFAULT for the value of the            */
/* ulHeadWhere parameter.                                                   */
/*                                                                          */
/* If reset, the IdmaRelationshipOrdering interface is not supported for    */
/* Referential Containment Relationship objects.                            */
/*                                                                          */
#define DMAC_CONTAIN_REF_ORDER_HEAD    23

/* DMAC_CONTAIN_REF_ORDER_HEAD_BEFORE                                       */
/*                                                                          */
/* If set, the IdmaRelationshipOrdering:: SetOrdering method allows the     */
/* value DMA_POS_BEFORE for the ulHeadWhere parameter for Referential       */
/* Containment Relationship objects.                                        */
/*                                                                          */
/* If reset, either the IdmaRelationshipOrdering interface is not           */
/* supported for Referential Containment Relationship objects, or the       */
/* DMA_POS_BEFORE value for the ulHeadWhere parameter to SetOrdering is     */
/* not supported for Referential Containment Relationship objects.          */
/*                                                                          */
#define DMAC_CONTAIN_REF_ORDER_HEAD_BEFORE    24

/* DMAC_CONTAIN_REF_ORDER_HEAD_AFTER                                        */
/*                                                                          */
/* If set, the IdmaRelationshipOrdering:: SetOrdering method allows the     */
/* value DMA_POS_AFTER for the ulHeadWhere parameter for Referential        */
/* Containment Relationship objects.                                        */
/*                                                                          */
/* If reset, either the IdmaRelationshipOrdering interface is not           */
/* supported for Referential Containment Relationship objects, or the       */
/* DMA_POS_AFTER value for the ulHeadWhere parameter to SetOrdering is not  */
/* supported for Referential Containment Relationship objects.              */
/*                                                                          */
#define DMAC_CONTAIN_REF_ORDER_HEAD_AFTER    25

/* DMAC_CONTAIN_REF_ORDER_HEAD_FIRST                                        */
/*                                                                          */
/* If set, the IdmaRelationshipOrdering:: SetOrdering method allows the     */
/* value DMA_POS_FIRST for the ulHeadWhere parameter for Referential        */
/* Containment Relationship objects.                                        */
/*                                                                          */
/* If reset, either the IdmaRelationshipOrdering interface is not           */
/* supported for Referential Containment Relationship objects, or the       */
/* DMA_POS_FIRST value for the ulHeadWhere parameter to SetOrdering is not  */
/* supported for Referential Containment Relationship objects.              */
/*                                                                          */
#define DMAC_CONTAIN_REF_ORDER_HEAD_FIRST    26

/* DMAC_CONTAIN_REF_ORDER_HEAD_LAST                                         */
/*                                                                          */
/* If set, the IdmaRelationshipOrdering:: SetOrdering method allows the     */
/* value DMA_POS_LAST for the ulHeadWhere parameter for Referential         */
/* Containment Relationship objects.                                        */
/*                                                                          */
/* If reset, either the IdmaRelationshipOrdering interface is not           */
/* supported for Referential Containment Relationship objects, or the       */
/* DMA_POS_LAST value for the ulHeadWhere parameter to SetOrdering is not   */
/* supported for Referential Containment Relationship objects.              */
/*                                                                          */
#define DMAC_CONTAIN_REF_ORDER_HEAD_LAST    27

/* DMAC_CONTAIN_REF_ORDER_HEAD_NO_CH                                        */
/*                                                                          */
/* If set, the IdmaRelationshipOrdering:: SetOrdering method allows the     */
/* value DMA_POS_NO_CHANGE for the ulHeadWhere parameter for Referential    */
/* Containment Relationship objects.                                        */
/*                                                                          */
/* If reset, either the IdmaRelationshipOrdering interface is not           */
/* implemented for Referential Containment Relationship objects, or the     */
/* DMA_POS_NO_CHANGE value for the ulHeadWhere parameter to SetOrdering is  */
/* not supported for Referential Containment Relationship objects.          */
/*                                                                          */
#define DMAC_CONTAIN_REF_ORDER_HEAD_NO_CH    28

/* DMAC_CONTAIN_REF_ORDER_TAIL                                              */
/*                                                                          */
/* If set, the IdmaRelationshipOrdering interface is supported for          */
/* Referential Containment Relationship objects, and the SetOrdering        */
/* method accepts the value DMA_POS_DEFAULT for the value of the            */
/* ulTailWhere parameter.                                                   */
/*                                                                          */
/* If reset, the IdmaRelationshipOrdering interface is not supported for    */
/* Referential Containment Relationship objects.                            */
/*                                                                          */
#define DMAC_CONTAIN_REF_ORDER_TAIL    29

/* DMAC_CONTAIN_REF_ORDER_TAIL_BEFORE                                       */
/*                                                                          */
/* If set, the IdmaRelationshipOrdering:: SetOrdering method allows the     */
/* value DMA_POS_BEFORE for the ulTailWhere parameter for Referential       */
/* Containment Relationship objects.                                        */
/*                                                                          */
/* If reset, either the IdmaRelationshipOrdering interface is not           */
/* supported for Referential Containment Relationship objects, or the       */
/* DMA_POS_BEFORE value for the ulTailWhere parameter to SetOrdering is     */
/* not supported for Referential Containment Relationship objects.          */
/*                                                                          */
#define DMAC_CONTAIN_REF_ORDER_TAIL_BEFORE    30

/* DMAC_CONTAIN_REF_ORDER_TAIL_AFTER                                        */
/*                                                                          */
/* If set, the IdmaRelationshipOrdering:: SetOrdering method allows the     */
/* value DMA_POS_AFTER for the ulTailWhere parameter for Referential        */
/* Containment Relationship objects.                                        */
/*                                                                          */
/* If reset, either the IdmaRelationshipOrdering interface is not           */
/* supported for Referential Containment Relationship objects, or the       */
/* DMA_POS_AFTER value for the ulTailWhere parameter to SetOrdering is not  */
/* supported for Referential Containment Relationship objects.              */
/*                                                                          */
#define DMAC_CONTAIN_REF_ORDER_TAIL_AFTER    31

/* DMAC_CONTAIN_REF_ORDER_TAIL_FIRST                                        */
/*                                                                          */
/* If set, the IdmaRelationshipOrdering:: SetOrdering method allows the     */
/* value DMA_POS_FIRST for the ulTailWhere parameter for Referential        */
/* Containment Relationship objects.                                        */
/*                                                                          */
/* If reset, either the IdmaRelationshipOrdering interface is not           */
/* supported for Referential Containment Relationship objects, or the       */
/* DMA_POS_FIRST value for the ulTailWhere parameter to SetOrdering is not  */
/* supported for Referential Containment Relationship objects.              */
/*                                                                          */
#define DMAC_CONTAIN_REF_ORDER_TAIL_FIRST    32

/* DMAC_CONTAIN_REF_ORDER_TAIL_LAST                                         */
/*                                                                          */
/* If set, the IdmaRelationshipOrdering:: SetOrdering method allows the     */
/* value DMA_POS_LAST for the ulTailWhere parameter for Referential         */
/* Containment Relationship objects.                                        */
/*                                                                          */
/* If reset, either the IdmaRelationshipOrdering interface is not           */
/* supported for Referential Containment Relationship objects, or the       */
/* DMA_POS_LAST value for the ulTailWhere parameter to SetOrdering is not   */
/* supported for Referential Containment Relationship objects.              */
/*                                                                          */
#define DMAC_CONTAIN_REF_ORDER_TAIL_LAST    33

/* DMAC_CONTAIN_REF_ORDER_TAIL_NO_CH                                        */
/*                                                                          */
/* If set, the IdmaRelationshipOrdering:: SetOrdering method allows the     */
/* value DMA_POS_NO_CHANGE for the ulTailWhere parameter for Referential    */
/* Containment Relationship objects.                                        */
/*                                                                          */
/* If reset, either the IdmaRelationshipOrdering interface is not           */
/* supported for Referential Containment Relationship objects, or the       */
/* SetOrdering DMA_POS_NO_CHANGE value for the ulTailWhere parameter to     */
/* SetOrdering is not supported for Referential Containment Relationship    */
/* objects.                                                                 */
/*                                                                          */
#define DMAC_CONTAIN_REF_ORDER_TAIL_NO_CH    34

/* DMAC_CONTAIN_DIR                                                         */
/*                                                                          */
/* The value of DMAC_CONTAIN_DIR is defined to be                           */
/* DMAC_CONTAIN_DIR_CONTAINER OR DMAC_CONTAIN_DIR_CFG_HISTORY OR            */
/* DMAC_CONTAIN_DIR_VER_SERIES OR DMAC_CONTAIN_DIR_VER_DESC OR              */
/* DMAC_CONTAIN_DIR_DOC_VER OR DMAC_CONTAIN_DIR_OTHER .                     */
/*                                                                          */
/* If DMAC_CONTAIN_DIR is set, the following optional classes must be       */
/* supported:                                                               */
/*                                                                          */
/* - Direct Containment Relationship                                        */
/*                                                                          */
#define DMAC_CONTAIN_DIR    35

/* DMAC_CONTAIN_DIR_CONTAINER                                               */
/*                                                                          */
/* If set, then classes of type Container and subclasses of that type may   */
/* be contained directly.                                                   */
/*                                                                          */
/* If reset, then classes of type Container and subclasses of that type     */
/* may not be directly contained.                                           */
/*                                                                          */
#define DMAC_CONTAIN_DIR_CONTAINER    36

/* DMAC_CONTAIN_DIR_CFG_HISTORY                                             */
/*                                                                          */
/* If set, then classes of type Configuration History and subclasses of     */
/* that type may be contained directly.                                     */
/*                                                                          */
/* If reset, then classes of type Configuration History and subclasses of   */
/* that type may not be directly contained.                                 */
/*                                                                          */
#define DMAC_CONTAIN_DIR_CFG_HISTORY    37

/* DMAC_CONTAIN_DIR_VER_SERIES                                              */
/*                                                                          */
/* If set, then classes of type Version Series and subclasses of that type  */
/* may be contained directly.                                               */
/*                                                                          */
/* If reset, then classes of type Version Series and subclasses of that     */
/* type may not be directly contained.                                      */
/*                                                                          */
#define DMAC_CONTAIN_DIR_VER_SERIES    38

/* DMAC_CONTAIN_DIR_VER_DESC                                                */
/*                                                                          */
/* If set, then classes of type Version Description and subclasses of that  */
/* type may be contained directly.                                          */
/*                                                                          */
/* If reset, then classes of type Version Description and subclasses of     */
/* that type may not be directly contained.                                 */
/*                                                                          */
#define DMAC_CONTAIN_DIR_VER_DESC    39

/* DMAC_CONTAIN_DIR_DOC_VER                                                 */
/*                                                                          */
/* If set, then classes of type Doc Version and subclasses of that type     */
/* may be contained directly.                                               */
/*                                                                          */
/* If reset, then classes of type Doc Version and subclasses of that type   */
/* may not be directly contained.                                           */
/*                                                                          */
#define DMAC_CONTAIN_DIR_DOC_VER    40

/* DMAC_CONTAIN_DIR_OTHER                                                   */
/*                                                                          */
/* If set, then a class of type other than Doc Version, Configuration       */
/* History, Version Series, and Version Description and subclasses of       */
/* those classes may be contained directly.                                 */
/*                                                                          */
/* If reset, then no classes of type other than Doc Version, Configuration  */
/* History, Version Series, and Version Description and subclasses of       */
/* those classes may be contained directly.                                 */
/*                                                                          */
#define DMAC_CONTAIN_DIR_OTHER    41

/* DMAC_CONTAIN_DIR_MAX_DEPTH                                               */
/*                                                                          */
/* This is the maximum number of recursive levels that containers can       */
/* contain other containers via direct containment. If a container can not  */
/* be contained by another container via direct containment, the value is   */
/* zero. If there is no limit on the number of levels, the value is -1.     */
/*                                                                          */
/* If direct containment is not supported, the value is zero.               */
/*                                                                          */
#define DMAC_CONTAIN_DIR_MAX_DEPTH    42

/* DMAC_CONTAIN_DIR_ORDER                                                   */
/*                                                                          */
/* This capability is defined as DMAC_CONTAIN_DIR_ORDER_HEAD OR             */
/* DMAC_CONTAIN_DIR_ORDER_TAIL .                                            */
/*                                                                          */
#define DMAC_CONTAIN_DIR_ORDER    43

/* DMAC_CONTAIN_DIR_ORDER_HEAD                                              */
/*                                                                          */
/* If set, the IdmaRelationshipOrdering interface is supported for Direct   */
/* Containment Relationship objects, and the SetOrdering method accepts     */
/* the value DMA_POS_DEFAULT for the value of the ulHeadWhere parameter.    */
/*                                                                          */
/* If reset, the IdmaRelationshipOrdering interface is not supported for    */
/* Direct Containment Relationship objects.                                 */
/*                                                                          */
#define DMAC_CONTAIN_DIR_ORDER_HEAD    44

/* DMAC_CONTAIN_DIR_ORDER_HEAD_BEFORE                                       */
/*                                                                          */
/* If set, the IdmaRelationshipOrdering:: SetOrdering method allows the     */
/* value DMA_POS_BEFORE for the ulHeadWhere parameter for Direct            */
/* Containment Relationship objects.                                        */
/*                                                                          */
/* If reset, either the IdmaRelationshipOrdering interface is not           */
/* supported for Direct Containment Relationship objects, or the            */
/* DMA_POS_BEFORE value for the ulHeadWhere parameter to SetOrdering is     */
/* not supported for Direct Containment Relationship objects.               */
/*                                                                          */
#define DMAC_CONTAIN_DIR_ORDER_HEAD_BEFORE    45

/* DMAC_CONTAIN_DIR_ORDER_HEAD_AFTER                                        */
/*                                                                          */
/* If set, the IdmaRelationshipOrdering:: SetOrdering method allows the     */
/* value DMA_POS_AFTER for the ulHeadWhere parameter for Direct             */
/* Containment Relationship objects.                                        */
/*                                                                          */
/* If reset, either the IdmaRelationshipOrdering interface is not           */
/* supported for Direct Containment Relationship objects, or the            */
/* DMA_POS_AFTER value for the ulHeadWhere parameter to SetOrdering is not  */
/* supported for Direct Containment Relationship objects.                   */
/*                                                                          */
#define DMAC_CONTAIN_DIR_ORDER_HEAD_AFTER    46

/* DMAC_CONTAIN_DIR_ORDER_HEAD_FIRST                                        */
/*                                                                          */
/* If set, the IdmaRelationshipOrdering:: SetOrdering method allows the     */
/* value DMA_POS_FIRST for the ulHeadWhere parameter for Direct             */
/* Containment Relationship objects.                                        */
/*                                                                          */
/* If reset, either the IdmaRelationshipOrdering interface is not           */
/* supported for Direct Containment Relationship objects, or the            */
/* DMA_POS_FIRST value for the ulHeadWhere parameter to SetOrdering is not  */
/* supported for Direct Containment Relationship objects.                   */
/*                                                                          */
#define DMAC_CONTAIN_DIR_ORDER_HEAD_FIRST    47

/* DMAC_CONTAIN_DIR_ORDER_HEAD_LAST                                         */
/*                                                                          */
/* If set, the IdmaRelationshipOrdering:: SetOrdering method allows the     */
/* value DMA_POS_LAST for the ulHeadWhere parameter for Direct Containment  */
/* Relationship objects.                                                    */
/*                                                                          */
/* If reset, either the IdmaRelationshipOrdering interface is not           */
/* supported for Direct Containment Relationship objects, or the            */
/* DMA_POS_LAST value for the ulHeadWhere parameter to SetOrdering is not   */
/* supported for Direct Containment Relationship objects.                   */
/*                                                                          */
#define DMAC_CONTAIN_DIR_ORDER_HEAD_LAST    48

/* DMAC_CONTAIN_DIR_ORDER_HEAD_NO_CH                                        */
/*                                                                          */
/* If set, the IdmaRelationshipOrdering:: SetOrdering method allows the     */
/* value DMA_POS_NO_CHANGE for the ulHeadWhere parameter for Direct         */
/* Containment Relationship objects.                                        */
/*                                                                          */
/* If reset, either the IdmaRelationshipOrdering interface is not           */
/* implemented for Direct Containment Relationship objects, or the          */
/* DMA_POS_NO_CHANGE value for the ulHeadWhere parameter to SetOrdering is  */
/* not supported for Direct Containment Relationship objects.               */
/*                                                                          */
#define DMAC_CONTAIN_DIR_ORDER_HEAD_NO_CH    49

/* DMAC_CONTAIN_DIR_ORDER_TAIL                                              */
/*                                                                          */
/* If set, the IdmaRelationshipOrdering interface is supported for Direct   */
/* Containment Relationship objects, and the SetOrdering method accepts     */
/* the value DMA_POS_DEFAULT for the value of the ulTailWhere parameter.    */
/*                                                                          */
/* If reset, the IdmaRelationshipOrdering interface is not supported for    */
/* Direct Containment Relationship objects.                                 */
/*                                                                          */
#define DMAC_CONTAIN_DIR_ORDER_TAIL    50

/* DMAC_CONTAIN_DIR_ORDER_TAIL_BEFORE                                       */
/*                                                                          */
/* If set, the IdmaRelationshipOrdering:: SetOrdering method allows the     */
/* value DMA_POS_BEFORE for the ulTailWhere parameter for Direct            */
/* Containment Relationship objects.                                        */
/*                                                                          */
/* If reset, either the IdmaRelationshipOrdering interface is not           */
/* supported for Direct Containment Relationship objects, or the            */
/* DMA_POS_BEFORE value for the ulTailWhere parameter to SetOrdering is     */
/* not supported for Direct Containment Relationship objects.               */
/*                                                                          */
#define DMAC_CONTAIN_DIR_ORDER_TAIL_BEFORE    51

/* DMAC_CONTAIN_DIR_ORDER_TAIL_AFTER                                        */
/*                                                                          */
/* If set, the IdmaRelationshipOrdering:: SetOrdering method allows the     */
/* value DMA_POS_AFTER for the ulTailWhere parameter for Direct             */
/* Containment Relationship objects.                                        */
/*                                                                          */
/* If reset, either the IdmaRelationshipOrdering interface is not           */
/* supported for Direct Containment Relationship objects, or the            */
/* DMA_POS_AFTER value for the ulTailWhere parameter to SetOrdering is not  */
/* supported for Direct Containment Relationship objects.                   */
/*                                                                          */
#define DMAC_CONTAIN_DIR_ORDER_TAIL_AFTER    52

/* DMAC_CONTAIN_DIR_ORDER_TAIL_FIRST                                        */
/*                                                                          */
/* If set, the IdmaRelationshipOrdering:: SetOrdering method allows the     */
/* value DMA_POS_FIRST for the ulTailWhere parameter for Direct             */
/* Containment Relationship objects.                                        */
/*                                                                          */
/* If reset, either the IdmaRelationshipOrdering interface is not           */
/* supported for Direct Containment Relationship objects, or the            */
/* DMA_POS_FIRST value for the ulTailWhere parameter to SetOrdering is not  */
/* supported for Direct Containment Relationship objects.                   */
/*                                                                          */
#define DMAC_CONTAIN_DIR_ORDER_TAIL_FIRST    53

/* DMAC_CONTAIN_DIR_ORDER_TAIL_LAST                                         */
/*                                                                          */
/* If set, the IdmaRelationshipOrdering:: SetOrdering method allows the     */
/* value DMA_POS_LAST for the ulTailWhere parameter for Direct Containment  */
/* Relationship objects.                                                    */
/*                                                                          */
/* If reset, either the IdmaRelationshipOrdering interface is not           */
/* supported for Direct Containment Relationship objects, or the            */
/* DMA_POS_LAST value for the ulTailWhere parameter to SetOrdering is not   */
/* supported for Direct Containment Relationship objects.                   */
/*                                                                          */
#define DMAC_CONTAIN_DIR_ORDER_TAIL_LAST    54

/* DMAC_CONTAIN_DIR_ORDER_TAIL_NO_CH                                        */
/*                                                                          */
/* If set, the IdmaRelationshipOrdering:: SetOrdering method allows the     */
/* value DMA_POS_NO_CHANGE for the ulTailWhere parameter for Direct         */
/* Containment Relationship objects.                                        */
/*                                                                          */
/* If reset, either the IdmaRelationshipOrdering interface is not           */
/* supported for Direct Containment Relationship objects, or the            */
/* SetOrdering DMA_POS_NO_CHANGE value for the ulTailWhere parameter to     */
/* SetOrdering is not supported for Direct Containment Relationship         */
/* objects.                                                                 */
/*                                                                          */
#define DMAC_CONTAIN_DIR_ORDER_TAIL_NO_CH    55

/* DMAC_VERSION                                                             */
/*                                                                          */
/* If set, new document versions can be created via IdmaVersionable::       */
/* SetCheckin on the Doc Version object, followed by IdmaConnection::       */
/* ExecuteChange on the Doc Version object..                                */
/*                                                                          */
/* If reset, the checking in of new document versions is not supported.     */
/*                                                                          */
#define DMAC_VERSION    56

/* DMAC_VERSION_REQUIRED                                                    */
/*                                                                          */
/* If set, then the versioning related properties are required to have      */
/* values. Thus, for example, all documents have to be versioned.           */
/*                                                                          */
/* If reset, then the versioning related properties are not required to     */
/* have values. Thus, for example, there can be documents not in a version  */
/* series.                                                                  */
/*                                                                          */
#define DMAC_VERSION_REQUIRED    57

/* DMAC_VERSION_OTHER_ENTITIES                                              */
/*                                                                          */
/* If set, then there are classes that are not subclasses of Versionable    */
/* that have versioning properties, and so may be versioned.                */
/*                                                                          */
/* If reset, then only classes that are subclasses of Versionable can have  */
/* versioning properties.                                                   */
/*                                                                          */
#define DMAC_VERSION_OTHER_ENTITIES    58

/* DMAC_VERSION_CHECKIN_EXISTING                                            */
/*                                                                          */
/* If set, then the document space allows checkin of an object that is      */
/* already persistent.                                                      */
/*                                                                          */
/* If reset, then the document space does not allow checkin of an object    */
/* that is already persistent.                                              */
/*                                                                          */
#define DMAC_VERSION_CHECKIN_EXISTING    59

/* DMAC_VERSION_THREADED                                                    */
/*                                                                          */
/* If set, then a Doc Version can have more than one Version Description    */
/* as a parent.                                                             */
/*                                                                          */
/* If reset, then a Doc Version can have at most one Version Description    */
/* as a parent.                                                             */
/*                                                                          */
#define DMAC_VERSION_THREADED    60

/* DMAC_VERSION_CHECKOUT                                                    */
/*                                                                          */
/* If set, then the document space supports IdmaVersionSeries::             */
/* SetCheckOutNext.                                                         */
/*                                                                          */
/* If reset, then the document space does not support SetCheckOutNext.      */
/* (SetReserveNext is in the versioning baseline. SetCheckOutNext isn�t.)   */
/*                                                                          */
#define DMAC_VERSION_CHECKOUT    61

/* DMAC_VERSION_CHANGE_CURRENT                                              */
/*                                                                          */
/* If set, then the document space supports making a version other than     */
/* the last be the current version. The current version is what gets        */
/* checked out and leads to the next version when it�s checked in.          */
/* Changing the current version would be done by changing the Current       */
/* Version Description property of the Version Series object.               */
/*                                                                          */
/* If reset, the current version cannot be modified. This implies that the  */
/* current version is always the last version. This also implies that the   */
/* only way to insert a new version is checkout or reserve, followed by     */
/* checkin.                                                                 */
/*                                                                          */
#define DMAC_VERSION_CHANGE_CURRENT    62

/* DMAC_VERSION_DELETE_VERSION_DESCRIPTION                                  */
/*                                                                          */
/* If set, then the document space supports deleting some, but not          */
/* necessarily all, Version Descriptions in one operation.                  */
/*                                                                          */
/* If reset, versions can not be deleted selectively.                       */
/*                                                                          */
#define DMAC_VERSION_DELETE_VERSION_DESCRIPTION    63

/* DMAC_QUERY                                                               */
/*                                                                          */
/* If set, then query is supported: IdmaDocSpace:: GetScope is supported,   */
/* and at least the following query classes are supported: Scope, Query,    */
/* Query Node, Query Root, Query Property, Query Searchable Class, Query    */
/* Result Set, Query Result Row. There is at least one searchable class in  */
/* the Searchable Classes property of scopes generated by the document      */
/* space, and at least one selectable property in every searchable class    */
/* in scopes generated by the document space.                               */
/*                                                                          */
/* If reset, there are no useful queries that are supported. The            */
/* IdmaDocSpace:: GetScope method is not supported, and none of the query   */
/* classes are supported. The query classes are: Query, Query Constant,     */
/* Query Constant Binaries, Query Constant Binary, Query Constant Boolean,  */
/* Query Constant Booleans, Query Constant Date Time, Query Constant Date   */
/* Times, Query Constant Float64, Query Constant Float64s, Query Constant   */
/* Id, Query Constant Ids, Query Constant Integer32, Query Constant         */
/* Integer32s, Query Constant String, Query Constant Strings, Query Join    */
/* Op, Query Node, Query Nonterminal Node, Query Operand Description,       */
/* Query Operator, Query Operator Description, Query Order By Node, Query   */
/* Property, Query Result Row, Query Result Set, Query Root, Query          */
/* Searchable Class, Scope.                                                 */
/*                                                                          */
#define DMAC_QUERY    64

/* DMAC_QUERY_EXPRESSION                                                    */
/*                                                                          */
/* If set, then the following is true: DMAC_QUERY is set. The Query         */
/* Expression property of the  Query Root object may be non null. The       */
/* classes Query Operator Description, Query Operand Description, Query     */
/* Nonterminal Node, Query Constant, and Query Operator are supported. At   */
/* least one query operator that is not a join operator is supported. At    */
/* least one of the following query classes is supported: Query Constant    */
/* Binaries, Query Constant Binary, Query Constant Boolean, Query Constant  */
/* Booleans, Query Constant Date Time, Query Constant Date Times, Query     */
/* Constant Float64, Query Constant Float64s, Query Constant Id, Query      */
/* Constant Ids, Query Constant Integer32, Query Constant Integer32s,       */
/* Query Constant String, Query Constant Strings.                           */
/*                                                                          */
/* If reset, then the Query Expression property of the Query Root object    */
/* must be null.                                                            */
/*                                                                          */
#define DMAC_QUERY_EXPRESSION    65

/* DMAC_QUERY_JOINS                                                         */
/*                                                                          */
/* If set, then DMAC_QUERY is set, and at least one query join operator is  */
/* supported.                                                               */
/*                                                                          */
/* If reset, then no query join operators are supported.                    */
/*                                                                          */
#define DMAC_QUERY_JOINS    66

/* DMAC_QUERY_ORDERINGS                                                     */
/*                                                                          */
/* If set, then DMA_QUERY is set, and the Orderings property of the Query   */
/* Root object may be non null.                                             */
/*                                                                          */
/* If reset, then the Orderings property of the Query Root object must be   */
/* null.                                                                    */
/*                                                                          */
#define DMAC_QUERY_ORDERINGS    67

/* DMAC_3V_ELIMINATION                                                      */
/*                                                                          */
/* If set, Scope objects created by the current document space object       */
/* always perform three valued elimination on queries when requested to do  */
/* so.                                                                      */
/*                                                                          */
/* If reset, Scope objects created by the current document space object     */
/* never perform three valued elimination on queries.                       */
/*                                                                          */
#define DMAC_3V_ELIMINATION    68

/* DMAC_LOCKING                                                             */
/*                                                                          */
/* If this capability is set, locking is supported. The value of            */
/* DMAC_LOCKING is defined as DMAC_LOCKING_WRITER OR DMAC_LOCKING_READER    */
/* OR DMAC_LOCKING_EXISTENCE.                                               */
/*                                                                          */
/* Required Interfaces and methods:                                         */
/*                                                                          */
/* - IdmaConnection                                                         */
/*                                                                          */
/* - ApplyLock                                                              */
/*                                                                          */
/* - RemoveLock                                                             */
/*                                                                          */
/* - IdmaDocSpace                                                           */
/*                                                                          */
/* - ConnectAndLockObject                                                   */
/*                                                                          */
#define DMAC_LOCKING    69

/* DMAC_LOCKING_WRITER                                                      */
/*                                                                          */
/* If set, the value DMA_LOCK_WRITE for the lLockType parameter to          */
/* ApplyLock is supported.                                                  */
/*                                                                          */
/* If reset, the value DMA_LOCK_WRITE for the lLockType parameter to        */
/* ApplyLock is not supported.                                              */
/*                                                                          */
#define DMAC_LOCKING_WRITER    70

/* DMAC_LOCKING_READER                                                      */
/*                                                                          */
/* If set, the value DMA_LOCK_READ for the lLockType parameter to           */
/* ApplyLock is supported.                                                  */
/*                                                                          */
/* If reset, the value DMA_LOCK_READ for the lLockType parameter to         */
/* ApplyLock is not supported.                                              */
/*                                                                          */
#define DMAC_LOCKING_READER    71

/* DMAC_LOCKING_EXISTENCE                                                   */
/*                                                                          */
/* If set, the value DMA_LOCK_EXIST for the lLockType parameter to          */
/* ApplyLock is supported.                                                  */
/*                                                                          */
/* If reset, the value DMA_LOCK_EXIST for the lLockType parameter to        */
/* ApplyLock is not supported.                                              */
/*                                                                          */
#define DMAC_LOCKING_EXISTENCE    72


#endif /* DMACAPS_H */
