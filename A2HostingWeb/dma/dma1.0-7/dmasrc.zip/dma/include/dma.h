#ifndef DMA_H
#define DMA_H

/* DMA Spec 1.0                                                             */
/*    DMA universal include file.                                           */
/*    This file produced by hand on: 14-Apr-1998 at 11:44 PST               */
/*                                                                          */
/* Copyright 1995,1996,1997,1998 by                                         */
/*                                                                          */
/* Association for Information and Image Management Int'l                   */
/* 1100 Wayne Avenue                                                        */
/* Silver Spring, MD 20910-5603                                             */
/* Tel: 301/587-8202                                                        */
/* Fax: 301/587-2711                                                        */
/*                                                                          */
/* All Rights Reserved.                                                     */
/* DMA (Document Management Alliance) working group.                        */



/*                                                                          */
/*  Packing list for the DMA 1.0 header file package of 10-Apr-1998         */
/*    dmatypes.h produced on  08-Apr-1998 at 09:22                          */
/*    dmastr.h   produced on  08-Apr-1998 at 18:29                          */
/*    dmaenums.h produced on: 09-Apr-1998 at 08:20:53                       */
/*    dmacaps.h  produced on: 09-Apr-1998 at 08:20:53                       */
/*    dmarc.h    produced on  20-Feb-1998 at 09:15:07                       */
/*    dmacom.h   produced on  20-Feb-1998                                   */
/*    dmaiface.h produced on  20-Feb-1998 at 09:15:06                       */
/*    dmacfunc.h produced on  20-Feb-1998 at 09:15:05                       */
/*    dmaids.h   produced on: 09-Apr-1998 at 08:20:53                       */
/*    dmaidvar.h produced on: 14-Apr-1998 at 08:37:24                       */
/*                                                                          */
/* These are a consistent set of header files. Each of these header files   */
/* includes a comment that identifies the date it was produced.             */
/* This allows you to verify that you are using a consistent set of         */
/* header files.                                                            */


#include <dmatypes.h>
#include <dmastr.h>
#include <dmaenums.h>
#include <dmacaps.h>
#include <dmarc.h>
#include <dmacom.h>
#include <dmaiface.h>
#include <dmacfunc.h>
#include <dmaids.h>


#endif  /* DMA_H */