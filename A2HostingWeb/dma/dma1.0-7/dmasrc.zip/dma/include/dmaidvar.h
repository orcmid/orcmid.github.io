#ifndef  DMAIDVAR_H
#define  DMAIDVAR_H

/* DMA Spec 1.0                                                             */
/*    Classes and Properties DB Version  6,  17-Mar-1998                    */
/*    Interfaces and Methods DB Version  4,  18-Feb-1998                    */
/*    dmaidvar.h produced on: 14-Apr-1998 at 08:37:24                       */
/*                                                                          */
/* Copyright 1995,1996,1997,1998 by                                         */
/*                                                                          */
/* Association for Information and Image Management Int'l                   */
/* 1100 Wayne Avenue                                                        */
/* Silver Spring, MD 20910-5603                                             */
/* Tel: 301/587-8202                                                        */
/* Fax: 301/587-2711                                                        */
/*                                                                          */
/* All Rights Reserved.                                                     */
/* DMA (Document Management Alliance) working group.                        */

#if !defined(DMATYPES_H)
#   include <dmatypes.h>
#endif
#if !defined(DMACOM_H)
#   include <dmacom.h>
#endif
#if !defined(DMAIFACE_H)
#   include <dmaiface.h>
#endif
#if !defined(DMAIDS_H)
#   include <dmaids.h>
#endif

/*      Global defines for property, class, interface GUIDs                 */

/* This file is used to obtain values for DMA-defined unique identifiers    */
/*                                                                          */
/* Usage:                                                                   */
/*                                                                          */
/* Microsoft Visual C/C++ version 5.0 or later:                             */
/*                                                                          */
/*      Simply #include this file in any source module which references     */
/*      a Dma id.                                                           */
/*                                                                          */
/* Others:                                                                  */
/*                                                                          */
/*      In all but one source module, #include this file without defining   */
/*      DMA_INIT_ID. In one source module (per EXE or DLL) #include this    */
/*      file after #defining DMA_INIT_ID.                                   */

#if defined(_MSC_VER) && (_MSC_VER >= 1100)
#  define DMA_DECL_ID(x_) DMA_EXTERN_C DmaId __declspec(selectany) x_ = x_##Val;
#elif  defined(DMA_INIT_ID)
#  define DMA_DECL_ID(x_) DMA_EXTERN_C DmaId x_ = x_##Val;
#else
#  define DMA_DECL_ID(x_) DMA_EXTERN_C DmaId x_;
#endif

#ifndef __IUnknown_INTERFACE_DEFINED__
DMA_DECL_ID(IID_IUnknown)
#endif

#ifndef __IMalloc_INTERFACE_DEFINED__
DMA_DECL_ID(IID_IMalloc)
#endif

/*      Interfaces                                                          */

DMA_DECL_ID(IID_IdmaAuthentication)
DMA_DECL_ID(IID_IdmaBatch)
DMA_DECL_ID(IID_IdmaClassDescription)
DMA_DECL_ID(IID_IdmaConnection)
DMA_DECL_ID(IID_IdmaContentTransfer)
DMA_DECL_ID(IID_IdmaDocSpace)
DMA_DECL_ID(IID_IdmaEditList)
DMA_DECL_ID(IID_IdmaEditListOfBinary)
DMA_DECL_ID(IID_IdmaEditListOfBoolean)
DMA_DECL_ID(IID_IdmaEditListOfDateTime)
DMA_DECL_ID(IID_IdmaEditListOfFloat64)
DMA_DECL_ID(IID_IdmaEditListOfId)
DMA_DECL_ID(IID_IdmaEditListOfInteger32)
DMA_DECL_ID(IID_IdmaEditListOfObject)
DMA_DECL_ID(IID_IdmaEditListOfString)
DMA_DECL_ID(IID_IdmaEditProperties)
DMA_DECL_ID(IID_IdmaEnumOfObject)
DMA_DECL_ID(IID_IdmaList)
DMA_DECL_ID(IID_IdmaListOfBinary)
DMA_DECL_ID(IID_IdmaListOfBoolean)
DMA_DECL_ID(IID_IdmaListOfDateTime)
DMA_DECL_ID(IID_IdmaListOfFloat64)
DMA_DECL_ID(IID_IdmaListOfId)
DMA_DECL_ID(IID_IdmaListOfInteger32)
DMA_DECL_ID(IID_IdmaListOfObject)
DMA_DECL_ID(IID_IdmaListOfString)
DMA_DECL_ID(IID_IdmaObject)
DMA_DECL_ID(IID_IdmaObjectFactory)
DMA_DECL_ID(IID_IdmaOIID)
DMA_DECL_ID(IID_IdmaProgressCallback)
DMA_DECL_ID(IID_IdmaProperties)
DMA_DECL_ID(IID_IdmaRelationshipOrdering)
DMA_DECL_ID(IID_IdmaResultSet)
DMA_DECL_ID(IID_IdmaScope)
DMA_DECL_ID(IID_IdmaScopeFactory)
DMA_DECL_ID(IID_IdmaServiceRegistry)
DMA_DECL_ID(IID_IdmaStream)
DMA_DECL_ID(IID_IdmaSystem)
DMA_DECL_ID(IID_IdmaSystemManager)
DMA_DECL_ID(IID_IdmaTextOrdering)
DMA_DECL_ID(IID_IdmaVersionable)
DMA_DECL_ID(IID_IdmaVersionSeries)

/*      Class Definitions                                                   */

/* A metadata object describing a class.                                    */
DMA_DECL_ID(dmaClass_ClassDescription)

/* The root object for a conceptual versioned entity.                       */
DMA_DECL_ID(dmaClass_ConfigurationHistory)

/* The base class for all objects which can be contained, that is, the      */
/* generic "containee" class.                                               */
DMA_DECL_ID(dmaClass_Containable)

/* An object that can contain other objects either directly or              */
/* referentially, but cannot have content data of its own.                  */
DMA_DECL_ID(dmaClass_Container)

/* Relationship subclass for modeling containment                           */
DMA_DECL_ID(dmaClass_ContainmentRelationship)

/* Base class for classes used to access document content.                  */
DMA_DECL_ID(dmaClass_ContentElement)

/* A content element that represents content that exists outside the        */
/* control of the document space, but to which the document space           */
/* maintains a reference.                                                   */
DMA_DECL_ID(dmaClass_ContentReference)

/* A content element that represents content that is, or will be, directly  */
/* captured and managed by the document space.                              */
DMA_DECL_ID(dmaClass_ContentTransfer)

/* Defines a direct containment relationship                                */
DMA_DECL_ID(dmaClass_DirectContainmentRelationship)

/* The DMA base class.                                                      */
DMA_DECL_ID(dmaClass_DMA)

/* A Doc Space is a collection of documents and policies.                   */
DMA_DECL_ID(dmaClass_DocSpace)

/* A document version is single document stored in a Document Space.        */
DMA_DECL_ID(dmaClass_DocVersion)

/* A metadata class object describing an enumeration.                       */
DMA_DECL_ID(dmaClass_Enumeration)

/* An enumeration of object elements.                                       */
DMA_DECL_ID(dmaClass_EnumerationOfObject)

/* A list of elements of a common data type.                                */
DMA_DECL_ID(dmaClass_List)

/* A list of binary elements.                                               */
DMA_DECL_ID(dmaClass_ListOfBinary)

/* A list of boolean elements.                                              */
DMA_DECL_ID(dmaClass_ListOfBoolean)

/* A list of Date Time elements.                                            */
DMA_DECL_ID(dmaClass_ListOfDateTime)

/* A list of float elements.                                                */
DMA_DECL_ID(dmaClass_ListOfFloat64)

/* A list of ID elements.                                                   */
DMA_DECL_ID(dmaClass_ListOfId)

/* A list of integer elements.                                              */
DMA_DECL_ID(dmaClass_ListOfInteger32)

/* A list of object elements.                                               */
DMA_DECL_ID(dmaClass_ListOfObject)

/* A list of string elements.                                               */
DMA_DECL_ID(dmaClass_ListOfString)

/* The base for the metadata classes that describe classes, properties and  */
/* operators.                                                               */
DMA_DECL_ID(dmaClass_Metadata)

/* A metadata class object describing a property.                           */
DMA_DECL_ID(dmaClass_PropertyDescription)

/* A metadata class object describing a binary property.                    */
DMA_DECL_ID(dmaClass_PropertyDescriptionBinary)

/* A metadata class object describing a boolean property.                   */
DMA_DECL_ID(dmaClass_PropertyDescriptionBoolean)

/* A metadata class object describing a Date Time property.                 */
DMA_DECL_ID(dmaClass_PropertyDescriptionDateTime)

/* A metadata class object describing a float property.                     */
DMA_DECL_ID(dmaClass_PropertyDescriptionFloat64)

/* A metadata class object describing an ID property.                       */
DMA_DECL_ID(dmaClass_PropertyDescriptionId)

/* A metadata class object describing an integer property.                  */
DMA_DECL_ID(dmaClass_PropertyDescriptionInteger32)

/* A metadata class object describing an object property.                   */
DMA_DECL_ID(dmaClass_PropertyDescriptionObject)

/* A metadata class object describing a string property.                    */
DMA_DECL_ID(dmaClass_PropertyDescriptionString)

/* The complete definition of a query, including control settings.          */
DMA_DECL_ID(dmaClass_Query)

/* The purpose of this class is to factor out properties common to each     */
/* query constant class, and to each query parameter class.                 */
DMA_DECL_ID(dmaClass_QueryConstant)

/* This class is for lists of binary constants in query expressions.        */
DMA_DECL_ID(dmaClass_QueryConstantBinaries)

/* This class is for singleton constants in query expressions.              */
DMA_DECL_ID(dmaClass_QueryConstantBinary)

/* This class is for Boolean constants in query expressions.                */
DMA_DECL_ID(dmaClass_QueryConstantBoolean)

/* This class is for lists of Boolean constants in query expressions.       */
DMA_DECL_ID(dmaClass_QueryConstantBooleans)

/* This class is for Date Time constants in query expressions.              */
DMA_DECL_ID(dmaClass_QueryConstantDateTime)

/* This class is for lists of Date Time constants in query expressions.     */
DMA_DECL_ID(dmaClass_QueryConstantDateTimes)

/* This class is for float64 constants in query expressions.                */
DMA_DECL_ID(dmaClass_QueryConstantFloat64)

/* This class is for lists of float64 constants in query expressions.       */
DMA_DECL_ID(dmaClass_QueryConstantFloat64s)

/* This class is for DmaId constants in query expressions.                  */
DMA_DECL_ID(dmaClass_QueryConstantId)

/* This class is for lists of DmaIds in query expressions.                  */
DMA_DECL_ID(dmaClass_QueryConstantIds)

/* This class is for integer32 constants in query expressions.              */
DMA_DECL_ID(dmaClass_QueryConstantInteger32)

/* This class is for lists of integer32 constants in query expressions.     */
DMA_DECL_ID(dmaClass_QueryConstantInteger32s)

/* This class is for singleton constants in query expressions.              */
DMA_DECL_ID(dmaClass_QueryConstantString)

/* This class is for a list of string constants in a query expression.      */
DMA_DECL_ID(dmaClass_QueryConstantStrings)

/* This object class represents a join operation.                           */
DMA_DECL_ID(dmaClass_QueryJoinOperator)

/* The base class for most Query-related objects.                           */
DMA_DECL_ID(dmaClass_QueryNode)

/* This class exists to provide a place to factor out the dmaProp_Operands  */
/* property of query node objects.                                          */
DMA_DECL_ID(dmaClass_QueryNonterminalNode)

/* The Query Operand Description class is the metadata class that defines   */
/* the signatures of operands used in a query expression. Note that this    */
/* class does not inherit from the Metadata class, even though it is        */
/* metadata.                                                                */
DMA_DECL_ID(dmaClass_QueryOperandDescription)

/* This class represents operators in a query expression.                   */
DMA_DECL_ID(dmaClass_QueryOperator)

/* The Query Operator Description class is the metadata class that defines  */
/* the signatures of operators used in a Query Expression.                  */
DMA_DECL_ID(dmaClass_QueryOperatorDescription)

/* The elements in an Order By list must be of this class. Document spaces  */
/* do not have to support this class. And if it is supported, the Order By  */
/* list is optional for any given query.                                    */
DMA_DECL_ID(dmaClass_QueryOrderByNode)

/* The purpose of this class is to designate a property of a persistent     */
/* object involved in a query. Thus, leaf nodes of the Query Expression     */
/* parse tree that reference properties are of this class.                  */
DMA_DECL_ID(dmaClass_QueryProperty)

/* This object is a result row from the result set object of a query.       */
/* Thus, this is the end product of a query.                                */
DMA_DECL_ID(dmaClass_QueryResultRow)

/* Objects of this class are the root of a tree of objects stitched         */
/* together by reference.  The root object of the main query and the root   */
/* object of all subqueries (if any) are of this class.                     */
DMA_DECL_ID(dmaClass_QueryResultSet)

/* The root of a tree of Query Node objects that represents the main query  */
/* or a subquery of a query expression.                                     */
DMA_DECL_ID(dmaClass_QueryRoot)

/* Objects of this class designate a searchable class in a Document space.  */
/*  Objects of this class appear in the From Expression of queries and      */
/* subqueries.                                                              */
DMA_DECL_ID(dmaClass_QuerySearchableClass)

/* Defines a referential containment relationship.                          */
DMA_DECL_ID(dmaClass_ReferentialContainmentRelationship)

/* This is the base class for binary relationships between independently    */
/* persistable objects of a Document Space.                                 */
DMA_DECL_ID(dmaClass_Relationship)

/* Represents the content of the DocVersion in a particular format.         */
DMA_DECL_ID(dmaClass_Rendition)

/* Records the intention to perform a checkin of the versionable object to  */
/* the specified version series.                                            */
DMA_DECL_ID(dmaClass_Reservation)

/* A Scope object provides access to the query capabilities of a document   */
/* space or collection of document spaces.                                  */
DMA_DECL_ID(dmaClass_Scope)

/* A DMA system is a collection of Document Spaces.                         */
DMA_DECL_ID(dmaClass_System)

/* Base class for versionable classes                                       */
DMA_DECL_ID(dmaClass_Versionable)

/* Accounts for a single, specific occurrence of a versionable object in a  */
/* Version Series.                                                          */
DMA_DECL_ID(dmaClass_VersionDescription)

/* The Version Series Class objects represent collections of versionable    */
/* objects.                                                                 */
DMA_DECL_ID(dmaClass_VersionSeries)

/*      DMA Well Known Properties                                           */


/* All Version Series                                                       */
DMA_DECL_ID(dmaProp_AllVersionSeries)

/* Allows Constant                                                          */
DMA_DECL_ID(dmaProp_AllowsConstant)

/* Allows Expression                                                        */
DMA_DECL_ID(dmaProp_AllowsExpression)

/* Allows List                                                              */
DMA_DECL_ID(dmaProp_AllowsList)

/* Allows Property                                                          */
DMA_DECL_ID(dmaProp_AllowsProperty)

/* Allows Singleton                                                         */
DMA_DECL_ID(dmaProp_AllowsSingleton)

/* Batch Size Hint                                                          */
DMA_DECL_ID(dmaProp_BatchSizeHint)

/* Branched From Version Descriptions                                       */
DMA_DECL_ID(dmaProp_BranchedFromVersionDescriptions)

/* Branches                                                                 */
DMA_DECL_ID(dmaProp_Branches)

/* Cardinality                                                              */
DMA_DECL_ID(dmaProp_Cardinality)

/* Character Set Encoding                                                   */
DMA_DECL_ID(dmaProp_CharacterSetEncoding)

/* Children                                                                 */
DMA_DECL_ID(dmaProp_Children)

/* Class Description                                                        */
DMA_DECL_ID(dmaProp_ClassDescription)

/* Class Descriptions                                                       */
DMA_DECL_ID(dmaProp_ClassDescriptions)

/* Collation Sequence Id                                                    */
DMA_DECL_ID(dmaProp_CollationSequenceId)

/* Collation Sequence Ids                                                   */
DMA_DECL_ID(dmaProp_CollationSequenceIds)

/* Component Scopes                                                         */
DMA_DECL_ID(dmaProp_ComponentScopes)

/* Component Type                                                           */
DMA_DECL_ID(dmaProp_ComponentType)

/* Configuration History                                                    */
DMA_DECL_ID(dmaProp_ConfigurationHistory)

/* Constant Data Type                                                       */
DMA_DECL_ID(dmaProp_ConstantDataType)

/* Constant Is List                                                         */
DMA_DECL_ID(dmaProp_ConstantIsList)

/* Constant Value Binaries                                                  */
DMA_DECL_ID(dmaProp_ConstantValueBinaries)

/* Constant Value Binary                                                    */
DMA_DECL_ID(dmaProp_ConstantValueBinary)

/* Constant Value Boolean                                                   */
DMA_DECL_ID(dmaProp_ConstantValueBoolean)

/* Constant Value Booleans                                                  */
DMA_DECL_ID(dmaProp_ConstantValueBooleans)

/* Constant Value Date Time                                                 */
DMA_DECL_ID(dmaProp_ConstantValueDateTime)

/* Constant Value Date Times                                                */
DMA_DECL_ID(dmaProp_ConstantValueDateTimes)

/* Constant Value Float64                                                   */
DMA_DECL_ID(dmaProp_ConstantValueFloat64)

/* Constant Value Float64s                                                  */
DMA_DECL_ID(dmaProp_ConstantValueFloat64s)

/* Constant Value Id                                                        */
DMA_DECL_ID(dmaProp_ConstantValueId)

/* Constant Value Ids                                                       */
DMA_DECL_ID(dmaProp_ConstantValueIds)

/* Constant Value Integer32                                                 */
DMA_DECL_ID(dmaProp_ConstantValueInteger32)

/* Constant Value Integer32s                                                */
DMA_DECL_ID(dmaProp_ConstantValueInteger32s)

/* Constant Value String                                                    */
DMA_DECL_ID(dmaProp_ConstantValueString)

/* Constant Value Strings                                                   */
DMA_DECL_ID(dmaProp_ConstantValueStrings)

/* Containees                                                               */
DMA_DECL_ID(dmaProp_Containees)

/* Containers                                                               */
DMA_DECL_ID(dmaProp_Containers)

/* Content Elements                                                         */
DMA_DECL_ID(dmaProp_ContentElements)

/* Content Elements Present                                                 */
DMA_DECL_ID(dmaProp_ContentElementsPresent)

/* Content Location                                                         */
DMA_DECL_ID(dmaProp_ContentLocation)

/* Create Pending                                                           */
DMA_DECL_ID(dmaProp_CreatePending)

/* Current Of Series Count                                                  */
DMA_DECL_ID(dmaProp_CurrentOfSeriesCount)

/* Current Version Description                                              */
DMA_DECL_ID(dmaProp_CurrentVersionDescription)

/* Data Type                                                                */
DMA_DECL_ID(dmaProp_DataType)

/* Delete Pending                                                           */
DMA_DECL_ID(dmaProp_DeletePending)

/* Descending Requested                                                     */
DMA_DECL_ID(dmaProp_DescendingRequested)

/* Descriptive Text                                                         */
DMA_DECL_ID(dmaProp_DescriptiveText)

/* Display Name                                                             */
DMA_DECL_ID(dmaProp_DisplayName)

/* Distinct Rows Requested                                                  */
DMA_DECL_ID(dmaProp_DistinctRowsRequested)

/* Doc Space Capabilities                                                   */
DMA_DECL_ID(dmaProp_DocSpaceCapabilities)

/* Doc Space Id                                                             */
DMA_DECL_ID(dmaProp_DocSpaceId)

/* From Expression                                                          */
DMA_DECL_ID(dmaProp_FromExpression)

/* Has Arbitrary Order By                                                   */
DMA_DECL_ID(dmaProp_HasArbitraryOrderBy)

/* Has Distinct                                                             */
DMA_DECL_ID(dmaProp_HasDistinct)

/* Has Elimination                                                          */
DMA_DECL_ID(dmaProp_HasElimination)

/* Has Include Subclasses                                                   */
DMA_DECL_ID(dmaProp_HasIncludeSubclasses)

/* Has Proper Subclass Properties                                           */
DMA_DECL_ID(dmaProp_HasProperSubclassProperties)

/* Head                                                                     */
DMA_DECL_ID(dmaProp_Head)

/* Ids                                                                      */
DMA_DECL_ID(dmaProp_Ids)

/* Immediate Subclass Descriptions                                          */
DMA_DECL_ID(dmaProp_ImmediateSubclassDescriptions)

/* Include Subclasses Requested                                             */
DMA_DECL_ID(dmaProp_IncludeSubclassesRequested)

/* Initial Containers                                                       */
DMA_DECL_ID(dmaProp_InitialContainers)

/* Is Current Version                                                       */
DMA_DECL_ID(dmaProp_IsCurrentVersion)

/* Is Hidden                                                                */
DMA_DECL_ID(dmaProp_IsHidden)

/* Is List                                                                  */
DMA_DECL_ID(dmaProp_IsList)

/* Is Order Preserving                                                      */
DMA_DECL_ID(dmaProp_IsOrderPreserving)

/* Is Orderable                                                             */
DMA_DECL_ID(dmaProp_IsOrderable)

/* Is Primary Series                                                        */
DMA_DECL_ID(dmaProp_IsPrimarySeries)

/* Is Read Only                                                             */
DMA_DECL_ID(dmaProp_IsReadOnly)

/* Is Safe to Eliminate                                                     */
DMA_DECL_ID(dmaProp_IsSafeToEliminate)

/* Is Searchable                                                            */
DMA_DECL_ID(dmaProp_IsSearchable)

/* Is Selectable                                                            */
DMA_DECL_ID(dmaProp_IsSelectable)

/* Is System Generated                                                      */
DMA_DECL_ID(dmaProp_IsSystemGenerated)

/* Is Value Required                                                        */
DMA_DECL_ID(dmaProp_IsValueRequired)

/* Join Operator Id                                                         */
DMA_DECL_ID(dmaProp_JoinOperatorId)

/* Join Participation                                                       */
DMA_DECL_ID(dmaProp_JoinParticipation)

/* Locale Name                                                              */
DMA_DECL_ID(dmaProp_LocaleName)

/* Locale Names                                                             */
DMA_DECL_ID(dmaProp_LocaleNames)

/* Maximum Elements                                                         */
DMA_DECL_ID(dmaProp_MaximumElements)

/* Maximum Length Binary                                                    */
DMA_DECL_ID(dmaProp_MaximumLengthBinary)

/* Maximum Length String                                                    */
DMA_DECL_ID(dmaProp_MaximumLengthString)

/* Maximum Operands                                                         */
DMA_DECL_ID(dmaProp_MaximumOperands)

/* Maximum Result Items                                                     */
DMA_DECL_ID(dmaProp_MaximumResultItems)

/* Merges                                                                   */
DMA_DECL_ID(dmaProp_Merges)

/* Metadata Epoch                                                           */
DMA_DECL_ID(dmaProp_MetadataEpoch)

/* Minimum Elements                                                         */
DMA_DECL_ID(dmaProp_MinimumElements)

/* Minimum Operands                                                         */
DMA_DECL_ID(dmaProp_MinimumOperands)

/* Name Property Index                                                      */
DMA_DECL_ID(dmaProp_NamePropertyIndex)

/* New Version                                                              */
DMA_DECL_ID(dmaProp_NewVersion)

/* OIID                                                                     */
DMA_DECL_ID(dmaProp_OIID)

/* Operand Data Type                                                        */
DMA_DECL_ID(dmaProp_OperandDataType)

/* Operand Descriptions                                                     */
DMA_DECL_ID(dmaProp_OperandDescriptions)

/* Operands                                                                 */
DMA_DECL_ID(dmaProp_Operands)

/* Operators                                                                */
DMA_DECL_ID(dmaProp_Operators)

/* Orderings                                                                */
DMA_DECL_ID(dmaProp_Orderings)

/* Parent                                                                   */
DMA_DECL_ID(dmaProp_Parent)

/* Parent Container                                                         */
DMA_DECL_ID(dmaProp_ParentContainer)

/* Primary Version Series                                                   */
DMA_DECL_ID(dmaProp_PrimaryVersionSeries)

/* Proper Subclass Property Descriptions                                    */
DMA_DECL_ID(dmaProp_ProperSubclassPropertyDescriptions)

/* Property Default Binary                                                  */
DMA_DECL_ID(dmaProp_PropertyDefaultBinary)

/* Property Default Boolean                                                 */
DMA_DECL_ID(dmaProp_PropertyDefaultBoolean)

/* Property Default Date Time                                               */
DMA_DECL_ID(dmaProp_PropertyDefaultDateTime)

/* Property Default Float64                                                 */
DMA_DECL_ID(dmaProp_PropertyDefaultFloat64)

/* Property Default Id                                                      */
DMA_DECL_ID(dmaProp_PropertyDefaultId)

/* Property Default Integer32                                               */
DMA_DECL_ID(dmaProp_PropertyDefaultInteger32)

/* Property Default Object                                                  */
DMA_DECL_ID(dmaProp_PropertyDefaultObject)

/* Property Default String                                                  */
DMA_DECL_ID(dmaProp_PropertyDefaultString)

/* Property Descriptions                                                    */
DMA_DECL_ID(dmaProp_PropertyDescriptions)

/* Property Id                                                              */
DMA_DECL_ID(dmaProp_PropertyId)

/* Property Maximum Date Time                                               */
DMA_DECL_ID(dmaProp_PropertyMaximumDateTime)

/* Property Maximum Float64                                                 */
DMA_DECL_ID(dmaProp_PropertyMaximumFloat64)

/* Property Maximum Integer32                                               */
DMA_DECL_ID(dmaProp_PropertyMaximumInteger32)

/* Property Minimum Date Time                                               */
DMA_DECL_ID(dmaProp_PropertyMinimumDateTime)

/* Property Minimum Float64                                                 */
DMA_DECL_ID(dmaProp_PropertyMinimumFloat64)

/* Property Minimum Integer32                                               */
DMA_DECL_ID(dmaProp_PropertyMinimumInteger32)

/* Property Selection Binary                                                */
DMA_DECL_ID(dmaProp_PropertySelectionsBinary)

/* Property Selections Boolean                                              */
DMA_DECL_ID(dmaProp_PropertySelectionsBoolean)

/* Property Selections Date Time                                            */
DMA_DECL_ID(dmaProp_PropertySelectionsDateTime)

/* Property Selections Float64                                              */
DMA_DECL_ID(dmaProp_PropertySelectionsFloat64)

/* Property Selections Id                                                   */
DMA_DECL_ID(dmaProp_PropertySelectionsId)

/* Property Selections Integer32                                            */
DMA_DECL_ID(dmaProp_PropertySelectionsInteger32)

/* Property Selections Object                                               */
DMA_DECL_ID(dmaProp_PropertySelectionsObject)

/* Property Selections String                                               */
DMA_DECL_ID(dmaProp_PropertySelectionsString)

/* Query Construction Class Descriptions                                    */
DMA_DECL_ID(dmaProp_QueryConstructionClassDescriptions)

/* Query Expression                                                         */
DMA_DECL_ID(dmaProp_QueryExpression)

/* Query Id                                                                 */
DMA_DECL_ID(dmaProp_QueryId)

/* Query Operator Descriptions                                              */
DMA_DECL_ID(dmaProp_QueryOperatorDescriptions)

/* Query Operator Id                                                        */
DMA_DECL_ID(dmaProp_QueryOperatorId)

/* Query Root                                                               */
DMA_DECL_ID(dmaProp_QueryRoot)

/* Reflective Property Id                                                   */
DMA_DECL_ID(dmaProp_ReflectivePropertyId)

/* Rendition Type                                                           */
DMA_DECL_ID(dmaProp_RenditionType)

/* Renditions                                                               */
DMA_DECL_ID(dmaProp_Renditions)

/* Renditions Present                                                       */
DMA_DECL_ID(dmaProp_RenditionsPresent)

/* Required Class                                                           */
DMA_DECL_ID(dmaProp_RequiredClass)

/* Requires Unique Elements                                                 */
DMA_DECL_ID(dmaProp_RequiresUniqueElements)

/* Reservation                                                              */
DMA_DECL_ID(dmaProp_Reservation)

/* Reserved For                                                             */
DMA_DECL_ID(dmaProp_ReservedFor)

/* Result Type                                                              */
DMA_DECL_ID(dmaProp_ResultType)

/* Retrieval Name                                                           */
DMA_DECL_ID(dmaProp_RetrievalName)

/* Searchable Class Descriptions                                            */
DMA_DECL_ID(dmaProp_SearchableClassDescriptions)

/* Searchable Class Id                                                      */
DMA_DECL_ID(dmaProp_SearchableClassId)

/* Searchable Class Occurrence                                              */
DMA_DECL_ID(dmaProp_SearchableClassOccurrence)

/* Select List Offset                                                       */
DMA_DECL_ID(dmaProp_SelectListOffset)

/* Selections                                                               */
DMA_DECL_ID(dmaProp_Selections)

/* Selections Index                                                         */
DMA_DECL_ID(dmaProp_SelectionsIndex)

/* Superclass Description                                                   */
DMA_DECL_ID(dmaProp_SuperclassDescription)

/* Superclass Property Count                                                */
DMA_DECL_ID(dmaProp_SuperclassPropertyCount)

/* System Id                                                                */
DMA_DECL_ID(dmaProp_SystemId)

/* System OIID Prefix                                                       */
DMA_DECL_ID(dmaProp_SystemOIIDPrefix)

/* Tail                                                                     */
DMA_DECL_ID(dmaProp_Tail)

/* Terminated Into Version Descriptions                                     */
DMA_DECL_ID(dmaProp_TerminatedIntoVersionDescriptions)

/* This                                                                     */
DMA_DECL_ID(dmaProp_This)

/* Time Limit                                                               */
DMA_DECL_ID(dmaProp_TimeLimit)

/* Update Pending                                                           */
DMA_DECL_ID(dmaProp_UpdatePending)

/* Version                                                                  */
DMA_DECL_ID(dmaProp_Version)

/* Version Descriptions                                                     */
DMA_DECL_ID(dmaProp_VersionDescriptions)

/* Version Series                                                           */
DMA_DECL_ID(dmaProp_VersionSeries)

/* Versioned Object Class                                                   */
DMA_DECL_ID(dmaProp_VersionedObjectClass)

/*      DMA Well Known Query Operators                                      */


/* And                                                                      */
DMA_DECL_ID(dmaQueryOperator_And)

/* Or                                                                       */
DMA_DECL_ID(dmaQueryOperator_Or)

/* Not                                                                      */
DMA_DECL_ID(dmaQueryOperator_Not)

/* Equal Binary                                                             */
DMA_DECL_ID(dmaQueryOperator_EqualBinary)

/* Unequal Binary                                                           */
DMA_DECL_ID(dmaQueryOperator_UnequalBinary)

/* Greater Binary                                                           */
DMA_DECL_ID(dmaQueryOperator_GreaterBinary)

/* Greater Or Equal Binary                                                  */
DMA_DECL_ID(dmaQueryOperator_GreaterOrEqualBinary)

/* Less Binary                                                              */
DMA_DECL_ID(dmaQueryOperator_LessBinary)

/* Less Or Equal Binary                                                     */
DMA_DECL_ID(dmaQueryOperator_LessOrEqualBinary)

/* Equal String                                                             */
DMA_DECL_ID(dmaQueryOperator_EqualString)

/* Unequal String                                                           */
DMA_DECL_ID(dmaQueryOperator_UnequalString)

/* Greater String                                                           */
DMA_DECL_ID(dmaQueryOperator_GreaterString)

/* Greater Or Equal String                                                  */
DMA_DECL_ID(dmaQueryOperator_GreaterOrEqualString)

/* Less String                                                              */
DMA_DECL_ID(dmaQueryOperator_LessString)

/* Less Or Equal String                                                     */
DMA_DECL_ID(dmaQueryOperator_LessOrEqualString)

/* Equal Boolean                                                            */
DMA_DECL_ID(dmaQueryOperator_EqualBoolean)

/* Unequal Boolean                                                          */
DMA_DECL_ID(dmaQueryOperator_UnequalBoolean)

/* Equal Integer32                                                          */
DMA_DECL_ID(dmaQueryOperator_EqualInteger32)

/* Unequal Integer32                                                        */
DMA_DECL_ID(dmaQueryOperator_UnequalInteger32)

/* Greater Integer32                                                        */
DMA_DECL_ID(dmaQueryOperator_GreaterInteger32)

/* Greater Or Equal Integer32                                               */
DMA_DECL_ID(dmaQueryOperator_GreaterOrEqualInteger32)

/* Less Integer32                                                           */
DMA_DECL_ID(dmaQueryOperator_LessInteger32)

/* Less Or Equal Integer32                                                  */
DMA_DECL_ID(dmaQueryOperator_LessOrEqualInteger32)

/* Equal Float64                                                            */
DMA_DECL_ID(dmaQueryOperator_EqualFloat64)

/* Unequal Float64                                                          */
DMA_DECL_ID(dmaQueryOperator_UnequalFloat64)

/* Greater Float64                                                          */
DMA_DECL_ID(dmaQueryOperator_GreaterFloat64)

/* Greater Or Equal Float64                                                 */
DMA_DECL_ID(dmaQueryOperator_GreaterOrEqualFloat64)

/* Less Float64                                                             */
DMA_DECL_ID(dmaQueryOperator_LessFloat64)

/* Less Or Equal Float64                                                    */
DMA_DECL_ID(dmaQueryOperator_LessOrEqualFloat64)

/* Equal Date Time                                                          */
DMA_DECL_ID(dmaQueryOperator_EqualDateTime)

/* Unequal Date Time                                                        */
DMA_DECL_ID(dmaQueryOperator_UnequalDateTime)

/* Greater Date Time                                                        */
DMA_DECL_ID(dmaQueryOperator_GreaterDateTime)

/* Greater Or Equal Date Time                                               */
DMA_DECL_ID(dmaQueryOperator_GreaterOrEqualDateTime)

/* Less DateTime                                                            */
DMA_DECL_ID(dmaQueryOperator_LessDateTime)

/* Less Or Equal Date Time                                                  */
DMA_DECL_ID(dmaQueryOperator_LessOrEqualDateTime)

/* Equal Id                                                                 */
DMA_DECL_ID(dmaQueryOperator_EqualId)

/* Unequal Id                                                               */
DMA_DECL_ID(dmaQueryOperator_UnequalId)

/* Equal Object                                                             */
DMA_DECL_ID(dmaQueryOperator_EqualObject)

/* Is Defined                                                               */
DMA_DECL_ID(dmaQueryOperator_IsDefined)

/* Is Null                                                                  */
DMA_DECL_ID(dmaQueryOperator_IsNull)

/* Like                                                                     */
DMA_DECL_ID(dmaQueryOperator_Like)

/* Is Class                                                                 */
DMA_DECL_ID(dmaQueryOperator_IsClass)

/* Add Integer32                                                            */
DMA_DECL_ID(dmaQueryOperator_AddInteger32)

/* Subtract Integer32                                                       */
DMA_DECL_ID(dmaQueryOperator_SubtractInteger32)

/* Negate Integer32                                                         */
DMA_DECL_ID(dmaQueryOperator_NegateInteger32)

/* Absolute Value Integer32                                                 */
DMA_DECL_ID(dmaQueryOperator_AbsoluteValueInteger32)

/* Multiply Integer32                                                       */
DMA_DECL_ID(dmaQueryOperator_MultiplyInteger32)

/* Divide Integer32                                                         */
DMA_DECL_ID(dmaQueryOperator_DivideInteger32)

/* Add Float64                                                              */
DMA_DECL_ID(dmaQueryOperator_AddFloat64)

/* Subtract Float64                                                         */
DMA_DECL_ID(dmaQueryOperator_SubtractFloat64)

/* Negate Float64                                                           */
DMA_DECL_ID(dmaQueryOperator_NegateFloat64)

/* Absolute Value Float64                                                   */
DMA_DECL_ID(dmaQueryOperator_AbsoluteValueFloat64)

/* Multiply Float64                                                         */
DMA_DECL_ID(dmaQueryOperator_MultiplyFloat64)

/* Divide Float64                                                           */
DMA_DECL_ID(dmaQueryOperator_DivideFloat64)

/* Integer32 To Float64                                                     */
DMA_DECL_ID(dmaQueryOperator_Integer32ToFloat32)

/* Float64 To Integer32 Round                                               */
DMA_DECL_ID(dmaQueryOperator_Float64ToInteger32Round)

/* Float64 To Integer32 Truncate                                            */
DMA_DECL_ID(dmaQueryOperator_Float64ToInteger32Truncate)

/* Exists                                                                   */
DMA_DECL_ID(dmaQueryOperator_Exists)

/* In Binary                                                                */
DMA_DECL_ID(dmaQueryOperator_InBinary)

/* In Boolean                                                               */
DMA_DECL_ID(dmaQueryOperator_InBoolean)

/* In String                                                                */
DMA_DECL_ID(dmaQueryOperator_InString)

/* In Integer32                                                             */
DMA_DECL_ID(dmaQueryOperator_InInteger32)

/* In Float64                                                               */
DMA_DECL_ID(dmaQueryOperator_InFloat64)

/* In Date Time                                                             */
DMA_DECL_ID(dmaQueryOperator_InDateTime)

/* In Id                                                                    */
DMA_DECL_ID(dmaQueryOperator_InId)

/*      DMA Well Known Join Operators                                       */


/* Cross Join                                                               */
DMA_DECL_ID(dmaJoinOperator_Cross)

/* Inner Join                                                               */
DMA_DECL_ID(dmaJoinOperator_Inner)

/* Left Outer Join                                                          */
DMA_DECL_ID(dmaJoinOperator_LeftOuter)

/* Right Outer Join                                                         */
DMA_DECL_ID(dmaJoinOperator_RightOuter)

/* Module Type identifiers                                                  */

/* Win32 DLL                                                                */
DMA_DECL_ID(dmaModuleType_Win32DLL)

/* Service Type identifiers                                                 */

/* System                                                                   */
DMA_DECL_ID(dmaServiceType_System)
/* DocSpace                                                                 */
DMA_DECL_ID(dmaServiceType_DocSpace)
/* Text Ordering                                                            */
DMA_DECL_ID(dmaServiceType_TextOrdering)
/* Scope Factory                                                            */
DMA_DECL_ID(dmaServiceType_ScopeFactory)
/* OIID Parser                                                              */
DMA_DECL_ID(dmaServiceType_OIIDParser)

/* Well known service instance identifiers                                  */

/* Scope Factory                                                            */
DMA_DECL_ID(dmaServiceObject_ScopeFactory)
/* OIID Parser                                                              */
DMA_DECL_ID(dmaServiceObject_OIIDParser)

/* Well known collation sequence identifiers                                */

/* Case sensitive, code point order                                         */
DMA_DECL_ID(dmaCollation_CaseSensitiveCodePoint)
/* Case insensitive, code point order                                       */
DMA_DECL_ID(dmaCollation_CaseInsensitiveCodePoint)
/* Case sensitive, locale-determined lexicographic order                    */
DMA_DECL_ID(dmaCollation_CaseSensitiveLexicographic)
/* Case insensitive, locale-determined lexicographic order                  */
DMA_DECL_ID(dmaCollation_CaseInsensitiveLexicographic)

#endif /* DMAIDVAR_H */
