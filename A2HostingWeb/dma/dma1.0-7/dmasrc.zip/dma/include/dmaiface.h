#ifndef  DMAIFACE_H
#define  DMAIFACE_H

/* DMA Spec 1.0                                                             */
/*    Interfaces and Methods DB Version  4,  18-Feb-1998                    */
/*    This file produced on: 20-Feb-1998 at 09:15:06                        */
/*                                                                          */
/* Copyright 1995,1996,1997,1998 by                                         */
/*                                                                          */
/* Association for Information and Image Management Int'l                   */
/* 1100 Wayne Avenue                                                        */
/* Silver Spring, MD 20910-5603                                             */
/* Tel: 301/587-8202                                                        */
/* Fax: 301/587-2711                                                        */
/*                                                                          */
/* All Rights Reserved.                                                     */
/* DMA (Document Management Alliance) working group.                        */

/*     DMA Interface Definitions                                            */

#if !defined(DMATYPES_H)
#   include <dmatypes.h>
#endif
#if !defined(DMACOM_H)
#   include <dmacom.h>
#endif

/* IdmaObject Interface */
#undef  INTERFACE
#define INTERFACE   IdmaObject
#define IID_IdmaObjectVal {0x387E843A, 0x7AE7, 0x11d1, \
    {0x8E, 0x99, 0x08, 0x00, 0x2B, 0xE2, 0x9E, 0x1D}}
DMA_DECLARE_INTERFACE_(387E843A-7AE7-11d1-8E99-08002BE29E1D,IdmaObject, IUnknown)
{
    DMA_BEGIN_INTERFACE
    DMA_DECLARE_IUNKNOWN_METHODS
    DMA_STDMETHOD(IsOfClass) (DMA_THIS_ pDmaId pClassId, 
             pDmaBoolean pbIsOfClass) DMA_PURE;
    DMA_END_INTERFACE
};
typedef IdmaObject DMA_DATA_FAR * LPIdmaObject;

/* IdmaProperties Interface */
#undef  INTERFACE
#define INTERFACE   IdmaProperties
#define IID_IdmaPropertiesVal {0x387E843E, 0x7AE7, 0x11d1, \
    {0x8E, 0x99, 0x08, 0x00, 0x2B, 0xE2, 0x9E, 0x1D}}
DMA_DECLARE_INTERFACE_(387E843E-7AE7-11d1-8E99-08002BE29E1D,IdmaProperties, IUnknown)
{
    DMA_BEGIN_INTERFACE
    DMA_DECLARE_IUNKNOWN_METHODS
    DMA_STDMETHOD(GetPropValBooleanByIndex) (DMA_THIS_ DmaIndex32 iIndex, 
             pDmaBoolean pbBooleanValue) DMA_PURE;
    DMA_STDMETHOD(GetPropValBooleanById) (DMA_THIS_ pDmaId pPropertyId, 
             pDmaBoolean pbBooleanValue) DMA_PURE;
    DMA_STDMETHOD(GetPropValInteger32ByIndex) (DMA_THIS_ DmaIndex32 iIndex, 
             pDmaInteger32 plIntegerValue) DMA_PURE;
    DMA_STDMETHOD(GetPropValInteger32ById) (DMA_THIS_ pDmaId pPropertyId, 
             pDmaInteger32 plIntegerValue) DMA_PURE;
    DMA_STDMETHOD(GetPropValFloat64ByIndex) (DMA_THIS_ DmaIndex32 iIndex, 
             pDmaFloat64 pfFloatValue) DMA_PURE;
    DMA_STDMETHOD(GetPropValFloat64ById) (DMA_THIS_ pDmaId pPropertyId, 
             pDmaFloat64 pfFloatValue) DMA_PURE;
    DMA_STDMETHOD(GetPropValStringByIndex) (DMA_THIS_ DmaIndex32 iIndex, 
             ppDmaString ppStringValue) DMA_PURE;
    DMA_STDMETHOD(GetPropValStringById) (DMA_THIS_ pDmaId pPropertyId, 
             ppDmaString ppStringValue) DMA_PURE;
    DMA_STDMETHOD(GetPropValBinaryByIndex) (DMA_THIS_ DmaIndex32 iIndex, 
             DmaBinaryValue* pBinaryValue) DMA_PURE;
    DMA_STDMETHOD(GetPropValBinaryById) (DMA_THIS_ pDmaId pPropertyId, 
             DmaBinaryValue* pBinaryValue) DMA_PURE;
    DMA_STDMETHOD(GetPropValObjectByIndex) (DMA_THIS_ DmaIndex32 iIndex, 
             DMA_REFIID riid, pDmapv ppIObjectValue) DMA_PURE;
    DMA_STDMETHOD(GetPropValObjectById) (DMA_THIS_ pDmaId pPropertyId, 
             DMA_REFIID riid, pDmapv ppIObjectValue) DMA_PURE;
    DMA_STDMETHOD(GetPropValIdById) (DMA_THIS_ pDmaId pPropertyId, 
             pDmaId pIdValue) DMA_PURE;
    DMA_STDMETHOD(GetPropValIdByIndex) (DMA_THIS_ DmaIndex32 iIndex, 
             pDmaId pIdValue) DMA_PURE;
    DMA_STDMETHOD(GetPropValDateTimeById) (DMA_THIS_ pDmaId pPropertyId, 
             ppDmaDateTime ppDateTimeValue) DMA_PURE;
    DMA_STDMETHOD(GetPropValDateTimeByIndex) (DMA_THIS_ DmaIndex32 iIndex, 
             ppDmaDateTime ppDateTimeValue) DMA_PURE;
    DMA_END_INTERFACE
};
typedef IdmaProperties DMA_DATA_FAR * LPIdmaProperties;

/* IdmaAuthentication Interface */
#undef  INTERFACE
#define INTERFACE   IdmaAuthentication
#define IID_IdmaAuthenticationVal {0x387E8420, 0x7AE7, 0x11d1, \
    {0x8E, 0x99, 0x08, 0x00, 0x2B, 0xE2, 0x9E, 0x1D}}
DMA_DECLARE_INTERFACE_(387E8420-7AE7-11d1-8E99-08002BE29E1D,IdmaAuthentication, IUnknown)
{
    DMA_BEGIN_INTERFACE
    DMA_DECLARE_IUNKNOWN_METHODS
    DMA_STDMETHOD(AuthenticateUser) (DMA_THIS_ pDmaString pStringIn, 
             ppDmaString ppStringOut) DMA_PURE;
    DMA_STDMETHOD(AutoAuthenticateUser) (DMA_THIS) DMA_PURE;
    DMA_END_INTERFACE
};
typedef IdmaAuthentication DMA_DATA_FAR * LPIdmaAuthentication;

/* IdmaBatch Interface */
#undef  INTERFACE
#define INTERFACE   IdmaBatch
#define IID_IdmaBatchVal {0x387E8421, 0x7AE7, 0x11d1, \
    {0x8E, 0x99, 0x08, 0x00, 0x2B, 0xE2, 0x9E, 0x1D}}
DMA_DECLARE_INTERFACE_(387E8421-7AE7-11d1-8E99-08002BE29E1D,IdmaBatch, IUnknown)
{
    DMA_BEGIN_INTERFACE
    DMA_DECLARE_IUNKNOWN_METHODS
    DMA_STDMETHOD(ExecuteChanges) (DMA_THIS_ Dmapv pICallback, 
             Dmapv plListOfObj, pDmaIndex32 piIndex, 
             DmaInteger32 lProtectionLevel, DmaBoolean bRefreshFlag) DMA_PURE;
    DMA_END_INTERFACE
};
typedef IdmaBatch DMA_DATA_FAR * LPIdmaBatch;

/* IdmaClassDescription Interface */
#undef  INTERFACE
#define INTERFACE   IdmaClassDescription
#define IID_IdmaClassDescriptionVal {0x387E8422, 0x7AE7, 0x11d1, \
    {0x8E, 0x99, 0x08, 0x00, 0x2B, 0xE2, 0x9E, 0x1D}}
DMA_DECLARE_INTERFACE_(387E8422-7AE7-11d1-8E99-08002BE29E1D,IdmaClassDescription, IUnknown)
{
    DMA_BEGIN_INTERFACE
    DMA_DECLARE_IUNKNOWN_METHODS
    DMA_STDMETHOD(CreateInstance) (DMA_THIS_ DMA_REFIID riid, pDmapv ppIObject) DMA_PURE;
    DMA_STDMETHOD(IsOfClass) (DMA_THIS_ pDmaId pClassId, 
             pDmaBoolean pbIsOfClass) DMA_PURE;
    DMA_END_INTERFACE
};
typedef IdmaClassDescription DMA_DATA_FAR * LPIdmaClassDescription;

/* IdmaConnection Interface */
#undef  INTERFACE
#define INTERFACE   IdmaConnection
#define IID_IdmaConnectionVal {0x387E8423, 0x7AE7, 0x11d1, \
    {0x8E, 0x99, 0x08, 0x00, 0x2B, 0xE2, 0x9E, 0x1D}}
DMA_DECLARE_INTERFACE_(387E8423-7AE7-11d1-8E99-08002BE29E1D,IdmaConnection, IUnknown)
{
    DMA_BEGIN_INTERFACE
    DMA_DECLARE_IUNKNOWN_METHODS
    DMA_STDMETHOD(ExecuteChange) (DMA_THIS_ Dmapv pICallback, 
             DmaInteger32 lProtectionLevel, DmaBoolean bRefreshFlag) DMA_PURE;
    DMA_STDMETHOD(SetDeletePending) (DMA_THIS_ DmaBoolean bDeleteFlag) DMA_PURE;
    DMA_STDMETHOD(IsCurrent) (DMA_THIS_ pDmaBoolean pbIsCurrent) DMA_PURE;
    DMA_STDMETHOD(ExecuteRefresh) (DMA_THIS) DMA_PURE;
    DMA_STDMETHOD(ApplyLock) (DMA_THIS_ DmaInteger32 lLockType) DMA_PURE;
    DMA_STDMETHOD(RemoveLock) (DMA_THIS) DMA_PURE;
    DMA_END_INTERFACE
};
typedef IdmaConnection DMA_DATA_FAR * LPIdmaConnection;

/* IdmaContentTransfer Interface */
#undef  INTERFACE
#define INTERFACE   IdmaContentTransfer
#define IID_IdmaContentTransferVal {0x387E8424, 0x7AE7, 0x11d1, \
    {0x8E, 0x99, 0x08, 0x00, 0x2B, 0xE2, 0x9E, 0x1D}}
DMA_DECLARE_INTERFACE_(387E8424-7AE7-11d1-8E99-08002BE29E1D,IdmaContentTransfer, IUnknown)
{
    DMA_BEGIN_INTERFACE
    DMA_DECLARE_IUNKNOWN_METHODS
    DMA_STDMETHOD(SetCaptureStream) (DMA_THIS_ Dmapv pStream) DMA_PURE;
    DMA_STDMETHOD(SetCaptureResource) (DMA_THIS_ pDmaString pResourceName) DMA_PURE;
    DMA_STDMETHOD(GetResourceName) (DMA_THIS_ ppDmaString ppName) DMA_PURE;
    DMA_STDMETHOD(GetStream) (DMA_THIS_ DMA_REFIID riid, pDmapv ppIStream) DMA_PURE;
    DMA_STDMETHOD(CopyToResource) (DMA_THIS_ pDmaString pDestName, 
             DmaInteger32 flags) DMA_PURE;
    DMA_END_INTERFACE
};
typedef IdmaContentTransfer DMA_DATA_FAR * LPIdmaContentTransfer;

/* IdmaDocSpace Interface */
#undef  INTERFACE
#define INTERFACE   IdmaDocSpace
#define IID_IdmaDocSpaceVal {0x387E8425, 0x7AE7, 0x11d1, \
    {0x8E, 0x99, 0x08, 0x00, 0x2B, 0xE2, 0x9E, 0x1D}}
DMA_DECLARE_INTERFACE_(387E8425-7AE7-11d1-8E99-08002BE29E1D,IdmaDocSpace, IUnknown)
{
    DMA_BEGIN_INTERFACE
    DMA_DECLARE_IUNKNOWN_METHODS
    DMA_STDMETHOD(ConnectObject) (DMA_THIS_ pDmaString pObjectId, 
             DMA_REFIID riid, pDmapv ppIObject) DMA_PURE;
    DMA_STDMETHOD(ConnectAndLockObject) (DMA_THIS_ pDmaString pObjectId, 
             DmaInteger32 lLockType, DMA_REFIID riid, pDmapv ppIObject) DMA_PURE;
    DMA_STDMETHOD(GetScope) (DMA_THIS_ DMA_REFIID riid, pDmapv ppIScope) DMA_PURE;
    DMA_STDMETHOD(ExecuteDisconnect) (DMA_THIS) DMA_PURE;
    DMA_END_INTERFACE
};
typedef IdmaDocSpace DMA_DATA_FAR * LPIdmaDocSpace;

/* IdmaEditList Interface */
#undef  INTERFACE
#define INTERFACE   IdmaEditList
#define IID_IdmaEditListVal {0x387E8426, 0x7AE7, 0x11d1, \
    {0x8E, 0x99, 0x08, 0x00, 0x2B, 0xE2, 0x9E, 0x1D}}
DMA_DECLARE_INTERFACE_(387E8426-7AE7-11d1-8E99-08002BE29E1D,IdmaEditList, IUnknown)
{
    DMA_BEGIN_INTERFACE
    DMA_DECLARE_IUNKNOWN_METHODS
    DMA_STDMETHOD(DeleteElement) (DMA_THIS_ DmaIndex32 iIndex) DMA_PURE;
    DMA_STDMETHOD(TruncateList) (DMA_THIS_ DmaIndex32 iIndex) DMA_PURE;
    DMA_END_INTERFACE
};
typedef IdmaEditList DMA_DATA_FAR * LPIdmaEditList;

/* IdmaEditListOfBinary Interface */
#undef  INTERFACE
#define INTERFACE   IdmaEditListOfBinary
#define IID_IdmaEditListOfBinaryVal {0x387E8427, 0x7AE7, 0x11d1, \
    {0x8E, 0x99, 0x08, 0x00, 0x2B, 0xE2, 0x9E, 0x1D}}
DMA_DECLARE_INTERFACE_(387E8427-7AE7-11d1-8E99-08002BE29E1D,IdmaEditListOfBinary, IdmaEditList)
{
    DMA_BEGIN_INTERFACE
    DMA_DECLARE_IUNKNOWN_METHODS
    DMA_STDMETHOD(DeleteElement) (DMA_THIS_ DmaIndex32 iIndex) DMA_PURE;
    DMA_STDMETHOD(TruncateList) (DMA_THIS_ DmaIndex32 iIndex) DMA_PURE;
    DMA_STDMETHOD(InsertBinary) (DMA_THIS_ DmaIndex32 iIndex, 
             DmaBinaryValue* pBinaryValue) DMA_PURE;
    DMA_STDMETHOD(ReplaceBinary) (DMA_THIS_ DmaIndex32 iIndex, 
             DmaBinaryValue* pBinaryValue) DMA_PURE;
    DMA_END_INTERFACE
};
typedef IdmaEditListOfBinary DMA_DATA_FAR * LPIdmaEditListOfBinary;

/* IdmaEditListOfBoolean Interface */
#undef  INTERFACE
#define INTERFACE   IdmaEditListOfBoolean
#define IID_IdmaEditListOfBooleanVal {0x387E8428, 0x7AE7, 0x11d1, \
    {0x8E, 0x99, 0x08, 0x00, 0x2B, 0xE2, 0x9E, 0x1D}}
DMA_DECLARE_INTERFACE_(387E8428-7AE7-11d1-8E99-08002BE29E1D,IdmaEditListOfBoolean, IdmaEditList)
{
    DMA_BEGIN_INTERFACE
    DMA_DECLARE_IUNKNOWN_METHODS
    DMA_STDMETHOD(DeleteElement) (DMA_THIS_ DmaIndex32 iIndex) DMA_PURE;
    DMA_STDMETHOD(TruncateList) (DMA_THIS_ DmaIndex32 iIndex) DMA_PURE;
    DMA_STDMETHOD(InsertBoolean) (DMA_THIS_ DmaIndex32 iIndex, 
             DmaBoolean bBooleanValue) DMA_PURE;
    DMA_STDMETHOD(ReplaceBoolean) (DMA_THIS_ DmaIndex32 iIndex, 
             DmaBoolean bBooleanValue) DMA_PURE;
    DMA_END_INTERFACE
};
typedef IdmaEditListOfBoolean DMA_DATA_FAR * LPIdmaEditListOfBoolean;

/* IdmaEditListOfDateTime Interface */
#undef  INTERFACE
#define INTERFACE   IdmaEditListOfDateTime
#define IID_IdmaEditListOfDateTimeVal {0x387E8429, 0x7AE7, 0x11d1, \
    {0x8E, 0x99, 0x08, 0x00, 0x2B, 0xE2, 0x9E, 0x1D}}
DMA_DECLARE_INTERFACE_(387E8429-7AE7-11d1-8E99-08002BE29E1D,IdmaEditListOfDateTime, IdmaEditList)
{
    DMA_BEGIN_INTERFACE
    DMA_DECLARE_IUNKNOWN_METHODS
    DMA_STDMETHOD(DeleteElement) (DMA_THIS_ DmaIndex32 iIndex) DMA_PURE;
    DMA_STDMETHOD(TruncateList) (DMA_THIS_ DmaIndex32 iIndex) DMA_PURE;
    DMA_STDMETHOD(InsertDateTime) (DMA_THIS_ DmaIndex32 iIndex, 
             pDmaDateTime pDateTimeValue) DMA_PURE;
    DMA_STDMETHOD(ReplaceDateTime) (DMA_THIS_ DmaIndex32 iIndex, 
             pDmaDateTime pDateTimeValue) DMA_PURE;
    DMA_END_INTERFACE
};
typedef IdmaEditListOfDateTime DMA_DATA_FAR * LPIdmaEditListOfDateTime;

/* IdmaEditListOfFloat64 Interface */
#undef  INTERFACE
#define INTERFACE   IdmaEditListOfFloat64
#define IID_IdmaEditListOfFloat64Val {0x387E842A, 0x7AE7, 0x11d1, \
    {0x8E, 0x99, 0x08, 0x00, 0x2B, 0xE2, 0x9E, 0x1D}}
DMA_DECLARE_INTERFACE_(387E842A-7AE7-11d1-8E99-08002BE29E1D,IdmaEditListOfFloat64, IdmaEditList)
{
    DMA_BEGIN_INTERFACE
    DMA_DECLARE_IUNKNOWN_METHODS
    DMA_STDMETHOD(DeleteElement) (DMA_THIS_ DmaIndex32 iIndex) DMA_PURE;
    DMA_STDMETHOD(TruncateList) (DMA_THIS_ DmaIndex32 iIndex) DMA_PURE;
    DMA_STDMETHOD(InsertFloat64) (DMA_THIS_ DmaIndex32 iIndex, 
             DmaFloat64 fFloatValue) DMA_PURE;
    DMA_STDMETHOD(ReplaceFloat64) (DMA_THIS_ DmaIndex32 iIndex, 
             DmaFloat64 fFloatValue) DMA_PURE;
    DMA_END_INTERFACE
};
typedef IdmaEditListOfFloat64 DMA_DATA_FAR * LPIdmaEditListOfFloat64;

/* IdmaEditListOfId Interface */
#undef  INTERFACE
#define INTERFACE   IdmaEditListOfId
#define IID_IdmaEditListOfIdVal {0x387E842B, 0x7AE7, 0x11d1, \
    {0x8E, 0x99, 0x08, 0x00, 0x2B, 0xE2, 0x9E, 0x1D}}
DMA_DECLARE_INTERFACE_(387E842B-7AE7-11d1-8E99-08002BE29E1D,IdmaEditListOfId, IdmaEditList)
{
    DMA_BEGIN_INTERFACE
    DMA_DECLARE_IUNKNOWN_METHODS
    DMA_STDMETHOD(DeleteElement) (DMA_THIS_ DmaIndex32 iIndex) DMA_PURE;
    DMA_STDMETHOD(TruncateList) (DMA_THIS_ DmaIndex32 iIndex) DMA_PURE;
    DMA_STDMETHOD(InsertId) (DMA_THIS_ DmaIndex32 iIndex, pDmaId pIdValue) DMA_PURE;
    DMA_STDMETHOD(ReplaceId) (DMA_THIS_ DmaIndex32 iIndex, pDmaId pIdValue) DMA_PURE;
    DMA_END_INTERFACE
};
typedef IdmaEditListOfId DMA_DATA_FAR * LPIdmaEditListOfId;

/* IdmaEditListOfInteger32 Interface */
#undef  INTERFACE
#define INTERFACE   IdmaEditListOfInteger32
#define IID_IdmaEditListOfInteger32Val {0x387E842C, 0x7AE7, 0x11d1, \
    {0x8E, 0x99, 0x08, 0x00, 0x2B, 0xE2, 0x9E, 0x1D}}
DMA_DECLARE_INTERFACE_(387E842C-7AE7-11d1-8E99-08002BE29E1D,IdmaEditListOfInteger32, IdmaEditList)
{
    DMA_BEGIN_INTERFACE
    DMA_DECLARE_IUNKNOWN_METHODS
    DMA_STDMETHOD(DeleteElement) (DMA_THIS_ DmaIndex32 iIndex) DMA_PURE;
    DMA_STDMETHOD(TruncateList) (DMA_THIS_ DmaIndex32 iIndex) DMA_PURE;
    DMA_STDMETHOD(InsertInteger32) (DMA_THIS_ DmaIndex32 iIndex, 
             DmaInteger32 lIntegerValue) DMA_PURE;
    DMA_STDMETHOD(ReplaceInteger32) (DMA_THIS_ DmaIndex32 iIndex, 
             DmaInteger32 lIntegerValue) DMA_PURE;
    DMA_END_INTERFACE
};
typedef IdmaEditListOfInteger32 DMA_DATA_FAR * LPIdmaEditListOfInteger32;

/* IdmaEditListOfObject Interface */
#undef  INTERFACE
#define INTERFACE   IdmaEditListOfObject
#define IID_IdmaEditListOfObjectVal {0x387E842D, 0x7AE7, 0x11d1, \
    {0x8E, 0x99, 0x08, 0x00, 0x2B, 0xE2, 0x9E, 0x1D}}
DMA_DECLARE_INTERFACE_(387E842D-7AE7-11d1-8E99-08002BE29E1D,IdmaEditListOfObject, IdmaEditList)
{
    DMA_BEGIN_INTERFACE
    DMA_DECLARE_IUNKNOWN_METHODS
    DMA_STDMETHOD(DeleteElement) (DMA_THIS_ DmaIndex32 iIndex) DMA_PURE;
    DMA_STDMETHOD(TruncateList) (DMA_THIS_ DmaIndex32 iIndex) DMA_PURE;
    DMA_STDMETHOD(InsertObject) (DMA_THIS_ DmaIndex32 iIndex, 
             Dmapv pIObjectValue) DMA_PURE;
    DMA_STDMETHOD(ReplaceObject) (DMA_THIS_ DmaIndex32 iIndex, 
             Dmapv pIObjectValue) DMA_PURE;
    DMA_END_INTERFACE
};
typedef IdmaEditListOfObject DMA_DATA_FAR * LPIdmaEditListOfObject;

/* IdmaEditListOfString Interface */
#undef  INTERFACE
#define INTERFACE   IdmaEditListOfString
#define IID_IdmaEditListOfStringVal {0x387E842E, 0x7AE7, 0x11d1, \
    {0x8E, 0x99, 0x08, 0x00, 0x2B, 0xE2, 0x9E, 0x1D}}
DMA_DECLARE_INTERFACE_(387E842E-7AE7-11d1-8E99-08002BE29E1D,IdmaEditListOfString, IdmaEditList)
{
    DMA_BEGIN_INTERFACE
    DMA_DECLARE_IUNKNOWN_METHODS
    DMA_STDMETHOD(DeleteElement) (DMA_THIS_ DmaIndex32 iIndex) DMA_PURE;
    DMA_STDMETHOD(TruncateList) (DMA_THIS_ DmaIndex32 iIndex) DMA_PURE;
    DMA_STDMETHOD(InsertString) (DMA_THIS_ DmaIndex32 iIndex, 
             pDmaString pStringValue) DMA_PURE;
    DMA_STDMETHOD(ReplaceString) (DMA_THIS_ DmaIndex32 iIndex, 
             pDmaString pStringValue) DMA_PURE;
    DMA_END_INTERFACE
};
typedef IdmaEditListOfString DMA_DATA_FAR * LPIdmaEditListOfString;

/* IdmaEditProperties Interface */
#undef  INTERFACE
#define INTERFACE   IdmaEditProperties
#define IID_IdmaEditPropertiesVal {0x387E842F, 0x7AE7, 0x11d1, \
    {0x8E, 0x99, 0x08, 0x00, 0x2B, 0xE2, 0x9E, 0x1D}}
DMA_DECLARE_INTERFACE_(387E842F-7AE7-11d1-8E99-08002BE29E1D,IdmaEditProperties, IdmaProperties)
{
    DMA_BEGIN_INTERFACE
    DMA_DECLARE_IUNKNOWN_METHODS
    DMA_STDMETHOD(GetPropValBooleanByIndex) (DMA_THIS_ DmaIndex32 iIndex, 
             pDmaBoolean pbBooleanValue) DMA_PURE;
    DMA_STDMETHOD(GetPropValBooleanById) (DMA_THIS_ pDmaId pPropertyId, 
             pDmaBoolean pbBooleanValue) DMA_PURE;
    DMA_STDMETHOD(GetPropValInteger32ByIndex) (DMA_THIS_ DmaIndex32 iIndex, 
             pDmaInteger32 plIntegerValue) DMA_PURE;
    DMA_STDMETHOD(GetPropValInteger32ById) (DMA_THIS_ pDmaId pPropertyId, 
             pDmaInteger32 plIntegerValue) DMA_PURE;
    DMA_STDMETHOD(GetPropValFloat64ByIndex) (DMA_THIS_ DmaIndex32 iIndex, 
             pDmaFloat64 pfFloatValue) DMA_PURE;
    DMA_STDMETHOD(GetPropValFloat64ById) (DMA_THIS_ pDmaId pPropertyId, 
             pDmaFloat64 pfFloatValue) DMA_PURE;
    DMA_STDMETHOD(GetPropValStringByIndex) (DMA_THIS_ DmaIndex32 iIndex, 
             ppDmaString ppStringValue) DMA_PURE;
    DMA_STDMETHOD(GetPropValStringById) (DMA_THIS_ pDmaId pPropertyId, 
             ppDmaString ppStringValue) DMA_PURE;
    DMA_STDMETHOD(GetPropValBinaryByIndex) (DMA_THIS_ DmaIndex32 iIndex, 
             DmaBinaryValue* pBinaryValue) DMA_PURE;
    DMA_STDMETHOD(GetPropValBinaryById) (DMA_THIS_ pDmaId pPropertyId, 
             DmaBinaryValue* pBinaryValue) DMA_PURE;
    DMA_STDMETHOD(GetPropValObjectByIndex) (DMA_THIS_ DmaIndex32 iIndex, 
             DMA_REFIID riid, pDmapv ppIObjectValue) DMA_PURE;
    DMA_STDMETHOD(GetPropValObjectById) (DMA_THIS_ pDmaId pPropertyId, 
             DMA_REFIID riid, pDmapv ppIObjectValue) DMA_PURE;
    DMA_STDMETHOD(GetPropValIdById) (DMA_THIS_ pDmaId pPropertyId, 
             pDmaId pIdValue) DMA_PURE;
    DMA_STDMETHOD(GetPropValIdByIndex) (DMA_THIS_ DmaIndex32 iIndex, 
             pDmaId pIdValue) DMA_PURE;
    DMA_STDMETHOD(GetPropValDateTimeById) (DMA_THIS_ pDmaId pPropertyId, 
             ppDmaDateTime ppDateTimeValue) DMA_PURE;
    DMA_STDMETHOD(GetPropValDateTimeByIndex) (DMA_THIS_ DmaIndex32 iIndex, 
             ppDmaDateTime ppDateTimeValue) DMA_PURE;
    DMA_STDMETHOD(DeletePropValByIndex) (DMA_THIS_ DmaIndex32 iIndex) DMA_PURE;
    DMA_STDMETHOD(DeletePropValById) (DMA_THIS_ pDmaId pPropertyId) DMA_PURE;
    DMA_STDMETHOD(PutPropValBooleanByIndex) (DMA_THIS_ DmaIndex32 iIndex, 
             DmaBoolean bBooleanValue) DMA_PURE;
    DMA_STDMETHOD(PutPropValBooleanById) (DMA_THIS_ pDmaId pPropertyId, 
             DmaBoolean bBooleanValue) DMA_PURE;
    DMA_STDMETHOD(PutPropValInteger32ByIndex) (DMA_THIS_ DmaIndex32 iIndex, 
             DmaInteger32 lIntegerValue) DMA_PURE;
    DMA_STDMETHOD(PutPropValInteger32ById) (DMA_THIS_ pDmaId pPropertyId, 
             DmaInteger32 lIntegerValue) DMA_PURE;
    DMA_STDMETHOD(PutPropValFloat64ByIndex) (DMA_THIS_ DmaIndex32 iIndex, 
             DmaFloat64 fFloatValue) DMA_PURE;
    DMA_STDMETHOD(PutPropValFloat64ById) (DMA_THIS_ pDmaId pPropertyId, 
             DmaFloat64 fFloatValue) DMA_PURE;
    DMA_STDMETHOD(PutPropValStringByIndex) (DMA_THIS_ DmaIndex32 iIndex, 
             pDmaString pStringValue) DMA_PURE;
    DMA_STDMETHOD(PutPropValStringById) (DMA_THIS_ pDmaId pPropertyId, 
             pDmaString pStringValue) DMA_PURE;
    DMA_STDMETHOD(PutPropValBinaryByIndex) (DMA_THIS_ DmaIndex32 iIndex, 
             DmaBinaryValue* pBinaryValue) DMA_PURE;
    DMA_STDMETHOD(PutPropValBinaryById) (DMA_THIS_ pDmaId pPropertyId, 
             DmaBinaryValue* pBinaryValue) DMA_PURE;
    DMA_STDMETHOD(PutPropValObjectByIndex) (DMA_THIS_ DmaIndex32 iIndex, 
             Dmapv pIObjectValue) DMA_PURE;
    DMA_STDMETHOD(PutPropValObjectById) (DMA_THIS_ pDmaId pPropertyId, 
             Dmapv pIObjectValue) DMA_PURE;
    DMA_STDMETHOD(PutPropValIdByIndex) (DMA_THIS_ DmaIndex32 iIndex, 
             pDmaId pIdValue) DMA_PURE;
    DMA_STDMETHOD(PutPropValIdById) (DMA_THIS_ pDmaId pPropertyId, 
             pDmaId pIdValue) DMA_PURE;
    DMA_STDMETHOD(PutPropValDateTimeByIndex) (DMA_THIS_ DmaIndex32 iIndex, 
             pDmaDateTime pDateTimeValue) DMA_PURE;
    DMA_STDMETHOD(PutPropValDateTimeById) (DMA_THIS_ pDmaId pPropertyId, 
             pDmaDateTime pDateTimeValue) DMA_PURE;
    DMA_END_INTERFACE
};
typedef IdmaEditProperties DMA_DATA_FAR * LPIdmaEditProperties;

/* IdmaEnumOfObject Interface */
#undef  INTERFACE
#define INTERFACE   IdmaEnumOfObject
#define IID_IdmaEnumOfObjectVal {0x387E8430, 0x7AE7, 0x11d1, \
    {0x8E, 0x99, 0x08, 0x00, 0x2B, 0xE2, 0x9E, 0x1D}}
DMA_DECLARE_INTERFACE_(387E8430-7AE7-11d1-8E99-08002BE29E1D,IdmaEnumOfObject, IUnknown)
{
    DMA_BEGIN_INTERFACE
    DMA_DECLARE_IUNKNOWN_METHODS
    DMA_STDMETHOD(GetNextObject) (DMA_THIS_ DmaIndex32 iNumItems, 
             IUnknown** pArray, pDmaIndex32 piNumReturned) DMA_PURE;
    DMA_END_INTERFACE
};
typedef IdmaEnumOfObject DMA_DATA_FAR * LPIdmaEnumOfObject;

/* IdmaList Interface */
#undef  INTERFACE
#define INTERFACE   IdmaList
#define IID_IdmaListVal {0x387E8431, 0x7AE7, 0x11d1, \
    {0x8E, 0x99, 0x08, 0x00, 0x2B, 0xE2, 0x9E, 0x1D}}
DMA_DECLARE_INTERFACE_(387E8431-7AE7-11d1-8E99-08002BE29E1D,IdmaList, IUnknown)
{
    DMA_BEGIN_INTERFACE
    DMA_DECLARE_IUNKNOWN_METHODS
    DMA_STDMETHOD(GetElementCount) (DMA_THIS_ pDmaIndex32 piCount) DMA_PURE;
    DMA_END_INTERFACE
};
typedef IdmaList DMA_DATA_FAR * LPIdmaList;

/* IdmaListOfBinary Interface */
#undef  INTERFACE
#define INTERFACE   IdmaListOfBinary
#define IID_IdmaListOfBinaryVal {0x387E8432, 0x7AE7, 0x11d1, \
    {0x8E, 0x99, 0x08, 0x00, 0x2B, 0xE2, 0x9E, 0x1D}}
DMA_DECLARE_INTERFACE_(387E8432-7AE7-11d1-8E99-08002BE29E1D,IdmaListOfBinary, IdmaList)
{
    DMA_BEGIN_INTERFACE
    DMA_DECLARE_IUNKNOWN_METHODS
    DMA_STDMETHOD(GetElementCount) (DMA_THIS_ pDmaIndex32 piCount) DMA_PURE;
    DMA_STDMETHOD(GetBinary) (DMA_THIS_ DmaIndex32 iIndex, 
             DmaBinaryValue* pBinaryValue) DMA_PURE;
    DMA_END_INTERFACE
};
typedef IdmaListOfBinary DMA_DATA_FAR * LPIdmaListOfBinary;

/* IdmaListOfBoolean Interface */
#undef  INTERFACE
#define INTERFACE   IdmaListOfBoolean
#define IID_IdmaListOfBooleanVal {0x387E8433, 0x7AE7, 0x11d1, \
    {0x8E, 0x99, 0x08, 0x00, 0x2B, 0xE2, 0x9E, 0x1D}}
DMA_DECLARE_INTERFACE_(387E8433-7AE7-11d1-8E99-08002BE29E1D,IdmaListOfBoolean, IdmaList)
{
    DMA_BEGIN_INTERFACE
    DMA_DECLARE_IUNKNOWN_METHODS
    DMA_STDMETHOD(GetElementCount) (DMA_THIS_ pDmaIndex32 piCount) DMA_PURE;
    DMA_STDMETHOD(GetBoolean) (DMA_THIS_ DmaIndex32 iIndex, 
             pDmaBoolean pbBooleanValue) DMA_PURE;
    DMA_END_INTERFACE
};
typedef IdmaListOfBoolean DMA_DATA_FAR * LPIdmaListOfBoolean;

/* IdmaListOfDateTime Interface */
#undef  INTERFACE
#define INTERFACE   IdmaListOfDateTime
#define IID_IdmaListOfDateTimeVal {0x387E8434, 0x7AE7, 0x11d1, \
    {0x8E, 0x99, 0x08, 0x00, 0x2B, 0xE2, 0x9E, 0x1D}}
DMA_DECLARE_INTERFACE_(387E8434-7AE7-11d1-8E99-08002BE29E1D,IdmaListOfDateTime, IdmaList)
{
    DMA_BEGIN_INTERFACE
    DMA_DECLARE_IUNKNOWN_METHODS
    DMA_STDMETHOD(GetElementCount) (DMA_THIS_ pDmaIndex32 piCount) DMA_PURE;
    DMA_STDMETHOD(GetDateTime) (DMA_THIS_ DmaIndex32 iIndex, 
             ppDmaDateTime ppValue) DMA_PURE;
    DMA_END_INTERFACE
};
typedef IdmaListOfDateTime DMA_DATA_FAR * LPIdmaListOfDateTime;

/* IdmaListOfFloat64 Interface */
#undef  INTERFACE
#define INTERFACE   IdmaListOfFloat64
#define IID_IdmaListOfFloat64Val {0x387E8435, 0x7AE7, 0x11d1, \
    {0x8E, 0x99, 0x08, 0x00, 0x2B, 0xE2, 0x9E, 0x1D}}
DMA_DECLARE_INTERFACE_(387E8435-7AE7-11d1-8E99-08002BE29E1D,IdmaListOfFloat64, IdmaList)
{
    DMA_BEGIN_INTERFACE
    DMA_DECLARE_IUNKNOWN_METHODS
    DMA_STDMETHOD(GetElementCount) (DMA_THIS_ pDmaIndex32 piCount) DMA_PURE;
    DMA_STDMETHOD(GetFloat64) (DMA_THIS_ DmaIndex32 iIndex, 
             pDmaFloat64 pfFloatValue) DMA_PURE;
    DMA_END_INTERFACE
};
typedef IdmaListOfFloat64 DMA_DATA_FAR * LPIdmaListOfFloat64;

/* IdmaListOfId Interface */
#undef  INTERFACE
#define INTERFACE   IdmaListOfId
#define IID_IdmaListOfIdVal {0x387E8436, 0x7AE7, 0x11d1, \
    {0x8E, 0x99, 0x08, 0x00, 0x2B, 0xE2, 0x9E, 0x1D}}
DMA_DECLARE_INTERFACE_(387E8436-7AE7-11d1-8E99-08002BE29E1D,IdmaListOfId, IdmaList)
{
    DMA_BEGIN_INTERFACE
    DMA_DECLARE_IUNKNOWN_METHODS
    DMA_STDMETHOD(GetElementCount) (DMA_THIS_ pDmaIndex32 piCount) DMA_PURE;
    DMA_STDMETHOD(GetId) (DMA_THIS_ DmaIndex32 iIndex, pDmaId pValue) DMA_PURE;
    DMA_END_INTERFACE
};
typedef IdmaListOfId DMA_DATA_FAR * LPIdmaListOfId;

/* IdmaListOfInteger32 Interface */
#undef  INTERFACE
#define INTERFACE   IdmaListOfInteger32
#define IID_IdmaListOfInteger32Val {0x387E8437, 0x7AE7, 0x11d1, \
    {0x8E, 0x99, 0x08, 0x00, 0x2B, 0xE2, 0x9E, 0x1D}}
DMA_DECLARE_INTERFACE_(387E8437-7AE7-11d1-8E99-08002BE29E1D,IdmaListOfInteger32, IdmaList)
{
    DMA_BEGIN_INTERFACE
    DMA_DECLARE_IUNKNOWN_METHODS
    DMA_STDMETHOD(GetElementCount) (DMA_THIS_ pDmaIndex32 piCount) DMA_PURE;
    DMA_STDMETHOD(GetInteger32) (DMA_THIS_ DmaIndex32 iIndex, 
             pDmaInteger32 plIntegerValue) DMA_PURE;
    DMA_END_INTERFACE
};
typedef IdmaListOfInteger32 DMA_DATA_FAR * LPIdmaListOfInteger32;

/* IdmaListOfObject Interface */
#undef  INTERFACE
#define INTERFACE   IdmaListOfObject
#define IID_IdmaListOfObjectVal {0x387E8438, 0x7AE7, 0x11d1, \
    {0x8E, 0x99, 0x08, 0x00, 0x2B, 0xE2, 0x9E, 0x1D}}
DMA_DECLARE_INTERFACE_(387E8438-7AE7-11d1-8E99-08002BE29E1D,IdmaListOfObject, IdmaList)
{
    DMA_BEGIN_INTERFACE
    DMA_DECLARE_IUNKNOWN_METHODS
    DMA_STDMETHOD(GetElementCount) (DMA_THIS_ pDmaIndex32 piCount) DMA_PURE;
    DMA_STDMETHOD(GetObject) (DMA_THIS_ DmaIndex32 iIndex, DMA_REFIID riid, 
             pDmapv ppIObjectValue) DMA_PURE;
    DMA_END_INTERFACE
};
typedef IdmaListOfObject DMA_DATA_FAR * LPIdmaListOfObject;

/* IdmaListOfString Interface */
#undef  INTERFACE
#define INTERFACE   IdmaListOfString
#define IID_IdmaListOfStringVal {0x387E8439, 0x7AE7, 0x11d1, \
    {0x8E, 0x99, 0x08, 0x00, 0x2B, 0xE2, 0x9E, 0x1D}}
DMA_DECLARE_INTERFACE_(387E8439-7AE7-11d1-8E99-08002BE29E1D,IdmaListOfString, IdmaList)
{
    DMA_BEGIN_INTERFACE
    DMA_DECLARE_IUNKNOWN_METHODS
    DMA_STDMETHOD(GetElementCount) (DMA_THIS_ pDmaIndex32 piCount) DMA_PURE;
    DMA_STDMETHOD(GetString) (DMA_THIS_ DmaIndex32 iIndex, 
             ppDmaString ppStringValue) DMA_PURE;
    DMA_END_INTERFACE
};
typedef IdmaListOfString DMA_DATA_FAR * LPIdmaListOfString;

/* IdmaObjectFactory Interface */
#undef  INTERFACE
#define INTERFACE   IdmaObjectFactory
#define IID_IdmaObjectFactoryVal {0x387E843B, 0x7AE7, 0x11d1, \
    {0x8E, 0x99, 0x08, 0x00, 0x2B, 0xE2, 0x9E, 0x1D}}
DMA_DECLARE_INTERFACE_(387E843B-7AE7-11d1-8E99-08002BE29E1D,IdmaObjectFactory, IUnknown)
{
    DMA_BEGIN_INTERFACE
    DMA_DECLARE_IUNKNOWN_METHODS
    DMA_STDMETHOD(CreateObject) (DMA_THIS_ pDmaId pClassId, DMA_REFIID riid, 
             pDmapv ppIObject) DMA_PURE;
    DMA_END_INTERFACE
};
typedef IdmaObjectFactory DMA_DATA_FAR * LPIdmaObjectFactory;

/* IdmaOIID Interface */
#undef  INTERFACE
#define INTERFACE   IdmaOIID
#define IID_IdmaOIIDVal {0x387E843C, 0x7AE7, 0x11d1, \
    {0x8E, 0x99, 0x08, 0x00, 0x2B, 0xE2, 0x9E, 0x1D}}
DMA_DECLARE_INTERFACE_(387E843C-7AE7-11d1-8E99-08002BE29E1D,IdmaOIID, IUnknown)
{
    DMA_BEGIN_INTERFACE
    DMA_DECLARE_IUNKNOWN_METHODS
    DMA_STDMETHOD(GetDocSpaceId) (DMA_THIS_ pDmaString pOIID, 
             pDmaId pDocSpaceId) DMA_PURE;
    DMA_STDMETHOD(GetSystemId) (DMA_THIS_ pDmaString pOIID, pDmaId pSystemId) DMA_PURE;
    DMA_STDMETHOD(GetGuid) (DMA_THIS_ pDmaString pOIID, pDmaId pObjectGUID) DMA_PURE;
    DMA_STDMETHOD(GetObjectIdText) (DMA_THIS_ pDmaString pOIID, 
             ppDmaString ppObjectText) DMA_PURE;
    DMA_END_INTERFACE
};
typedef IdmaOIID DMA_DATA_FAR * LPIdmaOIID;

/* IdmaProgressCallback Interface */
#undef  INTERFACE
#define INTERFACE   IdmaProgressCallback
#define IID_IdmaProgressCallbackVal {0x387E843D, 0x7AE7, 0x11d1, \
    {0x8E, 0x99, 0x08, 0x00, 0x2B, 0xE2, 0x9E, 0x1D}}
DMA_DECLARE_INTERFACE_(387E843D-7AE7-11d1-8E99-08002BE29E1D,IdmaProgressCallback, IUnknown)
{
    DMA_BEGIN_INTERFACE
    DMA_DECLARE_IUNKNOWN_METHODS
    DMA_STDMETHOD(ReportProgress) (DMA_THIS_ DmaRC rcProgressStatus, 
             DmaUInteger32 ulProgressNumerator, 
             DmaUInteger32 ulProgressDenominator, DmaBoolean bAbortAllowed) DMA_PURE;
    DMA_END_INTERFACE
};
typedef IdmaProgressCallback DMA_DATA_FAR * LPIdmaProgressCallback;

/* IdmaRelationshipOrdering Interface */
#undef  INTERFACE
#define INTERFACE   IdmaRelationshipOrdering
#define IID_IdmaRelationshipOrderingVal {0x387E843F, 0x7AE7, 0x11d1, \
    {0x8E, 0x99, 0x08, 0x00, 0x2B, 0xE2, 0x9E, 0x1D}}
DMA_DECLARE_INTERFACE_(387E843F-7AE7-11d1-8E99-08002BE29E1D,IdmaRelationshipOrdering, IUnknown)
{
    DMA_BEGIN_INTERFACE
    DMA_DECLARE_IUNKNOWN_METHODS
    DMA_STDMETHOD(SetOrdering) (DMA_THIS_ Dmapv pIHeadRelationship, 
             DmaInteger32 ulHeadWhere, Dmapv pITailRelationship, 
             DmaInteger32 ulTailWhere) DMA_PURE;
    DMA_END_INTERFACE
};
typedef IdmaRelationshipOrdering DMA_DATA_FAR * LPIdmaRelationshipOrdering;

/* IdmaResultSet Interface */
#undef  INTERFACE
#define INTERFACE   IdmaResultSet
#define IID_IdmaResultSetVal {0x387E8440, 0x7AE7, 0x11d1, \
    {0x8E, 0x99, 0x08, 0x00, 0x2B, 0xE2, 0x9E, 0x1D}}
DMA_DECLARE_INTERFACE_(387E8440-7AE7-11d1-8E99-08002BE29E1D,IdmaResultSet, IUnknown)
{
    DMA_BEGIN_INTERFACE
    DMA_DECLARE_IUNKNOWN_METHODS
    DMA_STDMETHOD(GetNextResultRow) (DMA_THIS_ DMA_REFIID riid, 
             pDmapv ppIResultRow) DMA_PURE;
    DMA_STDMETHOD(IsResultReady) (DMA_THIS_ pDmaBoolean pbIsReady) DMA_PURE;
    DMA_STDMETHOD(ReExecuteQuery) (DMA_THIS_ Dmapv pICallback) DMA_PURE;
    DMA_STDMETHOD(TerminateResults) (DMA_THIS) DMA_PURE;
    DMA_END_INTERFACE
};
typedef IdmaResultSet DMA_DATA_FAR * LPIdmaResultSet;

/* IdmaScope Interface */
#undef  INTERFACE
#define INTERFACE   IdmaScope
#define IID_IdmaScopeVal {0x387E8441, 0x7AE7, 0x11d1, \
    {0x8E, 0x99, 0x08, 0x00, 0x2B, 0xE2, 0x9E, 0x1D}}
DMA_DECLARE_INTERFACE_(387E8441-7AE7-11d1-8E99-08002BE29E1D,IdmaScope, IUnknown)
{
    DMA_BEGIN_INTERFACE
    DMA_DECLARE_IUNKNOWN_METHODS
    DMA_STDMETHOD(ExecuteSearch) (DMA_THIS_ Dmapv pIQueryObject, 
             Dmapv pICallback, DmaBoolean bRequestElimination, 
             DMA_REFIID riidResultSet, pDmapv ppIResultSet) DMA_PURE;
    DMA_STDMETHOD(GetOperatorDescription) (DMA_THIS_ pDmaId pOperatorId, 
             DMA_REFIID riid, pDmapv ppIOperatorDesc) DMA_PURE;
    DMA_END_INTERFACE
};
typedef IdmaScope DMA_DATA_FAR * LPIdmaScope;

/* IdmaScopeFactory Interface */
#undef  INTERFACE
#define INTERFACE   IdmaScopeFactory
#define IID_IdmaScopeFactoryVal {0x387E8442, 0x7AE7, 0x11d1, \
    {0x8E, 0x99, 0x08, 0x00, 0x2B, 0xE2, 0x9E, 0x1D}}
DMA_DECLARE_INTERFACE_(387E8442-7AE7-11d1-8E99-08002BE29E1D,IdmaScopeFactory, IUnknown)
{
    DMA_BEGIN_INTERFACE
    DMA_DECLARE_IUNKNOWN_METHODS
    DMA_STDMETHOD(CreateScope) (DMA_THIS_ Dmapv pIScopeList, 
             DmaInteger32 lCombinationRule, DMA_REFIID riid, pDmapv ppIScope) DMA_PURE;
    DMA_STDMETHOD(CreateScopeList) (DMA_THIS_ DMA_REFIID riid, pDmapv ppIObject) DMA_PURE;
    DMA_END_INTERFACE
};
typedef IdmaScopeFactory DMA_DATA_FAR * LPIdmaScopeFactory;

/* IdmaServiceRegistry Interface */
#undef  INTERFACE
#define INTERFACE   IdmaServiceRegistry
#define IID_IdmaServiceRegistryVal {0x387E8443, 0x7AE7, 0x11d1, \
    {0x8E, 0x99, 0x08, 0x00, 0x2B, 0xE2, 0x9E, 0x1D}}
DMA_DECLARE_INTERFACE_(387E8443-7AE7-11d1-8E99-08002BE29E1D,IdmaServiceRegistry, IUnknown)
{
    DMA_BEGIN_INTERFACE
    DMA_DECLARE_IUNKNOWN_METHODS
    DMA_STDMETHOD(GetRegistryElement) (DMA_THIS_ pDmaId pRegistrationId, 
             pDmaId pServiceObjectId, pDmaId pServiceObjectTypeId, 
             ppDmaString ppProfile, pDmaId pModuleTypeId, 
             ppDmaString ppModuleLocation, pDmaInteger32 plCharSetEncodingId, 
             pDmaBoolean pbPublished) DMA_PURE;
    DMA_STDMETHOD(FindNextRegistryElement) (DMA_THIS_ 
             pDmaId pPrevRegistrationId, pDmaId pServiceObjectIdFilter, 
             pDmaId pServiceObjectTypeIdFilter, 
             pDmaInteger32 plCharSetEncodingIdFilter, 
             pDmaBoolean pbPublishedFilter, pDmaId pRegistrationId, 
             pDmaId pServiceObjectId, pDmaId pServiceObjectTypeId, 
             ppDmaString ppProfile, pDmaId pModuleTypeId, 
             ppDmaString ppModuleLocation, pDmaInteger32 plCharSetEncodingId, 
             pDmaBoolean pbPublished) DMA_PURE;
    DMA_STDMETHOD(PublishRegistryElement) (DMA_THIS_ pDmaId pRegistrationId) DMA_PURE;
    DMA_STDMETHOD(RegisterServiceElement) (DMA_THIS_ pDmaId pServiceObjectId, 
             pDmaId pServiceObjectTypeId, pDmaString pProfile, 
             pDmaId pModuleTypeId, pDmaString pModuleLocation, 
             DmaInteger32 lCharSetEncodingId, pDmaId pRegistrationId) DMA_PURE;
    DMA_STDMETHOD(RemoveRegistryElement) (DMA_THIS_ pDmaId pRegistrationId) DMA_PURE;
    DMA_STDMETHOD(UnpublishRegistryElement) (DMA_THIS_ pDmaId pRegistrationID) DMA_PURE;
    DMA_END_INTERFACE
};
typedef IdmaServiceRegistry DMA_DATA_FAR * LPIdmaServiceRegistry;

/* IdmaStream Interface */
#undef  INTERFACE
#define INTERFACE   IdmaStream
#define IID_IdmaStreamVal {0x387E8444, 0x7AE7, 0x11d1, \
    {0x8E, 0x99, 0x08, 0x00, 0x2B, 0xE2, 0x9E, 0x1D}}
DMA_DECLARE_INTERFACE_(387E8444-7AE7-11d1-8E99-08002BE29E1D,IdmaStream, IUnknown)
{
    DMA_BEGIN_INTERFACE
    DMA_DECLARE_IUNKNOWN_METHODS
    DMA_STDMETHOD(ReadStreamData) (DMA_THIS_ pDmaBinary pBuffer, 
             DmaUInteger32 ulBytesToRead, pDmaUInteger32 pulBytesRead) DMA_PURE;
    DMA_STDMETHOD(SetStreamPosition) (DMA_THIS_ DmaInt64 liDisplacement, 
             DmaInteger32 lRelativeTo, pDmaUInt64 puliNewPosition) DMA_PURE;
    DMA_END_INTERFACE
};
typedef IdmaStream DMA_DATA_FAR * LPIdmaStream;

/* IdmaSystem Interface */
#undef  INTERFACE
#define INTERFACE   IdmaSystem
#define IID_IdmaSystemVal {0x387E8445, 0x7AE7, 0x11d1, \
    {0x8E, 0x99, 0x08, 0x00, 0x2B, 0xE2, 0x9E, 0x1D}}
DMA_DECLARE_INTERFACE_(387E8445-7AE7-11d1-8E99-08002BE29E1D,IdmaSystem, IUnknown)
{
    DMA_BEGIN_INTERFACE
    DMA_DECLARE_IUNKNOWN_METHODS
    DMA_STDMETHOD(ConnectDocSpace) (DMA_THIS_ pDmaId pDocSpaceId, 
             pDmaString pLocaleName, DMA_REFIID riid, pDmapv ppIDocSpace) DMA_PURE;
    DMA_STDMETHOD(GetResultCodeDescription) (DMA_THIS_ DmaRC rcResultCode, 
             ppDmaString ppResultCodeDesc) DMA_PURE;
    DMA_STDMETHOD(EnumerateDocSpaces) (DMA_THIS_ DMA_REFIID riid, 
             pDmapv ppIEnumOfDocSpace) DMA_PURE;
    DMA_END_INTERFACE
};
typedef IdmaSystem DMA_DATA_FAR * LPIdmaSystem;

/* IdmaSystemManager Interface */
#undef  INTERFACE
#define INTERFACE   IdmaSystemManager
#define IID_IdmaSystemManagerVal {0x387E8446, 0x7AE7, 0x11d1, \
    {0x8E, 0x99, 0x08, 0x00, 0x2B, 0xE2, 0x9E, 0x1D}}
DMA_DECLARE_INTERFACE_(387E8446-7AE7-11d1-8E99-08002BE29E1D,IdmaSystemManager, IUnknown)
{
    DMA_BEGIN_INTERFACE
    DMA_DECLARE_IUNKNOWN_METHODS
    DMA_STDMETHOD(ConnectSystem) (DMA_THIS_ pDmaId pSystemId, 
             pDmaString pLocaleName, DMA_REFIID riid, pDmapv ppISystem) DMA_PURE;
    DMA_STDMETHOD(EnumerateSystems) (DMA_THIS_ DMA_REFIID riid, 
             pDmapv ppIEnumOfSystem) DMA_PURE;
    DMA_STDMETHOD(GetMalloc) (DMA_THIS_ DMA_REFIID riid, pDmapv ppIMalloc) DMA_PURE;
    DMA_END_INTERFACE
};
typedef IdmaSystemManager DMA_DATA_FAR * LPIdmaSystemManager;

/* IdmaTextOrdering Interface */
#undef  INTERFACE
#define INTERFACE   IdmaTextOrdering
#define IID_IdmaTextOrderingVal {0x387E8447, 0x7AE7, 0x11d1, \
    {0x8E, 0x99, 0x08, 0x00, 0x2B, 0xE2, 0x9E, 0x1D}}
DMA_DECLARE_INTERFACE_(387E8447-7AE7-11d1-8E99-08002BE29E1D,IdmaTextOrdering, IUnknown)
{
    DMA_BEGIN_INTERFACE
    DMA_DECLARE_IUNKNOWN_METHODS
    DMA_STDMETHOD(CompareStrings) (DMA_THIS_ pDmaString pString1, 
             pDmaString pString2, pDmaInteger32 pResult) DMA_PURE;
    DMA_END_INTERFACE
};
typedef IdmaTextOrdering DMA_DATA_FAR * LPIdmaTextOrdering;

/* IdmaVersionable Interface */
#undef  INTERFACE
#define INTERFACE   IdmaVersionable
#define IID_IdmaVersionableVal {0x387E8448, 0x7AE7, 0x11d1, \
    {0x8E, 0x99, 0x08, 0x00, 0x2B, 0xE2, 0x9E, 0x1D}}
DMA_DECLARE_INTERFACE_(387E8448-7AE7-11d1-8E99-08002BE29E1D,IdmaVersionable, IUnknown)
{
    DMA_BEGIN_INTERFACE
    DMA_DECLARE_IUNKNOWN_METHODS
    DMA_STDMETHOD(SetCheckIn) (DMA_THIS_ Dmapv pIVersionSeries, 
             Dmapv pIVersionDescription) DMA_PURE;
    DMA_END_INTERFACE
};
typedef IdmaVersionable DMA_DATA_FAR * LPIdmaVersionable;

/* IdmaVersionSeries Interface */
#undef  INTERFACE
#define INTERFACE   IdmaVersionSeries
#define IID_IdmaVersionSeriesVal {0x387E8449, 0x7AE7, 0x11d1, \
    {0x8E, 0x99, 0x08, 0x00, 0x2B, 0xE2, 0x9E, 0x1D}}
DMA_DECLARE_INTERFACE_(387E8449-7AE7-11d1-8E99-08002BE29E1D,IdmaVersionSeries, IUnknown)
{
    DMA_BEGIN_INTERFACE
    DMA_DECLARE_IUNKNOWN_METHODS
    DMA_STDMETHOD(SetReserveNext) (DMA_THIS_ Dmapv pReservation) DMA_PURE;
    DMA_STDMETHOD(SetCheckOutNext) (DMA_THIS_ Dmapv pReservation) DMA_PURE;
    DMA_STDMETHOD(SetRevoke) (DMA_THIS) DMA_PURE;
    DMA_END_INTERFACE
};
typedef IdmaVersionSeries DMA_DATA_FAR * LPIdmaVersionSeries;


#endif /* DMAIFACE_H */
