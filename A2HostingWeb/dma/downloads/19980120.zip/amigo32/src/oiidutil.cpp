/*
 *  Copyright 1995,1996,1997 by the Association for Information and Image Management Int'l
 *                                             1100 Wayne Avenue
 *                                             Silver Spring, MD 20910-5603
 *                                             Tel: 301/587-8202
 *                                             Fax: 301/587-2711
 *      All Rights Reserved.
 *      DMA (Document Management Alliance) working group.
 *
 *  oiidutil.cpp
 *
 *  OIID utility functions for parsing/validating OIIDs.
 *  
 *  **** THIS IS A WORK IN PROGRESS!! ****
 */
 
 

#include <string.h>     // for strlen()

#include "oiidutil.h"

//=============================================================================
static OIID_PARSER_RV parseAlphanumPlus(
   char *parseStr,      // Input
   char *matchChars,    // Input
   char *delimiters,    // Input
   char **foundStr,     // Output
   char **remainder,    // Output
   int *remainderIndex) // Output
//=============================================================================
{
   *foundStr = *remainder = NULL;
   *remainderIndex = 0;

   if (parseStr == NULL)
       return RV_NO_DATA;

   for (unsigned int i=0 ; i<strlen(parseStr) ; i++) {
       char ch = parseStr[i];
       for (unsigned int j=0 ; j<strlen(delimiters) ; j++) {
           if (ch == delimiters[j]) {   // Found terminator
               if (parseStr[i+1] != NULL_CHAR) { // Not at end
                   *remainder = &(parseStr[i+1]);
                   *remainderIndex = i+1;
               }
               if (i != 0) {
                   *foundStr = parseStr;
                   (*foundStr)[i] = NULL_CHAR;
                   return RV_NO_DATA;
               }
               else {
                   *foundStr = NULL;
                   return RV_NORMAL;
               }
           }
       }
    
       if (!((ch>='A' && ch<='Z') || (ch>='a' && ch<='z') || (ch>='0' && ch<='9'))) {
           int illegalChar=1;
           for (unsigned int k=0 ; k<strlen(matchChars) ; k++) {
               if (ch == matchChars[k]) {   // Found normal char
                   illegalChar = 0;
                   break;
               }
           }
           if (illegalChar) {     // Found inappropriate char
               *remainder = &((*foundStr)[i]);
               *remainderIndex = i;
               return RV_ILLEGAL_CHAR;
           }
       }
   }
   // No delimiter or illegal char found, so return orig string, and RV_NO_DELIMITER
   *foundStr = parseStr;
   return RV_NO_DELIMITER;
}

   
//=============================================================================
OIID_PARSER_RV validateAsciiOIID(
    char *asciiOIID,
    char **asciiSystemOIID,
    char **asciiDocSpaceOIID,
    char **asciiObjectIDOIID,
    char **asciiObjectGUIDOIID)
//=============================================================================
{
    // Initialize all values to NULL
    *asciiSystemOIID = *asciiDocSpaceOIID = *asciiObjectIDOIID = *asciiObjectGUIDOIID = NULL;
    OIID_PARSER_RV oprv;
    char *tmp = asciiOIID, *odmaStr, *dmaStr, *remainder = asciiOIID;
    int rIndex=0;

    // Get ODMA component if it exists (currently ignored)
    if (strncmp(tmp, ODMA_START, strlen(ODMA_START)) == 0) {
        if ((tmp[ODMA_STR_LEN] != BSLASH) && (tmp[ODMA_STR_LEN] != SLASH))
            return RV_MALFORMED; 
        oprv = parseAlphanumPlus(&(tmp[ODMA_STR_LEN+1]), OIID_LOGIN_CHARS,
                                 OIID_DELIMITERS, &odmaStr, &remainder, &rIndex);
        if ((oprv != RV_NORMAL) && (oprv != RV_NO_DATA))  // ie RV_NO_DELIMITER | RV_ILLEGAL_CHAR etc
            return RV_MALFORMED; 
        tmp = remainder;
    }

    // Get required DMA component
    if (_strnicmp(tmp, DMA_STR, DMA_STR_LEN) != 0)
        return RV_MALFORMED; 
    if (((tmp[DMA_STR_LEN] != BSLASH) && (tmp[DMA_STR_LEN] != SLASH)) ||
        ((tmp[DMA_STR_LEN+1] != BSLASH) && (tmp[DMA_STR_LEN+1] != SLASH)))
        return RV_MALFORMED; 

    // Parse the login information (currently ignored)
    oprv = parseAlphanumPlus(&(tmp[DMA_STR_LEN+2]), OIID_LOGIN_CHARS, 
                             OIID_DELIMITERS, &dmaStr, &remainder, &rIndex);
    if ((oprv != RV_NORMAL) && (oprv != RV_NO_DATA))
        return RV_MALFORMED;
    tmp = remainder;

    // Now get the pieces we are interested in (note: SystemID is required but may be NULL)
    oprv = parseAlphanumPlus(tmp, OIID_SIMPLE_CHARS, OIID_DELIMITERS, 
                             asciiSystemOIID, &remainder, &rIndex);
    if (oprv == RV_NO_DELIMITER)
        return RV_NO_DELIMITER; // Only the systemID has been found but this is legal
    if (oprv == RV_ILLEGAL_CHAR) {
        if (remainder[0] != SEMICOLON) {
            asciiSystemOIID[rIndex] = NULL_CHAR;
            return RV_NO_DELIMITER;
        }
    }
    tmp = remainder;

    if (tmp[0] == SEMICOLON) {      // Test to see if we skip DocSpace & object ID fields
        asciiSystemOIID[rIndex] = NULL_CHAR;
        tmp++;
    }
    else {          
       // Get the doc space ID
        oprv = parseAlphanumPlus(tmp, OIID_SIMPLE_CHARS, OIID_DELIMITERS, 
                                 asciiDocSpaceOIID, &remainder, &rIndex);
        if (oprv == RV_NO_DELIMITER)
            return RV_NO_DELIMITER;    // Optional field and no more data
        else if (oprv == RV_ILLEGAL_CHAR) {
            if (remainder[0] != SEMICOLON) {
                asciiDocSpaceOIID[rIndex] = NULL_CHAR;
                return RV_NO_DELIMITER;
            }
        }
        tmp = remainder;
        
        if (tmp[0] == SEMICOLON) {      // Test to see if we skip object ID field
            asciiDocSpaceOIID[rIndex] = NULL_CHAR;
            tmp++;
        }
        else  {      
            // Get the object ID
            oprv = parseAlphanumPlus(tmp, OIID_CHARS, OBJECT_DELIMITER, 
                                     asciiObjectIDOIID, &remainder, &rIndex);
            if (oprv == RV_NO_DELIMITER)
                return RV_NO_DELIMITER;    // Optional field and no more data
            if (oprv == RV_ILLEGAL_CHAR) {
                asciiObjectIDOIID[rIndex] = NULL_CHAR;
                return RV_NO_DELIMITER;
            }
            tmp = remainder;
        }
    }

    // To get here we must have found a semicolon, so look for "guid=" pattern
    if (strlen(remainder) >=  GUID_EQ_STR_LEN) {
        if (_strnicmp(GUID_EQ_STR, remainder, GUID_EQ_STR_LEN) == 0) {
            oprv = parseAlphanumPlus(&(tmp[GUID_EQ_STR_LEN]), OIID_SIMPLE_CHARS, "\0", 
                                     asciiObjectGUIDOIID, &remainder, &rIndex);
            if (oprv == RV_NORMAL)
                return RV_NORMAL;
            if (oprv == RV_ILLEGAL_CHAR)
                asciiObjectGUIDOIID[rIndex] = NULL_CHAR;
            // All other cases end the GUID string with NULL_CHAR OR cause it to remain NULL
        }
    }

    // Notice: This is not yet checking the remainder string for OIID syntax adherence
    return oprv;     // At least one of the optional fields was not found
}
