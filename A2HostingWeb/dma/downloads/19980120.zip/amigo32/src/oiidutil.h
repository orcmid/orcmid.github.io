/*
 *  Copyright 1995,1996,1997 by the Association for Information and Image Management Int'l
 *                                             1100 Wayne Avenue
 *                                             Silver Spring, MD 20910-5603
 *                                             Tel: 301/587-8202
 *                                             Fax: 301/587-2711
 *      All Rights Reserved.
 *      DMA (Document Management Alliance) working group.
 *
 *  File: oiidutil.h
 *
 *  Description: OIID utility definitions for parsing/validating OIIDs.
 *  
 *  **** THIS IS A WORK IN PROGRESS!! ****
 */

#ifndef OIIDUTIL_H_
#define OIIDUTIL_H_

// Macros used for ascii comparisons

#define OIID_SIMPLE_CHARS    ":@-.%$_+!*(,)\012\015"
#define OIID_CHARS           ":@-.%$_+!*(,)&=\\/\012\015"
#define OIID_LOGIN_CHARS     ":@-.%$_+!*(,);?&=\012\015"

#define OIID_DELIMITERS      "\\/"
#define OBJECT_DELIMITER     ";"

#define ODMA_START           "::"

#define ODMA_STR             "ODMA"
#define DMA_STR              "DMA:"
#define GUID_EQ_STR          "guid="

#define DMA_STR_LEN          4
#define ODMA_STR_LEN         4
#define GUID_EQ_STR_LEN      5

#define SLASH                '/'
#define BSLASH               '\\'
#define NULL_CHAR            '\0'
#define SEMICOLON            ';'

#define DMAID_FIELDS         11

    
// Return Values for OIID parsing functions

enum OIID_PARSER_RV {
    RV_NORMAL,          // Normal case i.e. terminated by delimiter
    RV_NO_DELIMITER,    // Exception no delimiter at end of string
    RV_NO_DATA,         // Empty string
    RV_ILLEGAL_CHAR,    // Invalid char found in string
    RV_MALFORMED,       // String does not conform to legal parse syntax
    RV_TRUNCATED        // Legal string syntax but missing optional parms
};


//////////////////////////////////////////////////////////////////////////
// Function: parseAlphanumPlus() (Parse AlphaNumeric Plus input string)
//
// Searches for the following characters within the string "str":
//      1) Each of the characters within "delimiters".  if found
//         a NULL is inserted instead of the delimiter and the string
//         pointed to initially is returned in "rv" and the function
//         return value is set to 1
//      2) AlphaNumeric characters (these are assumed legal for this
//         function).  If one is found the search simply proceeds to 
//         the next character
//      3) Each of the characters within "matchChars", these are the
//         other legal characters within the returned substring.  The 
//         search simply proceeds to the next character.
//      4) Invalid characters are found by not matching any of the above
//         cases.  If one of these is found the pointer "rv" is set
//         to point to it, and the function return value is set to -1.
//      5) If the entire string is searched and no delimiter is found
//         (or invalid chars) the return value is set to 0 and the entire
//         string is returned in "rv".
//
// Note: This is a cross between a strtok() and a substring search routine
//       because in the normal case it acts similarly to strtok() (ie side
//       effect of writing NULL into delimiter location). However it only
//       finds the first instance of the delimiter.
//////////////////////////////////////////////////////////////////////////


OIID_PARSER_RV parseAlphanumPlus(
   char *parseStr,      // Input
   char *matchChars,    // Input
   char *delimiters,    // Input
   char **foundStr,      // Output
   char **remainder,     // Output
   int *remainderIndex  // Output
);


//////////////////////////////////////////////////////////////////////////
// Function: validateAsciiOIID()
//
// Validates an OIID as per the syntax in:
//      http://www.aiim.org/dma/vote1.0/Integration.htm (the OIID Proposal)
// with following additional behavior:
//      - carriage returns and line feeds are ignored
//      - "odma" and "dma" strings are case insensitive
//      - OIID's may be truncated (e.g. partially filled out)
//      - docSpaceID, objectID and objectGUID are oprional fields
// Note: A simple flow chart for this behavior is shown in:
//      ..\doc\oiidpars.doc
//
// Assumes the OIID has been converted to an ascii string. This should be called
// prior to parsing individual fields from an OIID string, as this function
// defines the set of cases which represents conformance to legal OIID 
// syntax.
//
// Specifically the SystemID, DocSpaceID, ObjectID and ObjectGUID are all
// optional fields, but the entire OIID must parse according to the rules
// spelled out in the diagram at:
//      xxx.pdf
//
// Return values for OIID fields will be NULL if the field is not found.
// The function return value will correspond to the state of the initial
// OIID. 
//////////////////////////////////////////////////////////////////////////

OIID_PARSER_RV validateAsciiOIID(
    char *asciiOIID,             // Input
    char **asciiSystemOIID,      // Output
    char **asciiDocSpaceOIID,    // Output
    char **asciiObjectIDOIID,    // Output
    char **asciiObjectGUIDOIID   // Output
);

#endif