/*
 *  Copyright 1995,1996,1997 by the Association for Information and Image Management Int'l
 *                                             1100 Wayne Avenue
 *                                             Silver Spring, MD 20910-5603
 *                                             Tel: 301/587-8202
 *                                             Fax: 301/587-2711
 *      All Rights Reserved.
 *      DMA (Document Management Alliance) working group.
 *
 *  File: dmarcmsg.cpp
 *
 *  Description: Implementation of CdmaSystemObject::GetResultCodeDescription
 *
 */


// Local header files
#include "sysobj.h"
#include "dmastr.h"

#include <stdio.h>


////////////////////////////////////////////////////////////////////////////////
///////      implementation of GetResultCodeDescription                    /////
///////      Note: Currently supports en_US/en_UK only! No message file!   /////
////////////////////////////////////////////////////////////////////////////////

#define RC_SEVERITY(hr) (((hr) >> 31) & 0x1)
#define RC_FACILITY(hr) (((hr) >> 16) & 0x1fff)
#define RC_CODE(hr) ((hr) & 0xFFFF)
  


//=============================================================================
DMA_STDMETHOD_IMPL_(DmaRC, CdmaSystemObject::GetResultCodeDescription) (DMA_THIS_ 
             DmaRC rcResultCode, ppDmaString ppResultCodeDesc)
//=============================================================================
{   wchar_t msgBuf[128]; // long enough for longest msg
    DmaRC rc = DMARC_OK;
    switch(rcResultCode)
    {     
        case DMARC_3VE_NOT_SUPPORTED:
            wcscpy(msgBuf, L" The current scope does not support three valued elimination.");
            break;
        case DMARC_ABORT:
            wcscpy(msgBuf, L" The progress callback indicated that the method should be aborted.");
            break;
        case DMARC_ACCESS_DENIED:
            wcscpy(msgBuf, L" (E_ACCESSDENIED) The requester has insufficient access rights to perform the requested operation.");
            break;
        case DMARC_ALIAS_CONFLICT:
            wcscpy(msgBuf, L" A class, operator or property in one component scope unifies with more than one such entity in another component scope.");
            break;
        case DMARC_ALREADY_AUTHENTICATED:
            wcscpy(msgBuf, L" The user is already authenticated.");
            break;
        case DMARC_AT_ENUM_END:
            wcscpy(msgBuf, L" The enumerator object is positioned at the end of the component objects.");
            break;
        case DMARC_BAD_CLASSID:
            wcscpy(msgBuf, L" The supplied identifier does not reference an available class of object.");
            break;
        case DMARC_BAD_COLLATION_SEQUENCE:
            wcscpy(msgBuf, L" The specified collation sequence is not known or supported by the scope.");
            break;
        case DMARC_BAD_DOC_SPACE:
            wcscpy(msgBuf, L" There is no available document space with the specified DmaId.");
        case DMARC_BAD_FROM_EXPRESSION:
            wcscpy(msgBuf, L" The query contains an invalid From Expression.");
            break;
        case DMARC_BAD_INDEX:
            wcscpy(msgBuf, L" The index specified does not reference a valid property or list element.");
            break;
        case DMARC_BAD_INTERFACE:
            wcscpy(msgBuf, L" (E_NOINTERFACE) The requested interface is not supported by this object.");
            break;
        case DMARC_BAD_LOCK_TYPE:
            wcscpy(msgBuf, L" The lock type is invalid.");
            break;
        case DMARC_BAD_OBJECT:
            wcscpy(msgBuf, L" An inappropriate object was passed as parameter to this function. For example, the object does not support a required interface or is of an inappropriate class.");
            break;
        case DMARC_BAD_OIID:
            wcscpy(msgBuf, L" The supplied buffer does not contain a valid OIID.");
            break;
        case DMARC_BAD_OPERAND:
            wcscpy(msgBuf, L" An operand is incorrect in datatype, form, or class.");
            break;
        case DMARC_BAD_OPERATOR:
            wcscpy(msgBuf, L" An operator ID is not defined in the metadata of the current scope.");
            break;
        case DMARC_BAD_ORDERBY_ELEMENT:
            wcscpy(msgBuf, L" Illegal 'order by' list element.");
            break;
        case DMARC_BAD_PARAMETER:
            wcscpy(msgBuf, L" (E_INVALIDARG) Invalid input parameter.");
            break;
        case DMARC_BAD_PROPID:
            wcscpy(msgBuf, L" A property identifier is not valid.");
            break;
        case DMARC_BAD_PROTECTION_LEVEL:
            wcscpy(msgBuf, L" Illegal value for the protection level parameter.");
            break;
        case DMARC_BAD_RC:
            wcscpy(msgBuf, L" Invalid Result Code.");
            break;
        case DMARC_BAD_REFERENCE:
            wcscpy(msgBuf, L" The object cannot be saved because it references another object which is not persistent.");
            break;
        case DMARC_BAD_RESERVATION:
            wcscpy(msgBuf, L" One or more of the Reservations is not the current reservation in the VersionSeries to which it refers.");
            break;
        case DMARC_BAD_SC_OCCUR:
            wcscpy(msgBuf, L" The value of a query node's searchable class occurrence property is not present in the query.");
            break;
        case DMARC_BAD_SELECT_ELEMENT:
            wcscpy(msgBuf, L" Illegal select list element.");
            break;
        case DMARC_BAD_SUBQUERY_DATATYPE:
            wcscpy(msgBuf, L" The datatype of the query root node of an 'IN' subquery does not match that of the property in the select list.");
            break;
        case DMARC_BAD_SUBQUERY_SELECT:
            wcscpy(msgBuf, L" The select list of a subquery contains an inappropriate number of elements.");
        case DMARC_BAD_URL:
            wcscpy(msgBuf, L" The resource URL is not syntactically valid.");
            break;
        case DMARC_BAD_VALUE:
            wcscpy(msgBuf, L" The value given for a property or list element lies outside the permitted range or value set, or exceeds the maximum length allowed.");
            break;
        case DMARC_CLASS_NOT_SEARCHABLE:
            wcscpy(msgBuf, L" A class referred to in the From Expression is not searchable.");
            break;
        case DMARC_CLASSES_NOT_JOINABLE:
            wcscpy(msgBuf, L" A particular join operator in the query is supported, but the operator does not support the join between the particular operands specified in the query.");
            break;
        case DMARC_CONFLICTING_OPERATION:
            wcscpy(msgBuf, L" The call on this primary intentional method logically conflicts with a prior call on a different primary intentional method.");
            break;
        case DMARC_CONSTRAINT_VIOLATED:
            wcscpy(msgBuf, L" The operation violates a constraint of the implementation.");
            break;
        case DMARC_DATATYPE_MISMATCH:
            wcscpy(msgBuf, L" The method invoked is inappropriate for the datatype of the property.");
            break;
        case DMARC_DEVICE_ERROR:
            wcscpy(msgBuf, L" An error has occurred reading or writing a hardware device.");
            break;
        case DMARC_DISCONNECTED:
            wcscpy(msgBuf, L" The logical connection to the document space has been disconnected.");
            break;
        case DMARC_DISTINCT_NOT_SUPPORTED:
            wcscpy(msgBuf, L" The scope does not support the request for distinct result rows.");
            break;
        case DMARC_EXTRA_OPERANDS:
            wcscpy(msgBuf, L" A query node has extra operands.");
            break;
        case DMARC_FAILED:
            wcscpy(msgBuf, L" (E_FAIL) The operation failed.");
            break;
        case DMARC_FOREIGN_OBJECT:
            wcscpy(msgBuf, L" An object is not from the current document space.");
            break;
        case DMARC_ILLEGAL_OPERATION:
            wcscpy(msgBuf, L" The operation is disallowed by the DMA Specification.");
            break;
        case DMARC_LIST_BOUNDS_ERROR:
            wcscpy(msgBuf, L" The number of elements in a list is outside the permitted range.");
            break;
        case DMARC_LOST_CONNECTION:
            wcscpy(msgBuf, L" The logical connection of the current object to the persistent store has been lost permanently. The operation could not be completed.");
            break;
        case DMARC_MAX_ROWS:
            wcscpy(msgBuf, L" A result set was truncated because it exceeded the maximum result items parameter.");
            break;
        case DMARC_MISSING_OPERANDS:
            wcscpy(msgBuf, L" A query node is missing one or more operands.");
            break;
        case DMARC_MISSING_REFERENCE:
            wcscpy(msgBuf, L" The object cannot be saved because required reference to it is absent. For example, it may be required to be in a container and no appropriate relationship object exists.");
            break;
        case DMARC_MULTIPLE_CHECKIN_NOT_SUPPORTED:
            wcscpy(msgBuf, L" The implementation does not support multiple different checkins on the same object (i.e., threaded versioning).");
            break;
        case DMARC_NEED_MORE_DATA:
            wcscpy(msgBuf, L" (Warning) Indicates that more data is required to complete the browse connection operation.");
            break;
        case DMARC_NETWORK_ERROR:
            wcscpy(msgBuf, L" A network error has occurred.  It is undetermined as to whether retrying the method might succeed. The operation could not be completed.");
            break;
        case DMARC_NETWORK_UNAVAILABLE:
            wcscpy(msgBuf, L" The network needed to perform this operation is not available.");
            break;
        case DMARC_NO_COLLATIONS:
            wcscpy(msgBuf, L" Merged scope creation failed because there would be no supported collation sequences.");
            break;
        case DMARC_NO_CURRENT_VERSION:
            wcscpy(msgBuf, L" The version series has no current version.");
            break;
        case DMARC_NO_MEMORY:
            wcscpy(msgBuf, L" (E_OUTOFMEMORY) Insufficient memory to complete the operation.");
            break;
        case DMARC_NO_RESERVATION:
            wcscpy(msgBuf, L" The Version Series is not holding a reservation at this time.");
            break;
        case DMARC_NOT_AUTHENTICATED:
            wcscpy(msgBuf, L" The user is not authenticated.");
            break;
        case DMARC_NOT_CREATABLE:
            wcscpy(msgBuf, L" Creation of objects of the specified class is not supported.");
            break;
        case DMARC_NOT_FOUND:
            wcscpy(msgBuf, L" Requested item not found.");
            break;
        case DMARC_NOT_LOCKED:
            wcscpy(msgBuf, L" The object is not locked.");
            break;
        case DMARC_NOT_PUBLISHED:
            wcscpy(msgBuf, L" The service registry entry is not currently published.");
            break;
        case DMARC_NOT_SUPPORTED:
            wcscpy(msgBuf, L" This method is not supported in the context of this session or object.");
            break;
        case DMARC_NOT_UNIQUE:
            wcscpy(msgBuf, L" A uniqueness requirement has been violated.");
            break;
        case DMARC_OBJECT_DELETED:
            wcscpy(msgBuf, L" The object has been deleted since it was retrieved.");
            break;
        case DMARC_OBJECT_LOCKED:
            wcscpy(msgBuf, L" The lock(s) on the persistent object prohibit the attempted operation.");
            break;
        case DMARC_OBJECT_MODIFIED:
            wcscpy(msgBuf, L" The object has been modified since it was retrieved.");
            break;
        case DMARC_OBJECT_REFERENCED:
            wcscpy(msgBuf, L" The object cannot be deleted because it is referenced by other objects.");
            break;
        case DMARC_OK:
            wcscpy(msgBuf, L" (S_OK) Success.");
            break;
        case DMARC_OPERAND_MERGE_CONFLICT:
            wcscpy(msgBuf, L" The merge would create an invalid operand description.");
            break;
        case DMARC_OPERATOR_MERGE_CONFLICT:
            wcscpy(msgBuf, L" An operator could not be merged because it has conflicting signatures in component scopes.");
            break;
        case DMARC_POSITION_NOT_ALLOWED:
            wcscpy(msgBuf, L" The stream cannot be positioned as requested.");
            break;
        case DMARC_PROPERTY_MERGE_CONFLICT:
            wcscpy(msgBuf, L" A property could not be merged because there is a conflict of conflicting datatype or cardinality in component scopes.");
            break;
        case DMARC_PROPERTY_NOT_ORDERABLE:
            wcscpy(msgBuf, L" A property referred to in the query order by list is not orderable.");
            break;
        case DMARC_PROPERTY_NOT_SEARCHABLE:
            wcscpy(msgBuf, L" A property referred to in the Query Expression is not searchable.");
            break;
        case DMARC_PROPERTY_NOT_SELECTABLE:
            wcscpy(msgBuf, L" A property referred to in the Selections list is not selectable.");
            break;
        case DMARC_PROTECTION_LEVEL_NOT_SUPPORTED:
            wcscpy(msgBuf, L" The desired protection level is not supported by the doc space.");
            break;
        case DMARC_QUERY_AT_END:
            wcscpy(msgBuf, L" The query ran to successful completion without encountering any constraints on time limits, number of rows generated, or any other constraints, and there are no more result rows that satisfy the query. A result row is not returned.  No more result rows will be returned unless ReExecuteQuery is executed.");
            break;
        case DMARC_QUERY_TREE_LOOP:
            wcscpy(msgBuf, L" There is a circular reference loop or a shared node in the query.");
            break;
        case DMARC_READ_ONLY:
            wcscpy(msgBuf, L" Method failed because an object or property is read-only.");
            break;
        case DMARC_REFERENCES_OTHERS:
            wcscpy(msgBuf, L" The object cannot be deleted because it holds references to other objects.");
            break;
        case DMARC_REQUIRED_VALUE_ABSENT:
            wcscpy(msgBuf, L" A required property value has not been set.");
            break;
        case DMARC_RESERVATION_EXISTS:
            wcscpy(msgBuf, L" The version series is already holding a reservation.");
            break;
        case DMARC_RESERVATION_NOT_ALLOWED:
            wcscpy(msgBuf, L" The condition of the version series does not permit a reservation, though no reservation is currently present.");
            break;
        case DMARC_RESERVATION_PENDING:
            wcscpy(msgBuf, L" The connection is already holding a request for a reservation.  There cannot be more than one at a time.");
            break;
        case DMARC_RESOURCE_NOT_FOUND:
            wcscpy(msgBuf, L" The indicated resource was not found.");
            break;
        case DMARC_RESULTS_TRUNCATED:
            wcscpy(msgBuf, L" The result set was truncated explicitly by a call on IdmaResultSet:: TerminateResults. No further rows will be returned unless ReExecuteQuery is executed. This is a failure code - no row is returned.");
            break;
        case DMARC_SHORT_READ:
            wcscpy(msgBuf, L" (Warning) End of stream was encountered before the requested number of bytes was read.");
            break;
        case DMARC_STALE_METADATA:
            wcscpy(msgBuf, L" The metadata in the persistent store has been changed so that it does not match the client's current copy of the metadata.");
            break;
        case DMARC_TIMEOUT:
            wcscpy(msgBuf, L" A time limit has been exceeded.");
            break;
        case DMARC_TRUNCATED:
            wcscpy(msgBuf, L" Result sets were truncated in different component scopes for different reasons.");
            break;
        case DMARC_UNEXPECTED:
            wcscpy(msgBuf, L" (E_UNEXPECTED) An unexpected error occurred.");
            break;
        case DMARC_UNSUPPORTED_ORDERING:
            wcscpy(msgBuf, L" An unacceptable value was provided for an ordering parameter.");
            break;
        case DMARC_URL_PROTOCOL_NOT_SUPPORTED:
            wcscpy(msgBuf, L" The URL protocol specified in the reference is not supported.");
            break;
        case DMARC_VALUE_NOT_SET:
            wcscpy(msgBuf, L" The requested property currently has no value.");
            break;
        default:
            swprintf(msgBuf, L"no error msg: severity = %x, facility =  %04x, code = %04x",
                            RC_SEVERITY(rcResultCode),
                            RC_FACILITY(rcResultCode),
                            RC_CODE(rcResultCode));
            rc = DMARC_BAD_PARAMETER;
            break;
    }

    // Use macros to create a BSTR
    DMA_CREATE_STRING(((LPMALLOC)pIMalloc_)->Alloc, wcslen(msgBuf), msgBuf, ppResultCodeDesc);
    if (ppResultCodeDesc == NULL)
        return DMARC_NO_MEMORY;
    return rc;
}


