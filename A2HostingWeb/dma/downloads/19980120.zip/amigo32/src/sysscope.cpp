/*
 *  Copyright 1997 Xerox Corporation - All Rights Reserved.
 *                  3400 Hillview Ave
 *                  Palo Alto, CA
 *                  Tel: 415/813-7850
 *                  Fax: 415/813-7393
 *      
 *  Copyright protection claimed includes all forms and matters of
 *  copyrightable material and information now allowed by statuatory
 *  or judicial law or herein after granted.
 *
 *  This software may be employed as necessary for the conduct of
 *  DMA Interoperability Demonstrations at the AIIM 97 conference 
 *  in New York City, April 13-17, 1997
 *
 *  File: sysscope.cpp
 *
 *  Description: Thin Middleware System object interface IdmaSystem
 *      CreateScope method (plug-n-play) implementation.
 *
 *  Implements:
 *      CdmaSystemObject::CreateScope()
 *      CdmaSystemObject::ConnectScopeFactory()
 *
 *  **** THIS IS A WORK IN PROGRESS!! ****
 */

#include "sysobj.h"
#include "svcreg.h"

 /* Function: CreateScope()
  *
  * Description: This acts as a wrapper that allows a plug-in Scope Factory
  *              to be accessed invisibly by clients through the IdmaSystem
  *              CreateScope interface.  It will connect to a single scope
  *              object (the first one encountered in the system registry)
  *              and pass the parameters of this function to the CreateScope
  *              function found in the Scope Factory's IdmaSystem interface.
  *
  * Returns: Wrapper checks parameters and scope factory connection for errors.
  *          If any are found they are returned.  Otherwise the return code from
  *          the plug-in CreateScope function is returned.
  */

//=============================================================================
    DMA_STDMETHOD_IMPL_(DmaRC, CdmaSystemObject::CreateScopeList) (DMA_THIS_
             DMA_REFIID riid, 
             pDmapv ppIObject)
//=============================================================================
{
    if (pIScopeFactory_ == NULL) {
        return DMARC_UNEXPECTED;
    }
    return pIScopeFactory_->CreateScopeList(riid, ppIObject);
}


//=============================================================================
DMA_STDMETHOD_IMPL_(DmaRC, CdmaSystemObject::CreateScope) (DMA_THIS_ Dmapv pIScopeList, 
         DmaInteger32 lCombinationRule, DMA_REFIID riid, pDmapv ppIScope)
//=============================================================================
{
    if (pIScopeFactory_ == NULL) {
        return DMARC_UNEXPECTED;
    }
    return pIScopeFactory_->CreateScope(pIScopeList, lCombinationRule, riid, ppIScope);
}


 /* Function: CreateScope()
  *
  * Description: This creates a connection (and resulting IdmaSystem interface)
  *              for the single DMA system object to a single scope factory. This
  *              function is virtually identical to ConnectDocSpace, but reflects
  *              the fact we are connecting to a single scope factory.
  *
  * Returns: Return cases/values are similar to ConnectDocSpace.
  */

//=============================================================================
DMA_STDMETHOD_IMPL_(DmaRC, CdmaSystemObject::ConnectScopeFactory) (
    DMA_THIS_ pDmaId pScopeFactoryId, 
    pDmaString pLocaleName, 
    DMA_REFIID riid, 
    pDmapv ppIScopeFactory)
//=============================================================================
{
    DmaRC rc = DMARC_OK;

    PRT_DBG("\tDebug: Call to CdmaSystemObject::ConnectScopeFactory\n");
    if (ppIScopeFactory == NULL)
        return DMARC_BAD_PARAMETER;
    *ppIScopeFactory = NULL;    // For all error returns

    if (ppIScopeFactory == NULL) 
        return DMARC_BAD_PARAMETER;
    *ppIScopeFactory = NULL;

    // Override system manager locale if desired by client (not until V1.1)
    pDmaString pLocName = (pLocaleName != NULL) ? pLocaleName : pLocaleName_;

    DmaId id = dmaServiceObject_ScopeFactory;
    if (pScopeFactoryId != NULL) id = *pScopeFactoryId;
    rc = CallDmaGetServiceElementBySvcObjId(id, dmaServiceType_ScopeFactory, lCharSetEncodingID_,
                                            pvEnvInfo_,
                                            (IMalloc*)pIMalloc_,
                                            this,
                                            pLocaleName, riid, reg_, ppIScopeFactory);
    return rc;
}