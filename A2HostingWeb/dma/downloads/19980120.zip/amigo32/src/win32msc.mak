# Microsoft Developer Studio Generated NMAKE File, Format Version 4.20
# ** DO NOT EDIT **

# TARGTYPE "Win32 (x86) Console Application" 0x0103
# TARGTYPE "Win32 (x86) Dynamic-Link Library" 0x0102

!IF "$(CFG)" == ""
CFG=testclnt - Win32 Debug
!MESSAGE No configuration specified.  Defaulting to testclnt - Win32 Debug.
!ENDIF 

!IF "$(CFG)" != "sysmgr - Win32 Release" && "$(CFG)" != "sysmgr - Win32 Debug"\
 && "$(CFG)" != "system - Win32 Release" && "$(CFG)" != "system - Win32 Debug"\
 && "$(CFG)" != "testclnt - Win32 Release" && "$(CFG)" !=\
 "testclnt - Win32 Debug"
!MESSAGE Invalid configuration "$(CFG)" specified.
!MESSAGE You can specify a configuration when running NMAKE on this makefile
!MESSAGE by defining the macro CFG on the command line.  For example:
!MESSAGE 
!MESSAGE NMAKE /f "win32msc.mak" CFG="testclnt - Win32 Debug"
!MESSAGE 
!MESSAGE Possible choices for configuration are:
!MESSAGE 
!MESSAGE "sysmgr - Win32 Release" (based on "Win32 (x86) Dynamic-Link Library")
!MESSAGE "sysmgr - Win32 Debug" (based on "Win32 (x86) Dynamic-Link Library")
!MESSAGE "system - Win32 Release" (based on "Win32 (x86) Dynamic-Link Library")
!MESSAGE "system - Win32 Debug" (based on "Win32 (x86) Dynamic-Link Library")
!MESSAGE "testclnt - Win32 Release" (based on\
 "Win32 (x86) Console Application")
!MESSAGE "testclnt - Win32 Debug" (based on "Win32 (x86) Console Application")
!MESSAGE 
!ERROR An invalid configuration is specified.
!ENDIF 

!IF "$(OS)" == "Windows_NT"
NULL=
!ELSE 
NULL=nul
!ENDIF 
################################################################################
# Begin Project
# PROP Target_Last_Scanned "sysmgr - Win32 Debug"

!IF  "$(CFG)" == "sysmgr - Win32 Release"

# PROP BASE Use_MFC 0
# PROP BASE Use_Debug_Libraries 0
# PROP BASE Output_Dir "Release"
# PROP BASE Intermediate_Dir "Release"
# PROP BASE Target_Dir "."
# PROP Use_MFC 0
# PROP Use_Debug_Libraries 0
# PROP Output_Dir "..\bin\win32msc\Release"
# PROP Intermediate_Dir "..\obj\sysmgr\win32msc\Release"
# PROP Target_Dir "."
OUTDIR=.\..\bin\win32msc\Release
INTDIR=.\..\obj\sysmgr\win32msc\Release

ALL : "$(OUTDIR)\dma10.dll"

CLEAN : 
	-@erase "$(INTDIR)\dma10.res"
	-@erase "$(INTDIR)\oiidutil.obj"
	-@erase "$(INTDIR)\SVCCACHE.OBJ"
	-@erase "$(INTDIR)\SVCREG.OBJ"
	-@erase "$(INTDIR)\SYSMGR.OBJ"
	-@erase "$(OUTDIR)\dma10.dll"
	-@erase "$(OUTDIR)\dma10.exp"
	-@erase "$(OUTDIR)\dma10.lib"
	-@erase "..\obj\sysmgr\win32msc\Release\dma10.map"

"$(OUTDIR)" :
    if not exist "$(OUTDIR)/$(NULL)" mkdir "$(OUTDIR)"

"$(INTDIR)" :
    if not exist "$(INTDIR)/$(NULL)" mkdir "$(INTDIR)"

CPP=cl.exe
# ADD BASE CPP /nologo /MT /W3 /GX /O2 /D "WIN32" /D "NDEBUG" /D "_WINDOWS" /YX /c
# ADD CPP /nologo /MD /W3 /O2 /I "..\dma\include" /D "WIN32" /D "NDEBUG" /D "_WINDOWS" /YX /c
CPP_PROJ=/nologo /MD /W3 /O2 /I "..\dma\include" /D "WIN32" /D "NDEBUG" /D\
 "_WINDOWS" /Fp"$(INTDIR)/win32msc.pch" /YX /Fo"$(INTDIR)/" /c 
CPP_OBJS=.\..\obj\sysmgr\win32msc\Release/
CPP_SBRS=.\.

.c{$(CPP_OBJS)}.obj:
   $(CPP) $(CPP_PROJ) $<  

.cpp{$(CPP_OBJS)}.obj:
   $(CPP) $(CPP_PROJ) $<  

.cxx{$(CPP_OBJS)}.obj:
   $(CPP) $(CPP_PROJ) $<  

.c{$(CPP_SBRS)}.sbr:
   $(CPP) $(CPP_PROJ) $<  

.cpp{$(CPP_SBRS)}.sbr:
   $(CPP) $(CPP_PROJ) $<  

.cxx{$(CPP_SBRS)}.sbr:
   $(CPP) $(CPP_PROJ) $<  

MTL=mktyplib.exe
# ADD BASE MTL /nologo /D "NDEBUG" /win32
# ADD MTL /nologo /D "NDEBUG" /win32
MTL_PROJ=/nologo /D "NDEBUG" /win32 
RSC=rc.exe
# ADD BASE RSC /l 0x409 /d "NDEBUG"
# ADD RSC /l 0x409 /d "NDEBUG"
RSC_PROJ=/l 0x409 /fo"$(INTDIR)/dma10.res" /d "NDEBUG" 
BSC32=bscmake.exe
# ADD BASE BSC32 /nologo
# ADD BSC32 /nologo /o"..\obj\sysmgr\win32msc\Release/Amigo32.bsc"
BSC32_FLAGS=/nologo /o"..\obj\sysmgr\win32msc\Release/Amigo32.bsc" 
BSC32_SBRS= \
	
LINK32=link.exe
# ADD BASE LINK32 kernel32.lib user32.lib gdi32.lib winspool.lib comdlg32.lib advapi32.lib shell32.lib ole32.lib oleaut32.lib uuid.lib odbc32.lib odbccp32.lib /nologo /subsystem:windows /dll /machine:I386
# ADD LINK32 kernel32.lib user32.lib gdi32.lib winspool.lib comdlg32.lib advapi32.lib shell32.lib ole32.lib oleaut32.lib uuid.lib odbc32.lib odbccp32.lib /nologo /subsystem:windows /dll /map /machine:I386 /out:"..\bin\win32msc\Release/dma10.dll"
LINK32_FLAGS=kernel32.lib user32.lib gdi32.lib winspool.lib comdlg32.lib\
 advapi32.lib shell32.lib ole32.lib oleaut32.lib uuid.lib odbc32.lib\
 odbccp32.lib /nologo /subsystem:windows /dll /incremental:no\
 /pdb:"$(OUTDIR)/dma10.pdb" /map:"$(INTDIR)/dma10.map" /machine:I386\
 /def:".\sysmgr.def" /out:"$(OUTDIR)/dma10.dll" /implib:"$(OUTDIR)/dma10.lib" 
DEF_FILE= \
	".\sysmgr.def"
LINK32_OBJS= \
	"$(INTDIR)\dma10.res" \
	"$(INTDIR)\oiidutil.obj" \
	"$(INTDIR)\SVCCACHE.OBJ" \
	"$(INTDIR)\SVCREG.OBJ" \
	"$(INTDIR)\SYSMGR.OBJ"

"$(OUTDIR)\dma10.dll" : "$(OUTDIR)" $(DEF_FILE) $(LINK32_OBJS)
    $(LINK32) @<<
  $(LINK32_FLAGS) $(LINK32_OBJS)
<<

!ELSEIF  "$(CFG)" == "sysmgr - Win32 Debug"

# PROP BASE Use_MFC 0
# PROP BASE Use_Debug_Libraries 1
# PROP BASE Output_Dir ".\Debug"
# PROP BASE Intermediate_Dir ".\Debug"
# PROP BASE Target_Dir "."
# PROP Use_MFC 0
# PROP Use_Debug_Libraries 1
# PROP Output_Dir "..\bin\win32msc\Debug"
# PROP Intermediate_Dir "..\obj\sysmgr\win32msc\Debug"
# PROP Target_Dir "."
OUTDIR=.\..\bin\win32msc\Debug
INTDIR=.\..\obj\sysmgr\win32msc\Debug

ALL : "$(OUTDIR)\dma10.dll"

CLEAN : 
	-@erase "$(INTDIR)\dma10.res"
	-@erase "$(INTDIR)\oiidutil.obj"
	-@erase "$(INTDIR)\SVCCACHE.OBJ"
	-@erase "$(INTDIR)\SVCREG.OBJ"
	-@erase "$(INTDIR)\SYSMGR.OBJ"
	-@erase "$(INTDIR)\vc40.idb"
	-@erase "$(INTDIR)\vc40.pdb"
	-@erase "$(OUTDIR)\dma10.dll"
	-@erase "$(OUTDIR)\dma10.exp"
	-@erase "$(OUTDIR)\dma10.ilk"
	-@erase "$(OUTDIR)\dma10.lib"
	-@erase "$(OUTDIR)\dma10.pdb"

"$(OUTDIR)" :
    if not exist "$(OUTDIR)/$(NULL)" mkdir "$(OUTDIR)"

"$(INTDIR)" :
    if not exist "$(INTDIR)/$(NULL)" mkdir "$(INTDIR)"

CPP=cl.exe
# ADD BASE CPP /nologo /MTd /W3 /Gm /GX /Zi /Od /D "WIN32" /D "_DEBUG" /D "_WINDOWS" /YX /c
# ADD CPP /nologo /MTd /W3 /Gm /Zi /Od /I "..\dma\include" /D "WIN32" /D "_DEBUG" /D "_WINDOWS" /YX /c
CPP_PROJ=/nologo /MTd /W3 /Gm /Zi /Od /I "..\dma\include" /D "WIN32" /D\
 "_DEBUG" /D "_WINDOWS" /Fp"$(INTDIR)/win32msc.pch" /YX /Fo"$(INTDIR)/"\
 /Fd"$(INTDIR)/" /c 
CPP_OBJS=.\..\obj\sysmgr\win32msc\Debug/
CPP_SBRS=.\.

.c{$(CPP_OBJS)}.obj:
   $(CPP) $(CPP_PROJ) $<  

.cpp{$(CPP_OBJS)}.obj:
   $(CPP) $(CPP_PROJ) $<  

.cxx{$(CPP_OBJS)}.obj:
   $(CPP) $(CPP_PROJ) $<  

.c{$(CPP_SBRS)}.sbr:
   $(CPP) $(CPP_PROJ) $<  

.cpp{$(CPP_SBRS)}.sbr:
   $(CPP) $(CPP_PROJ) $<  

.cxx{$(CPP_SBRS)}.sbr:
   $(CPP) $(CPP_PROJ) $<  

MTL=mktyplib.exe
# ADD BASE MTL /nologo /D "_DEBUG" /win32
# ADD MTL /nologo /D "_DEBUG" /win32
MTL_PROJ=/nologo /D "_DEBUG" /win32 
RSC=rc.exe
# ADD BASE RSC /l 0x409 /d "_DEBUG"
# ADD RSC /l 0x409 /d "_DEBUG"
RSC_PROJ=/l 0x409 /fo"$(INTDIR)/dma10.res" /d "_DEBUG" 
BSC32=bscmake.exe
# ADD BASE BSC32 /nologo
# ADD BSC32 /nologo /o"..\obj\sysmgr\win32msc\Debug/Amigo32.bsc"
BSC32_FLAGS=/nologo /o"..\obj\sysmgr\win32msc\Debug/Amigo32.bsc" 
BSC32_SBRS= \
	
LINK32=link.exe
# ADD BASE LINK32 kernel32.lib user32.lib gdi32.lib winspool.lib comdlg32.lib advapi32.lib shell32.lib ole32.lib oleaut32.lib uuid.lib odbc32.lib odbccp32.lib /nologo /subsystem:windows /dll /debug /machine:I386
# ADD LINK32 kernel32.lib user32.lib gdi32.lib winspool.lib comdlg32.lib advapi32.lib shell32.lib ole32.lib oleaut32.lib uuid.lib odbc32.lib odbccp32.lib /nologo /subsystem:windows /dll /debug /machine:I386 /out:"..\bin\win32msc\Debug/dma10.dll"
LINK32_FLAGS=kernel32.lib user32.lib gdi32.lib winspool.lib comdlg32.lib\
 advapi32.lib shell32.lib ole32.lib oleaut32.lib uuid.lib odbc32.lib\
 odbccp32.lib /nologo /subsystem:windows /dll /incremental:yes\
 /pdb:"$(OUTDIR)/dma10.pdb" /debug /machine:I386 /def:".\sysmgr.def"\
 /out:"$(OUTDIR)/dma10.dll" /implib:"$(OUTDIR)/dma10.lib" 
DEF_FILE= \
	".\sysmgr.def"
LINK32_OBJS= \
	"$(INTDIR)\dma10.res" \
	"$(INTDIR)\oiidutil.obj" \
	"$(INTDIR)\SVCCACHE.OBJ" \
	"$(INTDIR)\SVCREG.OBJ" \
	"$(INTDIR)\SYSMGR.OBJ"

"$(OUTDIR)\dma10.dll" : "$(OUTDIR)" $(DEF_FILE) $(LINK32_OBJS)
    $(LINK32) @<<
  $(LINK32_FLAGS) $(LINK32_OBJS)
<<

!ELSEIF  "$(CFG)" == "system - Win32 Release"

# PROP BASE Use_MFC 0
# PROP BASE Use_Debug_Libraries 0
# PROP BASE Output_Dir "system\Release"
# PROP BASE Intermediate_Dir "system\Release"
# PROP BASE Target_Dir "system"
# PROP Use_MFC 0
# PROP Use_Debug_Libraries 0
# PROP Output_Dir "..\bin\win32msc\Release"
# PROP Intermediate_Dir "..\obj\system\win32msc\Release"
# PROP Target_Dir "system"
OUTDIR=.\..\bin\win32msc\Release
INTDIR=.\..\obj\system\win32msc\Release

ALL : "$(OUTDIR)\dmasys1.dll"

CLEAN : 
	-@erase "$(INTDIR)\dmaguids.obj"
	-@erase "$(INTDIR)\dmarcmsg.obj"
	-@erase "$(INTDIR)\dmasys1.res"
	-@erase "$(INTDIR)\oiidutil.obj"
	-@erase "$(INTDIR)\SVCCACHE.OBJ"
	-@erase "$(INTDIR)\SVCREG.OBJ"
	-@erase "$(INTDIR)\SYSOBJ.OBJ"
	-@erase "$(INTDIR)\SYSPROPS.OBJ"
	-@erase "$(INTDIR)\sysscope.obj"
	-@erase "$(OUTDIR)\dmasys1.dll"
	-@erase "$(OUTDIR)\dmasys1.exp"
	-@erase "$(OUTDIR)\dmasys1.lib"

"$(OUTDIR)" :
    if not exist "$(OUTDIR)/$(NULL)" mkdir "$(OUTDIR)"

"$(INTDIR)" :
    if not exist "$(INTDIR)/$(NULL)" mkdir "$(INTDIR)"

CPP=cl.exe
# ADD BASE CPP /nologo /MT /W3 /GX /O2 /D "WIN32" /D "NDEBUG" /D "_WINDOWS" /YX /c
# ADD CPP /nologo /MT /W3 /O2 /I "..\dma\include" /D "WIN32" /D "NDEBUG" /D "_WINDOWS" /YX /c
CPP_PROJ=/nologo /MT /W3 /O2 /I "..\dma\include" /D "WIN32" /D "NDEBUG" /D\
 "_WINDOWS" /Fp"$(INTDIR)/system.pch" /YX /Fo"$(INTDIR)/" /c 
CPP_OBJS=.\..\obj\system\win32msc\Release/
CPP_SBRS=.\.

.c{$(CPP_OBJS)}.obj:
   $(CPP) $(CPP_PROJ) $<  

.cpp{$(CPP_OBJS)}.obj:
   $(CPP) $(CPP_PROJ) $<  

.cxx{$(CPP_OBJS)}.obj:
   $(CPP) $(CPP_PROJ) $<  

.c{$(CPP_SBRS)}.sbr:
   $(CPP) $(CPP_PROJ) $<  

.cpp{$(CPP_SBRS)}.sbr:
   $(CPP) $(CPP_PROJ) $<  

.cxx{$(CPP_SBRS)}.sbr:
   $(CPP) $(CPP_PROJ) $<  

MTL=mktyplib.exe
# ADD BASE MTL /nologo /D "NDEBUG" /win32
# ADD MTL /nologo /D "NDEBUG" /win32
MTL_PROJ=/nologo /D "NDEBUG" /win32 
RSC=rc.exe
# ADD BASE RSC /l 0x409 /d "NDEBUG"
# ADD RSC /l 0x409 /d "NDEBUG"
RSC_PROJ=/l 0x409 /fo"$(INTDIR)/dmasys1.res" /d "NDEBUG" 
BSC32=bscmake.exe
# ADD BASE BSC32 /nologo
# ADD BSC32 /nologo /o"..\obj\system\win32msc\Release/system.bsc"
BSC32_FLAGS=/nologo /o"..\obj\system\win32msc\Release/system.bsc" 
BSC32_SBRS= \
	
LINK32=link.exe
# ADD BASE LINK32 kernel32.lib user32.lib gdi32.lib winspool.lib comdlg32.lib advapi32.lib shell32.lib ole32.lib oleaut32.lib uuid.lib odbc32.lib odbccp32.lib /nologo /subsystem:windows /dll /machine:I386
# ADD LINK32 kernel32.lib user32.lib gdi32.lib winspool.lib comdlg32.lib advapi32.lib shell32.lib ole32.lib oleaut32.lib uuid.lib odbc32.lib odbccp32.lib /nologo /subsystem:windows /dll /machine:I386 /out:"..\bin\win32msc\Release/dmasys1.dll"
LINK32_FLAGS=kernel32.lib user32.lib gdi32.lib winspool.lib comdlg32.lib\
 advapi32.lib shell32.lib ole32.lib oleaut32.lib uuid.lib odbc32.lib\
 odbccp32.lib /nologo /subsystem:windows /dll /incremental:no\
 /pdb:"$(OUTDIR)/dmasys1.pdb" /machine:I386 /def:".\system.def"\
 /out:"$(OUTDIR)/dmasys1.dll" /implib:"$(OUTDIR)/dmasys1.lib" 
DEF_FILE= \
	".\system.def"
LINK32_OBJS= \
	"$(INTDIR)\dmaguids.obj" \
	"$(INTDIR)\dmarcmsg.obj" \
	"$(INTDIR)\dmasys1.res" \
	"$(INTDIR)\oiidutil.obj" \
	"$(INTDIR)\SVCCACHE.OBJ" \
	"$(INTDIR)\SVCREG.OBJ" \
	"$(INTDIR)\SYSOBJ.OBJ" \
	"$(INTDIR)\SYSPROPS.OBJ" \
	"$(INTDIR)\sysscope.obj"

"$(OUTDIR)\dmasys1.dll" : "$(OUTDIR)" $(DEF_FILE) $(LINK32_OBJS)
    $(LINK32) @<<
  $(LINK32_FLAGS) $(LINK32_OBJS)
<<

!ELSEIF  "$(CFG)" == "system - Win32 Debug"

# PROP BASE Use_MFC 0
# PROP BASE Use_Debug_Libraries 1
# PROP BASE Output_Dir "system\Debug"
# PROP BASE Intermediate_Dir "system\Debug"
# PROP BASE Target_Dir "system"
# PROP Use_MFC 0
# PROP Use_Debug_Libraries 1
# PROP Output_Dir "..\bin\win32msc\Debug"
# PROP Intermediate_Dir "..\obj\system\win32msc\Debug"
# PROP Target_Dir "system"
OUTDIR=.\..\bin\win32msc\Debug
INTDIR=.\..\obj\system\win32msc\Debug

ALL : "$(OUTDIR)\dmasys1.dll"

CLEAN : 
	-@erase "$(INTDIR)\dmaguids.obj"
	-@erase "$(INTDIR)\dmarcmsg.obj"
	-@erase "$(INTDIR)\dmasys1.res"
	-@erase "$(INTDIR)\oiidutil.obj"
	-@erase "$(INTDIR)\SVCCACHE.OBJ"
	-@erase "$(INTDIR)\SVCREG.OBJ"
	-@erase "$(INTDIR)\SYSOBJ.OBJ"
	-@erase "$(INTDIR)\SYSPROPS.OBJ"
	-@erase "$(INTDIR)\sysscope.obj"
	-@erase "$(INTDIR)\vc40.idb"
	-@erase "$(INTDIR)\vc40.pdb"
	-@erase "$(OUTDIR)\dmasys1.dll"
	-@erase "$(OUTDIR)\dmasys1.exp"
	-@erase "$(OUTDIR)\dmasys1.ilk"
	-@erase "$(OUTDIR)\dmasys1.lib"
	-@erase "$(OUTDIR)\dmasys1.pdb"

"$(OUTDIR)" :
    if not exist "$(OUTDIR)/$(NULL)" mkdir "$(OUTDIR)"

"$(INTDIR)" :
    if not exist "$(INTDIR)/$(NULL)" mkdir "$(INTDIR)"

CPP=cl.exe
# ADD BASE CPP /nologo /MTd /W3 /Gm /GX /Zi /Od /D "WIN32" /D "_DEBUG" /D "_WINDOWS" /YX /c
# ADD CPP /nologo /MTd /W3 /Gm /Zi /Od /I "..\dma\include" /D "WIN32" /D "_DEBUG" /D "_WINDOWS" /YX /c
CPP_PROJ=/nologo /MTd /W3 /Gm /Zi /Od /I "..\dma\include" /D "WIN32" /D\
 "_DEBUG" /D "_WINDOWS" /Fp"$(INTDIR)/system.pch" /YX /Fo"$(INTDIR)/"\
 /Fd"$(INTDIR)/" /c 
CPP_OBJS=.\..\obj\system\win32msc\Debug/
CPP_SBRS=.\.

.c{$(CPP_OBJS)}.obj:
   $(CPP) $(CPP_PROJ) $<  

.cpp{$(CPP_OBJS)}.obj:
   $(CPP) $(CPP_PROJ) $<  

.cxx{$(CPP_OBJS)}.obj:
   $(CPP) $(CPP_PROJ) $<  

.c{$(CPP_SBRS)}.sbr:
   $(CPP) $(CPP_PROJ) $<  

.cpp{$(CPP_SBRS)}.sbr:
   $(CPP) $(CPP_PROJ) $<  

.cxx{$(CPP_SBRS)}.sbr:
   $(CPP) $(CPP_PROJ) $<  

MTL=mktyplib.exe
# ADD BASE MTL /nologo /D "_DEBUG" /win32
# ADD MTL /nologo /D "_DEBUG" /win32
MTL_PROJ=/nologo /D "_DEBUG" /win32 
RSC=rc.exe
# ADD BASE RSC /l 0x409 /d "_DEBUG"
# ADD RSC /l 0x409 /d "_DEBUG"
RSC_PROJ=/l 0x409 /fo"$(INTDIR)/dmasys1.res" /d "_DEBUG" 
BSC32=bscmake.exe
# ADD BASE BSC32 /nologo
# ADD BSC32 /nologo /o"..\obj\system\win32msc\Debug/system.bsc"
BSC32_FLAGS=/nologo /o"..\obj\system\win32msc\Debug/system.bsc" 
BSC32_SBRS= \
	
LINK32=link.exe
# ADD BASE LINK32 kernel32.lib user32.lib gdi32.lib winspool.lib comdlg32.lib advapi32.lib shell32.lib ole32.lib oleaut32.lib uuid.lib odbc32.lib odbccp32.lib /nologo /subsystem:windows /dll /debug /machine:I386
# ADD LINK32 kernel32.lib user32.lib gdi32.lib winspool.lib comdlg32.lib advapi32.lib shell32.lib ole32.lib oleaut32.lib uuid.lib odbc32.lib odbccp32.lib /nologo /subsystem:windows /dll /debug /machine:I386 /out:"..\bin\win32msc\Debug/dmasys1.dll"
LINK32_FLAGS=kernel32.lib user32.lib gdi32.lib winspool.lib comdlg32.lib\
 advapi32.lib shell32.lib ole32.lib oleaut32.lib uuid.lib odbc32.lib\
 odbccp32.lib /nologo /subsystem:windows /dll /incremental:yes\
 /pdb:"$(OUTDIR)/dmasys1.pdb" /debug /machine:I386 /def:".\system.def"\
 /out:"$(OUTDIR)/dmasys1.dll" /implib:"$(OUTDIR)/dmasys1.lib" 
DEF_FILE= \
	".\system.def"
LINK32_OBJS= \
	"$(INTDIR)\dmaguids.obj" \
	"$(INTDIR)\dmarcmsg.obj" \
	"$(INTDIR)\dmasys1.res" \
	"$(INTDIR)\oiidutil.obj" \
	"$(INTDIR)\SVCCACHE.OBJ" \
	"$(INTDIR)\SVCREG.OBJ" \
	"$(INTDIR)\SYSOBJ.OBJ" \
	"$(INTDIR)\SYSPROPS.OBJ" \
	"$(INTDIR)\sysscope.obj"

"$(OUTDIR)\dmasys1.dll" : "$(OUTDIR)" $(DEF_FILE) $(LINK32_OBJS)
    $(LINK32) @<<
  $(LINK32_FLAGS) $(LINK32_OBJS)
<<

!ELSEIF  "$(CFG)" == "testclnt - Win32 Release"

# PROP BASE Use_MFC 0
# PROP BASE Use_Debug_Libraries 0
# PROP BASE Output_Dir "testclnt\Release"
# PROP BASE Intermediate_Dir "testclnt\Release"
# PROP BASE Target_Dir "testclnt"
# PROP Use_MFC 0
# PROP Use_Debug_Libraries 0
# PROP Output_Dir "..\bin\win32msc\Release"
# PROP Intermediate_Dir "..\obj\testclnt\win32msc\Release"
# PROP Target_Dir "testclnt"
OUTDIR=.\..\bin\win32msc\Release
INTDIR=.\..\obj\testclnt\win32msc\Release

ALL : "$(OUTDIR)\testclnt.exe"

CLEAN : 
	-@erase "$(INTDIR)\testclnt.res"
	-@erase "$(INTDIR)\TESTMAIN.OBJ"
	-@erase "$(OUTDIR)\testclnt.exe"

"$(OUTDIR)" :
    if not exist "$(OUTDIR)/$(NULL)" mkdir "$(OUTDIR)"

"$(INTDIR)" :
    if not exist "$(INTDIR)/$(NULL)" mkdir "$(INTDIR)"

CPP=cl.exe
# ADD BASE CPP /nologo /W3 /GX /O2 /D "WIN32" /D "NDEBUG" /D "_CONSOLE" /YX /c
# ADD CPP /nologo /W3 /O2 /I "..\dma\include" /D "WIN32" /D "NDEBUG" /D "_CONSOLE" /YX /c
CPP_PROJ=/nologo /ML /W3 /O2 /I "..\dma\include" /D "WIN32" /D "NDEBUG" /D\
 "_CONSOLE" /Fp"$(INTDIR)/testclnt.pch" /YX /Fo"$(INTDIR)/" /c 
CPP_OBJS=.\..\obj\testclnt\win32msc\Release/
CPP_SBRS=.\.

.c{$(CPP_OBJS)}.obj:
   $(CPP) $(CPP_PROJ) $<  

.cpp{$(CPP_OBJS)}.obj:
   $(CPP) $(CPP_PROJ) $<  

.cxx{$(CPP_OBJS)}.obj:
   $(CPP) $(CPP_PROJ) $<  

.c{$(CPP_SBRS)}.sbr:
   $(CPP) $(CPP_PROJ) $<  

.cpp{$(CPP_SBRS)}.sbr:
   $(CPP) $(CPP_PROJ) $<  

.cxx{$(CPP_SBRS)}.sbr:
   $(CPP) $(CPP_PROJ) $<  

RSC=rc.exe
# ADD BASE RSC /l 0x409 /d "NDEBUG"
# ADD RSC /l 0x409 /d "NDEBUG"
RSC_PROJ=/l 0x409 /fo"$(INTDIR)/testclnt.res" /d "NDEBUG" 
BSC32=bscmake.exe
# ADD BASE BSC32 /nologo
# ADD BSC32 /nologo /o"..\obj\win32msc\testclnt\Release/testclnt.bsc"
BSC32_FLAGS=/nologo /o"..\obj\win32msc\testclnt\Release/testclnt.bsc" 
BSC32_SBRS= \
	
LINK32=link.exe
# ADD BASE LINK32 kernel32.lib user32.lib gdi32.lib winspool.lib comdlg32.lib advapi32.lib shell32.lib ole32.lib oleaut32.lib uuid.lib odbc32.lib odbccp32.lib /nologo /subsystem:console /machine:I386
# ADD LINK32 ..\bin\win32msc\Release/dma10.lib kernel32.lib user32.lib gdi32.lib winspool.lib comdlg32.lib advapi32.lib shell32.lib ole32.lib oleaut32.lib uuid.lib odbc32.lib odbccp32.lib /nologo /subsystem:console /machine:I386
LINK32_FLAGS=..\bin\win32msc\Release/dma10.lib kernel32.lib user32.lib\
 gdi32.lib winspool.lib comdlg32.lib advapi32.lib shell32.lib ole32.lib\
 oleaut32.lib uuid.lib odbc32.lib odbccp32.lib /nologo /subsystem:console\
 /incremental:no /pdb:"$(OUTDIR)/testclnt.pdb" /machine:I386\
 /out:"$(OUTDIR)/testclnt.exe" 
LINK32_OBJS= \
	"$(INTDIR)\testclnt.res" \
	"$(INTDIR)\TESTMAIN.OBJ"

"$(OUTDIR)\testclnt.exe" : "$(OUTDIR)" $(DEF_FILE) $(LINK32_OBJS)
    $(LINK32) @<<
  $(LINK32_FLAGS) $(LINK32_OBJS)
<<

!ELSEIF  "$(CFG)" == "testclnt - Win32 Debug"

# PROP BASE Use_MFC 0
# PROP BASE Use_Debug_Libraries 1
# PROP BASE Output_Dir "testclnt\Debug"
# PROP BASE Intermediate_Dir "testclnt\Debug"
# PROP BASE Target_Dir "testclnt"
# PROP Use_MFC 0
# PROP Use_Debug_Libraries 1
# PROP Output_Dir "..\bin\win32msc\Debug"
# PROP Intermediate_Dir "..\obj\testclnt\win32msc\Debug"
# PROP Target_Dir "testclnt"
OUTDIR=.\..\bin\win32msc\Debug
INTDIR=.\..\obj\testclnt\win32msc\Debug

ALL : "$(OUTDIR)\testclnt.exe"

CLEAN : 
	-@erase "$(INTDIR)\testclnt.res"
	-@erase "$(INTDIR)\TESTMAIN.OBJ"
	-@erase "$(INTDIR)\vc40.idb"
	-@erase "$(INTDIR)\vc40.pdb"
	-@erase "$(OUTDIR)\testclnt.exe"
	-@erase "$(OUTDIR)\testclnt.ilk"
	-@erase "$(OUTDIR)\testclnt.pdb"

"$(OUTDIR)" :
    if not exist "$(OUTDIR)/$(NULL)" mkdir "$(OUTDIR)"

"$(INTDIR)" :
    if not exist "$(INTDIR)/$(NULL)" mkdir "$(INTDIR)"

CPP=cl.exe
# ADD BASE CPP /nologo /W3 /Gm /GX /Zi /Od /D "WIN32" /D "_DEBUG" /D "_CONSOLE" /YX /c
# ADD CPP /nologo /W3 /Gm /Zi /Od /I "..\dma\include" /D "WIN32" /D "_DEBUG" /D "_CONSOLE" /YX /c
CPP_PROJ=/nologo /MLd /W3 /Gm /Zi /Od /I "..\dma\include" /D "WIN32" /D\
 "_DEBUG" /D "_CONSOLE" /Fp"$(INTDIR)/testclnt.pch" /YX /Fo"$(INTDIR)/"\
 /Fd"$(INTDIR)/" /c 
CPP_OBJS=.\..\obj\testclnt\win32msc\Debug/
CPP_SBRS=.\.

.c{$(CPP_OBJS)}.obj:
   $(CPP) $(CPP_PROJ) $<  

.cpp{$(CPP_OBJS)}.obj:
   $(CPP) $(CPP_PROJ) $<  

.cxx{$(CPP_OBJS)}.obj:
   $(CPP) $(CPP_PROJ) $<  

.c{$(CPP_SBRS)}.sbr:
   $(CPP) $(CPP_PROJ) $<  

.cpp{$(CPP_SBRS)}.sbr:
   $(CPP) $(CPP_PROJ) $<  

.cxx{$(CPP_SBRS)}.sbr:
   $(CPP) $(CPP_PROJ) $<  

RSC=rc.exe
# ADD BASE RSC /l 0x409 /d "_DEBUG"
# ADD RSC /l 0x409 /d "_DEBUG"
RSC_PROJ=/l 0x409 /fo"$(INTDIR)/testclnt.res" /d "_DEBUG" 
BSC32=bscmake.exe
# ADD BASE BSC32 /nologo
# ADD BSC32 /nologo /o"..\obj\win32msc\testclnt\Debug/testclnt.bsc"
BSC32_FLAGS=/nologo /o"..\obj\win32msc\testclnt\Debug/testclnt.bsc" 
BSC32_SBRS= \
	
LINK32=link.exe
# ADD BASE LINK32 kernel32.lib user32.lib gdi32.lib winspool.lib comdlg32.lib advapi32.lib shell32.lib ole32.lib oleaut32.lib uuid.lib odbc32.lib odbccp32.lib /nologo /subsystem:console /debug /machine:I386
# ADD LINK32 ..\bin\win32msc\Debug/dma10.lib kernel32.lib user32.lib gdi32.lib winspool.lib comdlg32.lib advapi32.lib shell32.lib ole32.lib oleaut32.lib uuid.lib odbc32.lib odbccp32.lib /nologo /subsystem:console /debug /machine:I386
LINK32_FLAGS=..\bin\win32msc\Debug/dma10.lib kernel32.lib user32.lib gdi32.lib\
 winspool.lib comdlg32.lib advapi32.lib shell32.lib ole32.lib oleaut32.lib\
 uuid.lib odbc32.lib odbccp32.lib /nologo /subsystem:console /incremental:yes\
 /pdb:"$(OUTDIR)/testclnt.pdb" /debug /machine:I386\
 /out:"$(OUTDIR)/testclnt.exe" 
LINK32_OBJS= \
	"$(INTDIR)\testclnt.res" \
	"$(INTDIR)\TESTMAIN.OBJ"

"$(OUTDIR)\testclnt.exe" : "$(OUTDIR)" $(DEF_FILE) $(LINK32_OBJS)
    $(LINK32) @<<
  $(LINK32_FLAGS) $(LINK32_OBJS)
<<

!ENDIF 

################################################################################
# Begin Target

# Name "sysmgr - Win32 Release"
# Name "sysmgr - Win32 Debug"

!IF  "$(CFG)" == "sysmgr - Win32 Release"

!ELSEIF  "$(CFG)" == "sysmgr - Win32 Debug"

!ENDIF 

################################################################################
# Begin Source File

SOURCE=.\SYSMGR.CPP
DEP_CPP_SYSMG=\
	"..\dma\include\dmacfunc.h"\
	"..\dma\include\dmacom.h"\
	"..\dma\include\dmaenums.h"\
	"..\dma\include\dmaids.h"\
	"..\dma\include\dmaidvar.h"\
	"..\dma\include\dmaiface.h"\
	"..\dma\include\dmarc.h"\
	"..\dma\include\dmastr.h"\
	"..\dma\include\dmatypes.h"\
	".\oiidutil.h"\
	".\SVCREG.H"\
	".\SYSMGR.H"\
	".\xdmacom.h"\
	

"$(INTDIR)\SYSMGR.OBJ" : $(SOURCE) $(DEP_CPP_SYSMG) "$(INTDIR)"


# End Source File
################################################################################
# Begin Source File

SOURCE=.\SVCREG.CPP
DEP_CPP_SVCRE=\
	"..\dma\include\dmacfunc.h"\
	"..\dma\include\dmacom.h"\
	"..\dma\include\dmaenums.h"\
	"..\dma\include\dmaids.h"\
	"..\dma\include\dmaidvar.h"\
	"..\dma\include\dmaiface.h"\
	"..\dma\include\dmarc.h"\
	"..\dma\include\dmatypes.h"\
	".\SVCREG.H"\
	".\xdmacom.h"\
	

"$(INTDIR)\SVCREG.OBJ" : $(SOURCE) $(DEP_CPP_SVCRE) "$(INTDIR)"


# End Source File
################################################################################
# Begin Source File

SOURCE=.\oiidutil.cpp
DEP_CPP_OIIDU=\
	".\oiidutil.h"\
	

"$(INTDIR)\oiidutil.obj" : $(SOURCE) $(DEP_CPP_OIIDU) "$(INTDIR)"


# End Source File
################################################################################
# Begin Source File

SOURCE=.\SVCCACHE.CPP

!IF  "$(CFG)" == "sysmgr - Win32 Release"

DEP_CPP_SVCCA=\
	"..\dma\include\dmacfunc.h"\
	"..\dma\include\dmacom.h"\
	"..\dma\include\dmatypes.h"\
	".\SVCREG.H"\
	".\xdmacom.h"\
	

"$(INTDIR)\SVCCACHE.OBJ" : $(SOURCE) $(DEP_CPP_SVCCA) "$(INTDIR)"


!ELSEIF  "$(CFG)" == "sysmgr - Win32 Debug"

DEP_CPP_SVCCA=\
	"..\dma\include\dmacfunc.h"\
	"..\dma\include\dmacom.h"\
	"..\dma\include\dmaenums.h"\
	"..\dma\include\dmaids.h"\
	"..\dma\include\dmaidvar.h"\
	"..\dma\include\dmaiface.h"\
	"..\dma\include\dmarc.h"\
	"..\dma\include\dmatypes.h"\
	".\SVCREG.H"\
	".\xdmacom.h"\
	

"$(INTDIR)\SVCCACHE.OBJ" : $(SOURCE) $(DEP_CPP_SVCCA) "$(INTDIR)"


!ENDIF 

# End Source File
################################################################################
# Begin Source File

SOURCE=.\sysmgr.def

!IF  "$(CFG)" == "sysmgr - Win32 Release"

!ELSEIF  "$(CFG)" == "sysmgr - Win32 Debug"

!ENDIF 

# End Source File
################################################################################
# Begin Source File

SOURCE=.\dma10.rc

"$(INTDIR)\dma10.res" : $(SOURCE) "$(INTDIR)"
   $(RSC) $(RSC_PROJ) $(SOURCE)


# End Source File
# End Target
################################################################################
# Begin Target

# Name "system - Win32 Release"
# Name "system - Win32 Debug"

!IF  "$(CFG)" == "system - Win32 Release"

!ELSEIF  "$(CFG)" == "system - Win32 Debug"

!ENDIF 

################################################################################
# Begin Source File

SOURCE=.\sysscope.cpp
DEP_CPP_SYSSC=\
	"..\dma\include\dmacfunc.h"\
	"..\dma\include\dmacom.h"\
	"..\dma\include\dmaenums.h"\
	"..\dma\include\dmaids.h"\
	"..\dma\include\dmaidvar.h"\
	"..\dma\include\dmaiface.h"\
	"..\dma\include\dmarc.h"\
	"..\dma\include\dmatypes.h"\
	".\SVCREG.H"\
	".\SYSOBJ.H"\
	".\xdmacom.h"\
	

"$(INTDIR)\sysscope.obj" : $(SOURCE) $(DEP_CPP_SYSSC) "$(INTDIR)"


# End Source File
################################################################################
# Begin Source File

SOURCE=.\oiidutil.cpp
DEP_CPP_OIIDU=\
	".\oiidutil.h"\
	

"$(INTDIR)\oiidutil.obj" : $(SOURCE) $(DEP_CPP_OIIDU) "$(INTDIR)"


# End Source File
################################################################################
# Begin Source File

SOURCE=.\SVCCACHE.CPP
DEP_CPP_SVCCA=\
	"..\dma\include\dmacfunc.h"\
	"..\dma\include\dmacom.h"\
	"..\dma\include\dmaenums.h"\
	"..\dma\include\dmaids.h"\
	"..\dma\include\dmaidvar.h"\
	"..\dma\include\dmaiface.h"\
	"..\dma\include\dmarc.h"\
	"..\dma\include\dmatypes.h"\
	".\SVCREG.H"\
	".\xdmacom.h"\
	

"$(INTDIR)\SVCCACHE.OBJ" : $(SOURCE) $(DEP_CPP_SVCCA) "$(INTDIR)"


# End Source File
################################################################################
# Begin Source File

SOURCE=.\SVCREG.CPP
DEP_CPP_SVCRE=\
	"..\dma\include\dmacfunc.h"\
	"..\dma\include\dmacom.h"\
	"..\dma\include\dmaenums.h"\
	"..\dma\include\dmaids.h"\
	"..\dma\include\dmaidvar.h"\
	"..\dma\include\dmaiface.h"\
	"..\dma\include\dmarc.h"\
	"..\dma\include\dmatypes.h"\
	".\SVCREG.H"\
	".\xdmacom.h"\
	

"$(INTDIR)\SVCREG.OBJ" : $(SOURCE) $(DEP_CPP_SVCRE) "$(INTDIR)"


# End Source File
################################################################################
# Begin Source File

SOURCE=.\SYSOBJ.CPP
DEP_CPP_SYSOB=\
	"..\dma\include\dmacfunc.h"\
	"..\dma\include\dmacom.h"\
	"..\dma\include\dmaenums.h"\
	"..\dma\include\dmaids.h"\
	"..\dma\include\dmaidvar.h"\
	"..\dma\include\dmaiface.h"\
	"..\dma\include\dmarc.h"\
	"..\dma\include\dmastr.h"\
	"..\dma\include\dmatypes.h"\
	".\SVCREG.H"\
	".\SYSOBJ.H"\
	".\xdmacom.h"\
	

"$(INTDIR)\SYSOBJ.OBJ" : $(SOURCE) $(DEP_CPP_SYSOB) "$(INTDIR)"


# End Source File
################################################################################
# Begin Source File

SOURCE=.\SYSPROPS.CPP
DEP_CPP_SYSPR=\
	"..\dma\include\dmacfunc.h"\
	"..\dma\include\dmacom.h"\
	"..\dma\include\dmaenums.h"\
	"..\dma\include\dmaids.h"\
	"..\dma\include\dmaidvar.h"\
	"..\dma\include\dmaiface.h"\
	"..\dma\include\dmarc.h"\
	"..\dma\include\dmastr.h"\
	"..\dma\include\dmatypes.h"\
	".\SYSOBJ.H"\
	".\xdmacom.h"\
	

"$(INTDIR)\SYSPROPS.OBJ" : $(SOURCE) $(DEP_CPP_SYSPR) "$(INTDIR)"


# End Source File
################################################################################
# Begin Source File

SOURCE=.\dmaguids.cpp
DEP_CPP_DMAGU=\
	"..\dma\include\dmacom.h"\
	"..\dma\include\dmaenums.h"\
	"..\dma\include\dmaids.h"\
	"..\dma\include\dmaidvar.h"\
	"..\dma\include\dmaiface.h"\
	"..\dma\include\dmarc.h"\
	"..\dma\include\dmatypes.h"\
	

"$(INTDIR)\dmaguids.obj" : $(SOURCE) $(DEP_CPP_DMAGU) "$(INTDIR)"


# End Source File
################################################################################
# Begin Source File

SOURCE=.\system.def

!IF  "$(CFG)" == "system - Win32 Release"

!ELSEIF  "$(CFG)" == "system - Win32 Debug"

!ENDIF 

# End Source File
################################################################################
# Begin Source File

SOURCE=.\dmasys1.rc

"$(INTDIR)\dmasys1.res" : $(SOURCE) "$(INTDIR)"
   $(RSC) $(RSC_PROJ) $(SOURCE)


# End Source File
################################################################################
# Begin Source File

SOURCE=.\dmarcmsg.cpp
DEP_CPP_DMARC=\
	"..\dma\include\dmacfunc.h"\
	"..\dma\include\dmacom.h"\
	"..\dma\include\dmaenums.h"\
	"..\dma\include\dmaids.h"\
	"..\dma\include\dmaidvar.h"\
	"..\dma\include\dmaiface.h"\
	"..\dma\include\dmarc.h"\
	"..\dma\include\dmastr.h"\
	"..\dma\include\dmatypes.h"\
	".\SYSOBJ.H"\
	".\xdmacom.h"\
	

"$(INTDIR)\dmarcmsg.obj" : $(SOURCE) $(DEP_CPP_DMARC) "$(INTDIR)"


# End Source File
# End Target
################################################################################
# Begin Target

# Name "testclnt - Win32 Release"
# Name "testclnt - Win32 Debug"

!IF  "$(CFG)" == "testclnt - Win32 Release"

!ELSEIF  "$(CFG)" == "testclnt - Win32 Debug"

!ENDIF 

################################################################################
# Begin Source File

SOURCE=.\TESTMAIN.CPP
DEP_CPP_TESTM=\
	"..\dma\include\dmacfunc.h"\
	"..\dma\include\dmacom.h"\
	"..\dma\include\dmaenums.h"\
	"..\dma\include\dmaids.h"\
	"..\dma\include\dmaidvar.h"\
	"..\dma\include\dmaiface.h"\
	"..\dma\include\dmarc.h"\
	"..\dma\include\dmastr.h"\
	"..\dma\include\dmatypes.h"\
	

"$(INTDIR)\TESTMAIN.OBJ" : $(SOURCE) $(DEP_CPP_TESTM) "$(INTDIR)"


# End Source File
################################################################################
# Begin Source File

SOURCE=.\testclnt.rc

"$(INTDIR)\testclnt.res" : $(SOURCE) "$(INTDIR)"
   $(RSC) $(RSC_PROJ) $(SOURCE)


# End Source File
# End Target
# End Project
################################################################################
