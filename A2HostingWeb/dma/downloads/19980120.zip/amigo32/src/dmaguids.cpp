/*
 *  Copyright 1995,1996,1997 by the Association for Information and Image Management Int'l
 *                                             1100 Wayne Avenue
 *                                             Silver Spring, MD 20910-5603
 *                                             Tel: 301/587-8202
 *                                             Fax: 301/587-2711
 *      All Rights Reserved.
 *      DMA (Document Management Alliance) working group.
 *
 *  Thin middleware System object interface implementations.
 *  
 *
 *  **** THIS IS A WORK IN PROGRESS!! ****
 */

#include <objbase.h>
#include <unknwn.h>
#include <objidl.h>

// Initialize DMA ID variables needed (must be prior to include of dmaidvar.h)!!!
// #define DMA_INIT_ID

// AIIM Header files
#include "dmatypes.h"
#include "dmacom.h"
#include "dmarc.h"
#include "dmaenums.h"
#include "dmaiface.h"
#include "dmaenums.h"
#include "dmaids.h"

#define DMA_INIT_ID
#include "dmaidvar.h"
