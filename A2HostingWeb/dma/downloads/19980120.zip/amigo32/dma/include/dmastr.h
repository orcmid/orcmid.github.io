#ifndef DMASTR_H
#define DMASTR_H

/*
 *  Copyright 1997, Association for Information and Image Management Int'l
 *                                         1100 Wayne Avenue
 *                                         Silver Spring, MD 20910-5603
 *                                         Tel: 301/587-8202
 *                                         Fax: 301/587-2711
 *      All Rights Reserved.
 *      AIIM Document Management Alliance (DMA) Task Force.
 *
 *  
 *
 * This header file implements DMA string macros, and hides some     
 * implementation details
 * 
 */


/*
 * Dependent includes    
 */

#if !defined(DMATYPES_H)
#   include <dmatypes.h>
#endif

/* memcpy in string.h */
#include <string.h>


/*
 * Dma String Macros    
 */

/*
 * DMA_CREATE_STRING - creates a string and initializes its characters
 * 
 * note: the macro appends the null terminator, thus _charcount
 *       is just what is says, and should not include any null. 
 *
 */

#define DMA_CREATE_STRING(_allocfn, _charcount, _srcwchars, _ppstr)  \
    {    const DmaUInteger32  _ctChars = (_charcount);  \
         DmaUInteger32 *_buf = (DmaUInteger32*) \
             (_allocfn) ( (_ctChars+1)*sizeof(DmaWChar)+sizeof(DmaUInteger32) ); \
         if (_buf != NULL) \
         {   DmaWChar        *_text = (DmaWChar*) &_buf[1]; \
             const DmaWChar  *_src  = (_srcwchars); \
             _buf[0] = _ctChars*sizeof(DmaWChar); \
             memcpy(_text, _src, _ctChars*sizeof(DmaWChar)); \
             _text[_ctChars] = 0; \
             *(_ppstr) = _text; \
         } \
        else  *(_ppstr) = NULL; \
    }

#define DMA_GET_STRING_CHAR_COUNT(_pstr) \
   (((_pstr) == NULL)? 0 : (*((DmaUInteger32*)(_pstr)-1) / sizeof(DmaWChar)))

/*
 * DMA_FREE_STRING - Free a DmaString using a specified Free function
 */ 
#define DMA_FREE_STRING(_freefn, _pstr) \
    {    const pDmaString _pstrInternal = (_pstr);\
         if (_pstrInternal != NULL) \
             (_freefn) ( ((DmaUInteger32*)(_pstrInternal)-1) );\
    }

/*
 * DMA_GET_STRING_TEXT - to access the UNICODE string
 */
#define DMA_GET_STRING_TEXT(_pstr)  \
     (const DmaWChar*)(_pstr)


#endif /* DMASTR.h */



