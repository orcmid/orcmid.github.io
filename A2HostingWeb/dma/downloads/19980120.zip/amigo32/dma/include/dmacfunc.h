#ifndef       DMACFUNC_H
#define       DMACFUNC_H
/*
 *  Copyright 1995, 1996, 1997 by the Association for Information and Image Management Int'l
 *                                             1100 Wayne Avenue
 *                                             Silver Spring, MD 20910-5603
 *                                             Tel: 301/587-8202
 *                                             Fax: 301/587-2711
 *      All Rights Reserved.
 *      DMA (Document Management Alliance) working group.
 *
 *  DMA C-Language Function definitions.
 *
 */

#if !defined(DMATYPES_H)
#   include <dmatypes.h>
#endif
#if !defined(DMACOM_H)
#   include <dmacom.h>
#endif

#ifndef  DMA_DLLEXPORT
#define  DMA_DLLEXPORT
#endif

#ifndef  DMA_CALLING_CONVENTION
#define  DMA_CALLING_CONVENTION  __cdecl
#endif

#ifndef DMA_EXTERN_FUNCTION
#define DMA_EXTERN_FUNCTION( retType ) DMA_EXTERN_C DMA_DLLEXPORT retType \
DMA_DATA_FAR \
DMA_CALLING_CONVENTION
#endif


DMA_EXTERN_FUNCTION ( DmaRC) DMA_GetServiceObject (
        pDmaVoid pvEnvInfo,
        pDmaString pProfile,
        Dmapv pIMalloc,
        Dmapv punkParent,
        DmaInteger32 lCharSetEncodingId,
        pDmaString pLocaleName,
        pDmaId pServiceObjectTypeId,
        pDmaId pServiceObjectId,
        DMA_REFIID riid,
        pDmapv ppIServiceObject);

DMA_EXTERN_FUNCTION ( DmaRC) dmaConnectSystemManager (
        pDmaVoid pEnvInfo,
        pDmaString pProfile,
        Dmapv pIMalloc,
        DmaInteger32 lCharSetEncodingId,
        pDmaString pLocaleName,
        DMA_REFIID riid,
        pDmapv ppISysMgr);



#endif /* DMACFUNC_H */

