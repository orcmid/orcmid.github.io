#ifndef DMA_H
#define DMA_H
/*
 *  Copyright 1997 by the Association for Information and Image Management Int'l
 *                                             1100 Wayne Avenue
 *                                             Silver Spring, MD 20910-5603
 *                                             Tel: 301/587-8202
 *                                             Fax: 301/587-2711
 *      All Rights Reserved.
 *      DMA (Document Management Alliance) working group.
 *
 *  DMA universal include file.
 *
 */


#include <dmatypes.h>
#include <dmastr.h>
#include <dmaenums.h>
#include <dmacaps.h>
#include <dmarc.h>
#include <dmacom.h>
#include <dmaiface.h>
#include <dmacfunc.h>
#include <dmaids.h>


#endif  /* DMA_H */