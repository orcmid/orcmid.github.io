#ifndef  DMAENUMS_H
#define  DMAENUMS_H
/*
 *  Copyright 1995,1996,1997,1998
 *  by the Association for Information and Image Management Int'l
 *                                             1100 Wayne Avenue
 *                                             Silver Spring, MD 20910-5603
 *                                             Tel: 301/587-8202
 *                                             Fax: 301/587-2711
 *      All Rights Reserved.
 *      DMA (Document Management Alliance) working group.
 *
 *
 *  DMA Enumeration Defines
 *
 */


/* Commonly Occuring Character Set ID's and corresponding lengths.          */
/*                                                                          */
/* These definitions where created using the document available at          */
/* http://www.isi.edu/in-notes/iana/assignments/character-sets. Other       */
/* character sets can be used with DMA, but should be defined using this    */
/* specification.                                                           */
/* ANSI X3.4-1968 (US ASCII) */
#define DMA_CS_ASCII                          3
/* ISO 8859-1:1987 (Latin1) */
#define DMA_CS_LATIN1                         4
/* ISO 8859-2:1987 (Latin2) */
#define DMA_CS_LATIN2                         5
/* ISO 8859-3:1987 (Latin3) */
#define DMA_CS_LATIN3                         6
/* ISO 8859-4:1987 (Latin4) */
#define DMA_CS_LATIN4                         7
/* ISO 8859-5:1987 (Latin/Cyrillic) */
#define DMA_CS_LATINCYRILLIC                  8
/* ISO 8859-6:1987 (Latin/Arabic) */
#define DMA_CS_LATINARABIC                    9
/* ISO 8859-7:1987 (Latin/Greek) */
#define DMA_CS_LATINGREEK                     10
/* ISO 8859-8:1987 (Latin/Hebrew) */
#define DMA_CS_LATINHEBREW                    11
/* ISO 8859-9:1987 (Latin5) */
#define DMA_CS_LATIN5                         12
/* Shift JIS (MS Kanji) */
#define DMA_CS_SHIFTJIS                       17
/* EUC Packed Format for Japaneese (EUC-J) */
#define DMA_CS_EUCPKDFMTJAPANESE              18
/* EUC-KR (KS C 5861-1992, RFC 1557) */
#define DMA_CS_EUCKR                          38
/* KS C 5601-1987 (KOREAN,RFC 1345) */
#define DMA_CS_KSC56011987                    36
/* UNICODE-1-1 */
#define DMA_CS_UNICODE11                      1010
/* UNICODE-1-1-UTF-7 */
#define DMA_CS_UNICODE11UTF7                  103
/* UNICODE-1-1-UTF-8, ISO-10646-UCS-2 (Unicode) */
#define DMA_CS_UNICODE                        1000
/* ISO-10646-USC-4 */
#define DMA_CS_USC4                           1001

/* Values defined for IdmaContentTransfer::CopyToResource().                */
#define DMA_CREATE_REPLACE_EXISTING           0x01
#define DMA_CREATE_PRESERVE_DATETIME          0x02

/* Values defined for the "relative to' argument of IStream::Seek.          */
#define DMA_REL_CURRENT                       0
#define DMA_REL_BEGINNING                     1
#define DMA_REL_END                           2

/* Manifest Boolean constants used in query expressions.                    */
/*                                                                          */
/*                                                                          */
/*                                                                          */
/* The DMA_UNKNOWN define designates the manifest constant for the third    */
/* boolean, UNKNOWN, in query expressions.  DMA_TRUE and DMA_FALSE          */
/* designate the usual TRUE and FALSE manifest Boolean constants,           */
/* respectively.                                                            */
#define DMA_UNKNOWN                           2

/* Enumeration of the base DMA data types.                                  */
#define DMA_DATATYPE_BINARY                   1
#define DMA_DATATYPE_BOOLEAN                  2
#define DMA_DATATYPE_DATETIME                 3
#define DMA_DATATYPE_FLOAT64                  4
#define DMA_DATATYPE_ID                       5
#define DMA_DATATYPE_INTEGER32                6
#define DMA_DATATYPE_OBJECT                   7
#define DMA_DATATYPE_STRING                   8

/* These DMA data types occur in connection with queries, but are not base  */
/* data types.                                                              */
#define DMA_DATATYPE_ANY_BASE_DATATYPE        9
#define DMA_DATATYPE_CLASS                    10
#define DMA_DATATYPE_RESULT_ROW               11

/* Protection Level values for ExecuteChange(s).                            */
#define DMA_MODIFY_UNPROTECTED                0
#define DMA_MODIFY_PROTECTED                  1

/* Lock Types.                                                              */
#define DMA_LOCK_READ                         1
#define DMA_LOCK_WRITE                        2
#define DMA_LOCK_EXIST                        3

/* Relationship Positional Types.                                           */
#define DMA_POS_FIRST                         1
#define DMA_POS_BEFORE                        2
#define DMA_POS_AFTER                         3
#define DMA_POS_ANYWHERE                      4
#define DMA_POS_LAST                          5

/* Property Cardinality values.                                             */
#define DMA_CARDINALITY_SINGLE                0
#define DMA_CARDINALITY_ENUM                  1
#define DMA_CARDINALITY_LIST                  2

/* Scope merge rules.                                                       */
#define DMA_COMBINATION_INTERSECTION          0
#define DMA_COMBINATION_UNION                 1

/* Specifies the extent to which an operator can participate in a join      */
/* expression (in the From clause of a query).                              */
#define DMA_JOIN_PARTICIPATION_NONE           0
#define DMA_JOIN_PARTICIPATION_OPERAND        1
#define DMA_JOIN_PARTICIPATION_OPERATOR       2

/* The value used to represent "no maximum".                                */
#define DMA_NO_MAXIMUM                        (-1)

#endif /* DMAENUMS_H */
