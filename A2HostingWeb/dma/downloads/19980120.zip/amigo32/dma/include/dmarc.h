#ifndef       DMARC_H
#define       DMARC_H
/*
 *  Copyright 1995, 1996, 1997 by the Association for Information and Image Management Int'l
 *                                             1100 Wayne Avenue
 *                                             Silver Spring, MD 20910-5603
 *                                             Tel: 301/587-8202
 *                                             Fax: 301/587-2711
 *      All Rights Reserved.
 *      DMA (Document Management Alliance) working group.
 *
 *  Contains definitions for each of the DMA Result Codes
 *
 */

#if !defined(DMATYPES_H)
#   include <dmatypes.h>
#endif



#define DMARC_3VE_NOT_SUPPORTED              DMA_MAKE_ERROR_RC(121)
   /* The current scope does not support three valued elimination. */
#define DMARC_ABORT                          DMA_MAKE_ERROR_RC(1)
   /* The progress callback indicated that the method should be aborted. */
#define DMARC_ACCESS_DENIED                  ((DmaRC) (0x80070005L))
   /* (E_ACCESSDENIED) The requester has insufficient access rights to perform the requested operation. */
#define DMARC_ALIAS_CONFLICT                 DMA_MAKE_ERROR_RC(108)
   /* A class, operator or property in one component scope unifies with more than one such entity in another component scope. */
#define DMARC_ALREADY_AUTHENTICATED          DMA_MAKE_ERROR_RC(88)
   /* The user is already authenticated. */
#define DMARC_AT_ENUM_END                    DMA_MAKE_ERROR_RC(119)
   /* The enumerator object is positioned at the end of the component objects. */
#define DMARC_BAD_CLASSID                    DMA_MAKE_ERROR_RC(4)
   /* The supplied identifier does not reference an available class of object. */
#define DMARC_BAD_COLLATION_SEQUENCE         DMA_MAKE_ERROR_RC(127)
   /* The specified collation sequence is not known or supported by the scope. */
#define DMARC_BAD_DOC_SPACE                  DMA_MAKE_ERROR_RC(122)
   /* There is no available document space with the specified DmaId */
#define DMARC_BAD_FROM_EXPRESSION            DMA_MAKE_ERROR_RC(48)
   /* The query contains an invalid From Expression. */
#define DMARC_BAD_INDEX                      DMA_MAKE_ERROR_RC(6)
   /* The index specified does not reference a valid property or list element. */
#define DMARC_BAD_INTERFACE                  ((DmaRC) (0x80004002L))
   /* (E_NOINTERFACE) The requested interface is not supported by this object. */
#define DMARC_BAD_LOCK_TYPE                  DMA_MAKE_ERROR_RC(8)
   /* The lock type is invalid. */
#define DMARC_BAD_OBJECT                     DMA_MAKE_ERROR_RC(9)
   /* An inappropriate object was passed as parameter to this function. For example, the object does not support a required interface or is of an inappropriate class. */
#define DMARC_BAD_OIID                       DMA_MAKE_ERROR_RC(47)
   /* The supplied buffer does not contain a valid OIID. */
#define DMARC_BAD_OPERAND                    DMA_MAKE_ERROR_RC(71)
   /* An operand is incorrect in datatype, form, or class. */
#define DMARC_BAD_OPERATOR                   DMA_MAKE_ERROR_RC(72)
   /* An operator ID is not defined in the metadata of the current scope. */
#define DMARC_BAD_ORDERBY_ELEMENT            DMA_MAKE_ERROR_RC(75)
   /* Illegal 'order by' list element. */
#define DMARC_BAD_PARAMETER                  ((DmaRC) (0x80070057L))
   /* (E_INVALIDARG) Invalid input parameter. */
#define DMARC_BAD_PROPID                     DMA_MAKE_ERROR_RC(11)
   /* A property identifier is not valid. */
#define DMARC_BAD_PROTECTION_LEVEL           DMA_MAKE_ERROR_RC(84)
   /* Illegal value for the protection level parameter. */
#define DMARC_BAD_RC                         DMA_MAKE_ERROR_RC(12)
   /* Invalid Result Code. */
#define DMARC_BAD_REFERENCE                  DMA_MAKE_ERROR_RC(106)
   /* The object cannot be saved because it references another object which is not persistent. */
#define DMARC_BAD_RESERVATION                DMA_MAKE_ERROR_RC(87)
   /* One or more of the Reservations is not the current reservation in the VersionSeries to which it refers. */
#define DMARC_BAD_SC_OCCUR                   DMA_MAKE_ERROR_RC(83)
   /* The value of a query node's searchable class occurrence property is not present in the query. */
#define DMARC_BAD_SELECT_ELEMENT             DMA_MAKE_ERROR_RC(74)
   /* Illegal select list element. */
#define DMARC_BAD_SUBQUERY_DATATYPE          DMA_MAKE_ERROR_RC(81)
   /* The datatype of the query root node of an "IN" subquery does not match that of the property in the select list. */
#define DMARC_BAD_SUBQUERY_SELECT            DMA_MAKE_ERROR_RC(76)
   /* The select list of a subquery contains an inappropriate number of elements */
#define DMARC_BAD_URL                        DMA_MAKE_ERROR_RC(39)
   /* The resource URL is not syntactically valid. */
#define DMARC_BAD_VALUE                      DMA_MAKE_ERROR_RC(41)
   /* The value given for a property or list element lies outside the permitted range or value set, or exceeds the maximum length allowed. */
#define DMARC_CLASS_NOT_SEARCHABLE           DMA_MAKE_ERROR_RC(115)
   /* A class referred to in the From Expression is not searchable. */
#define DMARC_CLASSES_NOT_JOINABLE           DMA_MAKE_ERROR_RC(120)
   /* A particular join operator in the query is supported, but the operator does not support the join between the particular operands specified in the query. */
#define DMARC_CONFLICTING_OPERATION          DMA_MAKE_ERROR_RC(124)
   /* The call on this primary intentional method logically conflicts with a prior call on a different primary intentional method. */
#define DMARC_CONSTRAINT_VIOLATED            DMA_MAKE_ERROR_RC(105)
   /* The operation violates a constraint of the implementation. */
#define DMARC_DATATYPE_MISMATCH              DMA_MAKE_ERROR_RC(103)
   /* The method invoked is inappropriate for the datatype of the property. */
#define DMARC_DEVICE_ERROR                   DMA_MAKE_ERROR_RC(49)
   /* An error has occurred reading or writing a hardware device. */
#define DMARC_DISCONNECTED                   DMA_MAKE_ERROR_RC(24)
   /* The logical connection to the document space has been disconnected. */
#define DMARC_DISTINCT_NOT_SUPPORTED         DMA_MAKE_ERROR_RC(126)
   /* The scope does not support the request for distinct result rows. */
#define DMARC_EXTRA_OPERANDS                 DMA_MAKE_ERROR_RC(70)
   /* A query node has extra operands. */
#define DMARC_FAILED                         ((DmaRC) (0x80004005L))
   /* (E_FAIL) The operation failed. */
#define DMARC_FOREIGN_OBJECT                 DMA_MAKE_ERROR_RC(13)
   /* An object is not from the current document space. */
#define DMARC_ILLEGAL_OPERATION              DMA_MAKE_ERROR_RC(92)
   /* The operation is disallowed by the DMA Specification. */
#define DMARC_LIST_BOUNDS_ERROR              DMA_MAKE_ERROR_RC(104)
   /* The number of elements in a list is outside the permitted range. */
#define DMARC_LOST_CONNECTION                DMA_MAKE_ERROR_RC(21)
   /* The logical connection of the current object to the persistent store has been lost permanently. The operation could not be completed. */
#define DMARC_MAX_ROWS                       DMA_MAKE_ERROR_RC(67)
   /* A result set was truncated because it exceeded the maximum result items parameter. */
#define DMARC_MISSING_OPERANDS               DMA_MAKE_ERROR_RC(69)
   /* A query node is missing one or more operands. */
#define DMARC_MISSING_REFERENCE              DMA_MAKE_ERROR_RC(61)
   /* The object cannot be saved because required reference to it is absent. For example, it may be required to be in a container and no appropriate relationship object exists. */
#define DMARC_MULTIPLE_CHECKIN_NOT_SUPPORTED DMA_MAKE_ERROR_RC(123)
   /* The implementation does not support multiple different checkins on the same object (i.e., threaded versioning). */
#define DMARC_NEED_MORE_DATA                 DMA_MAKE_SUCCESS_RC(22)
   /* (Warning) Indicates that more data is required to complete the browse connection operation. */
#define DMARC_NETWORK_ERROR                  DMA_MAKE_ERROR_RC(116)
   /* A network error has occurred.  It is undetermined as to whether retrying the method might succeed. The operation could not be completed. */
#define DMARC_NETWORK_UNAVAILABLE            DMA_MAKE_ERROR_RC(54)
   /* The network needed to perform this operation is not available. */
#define DMARC_NO_COLLATIONS                  DMA_MAKE_ERROR_RC(112)
   /* Merged scope creation failed because there would be no supported collation sequences. */
#define DMARC_NO_CURRENT_VERSION             DMA_MAKE_ERROR_RC(56)
   /* The version series has no current version. */
#define DMARC_NO_MEMORY                      ((DmaRC) (0x8007000EL))
   /* (E_OUTOFMEMORY) Insufficient memory to complete the operation. */
#define DMARC_NO_RESERVATION                 DMA_MAKE_ERROR_RC(86)
   /* The Version Series is not holding a reservation at this time. */
#define DMARC_NOT_AUTHENTICATED              DMA_MAKE_ERROR_RC(89)
   /* The user is not authenticated. */
#define DMARC_NOT_CREATABLE                  DMA_MAKE_ERROR_RC(63)
   /* Creation of objects of the specified class is not supported. */
#define DMARC_NOT_FOUND                      DMA_MAKE_ERROR_RC(26)
   /* Requested item not found. */
#define DMARC_NOT_LOCKED                     DMA_MAKE_ERROR_RC(27)
   /* The object is not locked. */
#define DMARC_NOT_PUBLISHED                  DMA_MAKE_ERROR_RC(91)
   /* The service registry entry is not currently published. */
#define DMARC_NOT_SUPPORTED                  DMA_MAKE_ERROR_RC(28)
   /* This method is not supported in the context of this session or object. */
#define DMARC_NOT_UNIQUE                     DMA_MAKE_ERROR_RC(90)
   /* A uniqueness requirement has been violated. */
#define DMARC_OBJECT_DELETED                 DMA_MAKE_ERROR_RC(29)
   /* The object has been deleted since it was retrieved. */
#define DMARC_OBJECT_LOCKED                  DMA_MAKE_ERROR_RC(30)
   /* The lock(s) on the persistent object prohibit the attempted operation. */
#define DMARC_OBJECT_MODIFIED                DMA_MAKE_ERROR_RC(31)
   /* The object has been modified since it was retrieved. */
#define DMARC_OBJECT_REFERENCED              DMA_MAKE_ERROR_RC(44)
   /* The object cannot be deleted because it is referenced by other objects. */
#define DMARC_OK                             (0L)
   /* (S_OK) Success. */
#define DMARC_OPERAND_MERGE_CONFLICT         DMA_MAKE_ERROR_RC(110)
   /* The merge would create an invalid operand description. */
#define DMARC_OPERATOR_MERGE_CONFLICT        DMA_MAKE_ERROR_RC(109)
   /* An operator could not be merged because it has conflicting signatures in component scopes. */
#define DMARC_POSITION_NOT_ALLOWED           DMA_MAKE_ERROR_RC(125)
   /* The stream cannot be positioned as requested. */
#define DMARC_PROPERTY_MERGE_CONFLICT        DMA_MAKE_ERROR_RC(111)
   /* A property could not be merged because there is a conflict of conflicting datatype or cardinality in component scopes. */
#define DMARC_PROPERTY_NOT_ORDERABLE         DMA_MAKE_ERROR_RC(77)
   /* A property referred to in the query order by list is not orderable. */
#define DMARC_PROPERTY_NOT_SEARCHABLE        DMA_MAKE_ERROR_RC(114)
   /* A property referred to in the Query Expression is not searchable. */
#define DMARC_PROPERTY_NOT_SELECTABLE        DMA_MAKE_ERROR_RC(113)
   /* A property referred to in the Selections list is not selectable. */
#define DMARC_PROTECTION_LEVEL_NOT_SUPPORTED DMA_MAKE_ERROR_RC(14)
   /* The desired protection level is not supported by the doc space. */
#define DMARC_QUERY_AT_END                   DMA_MAKE_ERROR_RC(118)
   /* The query ran to successful completion without encountering any constraints on time limits, number of rows generated, or any other constraints, and there are no more result rows that satisfy the query. A result row is not returned.  No more result rows will be returned unless ReExecuteQuery is executed. */
#define DMARC_QUERY_TREE_LOOP                DMA_MAKE_ERROR_RC(78)
   /* There is a circular reference loop or a shared node in the query. */
#define DMARC_READ_ONLY                      DMA_MAKE_ERROR_RC(45)
   /* Method failed because an object or property is read-only. */
#define DMARC_REFERENCES_OTHERS              DMA_MAKE_ERROR_RC(43)
   /* The object cannot be deleted because it holds references to other objects. */
#define DMARC_REQUIRED_VALUE_ABSENT          DMA_MAKE_ERROR_RC(107)
   /* A required property value has not been set. */
#define DMARC_RESERVATION_EXISTS             DMA_MAKE_ERROR_RC(60)
   /* The version series is already holding a reservation. */
#define DMARC_RESERVATION_NOT_ALLOWED        DMA_MAKE_ERROR_RC(59)
   /* The condition of the version series does not permit a reservation, though no reservation is currently present. */
#define DMARC_RESERVATION_PENDING            DMA_MAKE_ERROR_RC(58)
   /* The connection is already holding a request for a reservation.  There cannot be more than one at a time. */
#define DMARC_RESOURCE_NOT_FOUND             DMA_MAKE_ERROR_RC(35)
   /* The indicated resource was not found. */
#define DMARC_RESULTS_TRUNCATED              DMA_MAKE_ERROR_RC(117)
   /* The result set was truncated explicitly by a call on IdmaResultSet:: TerminateResults. No further rows will be returned unless ReExecuteQuery is executed. This is a failure code - no row is returned. */
#define DMARC_SHORT_READ                     DMA_MAKE_SUCCESS_RC(50)
   /* (Warning) End of stream was encountered before the requested number of bytes was read. */
#define DMARC_STALE_METADATA                 DMA_MAKE_ERROR_RC(85)
   /* The metadata in the persistent store has been changed so that it does not match the client's current copy of the metadata. */
#define DMARC_TIMEOUT                        DMA_MAKE_ERROR_RC(80)
   /* A time limit has been exceeded. */
#define DMARC_TRUNCATED                      DMA_MAKE_ERROR_RC(65)
   /* Result sets were truncated in different component scopes for different reasons. */
#define DMARC_UNEXPECTED                     ((DmaRC) (0x8000FFFFL))
   /* (E_UNEXPECTED) An unexpected error occurred. */
#define DMARC_UNSUPPORTED_ORDERING           DMA_MAKE_ERROR_RC(128)
   /* An unacceptable value was provided for an ordering parameter. */
#define DMARC_URL_PROTOCOL_NOT_SUPPORTED     DMA_MAKE_ERROR_RC(37)
   /* The URL protocol specified in the reference is not supported. */
#define DMARC_VALUE_NOT_SET                  DMA_MAKE_ERROR_RC(34)
   /* The requested property currently has no value. */


#endif /* DMARC_H */
